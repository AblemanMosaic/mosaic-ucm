"""Versioned profile-authoring and installed extension discovery contract.

This module describes only closed implementations already installed in this
distribution. It never imports code from caller-supplied names.
"""
from __future__ import annotations

import hashlib
from typing import Any

from .bindings import exact, hex_digest, profile_reference
from .codec import canonical, clone
from .errors import Refusal, require
from .j1.registry import contracts as j1_contracts


AUTHORING_SCHEMA = "cmba.profile-authoring-contract.v2"
EXTENSION_SCHEMA = "cmba.extension-contract.v2"
REFERENCE_SCHEMA = "cmba.extension-reference.v2"

_KINDS = {
    "cmba.admissibility": "COMPOSITION_RECIPE",
    "cmba.native-dkn": "PINNED_NATIVE_ADAPTER",
    "cmba.native-ccp-current-use": "PINNED_NATIVE_ADAPTER",
}


def authoring_contract() -> dict[str, Any]:
    """Return the finite requirements for an executable extension contract."""
    return {
        "schema": AUTHORING_SCHEMA,
        "contract_version": "v2",
        "kinds": ["PURE_EVALUATOR", "PINNED_NATIVE_ADAPTER", "COMPOSITION_RECIPE"],
        "required_sections": [
            "identity", "input_contract", "evidence_contract", "predicates", "limits",
            "result_meanings", "claim_ceiling", "nonclaims", "compatibility", "vector_classes",
        ],
        "required_vector_classes": ["POSITIVE", "NEGATIVE", "MISSING_INPUT", "UNSUPPORTED_SEMANTICS"],
        "selection": "CLOSED_INSTALLED_REGISTRY",
        "input_code_loading": False,
        "authority_effect": "NONE",
    }


def _kind(profile_id: str) -> str:
    return _KINDS.get(profile_id, "PURE_EVALUATOR")


def _body(contract: dict[str, Any]) -> dict[str, Any]:
    profile_id = contract["profile_id"]
    kind = _kind(profile_id)
    compatibility: dict[str, Any] = {
        "protocol": "AP-J1_SE-J1_SD-J1",
        "interface": "app",
        "operation": "evaluate",
    }
    if kind == "COMPOSITION_RECIPE":
        compatibility["composition"] = {
            "max_children": 8,
            "max_composition_depth": 1,
            "same_subject": True,
            "same_evaluation_time": True,
            "child_contexts": "EXACT_NO_UNUSED",
            "child_results": "RECOMPUTED",
            "allowed_child_profile_ids": [
                "cmba.consent", "cmba.coordination", "cmba.execution-record",
                "cmba.kasd", "cmba.observation",
            ],
        }
    native_dependency = None
    if kind == "PINNED_NATIVE_ADAPTER" and profile_id == "cmba.native-dkn":
        native_dependency = {
            "distribution": "dkn-core",
            "version": "0.2.0rc5",
            "identity": "EXACT_INSTALLED_RUNTIME_HASH_CHECKED_BY_NATIVE_ADAPTER",
            "auto_install": False,
        }
    elif kind == "PINNED_NATIVE_ADAPTER":
        native_dependency = {
            "distribution": "Universal Constitutional Machine",
            "version": "v0.1-r033",
            "identity": "EXACT_RELEASE_AND_SOURCE_MANIFEST_ROOTS_PLUS_MODULE_HASH",
            "auto_install": False,
        }
    return {
        "schema": EXTENSION_SCHEMA,
        "identity": {
            "extension_id": profile_id,
            "extension_version": contract["profile_version"],
            "base_profile": profile_reference(contract),
            "kind": kind,
        },
        "input_contract": {
            "required_dimensions": clone(contract["required_dimensions"]),
            "materialization": contract["materialization"],
            "unknown_critical": contract["unknown_critical"],
            "unknown_noncritical": contract["unknown_noncritical"],
        },
        "evidence_contract": {
            "policy_parameters": "PROFILE_DEFINED_EXACT_FIELDS",
            "authority_snapshot": "PROFILE_DEFINED",
            "evidence_snapshot": "PROFILE_DEFINED_NO_UNUSED_INPUTS",
            "reader_expected_root": "INDEPENDENT_INPUT_REQUIRED",
        },
        "predicates": clone(contract["predicates"]),
        "limits": {
            "canonical_bytes": 1048576,
            "canonical_depth": 32,
            "canonical_nodes": 16384,
            "profile_specific_limits": "ENFORCED_BY_INSTALLED_HANDLER",
        },
        "result_meanings": ["MATCH_FOR_SUPPLIED_EVIDENCE", "CONTRADICTED", "INSUFFICIENT", "UNSUPPORTED"],
        "claim_ceiling": contract["claim_ceiling"],
        "nonclaims": [
            "NO_GENERAL_TRUTH",
            "NO_EFFECT_PERMISSION",
            "NO_AUTHORITY_GRANT",
            "NO_AMBIENT_TRUST_ADOPTION",
        ],
        "compatibility": compatibility,
        "vector_classes": ["POSITIVE", "NEGATIVE", "MISSING_INPUT", "UNSUPPORTED_SEMANTICS"],
        "native_dependency": native_dependency,
        "authority_effect": "NONE",
    }


def _wrap(body: dict[str, Any]) -> dict[str, Any]:
    digest = hashlib.sha256(b"CMBA:extension-contract:v2\0" + canonical(body)).hexdigest()
    return {"schema": EXTENSION_SCHEMA + ".envelope", "body": body, "contract_hash": digest}


def _program_body(
    extension_id: str,
    kind: str,
    operation: str,
    predicates: list[str],
    claim_ceiling: str,
) -> dict[str, Any]:
    profile_spec = {
        "schema": "cmba.program-profile-spec.v2",
        "profile_id": extension_id,
        "profile_version": "v2",
        "operation": operation,
        "predicates": predicates,
    }
    profile_hash = hashlib.sha256(b"CMBA:program-profile-spec:v2\0" + canonical(profile_spec)).hexdigest()
    return {
        "schema": EXTENSION_SCHEMA,
        "identity": {
            "extension_id": extension_id,
            "extension_version": "v2",
            "base_profile": {
                "profile_id": extension_id,
                "profile_version": "v2",
                "contract_hash": profile_hash,
            },
            "kind": kind,
        },
        "input_contract": {
            "required_dimensions": ["subject", "scope", "statements", "reader_context"],
            "materialization": "EXACT_TYPED_V2_RECORDS",
            "unknown_critical": "UNSUPPORTED",
            "unknown_noncritical": "PRESERVE_WITHOUT_INTERPRETATION",
        },
        "evidence_contract": {
            "policy_parameters": "EXACT_OPERATION_ARGUMENTS",
            "authority_snapshot": "READER_SELECTED",
            "evidence_snapshot": "ROOTED_TYPED_REFERENCES_NO_PROSE_ENTAILMENT",
            "reader_expected_root": "INDEPENDENT_INPUT_REQUIRED",
        },
        "predicates": predicates,
        "limits": {
            "canonical_bytes": 1048576,
            "canonical_depth": 32,
            "canonical_nodes": 16384,
            "profile_specific_limits": "MAX_64_STATEMENTS_128_SUPPORT_EDGES",
        },
        "result_meanings": ["MATCH_FOR_SUPPLIED_EVIDENCE", "CONTRADICTED", "INSUFFICIENT", "UNSUPPORTED"],
        "claim_ceiling": claim_ceiling,
        "nonclaims": [
            "NO_NATURAL_LANGUAGE_ENTAILMENT", "NO_GENERAL_TRUTH", "NO_EFFECT_PERMISSION",
            "NO_AUTHORITY_GRANT", "NO_SIGNATURE_FORMAT_REPLACEMENT",
        ],
        "compatibility": {
            "protocol": "CMBA-V2-EXTENSIONS",
            "interface": "python",
            "operation": operation,
            "composition": "EXPLICIT_TYPED_INPUTS_ONLY" if kind == "COMPOSITION_RECIPE" else None,
        },
        "vector_classes": ["POSITIVE", "NEGATIVE", "MISSING_INPUT", "UNSUPPORTED_SEMANTICS"],
        "native_dependency": None,
        "authority_effect": "NONE",
    }


def _program_contracts() -> list[dict[str, Any]]:
    definitions = [
        (
            "cmba.recognition", "PURE_EVALUATOR", "recognize_statement",
            ["statement.exact-root", "issuer.reader-recognition", "validity.supplied-time"],
            "Exact statement selection and issuer recognition under supplied reader context; no signature or truth conclusion.",
        ),
        (
            "cmba.assurance-case", "PURE_EVALUATOR", "evaluate_assurance",
            ["support.acyclic", "evidence.required", "defeaters.resolved", "coverage.exact"],
            "Finite structural support, recognition, evidence, defeater, scope and coverage checks; no prose entailment.",
        ),
        (
            "federated-evidence", "COMPOSITION_RECIPE", "federate",
            ["statements.preserved", "conflicts.visible", "independence.reader-selected"],
            "Aggregation preserves statements and conflicts and counts reader-selected independence groups only.",
        ),
        (
            "selective-evidence", "COMPOSITION_RECIPE", "selective_view",
            ["coverage.narrowed", "omissions.visible", "required-evidence.rechecked"],
            "Selected views narrow exact coverage and must be re-evaluated; omitted evidence cannot support wider claims.",
        ),
        (
            "cmba.release", "PURE_EVALUATOR", "evaluate_release",
            ["artifacts.exact", "evidence.byte-bound", "gates.separate", "gaps.explicit"],
            "Exact supplied artifact and evidence association with separately evaluated release gates; no production trust or platform claim beyond the supplied evidence.",
        ),
        (
            "cmba.realization", "PURE_EVALUATOR", "evaluate_realization",
            ["contract.exact", "implementation.exact", "platform.exact", "corpus.finite"],
            "Agreement for the exact identified realization and finite corpus only; no universal program or semantic equivalence.",
        ),
        (
            "cmba.lifecycle", "PURE_EVALUATOR", "evaluate_lifecycle",
            ["history.preserved", "time.supplied", "withdrawal.supplied", "currentness.bounded"],
            "Lifecycle applicability under exact supplied history, revocation snapshot, scope and time only; no global currentness.",
        ),
        (
            "cmba.delegation", "PURE_EVALUATOR", "evaluate_delegation",
            ["chain.finite", "scope.attenuated", "validity.attenuated", "redelegation.bounded"],
            "Finite exact delegation attenuation only; no identity proof, capability grant or operational authority.",
        ),
        (
            "cmba.reassessment", "PURE_EVALUATOR", "evaluate_reassessment",
            ["dependencies.exact", "impact.paths", "history.preserved", "recomputation.closed"],
            "Dependency impact and recomputation closure for exact supplied graphs and snapshots; no watcher or scheduler.",
        ),
        (
            "cmba.access-policy", "PURE_EVALUATOR", "evaluate_access_policy",
            ["universe.finite", "decisions.reproduced", "denials.precede", "unknown.preserved"],
            "Decisions for an exact finite policy and request universe only; no unmodeled platform semantics.",
        ),
        (
            "cmba.policy-transition", "PURE_EVALUATOR", "compare_policy_transition",
            ["mappings.exact", "widening.counterexampled", "continuity.checked", "deltas.visible"],
            "Finite source/target policy comparison under exact mappings and approved deltas; no migration permission.",
        ),
        (
            "cmba.data-migration", "COMPOSITION_RECIPE", "evaluate_data_migration",
            ["inventory.exact", "concurrency.reconciled", "transfer.preserved", "cutover.separate"],
            "Exact supplied migration inventory, transfer, staging, cutover, policy and obligation evidence only; no ambient compliance.",
        ),
        (
            "cmba.schema-transition", "PURE_EVALUATOR", "schema_transition",
            ["schemas.exact", "fields.mapped", "labels.retained", "relaxations.approved"],
            "Declared schema, field, label, condition and relaxation mapping only; no semantic correctness of conversion.",
        ),
        (
            "cmba.data-derivation", "PURE_EVALUATOR", "evaluate_data_derivation",
            ["inputs.exact", "output.exact", "operation.declared", "redactions.approved"],
            "Exact derivation lineage and declared transformation checks only; no semantic correctness of derived output.",
        ),
        (
            "cmba.obligations", "PURE_EVALUATOR", "obligation_set",
            ["purpose.explicit", "transfer.explicit", "retention.explicit", "residency.explicit"],
            "Explicit obligation representation and migration comparison only; no enforcement or universal erasure claim.",
        ),
        (
            "cmba.ccp", "COMPOSITION_RECIPE", "evaluate_stack",
            ["subjects.distinct", "configurations.exact", "coverage.explicit", "disagreement.preserved"],
            "Exact reader-recognized curation statements and finite stack-obligation coverage only; no prose entailment, whole-stack promotion or execution authority.",
        ),
        (
            "cmba.native-ccp-current-use", "PINNED_NATIVE_ADAPTER", "evaluate_native_current_use",
            ["source.pinned", "anchors.independent", "decision.recomputed", "effect.none"],
            "The exact UCM r033 CCP current-use outcome for complete supplied records and independently supplied anchors; no full CCP product or effect authorization.",
        ),
        (
            "cmba.pippi", "COMPOSITION_RECIPE", "assess_turn_chain",
            ["turn.crosslinks", "proposal.denominator", "journal.expected-head", "effects.reconciled"],
            "Observable Pippi turns, supplied policy recomputation status, journal continuity, and faithful GenDev projection only; no hidden reasoning, enforced-host, authorship, policy-correctness or execution claim.",
        ),
        (
            "cmba.ucm.constitution", "PURE_EVALUATOR", "constitution",
            ["units.exact", "relations.typed", "compositions.closed", "schemas.non-substitutable"],
            "Exact AMCAS constitutive and separately identified legacy operational declarations only; no inferred crosswalk, implementation behavior or authority.",
        ),
        (
            "cmba.ucm.amcas-contract", "PURE_EVALUATOR", "assess_obligations",
            ["source.pinned", "obligations.total", "subjects.exact", "hard-requirements.precede-preference"],
            "Exact obligation correspondence for one pinned AMCAS source/compiled pair only; no semantic entailment or operational effect.",
        ),
        (
            "cmba.ucm.realization", "PURE_EVALUATOR", "assess_evidence_class",
            ["configuration.finite", "constraints.hard", "selection.deterministic", "evidence.classes-preserved"],
            "Finite candidate realization and evidence-class assessment only; no target admission, runtime observation or deployment authority.",
        ),
        (
            "cmba.ucm.goorrt", "PURE_EVALUATOR", "goorrt_declaration",
            ["representations.distinct", "contracts.exact", "correspondence.explicit", "mcir.variants-unresolved"],
            "Exact GOML, GSOL, CEIR and source-specific MCIR declarations and mappings only; matching names do not establish semantic equivalence.",
        ),
        (
            "cmba.ucm.correspondence", "PURE_EVALUATOR", "assess_correspondence",
            ["cases.exact", "refusals.preserved", "producer-evidence.separate", "permit.none"],
            "Exact supplied-case record correspondence, with execution claims requiring separate verified producer evidence; no permit is created.",
        ),
        (
            "cmba.ucm.operation-history", "PURE_EVALUATOR", "assess_operation_history",
            ["chain.exact", "anchors.independent", "partial.visible", "terminal.required"],
            "Exact supplied operation-history chain and anchors only; partial histories remain partial, unavailable validators remain unsupported, and no permit is created.",
        ),
    ]
    return [_wrap(_program_body(*definition)) for definition in definitions]


def contracts() -> list[dict[str, Any]]:
    """Normalize the installed J1 registry without changing its contracts."""
    return [_wrap(_body(contract)) for contract in j1_contracts()] + _program_contracts()


def reference(contract: dict[str, Any]) -> dict[str, Any]:
    validate_contract(contract)
    identity = contract["body"]["identity"]
    return {
        "schema": REFERENCE_SCHEMA,
        "extension_id": identity["extension_id"],
        "extension_version": identity["extension_version"],
        "contract_hash": contract["contract_hash"],
    }


def validate_contract(contract: dict[str, Any]) -> None:
    canonical(contract)
    exact(contract, {"schema", "body", "contract_hash"})
    require(contract["schema"] == EXTENSION_SCHEMA + ".envelope", "CMBA_EXTENSION_SCHEMA")
    hex_digest(contract["contract_hash"])
    require(_wrap(contract["body"])["contract_hash"] == contract["contract_hash"], "CMBA_EXTENSION_CONTRACT_HASH")
    body = contract["body"]
    exact(
        body,
        {
            "schema", "identity", "input_contract", "evidence_contract", "predicates", "limits",
            "result_meanings", "claim_ceiling", "nonclaims", "compatibility", "vector_classes",
            "native_dependency", "authority_effect",
        },
    )
    require(body["schema"] == EXTENSION_SCHEMA, "CMBA_EXTENSION_SCHEMA")
    require(body["identity"]["kind"] in authoring_contract()["kinds"], "CMBA_EXTENSION_KIND")
    require(body["vector_classes"] == authoring_contract()["required_vector_classes"], "CMBA_EXTENSION_VECTORS")
    require(body["authority_effect"] == "NONE", "CMBA_EXTENSION_AUTHORITY")


def resolve(ref: dict[str, Any]) -> dict[str, Any]:
    canonical(ref)
    exact(ref, {"schema", "extension_id", "extension_version", "contract_hash"})
    require(ref["schema"] == REFERENCE_SCHEMA, "CMBA_EXTENSION_REFERENCE_SCHEMA")
    hex_digest(ref["contract_hash"])
    found = [
        contract for contract in contracts()
        if contract["body"]["identity"]["extension_id"] == ref["extension_id"]
        and contract["body"]["identity"]["extension_version"] == ref["extension_version"]
    ]
    require(len(found) == 1, "CMBA_EXTENSION_UNSUPPORTED")
    require(found[0]["contract_hash"] == ref["contract_hash"], "CMBA_EXTENSION_COMMITMENT_MISMATCH")
    return clone(found[0])


def capabilities() -> list[dict[str, Any]]:
    result = []
    for contract in contracts():
        validate_contract(contract)
        body = contract["body"]
        identity = body["identity"]
        availability = "AVAILABLE"
        if identity["extension_id"] == "cmba.native-dkn":
            try:
                from .profiles.dkn import load_native
                load_native()
            except (ImportError, Refusal):
                availability = "OPTIONAL_DEPENDENCY_UNAVAILABLE"
        elif identity["extension_id"] == "cmba.native-ccp-current-use":
            availability = "EXPLICIT_PINNED_SOURCE_REQUIRED"
        result.append({
            "schema": "cmba.extension-capability.v2",
            "capability_id": identity["extension_id"] + ".evaluate",
            "extension": reference(contract),
            "kind": identity["kind"],
            "availability": availability,
            "effect_class": "PURE_READ",
            "network": False,
            "subprocess": False,
            "auto_install": False,
            "input_code_loading": False,
            "claim_ceiling": body["claim_ceiling"],
            "authority_effect": "NONE",
        })
    return result
