"""Pinned read-only adapter for selected UCM r033 contract surfaces."""
from __future__ import annotations

import hashlib
import importlib
import json
import sys
from pathlib import Path
from typing import Any

from ..errors import require
from .ccp import load_native as load_pinned_ucm


SELECTED_MODULES = (
    "ucm.amcas",
    "ucm.realization",
    "ucm.operation_gateway",
    "uclop.constitutional",
    "uclop.pipeline",
)


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_native(source_root: str | Path) -> tuple[dict[str, Any], dict[str, Any]]:
    """Load only exact source-manifest members from the already pinned UCM tree."""
    _, identity = load_pinned_ucm(source_root)
    root = Path(identity["source_root"]).resolve()
    src = str(root / "src")
    modules: dict[str, Any] = {}
    sys.path.insert(0, src)
    try:
        for name in SELECTED_MODULES:
            modules[name] = importlib.import_module(name)
    finally:
        if sys.path[0] == src:
            sys.path.pop(0)
    manifest = json.loads((root / "release" / "SOURCE-MANIFEST.json").read_text(encoding="utf-8"))
    member_hashes = {row["path"]: row["sha256"] for row in manifest["members"]}
    selected = []
    for name, module in sorted(sys.modules.items()):
        module_file = getattr(module, "__file__", None)
        if not module_file or not (name == "ucm" or name.startswith("ucm.") or name == "uclop" or name.startswith("uclop.")):
            continue
        path = Path(module_file).resolve()
        try:
            path.relative_to(root / "src")
        except ValueError:
            require(False, "CMBA_UCM_NATIVE_DEPENDENCY_OUTSIDE_PIN")
        relative = path.relative_to(root).as_posix()
        observed = _sha256(path)
        require(member_hashes.get(relative) == observed, "CMBA_UCM_NATIVE_MODULE_MISMATCH")
        selected.append({"module": name, "path": relative, "sha256": observed})
    require(all(any(row["module"] == name for row in selected) for name in SELECTED_MODULES), "CMBA_UCM_NATIVE_DEPENDENCY_INCOMPLETE")
    return modules, {
        **identity,
        "schema": "cmba.ucm-native-source-identity.v2",
        "pin_basis_schema": "cmba.ccp-native-source-identity.v2",
        "selected_module_files": selected,
        "authority_effect": "NONE",
    }
