"""Pinned adapter for UCM r033's supported CCP current-use evaluator."""
from __future__ import annotations

import hashlib
import importlib
import json
import sys
from pathlib import Path
from typing import Any

from ..bindings import exact
from ..codec import canonical, clone
from ..errors import require


PIN = {
    "engineering_revision": "r033",
    "release_root": "d8c41b03aec805a400cba5d44cd20d903d4ee6d0064a53c897a3a432ea0a2354",
    "release_identity_root": "cf8fc55bd32cc2246cb6a7ee8ebc18e20fbd826a03c092a273d5a5b4b5c6018d",
    "source_manifest_root": "169470fe465f9e6a926874ec6df3945f071dca1f7ef488ef103657307eefd605",
    "ccp_admissibility_sha256": "c832de3544069ebc18210d246ab4bfb0c396b7995b1e06ba78c769a34ebce5a2",
}


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def verify_source(source_root: str | Path) -> dict[str, Any]:
    root = Path(source_root).resolve()
    module_path = root / "src" / "ucm" / "ccp_admissibility.py"
    qualification_path = root / "release" / "UCM-v0.1-QUALIFICATION.json"
    manifest_path = root / "release" / "SOURCE-MANIFEST.json"
    require(module_path.is_file() and qualification_path.is_file() and manifest_path.is_file(), "CMBA_CCP_NATIVE_SOURCE_MISSING")
    require(_sha256(module_path) == PIN["ccp_admissibility_sha256"], "CMBA_CCP_NATIVE_MODULE_MISMATCH")
    try:
        qualification = json.loads(qualification_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        raise ValueError("CMBA_CCP_NATIVE_QUALIFICATION_INVALID") from error
    for field in ("engineering_revision", "release_root", "release_identity_root", "source_manifest_root"):
        require(qualification.get(field) == PIN[field], "CMBA_CCP_NATIVE_PIN_MISMATCH")
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        raise ValueError("CMBA_CCP_NATIVE_MANIFEST_INVALID") from error
    manifest_body = {key: value for key, value in manifest.items() if key != "root"}
    manifest_root = hashlib.sha256(json.dumps(
        manifest_body, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False,
    ).encode("utf-8")).hexdigest()
    require(manifest.get("root") == PIN["source_manifest_root"] == manifest_root, "CMBA_CCP_NATIVE_MANIFEST_ROOT_MISMATCH")
    require(manifest.get("member_count") == len(manifest.get("members", [])), "CMBA_CCP_NATIVE_MANIFEST_COUNT_MISMATCH")
    return {
        "schema": "cmba.ccp-native-source-identity.v2",
        **PIN,
        "source_root": str(root),
        "qualification_sha256": _sha256(qualification_path),
        "source_manifest_sha256": _sha256(manifest_path),
        "authority_effect": "NONE",
    }


def load_native(source_root: str | Path):
    identity = verify_source(source_root)
    src = str(Path(identity["source_root"]) / "src")
    loaded = sys.modules.get("ucm.ccp_admissibility")
    if loaded is not None:
        require(Path(loaded.__file__).resolve() == Path(src, "ucm", "ccp_admissibility.py").resolve(), "CMBA_CCP_NATIVE_ALREADY_LOADED")
        module = loaded
    else:
        sys.path.insert(0, src)
        try:
            module = importlib.import_module("ucm.ccp_admissibility")
        finally:
            if sys.path[0] == src:
                sys.path.pop(0)
        require(Path(module.__file__).resolve() == Path(src, "ucm", "ccp_admissibility.py").resolve(), "CMBA_CCP_NATIVE_IMPORT_MISMATCH")
    manifest = json.loads((Path(identity["source_root"]) / "release" / "SOURCE-MANIFEST.json").read_text(encoding="utf-8"))
    member_hashes = {row["path"]: row["sha256"] for row in manifest["members"]}
    loaded_rows = []
    source_path = Path(src).resolve()
    for name, candidate in sorted(sys.modules.items()):
        module_file = getattr(candidate, "__file__", None)
        if not module_file or not (name == "ucm" or name.startswith("ucm.") or name == "uclop" or name.startswith("uclop.")):
            continue
        path = Path(module_file).resolve()
        try:
            relative = path.relative_to(Path(identity["source_root"]).resolve()).as_posix()
            path.relative_to(source_path)
        except ValueError:
            require(False, "CMBA_CCP_NATIVE_DEPENDENCY_OUTSIDE_PIN")
        observed = _sha256(path)
        require(member_hashes.get(relative) == observed, "CMBA_CCP_NATIVE_DEPENDENCY_MISMATCH")
        loaded_rows.append({"module": name, "path": relative, "sha256": observed})
    require(any(row["module"] == "ucm.ccp_admissibility" for row in loaded_rows), "CMBA_CCP_NATIVE_DEPENDENCY_INCOMPLETE")
    identity["loaded_module_files"] = loaded_rows
    return module, identity


def evaluate_native_current_use(source_root: str | Path, records: dict[str, Any]) -> dict[str, Any]:
    exact(records, {"profile", "perimeter", "correspondence", "evidence", "use", "expected_anchors"})
    native, identity = load_native(source_root)
    profile = native.validate_jurisdiction_profile(records["profile"])
    perimeter = native.validate_enforcement_perimeter(records["perimeter"])
    correspondence = native.validate_chc_thr_correspondence(records["correspondence"])
    evidence = native.validate_evidence_snapshot(records["evidence"])
    use = native.validate_current_use_snapshot(records["use"])
    anchors = records["expected_anchors"]
    require(type(anchors) is dict and len(anchors) == 8, "CMBA_CCP_NATIVE_ANCHORS")
    decision = native.evaluate_current_admissibility(
        current_use_snapshot=use,
        evidence_snapshot=evidence,
        jurisdiction_profile=profile,
        enforcement_perimeter=perimeter,
        correspondence=correspondence,
        **anchors,
    )
    native.validate_admissibility_decision(
        decision,
        current_use_snapshot=use,
        evidence_snapshot=evidence,
        jurisdiction_profile=profile,
        enforcement_perimeter=perimeter,
        correspondence=correspondence,
        **anchors,
    )
    require(decision["decision"] in {"ADMIT", "REFUSE", "DEFER", "UNRESOLVED"}, "CMBA_CCP_NATIVE_DECISION")
    require(decision["effect_authorized"] is False, "CMBA_CCP_NATIVE_EFFECT_BOUNDARY")
    return {
        "schema": "cmba.ccp-native-current-use-result.v2",
        "native_source_identity": identity,
        "decision": clone(decision),
        "decision_recomputed": True,
        "native_outcome_preserved": decision["decision"],
        "execution_authorized": False,
        "authority_effect": "NONE",
    }


def validate_claimed_native_decision(source_root: str | Path, records: dict[str, Any], claimed: dict[str, Any]) -> None:
    native, _ = load_native(source_root)
    native.validate_admissibility_decision(
        claimed,
        current_use_snapshot=records["use"],
        evidence_snapshot=records["evidence"],
        jurisdiction_profile=records["profile"],
        enforcement_perimeter=records["perimeter"],
        correspondence=records["correspondence"],
        **records["expected_anchors"],
    )
