"""Pinned adapter from UCM r033 Pippi records to ``cmba.pippi``."""
from __future__ import annotations

import hashlib
import importlib
import json
import sys
from pathlib import Path
from typing import Any

from ..errors import require
from ..pippi import observable_turn
from .ccp import load_native as load_pinned_ucm


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_native(source_root: str | Path):
    _, identity = load_pinned_ucm(source_root)
    root = Path(identity["source_root"]).resolve()
    src = str(root / "src")
    sys.path.insert(0, src)
    try:
        pippi = importlib.import_module("ucm.pippi")
        runtime = importlib.import_module("ucm.pippi_runtime")
        journal = importlib.import_module("ucm.journal")
    finally:
        if sys.path[0] == src:
            sys.path.pop(0)
    manifest = json.loads((root / "release" / "SOURCE-MANIFEST.json").read_text(encoding="utf-8"))
    hashes = {row["path"]: row["sha256"] for row in manifest["members"]}
    rows = []
    for name, module in (("ucm.pippi", pippi), ("ucm.pippi_runtime", runtime), ("ucm.journal", journal)):
        path = Path(module.__file__).resolve()
        relative = path.relative_to(root).as_posix()
        observed = _sha256(path)
        require(hashes.get(relative) == observed, "CMBA_PIPPI_NATIVE_MODULE_MISMATCH")
        rows.append({"module": name, "path": relative, "sha256": observed})
    identity = {
        **identity,
        "schema": "cmba.pippi-native-source-identity.v2",
        "pin_basis_schema": "cmba.ccp-native-source-identity.v2",
        "pippi_selected_module_files": rows,
    }
    return pippi, runtime, journal, identity


def project_native_turn(
    source_root: str | Path,
    *,
    context: dict[str, Any],
    draft: dict[str, Any],
    decision: dict[str, Any],
    projection: dict[str, Any],
    native_turn: dict[str, Any],
    previous_cmba_turn_root: str | None,
    expected_journal_head: str,
    observed_journal_head: str,
) -> dict[str, Any]:
    pippi, _, _, identity = load_native(source_root)
    context = pippi.validate_pippi_context(context)
    draft = pippi.validate_model_draft(draft)
    decision = pippi.validate_pippi_decision(decision, draft=draft)
    projection = pippi.validate_human_projection(projection, draft=draft, decision=decision)
    native_turn = pippi.validate_turn_envelope(
        native_turn, context=context, draft=draft, decision=decision, projection=projection,
    )
    disposition_by_id = {row["proposal_id"]: row for row in decision["proposal_dispositions"]}
    projected_ids = {native_id: native_id.lower() for native_id in sorted(disposition_by_id)}
    require(len(set(projected_ids.values())) == len(projected_ids), "CMBA_PIPPI_NATIVE_ID_COLLISION")
    policy_root = decision["policy_evaluation_roots"][0] if len(decision["policy_evaluation_roots"]) == 1 else None
    proposals = []
    for row in draft["proposals"]:
        disposition = disposition_by_id[row["proposal_id"]]
        proposals.append({
            "proposal_id": projected_ids[row["proposal_id"]], "payload_root": row["payload_root"],
            "effect_class": row["effect_class"], "decision": disposition["decision"],
            "policy_evaluation_root": policy_root,
            "policy_recomputed": False,
        })
    require(not native_turn["tool_proposal_roots"] and not native_turn["dispatch_receipt_roots"] and not native_turn["tool_result_roots"], "CMBA_PIPPI_NATIVE_TOOL_MAPPING_UNSUPPORTED")
    projected = observable_turn(
        draft["turn_id"].lower(), native_turn["sequence"], previous_cmba_turn_root,
        context["context_root"], draft["draft_root"], decision["decision_root"],
        projection["projection_root"], sorted(projected_ids.values()), proposals, [],
        expected_journal_head, observed_journal_head, native_turn["turn_root"],
    )
    return {
        "schema": "cmba.pippi-native-turn-projection.v2",
        "native_source_identity": identity,
        "observable_turn": projected,
        "native_crosslinks_recomputed": True,
        "native_to_cmba_proposal_ids": projected_ids,
        "native_integration_mode": pippi.effective_integration_mode(context),
        "hidden_reasoning": "NOT_OBSERVED_OR_CLAIMED",
        "authority_effect": "NONE",
    }
