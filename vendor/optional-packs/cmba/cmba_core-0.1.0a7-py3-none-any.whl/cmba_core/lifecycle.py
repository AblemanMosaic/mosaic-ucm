"""Finite lifecycle, delegation, and dependency-reassessment profiles.

All time, history, revocation, trust, and dependency facts are supplied by the
caller. These evaluators neither discover current state nor grant authority.
"""
from __future__ import annotations

import hashlib
from typing import Any

from .bindings import exact, hex_digest, identifier, validate_reference
from .codec import canonical, clone
from .contract_types import multi_check_report, scope as make_scope
from .errors import require


MAX_RECORDS = 64
MAX_DELEGATION_DEPTH = 8


def _root(domain: str, value: Any) -> str:
    return hashlib.sha256(("CMBA:V2:" + domain + "\0").encode("ascii") + canonical(value)).hexdigest()


def _time(value: int) -> None:
    require(type(value) is int and type(value) is not bool and value >= 0, "CMBA_LIFECYCLE_TIME")


def _scope(value: dict[str, Any]) -> None:
    canonical(value)
    exact(value, {"schema", "subject", "actions", "resources", "jurisdictions", "configurations"})
    require(value["schema"] == "cmba.scope.v2", "CMBA_LIFECYCLE_SCOPE")
    rebuilt = make_scope(
        value["subject"], actions=value["actions"], resources=value["resources"],
        jurisdictions=value["jurisdictions"], configurations=value["configurations"],
    )
    require(canonical(rebuilt) == canonical(value), "CMBA_LIFECYCLE_SCOPE")


def _scope_within(child: dict[str, Any], parent: dict[str, Any]) -> bool:
    return (
        canonical(child["subject"]) == canonical(parent["subject"])
        and all(set(child[field]) <= set(parent[field]) for field in (
            "actions", "resources", "jurisdictions", "configurations"
        ))
    )


def lifecycle_item(
    item_id: str,
    subject: dict[str, Any],
    issuer_id: str,
    applicability: dict[str, Any],
    payload_root: str,
    *,
    issued_at: int,
    valid_until: int,
    predecessor_roots: list[str] | None = None,
    supersedes_roots: list[str] | None = None,
) -> dict[str, Any]:
    identifier(item_id)
    identifier(issuer_id)
    validate_reference(subject)
    _scope(applicability)
    require(canonical(subject) == canonical(applicability["subject"]), "CMBA_LIFECYCLE_SUBJECT")
    hex_digest(payload_root)
    _time(issued_at)
    _time(valid_until)
    require(issued_at < valid_until, "CMBA_LIFECYCLE_INTERVAL")
    predecessors = predecessor_roots or []
    supersedes = supersedes_roots or []
    for values in (predecessors, supersedes):
        require(type(values) is list and values == sorted(set(values)), "CMBA_LIFECYCLE_LINKS")
        for value in values:
            hex_digest(value)
    body = {
        "schema": "cmba.lifecycle-item-body.v2",
        "item_id": item_id,
        "subject": clone(subject),
        "issuer_id": issuer_id,
        "applicability": clone(applicability),
        "payload_root": payload_root,
        "issued_at": issued_at,
        "valid_until": valid_until,
        "predecessor_roots": list(predecessors),
        "supersedes_roots": list(supersedes),
        "authority_effect": "NONE",
    }
    return {"schema": "cmba.lifecycle-item.v2", "body": body, "item_root": _root("lifecycle-item", body)}


def validate_lifecycle_item(value: dict[str, Any]) -> None:
    canonical(value)
    exact(value, {"schema", "body", "item_root"})
    require(value["schema"] == "cmba.lifecycle-item.v2", "CMBA_LIFECYCLE_SCHEMA")
    hex_digest(value["item_root"])
    body = value["body"]
    rebuilt = lifecycle_item(
        body["item_id"], body["subject"], body["issuer_id"], body["applicability"],
        body["payload_root"], issued_at=body["issued_at"], valid_until=body["valid_until"],
        predecessor_roots=body["predecessor_roots"], supersedes_roots=body["supersedes_roots"],
    )
    require(canonical(rebuilt) == canonical(value), "CMBA_LIFECYCLE_ROOT")


def withdrawal_event(event_id: str, target_root: str, issuer_id: str, *, at: int) -> dict[str, Any]:
    identifier(event_id)
    identifier(issuer_id)
    hex_digest(target_root)
    _time(at)
    body = {
        "schema": "cmba.withdrawal-event-body.v2",
        "event_id": event_id,
        "target_root": target_root,
        "issuer_id": issuer_id,
        "at": at,
        "authority_effect": "NONE",
    }
    return {"schema": "cmba.withdrawal-event.v2", "body": body, "event_root": _root("withdrawal-event", body)}


def _validate_withdrawal(value: dict[str, Any]) -> None:
    canonical(value)
    exact(value, {"schema", "body", "event_root"})
    require(value["schema"] == "cmba.withdrawal-event.v2", "CMBA_LIFECYCLE_SCHEMA")
    body = value["body"]
    rebuilt = withdrawal_event(body["event_id"], body["target_root"], body["issuer_id"], at=body["at"])
    require(canonical(rebuilt) == canonical(value), "CMBA_LIFECYCLE_ROOT")


def evaluate_lifecycle(
    items: list[dict[str, Any]],
    withdrawals: list[dict[str, Any]],
    *,
    expected_item_roots: list[str],
    requested_scope: dict[str, Any],
    now: int,
    revocation_snapshot: dict[str, Any],
) -> dict[str, Any]:
    require(type(items) is list and 0 < len(items) <= MAX_RECORDS, "CMBA_LIFECYCLE_ITEMS")
    require(type(withdrawals) is list and len(withdrawals) <= MAX_RECORDS, "CMBA_LIFECYCLE_WITHDRAWALS")
    _scope(requested_scope)
    _time(now)
    exact(revocation_snapshot, {"source_id", "observed_at", "coverage"})
    identifier(revocation_snapshot["source_id"])
    _time(revocation_snapshot["observed_at"])
    require(revocation_snapshot["coverage"] in {"COMPLETE_FOR_DECLARED_SOURCE", "PARTIAL", "UNKNOWN"}, "CMBA_LIFECYCLE_REVOCATION")
    require(type(expected_item_roots) is list and expected_item_roots == sorted(set(expected_item_roots)), "CMBA_LIFECYCLE_EXPECTED")
    for root in expected_item_roots:
        hex_digest(root)

    by_root: dict[str, dict[str, Any]] = {}
    ids = set()
    for item in items:
        validate_lifecycle_item(item)
        require(item["item_root"] not in by_root and item["body"]["item_id"] not in ids, "CMBA_LIFECYCLE_DUPLICATE")
        by_root[item["item_root"]] = item
        ids.add(item["body"]["item_id"])
    seen_events = set()
    withdrawal_rows = []
    withdrawal_checks = {}
    withdrawn = set()
    for event in withdrawals:
        _validate_withdrawal(event)
        body = event["body"]
        require(body["event_id"] not in seen_events, "CMBA_LIFECYCLE_DUPLICATE")
        seen_events.add(body["event_id"])
        target = by_root.get(body["target_root"])
        applies = target is not None and body["issuer_id"] == target["body"]["issuer_id"] and body["at"] <= now
        withdrawal_checks["withdrawal." + body["event_id"]] = (
            "INSUFFICIENT" if target is None
            else "CONTRADICTED" if body["issuer_id"] != target["body"]["issuer_id"]
            else "MATCH"
        )
        if applies:
            withdrawn.add(body["target_root"])
        withdrawal_rows.append({"event_root": event["event_root"], "target_root": body["target_root"], "applies": applies})

    superseded = set()
    history_checks = {}
    for item in items:
        body = item["body"]
        for relation, roots in (("predecessor", body["predecessor_roots"]), ("supersedes", body["supersedes_roots"])):
            for linked_root in roots:
                linked = by_root.get(linked_root)
                key = f"history.{body['item_id']}.{relation}.{linked_root}"
                if linked is None:
                    history_checks[key] = "INSUFFICIENT"
                    continue
                same_lineage = (
                    canonical(linked["body"]["subject"]) == canonical(body["subject"])
                    and linked["body"]["issuer_id"] == body["issuer_id"]
                    and linked["body"]["issued_at"] < body["issued_at"]
                )
                if relation == "supersedes":
                    same_lineage = same_lineage and _scope_within(
                        linked["body"]["applicability"], body["applicability"]
                    ) and _scope_within(body["applicability"], linked["body"]["applicability"])
                history_checks[key] = "MATCH" if same_lineage else "CONTRADICTED"
                if relation == "supersedes" and same_lineage and body["issued_at"] <= now:
                    superseded.add(linked_root)

    rows = []
    checks = {**history_checks, **withdrawal_checks}
    for root in expected_item_roots:
        item = by_root.get(root)
        if item is None:
            checks["item." + root] = "INSUFFICIENT"
            continue
        body = item["body"]
        if root in withdrawn:
            disposition = "WITHDRAWN_IN_SUPPLIED_SNAPSHOT"
        elif root in superseded:
            disposition = "SUPERSEDED_IN_SUPPLIED_HISTORY"
        elif now < body["issued_at"]:
            disposition = "NOT_YET_APPLICABLE"
        elif now >= body["valid_until"]:
            disposition = "EXPIRED_AT_SUPPLIED_TIME"
        elif not _scope_within(requested_scope, body["applicability"]):
            disposition = "OUTSIDE_DECLARED_APPLICABILITY"
        else:
            disposition = "APPLICABLE_IN_SUPPLIED_SNAPSHOT"
        checks["item." + body["item_id"]] = "MATCH" if disposition == "APPLICABLE_IN_SUPPLIED_SNAPSHOT" else "CONTRADICTED"
        rows.append({"item_root": root, "item_id": body["item_id"], "disposition": disposition})
    checks["revocation.coverage"] = (
        "MATCH" if revocation_snapshot["coverage"] == "COMPLETE_FOR_DECLARED_SOURCE" and revocation_snapshot["observed_at"] >= now
        else "INSUFFICIENT"
    )
    report = multi_check_report(
        checks,
        details={
            "time": {"epoch": now, "clock_source": "caller-supplied"},
            "items": rows,
            "withdrawals": withdrawal_rows,
            "historical_item_roots": sorted(by_root),
            "revocation_snapshot": clone(revocation_snapshot),
            "currentness": "SUPPLIED_SNAPSHOT_ONLY",
            "global_currentness": "NOT_ESTABLISHED",
        },
        claim_ceiling="Applicability, succession, supersession, withdrawal and expiry relative to exact supplied history, revocation snapshot, scope and time only; no global currentness.",
    )
    report["schema"] = "cmba.lifecycle-assessment.v2"
    return report


def delegation_grant(
    grant_id: str,
    principal_id: str,
    delegate_id: str,
    subject: dict[str, Any],
    delegated_scope: dict[str, Any],
    *,
    issued_at: int,
    valid_until: int,
    parent_delegation_id: str | None,
    parent_delegation_root: str | None,
    depth: int,
    redelegations_remaining: int,
    scope_state: str = "RESOLVED",
) -> dict[str, Any]:
    for value in (grant_id, principal_id, delegate_id):
        identifier(value)
    validate_reference(subject)
    _scope(delegated_scope)
    require(canonical(subject) == canonical(delegated_scope["subject"]), "CMBA_DELEGATION_SUBJECT")
    _time(issued_at)
    _time(valid_until)
    require(issued_at < valid_until, "CMBA_DELEGATION_INTERVAL")
    require(type(depth) is int and type(depth) is not bool and 0 <= depth <= 64, "CMBA_DELEGATION_DEPTH")
    require(type(redelegations_remaining) is int and type(redelegations_remaining) is not bool and 0 <= redelegations_remaining <= 64, "CMBA_DELEGATION_REDELEGATION")
    require(scope_state in {"RESOLVED", "UNRESOLVED"}, "CMBA_DELEGATION_SCOPE")
    require((parent_delegation_id is None) == (parent_delegation_root is None), "CMBA_DELEGATION_PARENT")
    if parent_delegation_id is not None:
        identifier(parent_delegation_id)
        hex_digest(parent_delegation_root)
    body = {
        "schema": "cmba.delegation-grant-body.v2",
        "grant_id": grant_id,
        "principal_id": principal_id,
        "delegate_id": delegate_id,
        "subject": clone(subject),
        "scope": clone(delegated_scope),
        "issued_at": issued_at,
        "valid_until": valid_until,
        "parent_delegation_id": parent_delegation_id,
        "parent_delegation_root": parent_delegation_root,
        "depth": depth,
        "redelegations_remaining": redelegations_remaining,
        "scope_state": scope_state,
        "authority_effect": "NONE",
    }
    return {"schema": "cmba.delegation-grant.v2", "body": body, "delegation_root": _root("delegation-grant", body)}


def validate_delegation(value: dict[str, Any]) -> None:
    canonical(value)
    exact(value, {"schema", "body", "delegation_root"})
    require(value["schema"] == "cmba.delegation-grant.v2", "CMBA_DELEGATION_SCHEMA")
    body = value["body"]
    rebuilt = delegation_grant(
        body["grant_id"], body["principal_id"], body["delegate_id"], body["subject"], body["scope"],
        issued_at=body["issued_at"], valid_until=body["valid_until"],
        parent_delegation_id=body["parent_delegation_id"], parent_delegation_root=body["parent_delegation_root"],
        depth=body["depth"], redelegations_remaining=body["redelegations_remaining"],
        scope_state=body["scope_state"],
    )
    require(canonical(rebuilt) == canonical(value), "CMBA_DELEGATION_ROOT")


def _cycles(parents: dict[str, str | None]) -> set[str]:
    cyclic = set()
    for start in parents:
        path = []
        positions = {}
        node = start
        while node is not None and node in parents:
            if node in positions:
                cyclic.update(path[positions[node]:])
                break
            if node in path:
                break
            positions[node] = len(path)
            path.append(node)
            node = parents[node]
    return cyclic


def evaluate_delegation(
    grants: list[dict[str, Any]],
    *,
    trusted_principals: list[str],
    target_grant_id: str,
    requested_scope: dict[str, Any],
    now: int,
    maximum_depth: int = MAX_DELEGATION_DEPTH,
) -> dict[str, Any]:
    require(type(grants) is list and 0 < len(grants) <= MAX_RECORDS, "CMBA_DELEGATION_GRANTS")
    require(type(trusted_principals) is list and trusted_principals == sorted(set(trusted_principals)), "CMBA_DELEGATION_TRUST")
    for principal in trusted_principals:
        identifier(principal)
    identifier(target_grant_id)
    _scope(requested_scope)
    _time(now)
    require(type(maximum_depth) is int and type(maximum_depth) is not bool and 0 <= maximum_depth <= MAX_DELEGATION_DEPTH, "CMBA_DELEGATION_DEPTH")
    by_id = {}
    for grant in grants:
        validate_delegation(grant)
        grant_id = grant["body"]["grant_id"]
        require(grant_id not in by_id, "CMBA_DELEGATION_DUPLICATE")
        by_id[grant_id] = grant
    parents = {grant_id: grant["body"]["parent_delegation_id"] for grant_id, grant in by_id.items()}
    cyclic = _cycles(parents)
    checks = {"chain.acyclic": "CONTRADICTED" if cyclic else "MATCH"}
    rows = []
    for grant_id, grant in sorted(by_id.items()):
        body = grant["body"]
        reasons = []
        status = "MATCH"
        if body["scope_state"] == "UNRESOLVED" or body["depth"] > maximum_depth:
            status = "UNSUPPORTED"
            reasons.append("UNRESOLVED_SCOPE" if body["scope_state"] == "UNRESOLVED" else "MAXIMUM_DEPTH_EXCEEDED")
        if grant_id in cyclic:
            status = "CONTRADICTED"
            reasons.append("DELEGATION_CYCLE")
        parent_id = body["parent_delegation_id"]
        if parent_id is None:
            if body["principal_id"] not in trusted_principals or body["depth"] != 0:
                status = "CONTRADICTED"
                reasons.append("UNTRUSTED_OR_INVALID_ROOT")
        else:
            parent = by_id.get(parent_id)
            if parent is None:
                if status == "MATCH":
                    status = "INSUFFICIENT"
                reasons.append("PARENT_MISSING")
            else:
                parent_body = parent["body"]
                predicates = {
                    "PARENT_ROOT_MISMATCH": body["parent_delegation_root"] == parent["delegation_root"],
                    "INVALID_ISSUER_CHAIN": body["principal_id"] == parent_body["delegate_id"],
                    "SUBJECT_CHANGED": canonical(body["subject"]) == canonical(parent_body["subject"]),
                    "SCOPE_EXPANSION": _scope_within(body["scope"], parent_body["scope"]),
                    "VALIDITY_EXPANSION": parent_body["issued_at"] <= body["issued_at"] and body["valid_until"] <= parent_body["valid_until"],
                    "DEPTH_MISMATCH": body["depth"] == parent_body["depth"] + 1,
                    "REDELEGATION_NOT_ALLOWED": parent_body["redelegations_remaining"] > 0 and body["redelegations_remaining"] <= parent_body["redelegations_remaining"] - 1,
                }
                failed = [reason for reason, passed in predicates.items() if not passed]
                if failed:
                    status = "CONTRADICTED"
                    reasons.extend(failed)
        if not (body["issued_at"] <= now < body["valid_until"]):
            status = "CONTRADICTED"
            reasons.append("OUTSIDE_VALIDITY")
        checks["grant." + grant_id] = status
        rows.append({"grant_id": grant_id, "delegation_root": grant["delegation_root"], "status": status, "reasons": sorted(set(reasons))})
    target = by_id.get(target_grant_id)
    if target is None:
        checks["target.exists"] = "INSUFFICIENT"
    else:
        chain_statuses = []
        node = target_grant_id
        visited = set()
        while node is not None and node in by_id and node not in visited:
            visited.add(node)
            chain_statuses.append(checks["grant." + node])
            node = by_id[node]["body"]["parent_delegation_id"]
        checks["target.chain"] = next(
            (status for status in ("CONTRADICTED", "UNSUPPORTED", "INSUFFICIENT") if status in chain_statuses),
            "MATCH",
        )
        checks["target.scope"] = (
            "MATCH" if target["body"]["scope_state"] == "RESOLVED" and _scope_within(requested_scope, target["body"]["scope"])
            else "UNSUPPORTED" if target["body"]["scope_state"] == "UNRESOLVED"
            else "CONTRADICTED"
        )
    report = multi_check_report(
        checks,
        details={
            "target_grant_id": target_grant_id,
            "grants": rows,
            "trusted_principals": trusted_principals,
            "maximum_depth": maximum_depth,
            "time": {"epoch": now, "clock_source": "caller-supplied"},
            "authorization": "EXTERNAL_DECISION_REQUIRED",
        },
        claim_ceiling="Finite attenuation over exact supplied principals, parent roots, subject, scope, interval and redelegation budget only; no identity proof or operational authority.",
    )
    report["schema"] = "cmba.delegation-assessment.v2"
    return report


def dependency_graph(
    graph_id: str,
    dependencies: list[dict[str, Any]],
    claims: list[dict[str, Any]],
) -> dict[str, Any]:
    identifier(graph_id)
    require(type(dependencies) is list and 0 < len(dependencies) <= MAX_RECORDS, "CMBA_REASSESS_DEPENDENCIES")
    dependency_ids = set()
    for item in dependencies:
        exact(item, {"dependency_id", "kind", "historical_root", "recompute_operation"})
        for field in ("dependency_id", "kind", "recompute_operation"):
            identifier(item[field])
        require(item["dependency_id"] not in dependency_ids, "CMBA_REASSESS_DUPLICATE")
        dependency_ids.add(item["dependency_id"])
        hex_digest(item["historical_root"])
    require(type(claims) is list and 0 < len(claims) <= MAX_RECORDS, "CMBA_REASSESS_CLAIMS")
    claim_ids = set()
    for item in claims:
        exact(item, {"claim_id", "historical_evaluation_root", "dependency_ids", "requires_claim_ids"})
        identifier(item["claim_id"])
        require(item["claim_id"] not in claim_ids, "CMBA_REASSESS_DUPLICATE")
        claim_ids.add(item["claim_id"])
        hex_digest(item["historical_evaluation_root"])
        for field in ("dependency_ids", "requires_claim_ids"):
            require(type(item[field]) is list and item[field] == sorted(set(item[field])), "CMBA_REASSESS_LINKS")
            for value in item[field]:
                identifier(value)
        require(set(item["dependency_ids"]) <= dependency_ids, "CMBA_REASSESS_DEPENDENCY_UNKNOWN")
    for item in claims:
        require(set(item["requires_claim_ids"]) <= claim_ids - {item["claim_id"]}, "CMBA_REASSESS_CLAIM_UNKNOWN")
    body = {
        "schema": "cmba.dependency-graph-body.v2",
        "graph_id": graph_id,
        "dependencies": sorted(clone(dependencies), key=lambda item: item["dependency_id"]),
        "claims": sorted(clone(claims), key=lambda item: item["claim_id"]),
        "authority_effect": "NONE",
    }
    return {"schema": "cmba.dependency-graph.v2", "body": body, "graph_root": _root("dependency-graph", body)}


def validate_dependency_graph(value: dict[str, Any]) -> None:
    canonical(value)
    exact(value, {"schema", "body", "graph_root"})
    require(value["schema"] == "cmba.dependency-graph.v2", "CMBA_REASSESS_SCHEMA")
    body = value["body"]
    rebuilt = dependency_graph(body["graph_id"], body["dependencies"], body["claims"])
    require(canonical(rebuilt) == canonical(value), "CMBA_REASSESS_ROOT")


def dependency_snapshot(snapshot_id: str, roots: dict[str, str], *, observed_at: int, complete: bool) -> dict[str, Any]:
    identifier(snapshot_id)
    require(type(roots) is dict, "CMBA_REASSESS_SNAPSHOT")
    admitted = {}
    for dependency_id, root in roots.items():
        identifier(dependency_id)
        hex_digest(root)
        admitted[dependency_id] = root
    _time(observed_at)
    require(type(complete) is bool, "CMBA_REASSESS_SNAPSHOT")
    return {
        "schema": "cmba.dependency-snapshot.v2",
        "snapshot_id": snapshot_id,
        "roots": {key: admitted[key] for key in sorted(admitted)},
        "observed_at": observed_at,
        "complete": complete,
        "authority_effect": "NONE",
    }


def _validate_snapshot(value: dict[str, Any]) -> None:
    canonical(value)
    exact(value, {"schema", "snapshot_id", "roots", "observed_at", "complete", "authority_effect"})
    require(value["schema"] == "cmba.dependency-snapshot.v2" and value["authority_effect"] == "NONE", "CMBA_REASSESS_SNAPSHOT")
    require(canonical(dependency_snapshot(value["snapshot_id"], value["roots"], observed_at=value["observed_at"], complete=value["complete"])) == canonical(value), "CMBA_REASSESS_SNAPSHOT")


def _graph_cycles(edges: dict[str, list[str]]) -> set[str]:
    cyclic = set()
    visiting = []
    visited = set()

    def visit(node: str) -> None:
        if node in visiting:
            cyclic.update(visiting[visiting.index(node):])
            return
        if node in visited:
            return
        visiting.append(node)
        for child in edges[node]:
            visit(child)
        visiting.pop()
        visited.add(node)

    for node in edges:
        visit(node)
    return cyclic


def evaluate_reassessment(
    graph: dict[str, Any],
    previous_snapshot: dict[str, Any],
    current_snapshot: dict[str, Any],
    recomputations: list[dict[str, Any]],
) -> dict[str, Any]:
    validate_dependency_graph(graph)
    _validate_snapshot(previous_snapshot)
    _validate_snapshot(current_snapshot)
    require(previous_snapshot["observed_at"] <= current_snapshot["observed_at"], "CMBA_REASSESS_TIME")
    require(type(recomputations) is list and len(recomputations) <= MAX_RECORDS, "CMBA_REASSESS_RECOMPUTATIONS")
    dependencies = {item["dependency_id"]: item for item in graph["body"]["dependencies"]}
    claims = {item["claim_id"]: item for item in graph["body"]["claims"]}
    require(set(previous_snapshot["roots"]) == set(dependencies), "CMBA_REASSESS_PREVIOUS_INCOMPLETE")
    require(set(current_snapshot["roots"]) <= set(dependencies), "CMBA_REASSESS_DEPENDENCY_UNKNOWN")
    if current_snapshot["complete"]:
        require(set(current_snapshot["roots"]) == set(dependencies), "CMBA_REASSESS_CURRENT_INCOMPLETE")
    cyclic = _graph_cycles({claim_id: item["requires_claim_ids"] for claim_id, item in claims.items()})
    recomputed = {}
    for item in recomputations:
        exact(item, {"claim_id", "new_evaluation_root", "dependency_roots", "child_evaluation_roots"})
        identifier(item["claim_id"])
        require(item["claim_id"] in claims and item["claim_id"] not in recomputed, "CMBA_REASSESS_RECOMPUTATION")
        hex_digest(item["new_evaluation_root"])
        require(type(item["dependency_roots"]) is dict and type(item["child_evaluation_roots"]) is dict, "CMBA_REASSESS_RECOMPUTATION")
        for mapping in (item["dependency_roots"], item["child_evaluation_roots"]):
            for key, root in mapping.items():
                identifier(key)
                hex_digest(root)
        recomputed[item["claim_id"]] = item

    paths: dict[str, list[list[str]]] = {claim_id: [] for claim_id in claims}
    for claim_id, claim in claims.items():
        for dependency_id in claim["dependency_ids"]:
            before = previous_snapshot["roots"][dependency_id]
            after = current_snapshot["roots"].get(dependency_id)
            if after is None:
                paths[claim_id].append(["dependency:" + dependency_id + ":missing", "claim:" + claim_id])
            elif after != before:
                paths[claim_id].append(["dependency:" + dependency_id + ":changed", "claim:" + claim_id])
        if not current_snapshot["complete"]:
            paths[claim_id].append(["snapshot:" + current_snapshot["snapshot_id"] + ":incomplete", "claim:" + claim_id])
    for _ in range(len(claims)):
        changed = False
        for claim_id, claim in claims.items():
            existing = {tuple(path) for path in paths[claim_id]}
            for child in claim["requires_claim_ids"]:
                for child_path in paths[child]:
                    candidate = tuple(child_path + ["claim:" + claim_id])
                    if len(candidate) <= len(claims) + 2 and candidate not in existing and len(existing) < 128:
                        paths[claim_id].append(list(candidate))
                        existing.add(candidate)
                        changed = True
        if not changed:
            break

    states: dict[str, dict[str, Any]] = {}
    remaining = set(claims)
    while remaining:
        progress = False
        for claim_id in sorted(remaining):
            claim = claims[claim_id]
            if any(child in remaining for child in claim["requires_claim_ids"]):
                continue
            progress = True
            remaining.remove(claim_id)
            impacted = bool(paths[claim_id])
            historical_root = claim["historical_evaluation_root"]
            row = recomputed.get(claim_id)
            if claim_id in cyclic:
                state = "CONTRADICTED_DEPENDENCY_CYCLE"
                effective = historical_root
            elif not current_snapshot["complete"]:
                state = (
                    "CONTRADICTED_RECOMPUTATION_WITH_INCOMPLETE_INPUT"
                    if row is not None else "RECOMPUTE_REQUIRED_INCOMPLETE_DEPENDENCY_KNOWLEDGE"
                )
                effective = historical_root
            elif not impacted:
                state = "CONTRADICTED_UNNEEDED_RECOMPUTATION" if row is not None else "REUSABLE_UNCHANGED"
                effective = historical_root
            elif row is None:
                state = "RECOMPUTE_REQUIRED"
                effective = historical_root
            else:
                child_blocked = any(states[child]["state"] not in {"REUSABLE_UNCHANGED", "RECOMPUTED"} for child in claim["requires_claim_ids"])
                exact_dependencies = (
                    set(row["dependency_roots"]) == set(claim["dependency_ids"])
                    and all(row["dependency_roots"][dep] == current_snapshot["roots"].get(dep) for dep in claim["dependency_ids"])
                )
                exact_children = (
                    set(row["child_evaluation_roots"]) == set(claim["requires_claim_ids"])
                    and all(row["child_evaluation_roots"][child] == states[child]["effective_evaluation_root"] for child in claim["requires_claim_ids"])
                )
                if child_blocked:
                    state = "BLOCKED_STALE_CHILD"
                    effective = historical_root
                elif not exact_dependencies or not exact_children:
                    state = "CONTRADICTED_RECOMPUTATION_INPUTS"
                    effective = historical_root
                else:
                    state = "RECOMPUTED"
                    effective = row["new_evaluation_root"]
            states[claim_id] = {
                "claim_id": claim_id,
                "historical_evaluation_root": historical_root,
                "effective_evaluation_root": effective,
                "state": state,
                "reason_paths": sorted(paths[claim_id]),
                "recompute_operations": sorted(
                    {dependencies[dep]["recompute_operation"] for dep in claim["dependency_ids"]}
                    | {
                        operation
                        for child in claim["requires_claim_ids"]
                        for operation in states[child]["recompute_operations"]
                    }
                ),
            }
        if not progress:
            for claim_id in remaining:
                claim = claims[claim_id]
                states[claim_id] = {
                    "claim_id": claim_id,
                    "historical_evaluation_root": claim["historical_evaluation_root"],
                    "effective_evaluation_root": claim["historical_evaluation_root"],
                    "state": "CONTRADICTED_DEPENDENCY_CYCLE",
                    "reason_paths": sorted(paths[claim_id]),
                    "recompute_operations": [],
                }
            break
    checks = {"graph.acyclic": "CONTRADICTED" if cyclic else "MATCH"}
    for dependency_id, dependency in dependencies.items():
        checks["dependency.previous." + dependency_id] = (
            "MATCH" if previous_snapshot["roots"][dependency_id] == dependency["historical_root"]
            else "CONTRADICTED"
        )
    checks["snapshot.complete"] = "MATCH" if current_snapshot["complete"] else "INSUFFICIENT"
    for claim_id, row in states.items():
        if row["state"] in {"REUSABLE_UNCHANGED", "RECOMPUTED"}:
            status = "MATCH"
        elif row["state"].startswith("CONTRADICTED") or row["state"] == "BLOCKED_STALE_CHILD":
            status = "CONTRADICTED"
        else:
            status = "INSUFFICIENT"
        checks["claim." + claim_id] = status
    report = multi_check_report(
        checks,
        details={
            "graph_root": graph["graph_root"],
            "previous_snapshot": clone(previous_snapshot),
            "current_snapshot": clone(current_snapshot),
            "claims": [states[key] for key in sorted(states)],
            "historical_evaluations_preserved": True,
            "reuse_rule": "FRESH_PARENT_CANNOT_LAUNDER_STALE_CHILD",
        },
        claim_ceiling="Dependency impact and finite recomputation closure for exact supplied graph and snapshots only; historical evaluations remain historical and no watcher or scheduler is implied.",
    )
    report["schema"] = "cmba.reassessment-result.v2"
    return report
