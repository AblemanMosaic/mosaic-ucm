"""Typed claims, reader recognition, federated evidence, and assurance cases.

The predicates here are structural and finite. They do not infer natural-
language entailment, truth, authority, or operational permission.
"""
from __future__ import annotations

import hashlib
from typing import Any

from .bindings import exact, hex_digest, identifier, validate_reference
from .codec import canonical, clone
from .contract_types import multi_check_report
from .errors import Refusal, require
from .j1.common import recognized, validate_authority


CLAIM_KINDS = {
    "ADOPTION", "OBSERVATION", "CONFORMANCE", "RECOMMENDATION",
    "COUNTEREXAMPLE", "WITHDRAWAL", "ABSTENTION",
}
POLARITIES = {"POSITIVE", "NEGATIVE", "NEUTRAL"}


def _root(domain: str, value: Any) -> str:
    return hashlib.sha256(("CMBA:V2:" + domain + "\0").encode("ascii") + canonical(value)).hexdigest()


def _scope(value: dict[str, Any]) -> None:
    canonical(value)
    exact(value, {"schema", "subject", "actions", "resources", "jurisdictions", "configurations"})
    require(value["schema"] == "cmba.scope.v2", "CMBA_ASSURANCE_SCOPE")
    validate_reference(value["subject"])
    for field in ("actions", "resources", "jurisdictions", "configurations"):
        require(type(value[field]) is list and all(type(item) is str for item in value[field]), "CMBA_ASSURANCE_SCOPE")
        require(value[field] == sorted(set(value[field])), "CMBA_ASSURANCE_SCOPE")


def _evidence(value: dict[str, Any]) -> None:
    canonical(value)
    exact(value, {"schema", "evidence_id", "kind", "sha256", "bytes", "producer", "independence_group"})
    require(value["schema"] == "cmba.evidence-reference.v2", "CMBA_ASSURANCE_EVIDENCE")
    for field in ("evidence_id", "kind", "producer", "independence_group"):
        identifier(value[field])
    hex_digest(value["sha256"])
    require(type(value["bytes"]) is int and type(value["bytes"]) is not bool and value["bytes"] >= 0, "CMBA_ASSURANCE_EVIDENCE")


def statement(
    statement_id: str,
    claim_kind: str,
    proposition_id: str,
    polarity: str,
    subject: dict[str, Any],
    scope: dict[str, Any],
    issuer: dict[str, Any],
    *,
    issued_at: int,
    valid_until: int,
    claim: dict[str, Any],
    evidence: list[dict[str, Any]] | None = None,
    related_statement_roots: list[str] | None = None,
) -> dict[str, Any]:
    """Construct a rooted attribution record; no signature or truth is inferred."""
    for value in (statement_id, proposition_id):
        identifier(value)
    require(claim_kind in CLAIM_KINDS, "CMBA_CLAIM_KIND")
    require(polarity in POLARITIES, "CMBA_CLAIM_POLARITY")
    if claim_kind in {"COUNTEREXAMPLE", "WITHDRAWAL"}:
        require(polarity == "NEGATIVE", "CMBA_CLAIM_POLARITY")
    if claim_kind == "ABSTENTION":
        require(polarity == "NEUTRAL", "CMBA_CLAIM_POLARITY")
    validate_reference(subject)
    _scope(scope)
    require(canonical(scope["subject"]) == canonical(subject), "CMBA_CLAIM_SUBJECT_SCOPE")
    canonical(issuer)
    exact(issuer, {"issuer_id", "public_key", "role", "jurisdiction", "issuer_subject_relation", "declared_independence_group"})
    for field in ("issuer_id", "role", "jurisdiction", "declared_independence_group"):
        identifier(issuer[field])
    require(issuer["issuer_subject_relation"] in {"SELF", "THIRD_PARTY", "UNRESOLVED"}, "CMBA_ISSUER_SUBJECT_RELATION")
    hex_digest(issuer["public_key"])
    require(type(issued_at) is int and type(issued_at) is not bool and issued_at >= 0, "CMBA_CLAIM_TIME")
    require(type(valid_until) is int and type(valid_until) is not bool and issued_at < valid_until, "CMBA_CLAIM_TIME")
    canonical(claim)
    records = evidence or []
    require(type(records) is list and len(records) <= 64, "CMBA_ASSURANCE_EVIDENCE")
    seen_evidence = set()
    for record in records:
        _evidence(record)
        require(record["evidence_id"] not in seen_evidence, "CMBA_ASSURANCE_DUPLICATE")
        seen_evidence.add(record["evidence_id"])
    related = related_statement_roots or []
    require(type(related) is list and len(related) == len(set(related)), "CMBA_ASSURANCE_DUPLICATE")
    for item in related:
        hex_digest(item)
    body = {
        "schema": "cmba.claim-statement-body.v2",
        "statement_id": statement_id,
        "claim_kind": claim_kind,
        "proposition_id": proposition_id,
        "polarity": polarity,
        "subject": clone(subject),
        "scope": clone(scope),
        "issuer": clone(issuer),
        "issued_at": issued_at,
        "valid_until": valid_until,
        "claim": clone(claim),
        "evidence": sorted(clone(records), key=lambda item: item["evidence_id"]),
        "related_statement_roots": sorted(related),
        "interpretation": "ATTRIBUTED_ASSERTION_NOT_NATURAL_LANGUAGE_ENTAILMENT",
        "authority_effect": "NONE",
    }
    return {"schema": "cmba.claim-statement.v2", "body": body, "statement_root": _root("claim-statement", body)}


def validate_statement(value: dict[str, Any]) -> None:
    canonical(value)
    exact(value, {"schema", "body", "statement_root"})
    require(value["schema"] == "cmba.claim-statement.v2", "CMBA_CLAIM_SCHEMA")
    hex_digest(value["statement_root"])
    body = value["body"]
    rebuilt = statement(
        body["statement_id"], body["claim_kind"], body["proposition_id"], body["polarity"],
        body["subject"], body["scope"], body["issuer"], issued_at=body["issued_at"],
        valid_until=body["valid_until"], claim=body["claim"], evidence=body["evidence"],
        related_statement_roots=body["related_statement_roots"],
    )
    require(canonical(rebuilt) == canonical(value), "CMBA_CLAIM_ROOT")


def recognition_context(
    expected_statement_roots: list[str],
    authority_snapshot: dict[str, Any],
    independence_groups: list[dict[str, Any]],
    *,
    now: int,
) -> dict[str, Any]:
    require(type(expected_statement_roots) is list and len(expected_statement_roots) == len(set(expected_statement_roots)), "CMBA_RECOGNITION_ROOTS")
    for item in expected_statement_roots:
        hex_digest(item)
    validate_authority(authority_snapshot)
    require(type(now) is int and type(now) is not bool and now >= 0, "CMBA_CLAIM_TIME")
    require(type(independence_groups) is list, "CMBA_INDEPENDENCE_GROUPS")
    groups = []
    seen_groups = set()
    seen_keys = set()
    for group in independence_groups:
        exact(group, {"group_id", "public_keys"})
        identifier(group["group_id"])
        require(group["group_id"] not in seen_groups, "CMBA_INDEPENDENCE_GROUPS")
        seen_groups.add(group["group_id"])
        require(type(group["public_keys"]) is list and group["public_keys"], "CMBA_INDEPENDENCE_GROUPS")
        for key in group["public_keys"]:
            hex_digest(key)
            require(key not in seen_keys, "CMBA_INDEPENDENCE_KEY_MULTIPLE_GROUPS")
            seen_keys.add(key)
        groups.append({"group_id": group["group_id"], "public_keys": sorted(group["public_keys"])})
    return {
        "schema": "cmba.recognition-context.v2",
        "expected_statement_roots": sorted(expected_statement_roots),
        "authority_snapshot": clone(authority_snapshot),
        "independence_groups": sorted(groups, key=lambda item: item["group_id"]),
        "time": {"epoch": now, "clock_source": "caller-supplied"},
        "authority_effect": "NONE",
    }


def _validate_recognition_context(context: dict[str, Any]) -> None:
    canonical(context)
    exact(context, {"schema", "expected_statement_roots", "authority_snapshot", "independence_groups", "time", "authority_effect"})
    require(context["schema"] == "cmba.recognition-context.v2" and context["authority_effect"] == "NONE", "CMBA_RECOGNITION_CONTEXT")
    rebuilt = recognition_context(
        context["expected_statement_roots"], context["authority_snapshot"], context["independence_groups"],
        now=context["time"]["epoch"],
    )
    require(canonical(rebuilt) == canonical(context), "CMBA_RECOGNITION_CONTEXT")


def recognize_statement(value: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
    validate_statement(value)
    _validate_recognition_context(context)
    body = value["body"]
    issuer = body["issuer"]
    expected = value["statement_root"] in context["expected_statement_roots"]
    time_valid = body["issued_at"] <= context["time"]["epoch"] < body["valid_until"]
    issuer_recognized = recognized(
        context["authority_snapshot"], issuer["public_key"], issuer["role"], issuer["jurisdiction"]
    )
    group = next(
        (item["group_id"] for item in context["independence_groups"] if issuer["public_key"] in item["public_keys"]),
        None,
    )
    status = "RECOGNIZED_FOR_SUPPLIED_READER_CONTEXT" if expected and time_valid and issuer_recognized else "NOT_RECOGNIZED"
    return {
        "schema": "cmba.recognition-result.v2",
        "statement_root": value["statement_root"],
        "status": status,
        "expected_root": expected,
        "time_valid": time_valid,
        "issuer_recognized": issuer_recognized,
        "issuer_id": issuer["issuer_id"],
        "issuer_subject_relation": issuer["issuer_subject_relation"],
        "reader_independence_group": group,
        "declared_independence_group": issuer["declared_independence_group"],
        "signature_verification": "NOT_PART_OF_THIS_PROFILE",
        "semantic_truth": "NOT_ESTABLISHED",
        "authority_effect": "NONE",
    }


def federate(statements: list[dict[str, Any]], context: dict[str, Any]) -> dict[str, Any]:
    require(type(statements) is list and 0 < len(statements) <= 64, "CMBA_FEDERATED_STATEMENTS")
    _validate_recognition_context(context)
    roots = set()
    rows = []
    by_proposition: dict[str, list[tuple[dict[str, Any], dict[str, Any]]]] = {}
    for value in statements:
        validate_statement(value)
        require(value["statement_root"] not in roots, "CMBA_ASSURANCE_DUPLICATE")
        roots.add(value["statement_root"])
        result = recognize_statement(value, context)
        rows.append({"statement": clone(value), "recognition": result})
        by_proposition.setdefault(value["body"]["proposition_id"], []).append((value, result))
    propositions = []
    for proposition_id in sorted(by_proposition):
        entries = by_proposition[proposition_id]
        recognized_entries = [(value, result) for value, result in entries if result["status"] == "RECOGNIZED_FOR_SUPPLIED_READER_CONTEXT"]
        groups = sorted({result["reader_independence_group"] for _, result in recognized_entries if result["reader_independence_group"] is not None})
        polarities = sorted({value["body"]["polarity"] for value, _ in recognized_entries})
        conflict = "POSITIVE" in polarities and "NEGATIVE" in polarities
        negative_witnesses = sorted(
            value["statement_root"] for value, _ in entries
            if value["body"]["polarity"] == "NEGATIVE"
        )
        propositions.append({
            "proposition_id": proposition_id,
            "statement_roots": sorted(value["statement_root"] for value, _ in entries),
            "recognized_statement_roots": sorted(value["statement_root"] for value, _ in recognized_entries),
            "recognized_independence_groups": groups,
            "independent_group_count": len(groups),
            "recognized_polarities": polarities,
            "conflict": conflict,
            "negative_witnesses": negative_witnesses,
        })
    return {
        "schema": "cmba.federated-evidence-result.v2",
        "statements": rows,
        "propositions": propositions,
        "duplicate_or_dependent_reports": "COUNT_ONCE_PER_READER_SELECTED_INDEPENDENCE_GROUP",
        "semantic_truth": "NOT_ESTABLISHED",
        "authority_effect": "NONE",
    }


def assurance_case(
    case_id: str,
    subject: dict[str, Any],
    scope: dict[str, Any],
    statements: list[dict[str, Any]],
    requirements: list[dict[str, Any]],
    support_edges: list[dict[str, Any]],
    defeaters: list[dict[str, Any]],
    dependencies: list[dict[str, Any]],
    *,
    coverage_claim_ids: list[str] | None = None,
) -> dict[str, Any]:
    identifier(case_id)
    validate_reference(subject)
    _scope(scope)
    require(canonical(scope["subject"]) == canonical(subject), "CMBA_CLAIM_SUBJECT_SCOPE")
    require(type(statements) is list and statements, "CMBA_ASSURANCE_STATEMENTS")
    statement_roots = set()
    proposition_ids = set()
    for item in statements:
        validate_statement(item)
        require(canonical(item["body"]["subject"]) == canonical(subject), "CMBA_ASSURANCE_SUBJECT")
        require(item["statement_root"] not in statement_roots, "CMBA_ASSURANCE_DUPLICATE")
        statement_roots.add(item["statement_root"])
        proposition_ids.add(item["body"]["proposition_id"])
    require(type(requirements) is list and requirements, "CMBA_ASSURANCE_REQUIREMENTS")
    seen_requirements = set()
    for item in requirements:
        exact(item, {"proposition_id", "required_polarity", "minimum_independent_groups", "required_evidence_kinds"})
        identifier(item["proposition_id"])
        require(item["proposition_id"] in proposition_ids and item["proposition_id"] not in seen_requirements, "CMBA_ASSURANCE_REQUIREMENTS")
        seen_requirements.add(item["proposition_id"])
        require(item["required_polarity"] in POLARITIES, "CMBA_ASSURANCE_REQUIREMENTS")
        require(type(item["minimum_independent_groups"]) is int and type(item["minimum_independent_groups"]) is not bool and item["minimum_independent_groups"] >= 0, "CMBA_ASSURANCE_REQUIREMENTS")
        require(type(item["required_evidence_kinds"]) is list and item["required_evidence_kinds"] == sorted(set(item["required_evidence_kinds"])), "CMBA_ASSURANCE_REQUIREMENTS")
        for kind in item["required_evidence_kinds"]:
            identifier(kind)
    require(type(support_edges) is list and len(support_edges) <= 128, "CMBA_ASSURANCE_SUPPORT")
    for edge in support_edges:
        exact(edge, {"source_kind", "source_id", "target_proposition_id"})
        require(edge["source_kind"] in {"PROPOSITION", "EVIDENCE"}, "CMBA_ASSURANCE_SUPPORT")
        identifier(edge["source_id"])
        require(edge["target_proposition_id"] in proposition_ids, "CMBA_ASSURANCE_SUPPORT")
    require(type(defeaters) is list and len(defeaters) <= 64, "CMBA_ASSURANCE_DEFEATERS")
    seen_defeaters = set()
    for item in defeaters:
        exact(item, {"defeater_id", "target_proposition_id", "witness_statement_root", "status", "resolution_evidence_ids"})
        identifier(item["defeater_id"])
        require(item["defeater_id"] not in seen_defeaters, "CMBA_ASSURANCE_DUPLICATE")
        seen_defeaters.add(item["defeater_id"])
        require(item["target_proposition_id"] in proposition_ids, "CMBA_ASSURANCE_DEFEATERS")
        require(item["witness_statement_root"] in statement_roots, "CMBA_ASSURANCE_DEFEATERS")
        require(item["status"] in {"OPEN", "RESOLVED"}, "CMBA_ASSURANCE_DEFEATERS")
        require(type(item["resolution_evidence_ids"]) is list and item["resolution_evidence_ids"] == sorted(set(item["resolution_evidence_ids"])), "CMBA_ASSURANCE_DEFEATERS")
    require(type(dependencies) is list and len(dependencies) <= 64, "CMBA_ASSURANCE_DEPENDENCIES")
    seen_dependencies = set()
    for item in dependencies:
        exact(item, {"dependency_id", "root", "critical", "disclosed"})
        identifier(item["dependency_id"])
        require(item["dependency_id"] not in seen_dependencies, "CMBA_ASSURANCE_DUPLICATE")
        seen_dependencies.add(item["dependency_id"])
        hex_digest(item["root"])
        require(type(item["critical"]) is bool and type(item["disclosed"]) is bool, "CMBA_ASSURANCE_DEPENDENCIES")
    coverage = coverage_claim_ids if coverage_claim_ids is not None else sorted(proposition_ids)
    require(type(coverage) is list and coverage == sorted(set(coverage)) and set(coverage) <= proposition_ids, "CMBA_ASSURANCE_COVERAGE")
    body = {
        "schema": "cmba.assurance-case-body.v2",
        "case_id": case_id,
        "subject": clone(subject),
        "scope": clone(scope),
        "statements": sorted(clone(statements), key=lambda item: item["statement_root"]),
        "requirements": sorted(clone(requirements), key=lambda item: item["proposition_id"]),
        "support_edges": sorted(clone(support_edges), key=lambda item: (item["target_proposition_id"], item["source_kind"], item["source_id"])),
        "defeaters": sorted(clone(defeaters), key=lambda item: item["defeater_id"]),
        "dependencies": sorted(clone(dependencies), key=lambda item: item["dependency_id"]),
        "coverage_claim_ids": coverage,
        "entailment": "STRUCTURAL_SUPPORT_ONLY_NO_ARBITRARY_PROSE_ENTAILMENT",
        "authority_effect": "NONE",
    }
    return {"schema": "cmba.assurance-case.v2", "body": body, "case_root": _root("assurance-case", body)}


def validate_case(value: dict[str, Any]) -> None:
    canonical(value)
    exact(value, {"schema", "body", "case_root"})
    require(value["schema"] == "cmba.assurance-case.v2", "CMBA_ASSURANCE_SCHEMA")
    hex_digest(value["case_root"])
    body = value["body"]
    rebuilt = assurance_case(
        body["case_id"], body["subject"], body["scope"], body["statements"], body["requirements"],
        body["support_edges"], body["defeaters"], body["dependencies"],
        coverage_claim_ids=body["coverage_claim_ids"],
    )
    require(canonical(rebuilt) == canonical(value), "CMBA_ASSURANCE_ROOT")


def _has_cycle(propositions: set[str], edges: list[dict[str, Any]]) -> bool:
    graph = {item: [] for item in propositions}
    for edge in edges:
        if edge["source_kind"] == "PROPOSITION":
            require(edge["source_id"] in propositions, "CMBA_ASSURANCE_SUPPORT")
            graph[edge["source_id"]].append(edge["target_proposition_id"])
    visiting = set()
    visited = set()
    def visit(node: str) -> bool:
        if node in visiting:
            return True
        if node in visited:
            return False
        visiting.add(node)
        if any(visit(child) for child in graph[node]):
            return True
        visiting.remove(node)
        visited.add(node)
        return False
    return any(visit(node) for node in graph)


def evaluate_assurance(
    value: dict[str, Any],
    context: dict[str, Any],
    *,
    requested_scope: dict[str, Any],
    advertised_claim_ids: list[str],
) -> dict[str, Any]:
    validate_case(value)
    _validate_recognition_context(context)
    _scope(requested_scope)
    body = value["body"]
    require(canonical(requested_scope) == canonical(body["scope"]), "CMBA_ASSURANCE_SCOPE_MISMATCH")
    require(type(advertised_claim_ids) is list and advertised_claim_ids == sorted(set(advertised_claim_ids)), "CMBA_ASSURANCE_COVERAGE")
    require(set(advertised_claim_ids) <= set(body["coverage_claim_ids"]), "CMBA_ASSURANCE_COVERAGE_EXPANSION")
    federation = federate(body["statements"], context)
    proposition_rows = {item["proposition_id"]: item for item in federation["propositions"]}
    all_evidence = {
        evidence["evidence_id"]: evidence
        for statement_value in body["statements"]
        for evidence in statement_value["body"]["evidence"]
    }
    supported_evidence: dict[str, set[str]] = {item: set() for item in proposition_rows}
    for edge in body["support_edges"]:
        if edge["source_kind"] == "EVIDENCE":
            require(edge["source_id"] in all_evidence, "CMBA_ASSURANCE_SUPPORT")
            supported_evidence[edge["target_proposition_id"]].add(edge["source_id"])
    checks: dict[str, str] = {}
    cycle = _has_cycle(set(proposition_rows), body["support_edges"])
    checks["support.acyclic"] = "CONTRADICTED" if cycle else "MATCH"
    evidence_ids = set(all_evidence)
    for requirement in body["requirements"]:
        proposition_id = requirement["proposition_id"]
        row = proposition_rows[proposition_id]
        prefix = "claim." + proposition_id
        checks[prefix + ".recognized"] = "MATCH" if row["recognized_statement_roots"] else "INSUFFICIENT"
        checks[prefix + ".independence"] = (
            "MATCH" if row["independent_group_count"] >= requirement["minimum_independent_groups"] else "INSUFFICIENT"
        )
        checks[prefix + ".polarity"] = (
            "CONTRADICTED" if row["conflict"]
            else "MATCH" if requirement["required_polarity"] in row["recognized_polarities"]
            else "INSUFFICIENT"
        )
        kinds = {all_evidence[item]["kind"] for item in supported_evidence[proposition_id]}
        checks[prefix + ".evidence"] = (
            "MATCH" if set(requirement["required_evidence_kinds"]) <= kinds else "INSUFFICIENT"
        )
    for defeater in body["defeaters"]:
        key = "defeater." + defeater["defeater_id"]
        if defeater["status"] == "OPEN":
            checks[key] = "CONTRADICTED"
        else:
            checks[key] = "MATCH" if defeater["resolution_evidence_ids"] and set(defeater["resolution_evidence_ids"]) <= evidence_ids else "INSUFFICIENT"
    missing_critical = sorted(item["dependency_id"] for item in body["dependencies"] if item["critical"] and not item["disclosed"])
    checks["dependencies.critical-disclosure"] = "MATCH" if not missing_critical else "INSUFFICIENT"
    report = multi_check_report(
        checks,
        details={
            "case_root": value["case_root"],
            "federated_evidence": federation,
            "missing_critical_dependencies": missing_critical,
            "coverage_claim_ids": body["coverage_claim_ids"],
            "advertised_claim_ids": advertised_claim_ids,
            "entailment": body["entailment"],
        },
        claim_ceiling="Finite structural support, reader recognition, independence-group counting, conflicts, evidence kinds, defeaters, scope and coverage only; no arbitrary prose entailment, truth or permission.",
    )
    report["schema"] = "cmba.assurance-result.v2"
    return report


def selective_view(value: dict[str, Any], claim_ids: list[str], evidence_ids: list[str]) -> dict[str, Any]:
    validate_case(value)
    require(type(claim_ids) is list and claim_ids == sorted(set(claim_ids)), "CMBA_ASSURANCE_COVERAGE")
    require(type(evidence_ids) is list and evidence_ids == sorted(set(evidence_ids)), "CMBA_ASSURANCE_EVIDENCE")
    body = value["body"]
    require(set(claim_ids) <= set(body["coverage_claim_ids"]), "CMBA_ASSURANCE_COVERAGE_EXPANSION")
    statements = []
    for item in body["statements"]:
        if item["body"]["proposition_id"] in claim_ids:
            selected_evidence = [record for record in item["body"]["evidence"] if record["evidence_id"] in evidence_ids]
            b = item["body"]
            statements.append(statement(
                b["statement_id"], b["claim_kind"], b["proposition_id"], b["polarity"], b["subject"],
                b["scope"], b["issuer"], issued_at=b["issued_at"], valid_until=b["valid_until"],
                claim=b["claim"], evidence=selected_evidence, related_statement_roots=b["related_statement_roots"],
            ))
    selected_roots = {item["statement_root"] for item in statements}
    requirements = [item for item in body["requirements"] if item["proposition_id"] in claim_ids]
    edges = [
        item for item in body["support_edges"]
        if item["target_proposition_id"] in claim_ids
        and (item["source_kind"] != "EVIDENCE" or item["source_id"] in evidence_ids)
        and (item["source_kind"] != "PROPOSITION" or item["source_id"] in claim_ids)
    ]
    defeaters = [
        item for item in body["defeaters"]
        if item["target_proposition_id"] in claim_ids and item["witness_statement_root"] in selected_roots
    ]
    return assurance_case(
        body["case_id"] + ".selected", body["subject"], body["scope"], statements, requirements,
        edges, defeaters, body["dependencies"], coverage_claim_ids=claim_ids,
    )
