"""Finite CMBA declarations and assessments for selected UCM contracts.

AMCAS constitutive units, legacy UCL operational records, GOORRT
representations, supplied-case correspondence, and operation histories remain
separate record families.  The module performs no connection, compilation,
signature issuance, permit creation, or effect.
"""
from __future__ import annotations

import hashlib
from typing import Any

from .bindings import exact, hex_digest, identifier
from .codec import canonical, clone
from .contract_types import multi_check_report
from .errors import require


UNIT_SCHEMAS = {
    ("CRU", "AMCAS_CONSTITUTIVE"): "amcas.constitutive.cru.v1",
    ("BCR", "AMCAS_CONSTITUTIVE"): "amcas.constitutive.bcr.v1",
    ("CRU", "LEGACY_UCL_OPERATIONAL"): "ucl.cru.v1",
    ("BCR", "LEGACY_UCL_OPERATIONAL"): "ucl.bcr.v1",
    ("STANDARD", "AMCAS_STANDARD"): "amcas.standard-unit.v1",
    ("PROFILE", "UCM_PROFILE"): "ucm.profile-unit.v1",
}
RELATIONS = {"REQUIRES", "CONSTITUTES", "BOUNDS", "IMPLEMENTS", "PROVIDES", "CONSUMES"}
EVIDENCE_CLASSES = {"STATIC_DECLARATION", "IMPLEMENTATION_BINDING", "OBSERVED_RUNTIME"}
REPRESENTATIONS = {"GOML", "GSOL", "CEIR", "MCIR"}
SEMANTIC_SUPPORT = {"NATIVE_VERIFIED", "STRUCTURAL_ONLY", "UNRESOLVED", "UNSUPPORTED"}


def _root(domain: str, value: Any) -> str:
    return hashlib.sha256(("CMBA:UCM:v2:" + domain + "\0").encode("ascii") + canonical(value)).hexdigest()


def _ids(values: list[str], code: str, *, allow_empty: bool = False) -> list[str]:
    require(type(values) is list and (allow_empty or values) and values == sorted(set(values)), code)
    for value in values:
        identifier(value)
    return list(values)


def constitution(
    constitution_id: str,
    standard_root: str,
    units: list[dict[str, Any]],
    relations: list[dict[str, Any]],
    compositions: list[dict[str, Any]],
    implementation_bindings: list[dict[str, Any]],
) -> dict[str, Any]:
    identifier(constitution_id)
    hex_digest(standard_root)
    require(type(units) is list and units and len(units) <= 128, "CMBA_UCM_UNITS")
    unit_rows = []
    unit_ids = set()
    for raw in units:
        exact(raw, {"unit_id", "unit_kind", "origin", "schema_id", "record_root", "evidence_class"})
        identifier(raw["unit_id"])
        require(raw["unit_id"] not in unit_ids, "CMBA_UCM_UNIT_DUPLICATE")
        unit_ids.add(raw["unit_id"])
        expected_schema = UNIT_SCHEMAS.get((raw["unit_kind"], raw["origin"]))
        require(expected_schema is not None and raw["schema_id"] == expected_schema, "CMBA_UCM_UNIT_SCHEMA_SUBSTITUTION")
        hex_digest(raw["record_root"])
        require(raw["evidence_class"] in EVIDENCE_CLASSES, "CMBA_UCM_EVIDENCE_CLASS")
        unit_rows.append(clone(raw))
    relation_rows = []
    relation_ids = set()
    require(type(relations) is list and len(relations) <= 256, "CMBA_UCM_RELATIONS")
    for raw in relations:
        exact(raw, {"relation_id", "relation_type", "from_unit_id", "to_unit_id", "relation_root"})
        identifier(raw["relation_id"])
        require(raw["relation_id"] not in relation_ids and raw["relation_type"] in RELATIONS, "CMBA_UCM_RELATION")
        relation_ids.add(raw["relation_id"])
        require(raw["from_unit_id"] in unit_ids and raw["to_unit_id"] in unit_ids, "CMBA_UCM_RELATION_ENDPOINT")
        hex_digest(raw["relation_root"])
        relation_rows.append(clone(raw))
    composition_rows = []
    composition_ids = set()
    require(type(compositions) is list and len(compositions) <= 64, "CMBA_UCM_COMPOSITIONS")
    for raw in compositions:
        exact(raw, {"composition_id", "composition_kind", "unit_ids", "composition_root"})
        identifier(raw["composition_id"])
        require(raw["composition_id"] not in composition_ids, "CMBA_UCM_COMPOSITION_DUPLICATE")
        composition_ids.add(raw["composition_id"])
        require(raw["composition_kind"] in {"TYPED_SET", "ORDERED_PIPELINE", "DEPENDENCY_CLOSURE"}, "CMBA_UCM_COMPOSITION_KIND")
        members = _ids(raw["unit_ids"], "CMBA_UCM_COMPOSITION_MEMBERS")
        require(set(members) <= unit_ids, "CMBA_UCM_COMPOSITION_ENDPOINT")
        hex_digest(raw["composition_root"])
        composition_rows.append({**clone(raw), "unit_ids": members})
    bindings = []
    bound_units = set()
    require(type(implementation_bindings) is list and len(implementation_bindings) <= 128, "CMBA_UCM_BINDINGS")
    for raw in implementation_bindings:
        exact(raw, {"unit_id", "implementation_root", "evidence_class", "evidence_roots"})
        require(raw["unit_id"] in unit_ids and raw["unit_id"] not in bound_units, "CMBA_UCM_BINDING_UNIT")
        bound_units.add(raw["unit_id"])
        hex_digest(raw["implementation_root"])
        require(raw["evidence_class"] in EVIDENCE_CLASSES, "CMBA_UCM_EVIDENCE_CLASS")
        require(type(raw["evidence_roots"]) is list and raw["evidence_roots"] == sorted(set(raw["evidence_roots"])), "CMBA_UCM_EVIDENCE_ROOTS")
        for value in raw["evidence_roots"]:
            hex_digest(value)
        bindings.append(clone(raw))
    body = {
        "schema": "cmba.ucm-constitution-body.v2", "constitution_id": constitution_id,
        "standard_root": standard_root,
        "units": sorted(unit_rows, key=lambda row: row["unit_id"]),
        "relations": sorted(relation_rows, key=lambda row: row["relation_id"]),
        "compositions": sorted(composition_rows, key=lambda row: row["composition_id"]),
        "implementation_bindings": sorted(bindings, key=lambda row: row["unit_id"]),
        "constitutive_operational_crosswalk": "EXPLICIT_NEW_CONTRACT_REQUIRED",
        "authority_effect": "NONE",
    }
    return {"schema": "cmba.ucm-constitution.v2", "body": body, "constitution_root": _root("constitution", body)}


def validate_constitution(value: dict[str, Any]) -> None:
    canonical(value)
    exact(value, {"schema", "body", "constitution_root"})
    require(value["schema"] == "cmba.ucm-constitution.v2", "CMBA_UCM_CONSTITUTION_SCHEMA")
    body = value["body"]
    rebuilt = constitution(
        body["constitution_id"], body["standard_root"], body["units"], body["relations"],
        body["compositions"], body["implementation_bindings"],
    )
    require(canonical(rebuilt) == canonical(value), "CMBA_UCM_CONSTITUTION_ROOT")


def assess_obligations(
    source_contract_root: str,
    expected_obligations: list[dict[str, Any]],
    compiled_contract_root: str,
    compiled_obligations: list[dict[str, Any]],
    *,
    predecessor_contract_root: str | None = None,
) -> dict[str, Any]:
    for value in (source_contract_root, compiled_contract_root):
        hex_digest(value)
    require(predecessor_contract_root is None or (hex_digest(predecessor_contract_root) and True), "CMBA_UCM_PREDECESSOR")
    def admit(values, code):
        require(type(values) is list and len(values) <= 128, code)
        result = {}
        for raw in values:
            exact(raw, {"obligation_id", "subject_root", "kind", "required_evidence"})
            identifier(raw["obligation_id"])
            require(raw["obligation_id"] not in result, code)
            hex_digest(raw["subject_root"])
            identifier(raw["kind"])
            evidence = _ids(raw["required_evidence"], code, allow_empty=True)
            result[raw["obligation_id"]] = {**clone(raw), "required_evidence": evidence}
        return result
    expected = admit(expected_obligations, "CMBA_UCM_EXPECTED_OBLIGATIONS")
    observed = admit(compiled_obligations, "CMBA_UCM_COMPILED_OBLIGATIONS")
    rows = []
    checks = {}
    for obligation_id in sorted(set(expected) | set(observed)):
        left, right = expected.get(obligation_id), observed.get(obligation_id)
        if left is None:
            status, reason = "CONTRADICTED", "UNEXPECTED_OBLIGATION"
        elif right is None:
            status, reason = "CONTRADICTED", "MISSING_OBLIGATION"
        elif canonical(left) != canonical(right):
            status, reason = "CONTRADICTED", "RETARGETED_OR_CHANGED_OBLIGATION"
        else:
            status, reason = "MATCH", "EXACT"
        checks["obligation." + obligation_id] = status
        rows.append({"obligation_id": obligation_id, "status": reason, "expected": left, "compiled": right})
    result = multi_check_report(
        checks or {"obligations.denominator": "MATCH"},
        details={
            "source_contract_root": source_contract_root,
            "compiled_contract_root": compiled_contract_root,
            "predecessor_contract_root": predecessor_contract_root,
            "successor_contract": predecessor_contract_root is not None and predecessor_contract_root != source_contract_root,
            "obligations": rows,
            "preference_can_override_hard_failure": False,
            "execution_authorized": False,
        },
        claim_ceiling="Exact obligation identifier, subject, kind and evidence-set correspondence for one source and compiled contract only; no semantic entailment or effect authority.",
    )
    result["schema"] = "cmba.ucm-amcas-obligation-assessment.v2"
    return result


def assess_evidence_class(requirement_id: str, required_class: str, supplied_bindings: list[dict[str, Any]]) -> dict[str, Any]:
    identifier(requirement_id)
    require(required_class in EVIDENCE_CLASSES, "CMBA_UCM_EVIDENCE_CLASS")
    require(type(supplied_bindings) is list, "CMBA_UCM_EVIDENCE_BINDINGS")
    supplied = []
    for raw in supplied_bindings:
        exact(raw, {"binding_root", "evidence_class"})
        hex_digest(raw["binding_root"])
        require(raw["evidence_class"] in EVIDENCE_CLASSES, "CMBA_UCM_EVIDENCE_CLASS")
        supplied.append(clone(raw))
    matched = any(row["evidence_class"] == required_class for row in supplied)
    result = multi_check_report(
        {"evidence.class": "MATCH" if matched else "INSUFFICIENT"},
        details={"requirement_id": requirement_id, "required_class": required_class, "supplied": supplied, "class_promotion": False},
        claim_ceiling="Evidence-class equality only; static declarations and implementation bindings cannot satisfy observed-runtime requirements.",
    )
    result["schema"] = "cmba.ucm-evidence-class-assessment.v2"
    return result


def interface_declaration(
    interface_id: str,
    provider_id: str,
    consumer_id: str,
    provider_interface_root: str,
    consumer_accepted_interface_root: str,
    provider_schema_root: str,
    consumer_accepted_schema_root: str,
    *,
    invitation_root: str | None = None,
) -> dict[str, Any]:
    for value in (interface_id, provider_id, consumer_id):
        identifier(value)
    for value in (provider_interface_root, consumer_accepted_interface_root, provider_schema_root, consumer_accepted_schema_root):
        hex_digest(value)
    require(invitation_root is None or (hex_digest(invitation_root) and True), "CMBA_UCM_INVITATION")
    body = {
        "schema": "cmba.ucm-interface-declaration-body.v2", "interface_id": interface_id,
        "provider_id": provider_id, "consumer_id": consumer_id,
        "provider_interface_root": provider_interface_root,
        "consumer_accepted_interface_root": consumer_accepted_interface_root,
        "provider_schema_root": provider_schema_root,
        "consumer_accepted_schema_root": consumer_accepted_schema_root,
        "invitation_root": invitation_root,
        "interface_match": provider_interface_root == consumer_accepted_interface_root,
        "schema_match": provider_schema_root == consumer_accepted_schema_root,
        "live_connection": False, "permit_created": False, "authority_effect": "NONE",
    }
    return {"schema": "cmba.ucm-interface-declaration.v2", "body": body, "declaration_root": _root("interface", body)}


def goorrt_declaration(declaration_id: str, representations: list[dict[str, Any]], correspondences: list[dict[str, Any]]) -> dict[str, Any]:
    identifier(declaration_id)
    require(type(representations) is list and representations, "CMBA_UCM_REPRESENTATIONS")
    rows = []
    by_id = {}
    for raw in representations:
        exact(raw, {"representation_id", "kind", "contract_root", "source_variant", "support"})
        identifier(raw["representation_id"])
        require(raw["representation_id"] not in by_id and raw["kind"] in REPRESENTATIONS, "CMBA_UCM_REPRESENTATION")
        hex_digest(raw["contract_root"])
        require(type(raw["source_variant"]) is str and raw["source_variant"], "CMBA_UCM_SOURCE_VARIANT")
        require(raw["support"] in SEMANTIC_SUPPORT, "CMBA_UCM_SEMANTIC_SUPPORT")
        if raw["kind"] == "MCIR" and raw["source_variant"] == "EXPANSION_VARIANT_UNRESOLVED":
            require(raw["support"] in {"UNRESOLVED", "UNSUPPORTED"}, "CMBA_UCM_MCIR_INFERENCE")
        by_id[raw["representation_id"]] = raw
        rows.append(clone(raw))
    edges = []
    require(type(correspondences) is list and len(correspondences) <= 128, "CMBA_UCM_CORRESPONDENCES")
    for raw in correspondences:
        exact(raw, {"correspondence_id", "from_representation_id", "to_representation_id", "relation", "evidence_root"})
        identifier(raw["correspondence_id"])
        require(raw["from_representation_id"] in by_id and raw["to_representation_id"] in by_id, "CMBA_UCM_CORRESPONDENCE_ENDPOINT")
        require(raw["relation"] in {"REPRESENTS", "LOWERS", "CHECKS", "CORRESPONDS"}, "CMBA_UCM_CORRESPONDENCE_RELATION")
        hex_digest(raw["evidence_root"])
        edges.append(clone(raw))
    body = {
        "schema": "cmba.ucm-goorrt-declaration-body.v2", "declaration_id": declaration_id,
        "representations": sorted(rows, key=lambda row: row["representation_id"]),
        "correspondences": sorted(edges, key=lambda row: row["correspondence_id"]),
        "name_matching_implies_semantics": False, "authority_effect": "NONE",
    }
    return {"schema": "cmba.ucm-goorrt-declaration.v2", "body": body, "declaration_root": _root("goorrt", body)}


def assess_correspondence(
    report_id: str,
    supplied_cases: list[dict[str, Any]],
    *,
    producer_evidence_root: str | None,
    producer_verified: bool,
) -> dict[str, Any]:
    identifier(report_id)
    require(producer_evidence_root is None or (hex_digest(producer_evidence_root) and True), "CMBA_UCM_PRODUCER_EVIDENCE")
    require(type(producer_verified) is bool, "CMBA_UCM_PRODUCER_EVIDENCE")
    require(type(supplied_cases) is list and supplied_cases, "CMBA_UCM_CASES")
    checks = {}
    rows = []
    for raw in supplied_cases:
        exact(raw, {"case_id", "left_root", "right_root", "left_result_root", "right_result_root", "refusal_semantics_equal"})
        identifier(raw["case_id"])
        for name in ("left_root", "right_root", "left_result_root", "right_result_root"):
            hex_digest(raw[name])
        require(type(raw["refusal_semantics_equal"]) is bool, "CMBA_UCM_CASE")
        equal = raw["left_result_root"] == raw["right_result_root"] and raw["refusal_semantics_equal"]
        checks["case." + raw["case_id"]] = "MATCH" if equal else "CONTRADICTED"
        rows.append({**clone(raw), "record_correspondence": equal})
    result = multi_check_report(
        checks,
        details={
            "report_id": report_id, "cases": rows,
            "producer_evidence_root": producer_evidence_root,
            "producer_verified": producer_verified,
            "claim_kind": "EXECUTION_CORRESPONDENCE" if producer_evidence_root and producer_verified else "RECORD_CORRESPONDENCE",
            "permit_created": False, "authority_effect": "NONE",
        },
        claim_ceiling="Equality and refusal correspondence for exact supplied cases; execution correspondence additionally requires supplied verified producer evidence and never creates a permit.",
    )
    result["schema"] = "cmba.ucm-correspondence-assessment.v2"
    return result


def assess_operation_history(
    operation_id: str,
    events: list[dict[str, Any]],
    *,
    expected_issuer_root: str,
    expected_jurisdiction_root: str,
    expected_revocation_root: str,
) -> dict[str, Any]:
    identifier(operation_id)
    for value in (expected_issuer_root, expected_jurisdiction_root, expected_revocation_root):
        hex_digest(value)
    require(type(events) is list and events, "CMBA_UCM_OPERATION_EVENTS")
    stages = []
    previous = None
    checks = {}
    terminal = False
    for sequence, raw in enumerate(events, 1):
        exact(raw, {"event_id", "sequence", "previous_event_root", "stage", "issuer_root", "jurisdiction_root", "revocation_root", "signature_status", "event_root"})
        identifier(raw["event_id"])
        require(raw["stage"] in {"G1", "G2", "G3", "CANCELLED", "UNCERTAIN"}, "CMBA_UCM_OPERATION_STAGE")
        for name in ("issuer_root", "jurisdiction_root", "revocation_root", "event_root"):
            hex_digest(raw[name])
        require(raw["previous_event_root"] is None or (hex_digest(raw["previous_event_root"]) and True), "CMBA_UCM_OPERATION_PREDECESSOR")
        require(raw["signature_status"] in {"VERIFIED", "INVALID", "UNAVAILABLE"}, "CMBA_UCM_SIGNATURE_STATUS")
        prefix = f"event.{sequence}."
        checks[prefix + "sequence"] = "MATCH" if raw["sequence"] == sequence else "CONTRADICTED"
        checks[prefix + "predecessor"] = "MATCH" if raw["previous_event_root"] == previous else "CONTRADICTED"
        checks[prefix + "issuer"] = "MATCH" if raw["issuer_root"] == expected_issuer_root else "CONTRADICTED"
        checks[prefix + "jurisdiction"] = "MATCH" if raw["jurisdiction_root"] == expected_jurisdiction_root else "CONTRADICTED"
        checks[prefix + "revocation"] = "MATCH" if raw["revocation_root"] == expected_revocation_root else "CONTRADICTED"
        checks[prefix + "signature"] = "MATCH" if raw["signature_status"] == "VERIFIED" else "CONTRADICTED" if raw["signature_status"] == "INVALID" else "INSUFFICIENT"
        previous = raw["event_root"]
        terminal = raw["stage"] in {"G3", "CANCELLED"}
        stages.append(raw["stage"])
    checks["history.terminal"] = "MATCH" if terminal else "INSUFFICIENT"
    result = multi_check_report(
        checks,
        details={
            "operation_id": operation_id, "stages": stages, "final_event_root": previous,
            "history_scope": "COMPLETE" if terminal else "VALID_PARTIAL_HISTORY",
            "completion_claim": terminal,
            "permit_created": False,
            "unavailable_native_validator": "UNSUPPORTED_NOT_PROMOTED",
        },
        claim_ceiling="Exact supplied operation-event chain and independent issuer, jurisdiction, revocation and signature-status anchors only; partial histories remain partial and verification creates no permit.",
    )
    result["schema"] = "cmba.ucm-operation-history-assessment.v2"
    return result


def support_inventory(inventory_id: str, entries: list[dict[str, Any]], expected_capability_ids: list[str]) -> dict[str, Any]:
    identifier(inventory_id)
    expected = _ids(expected_capability_ids, "CMBA_UCM_INVENTORY_DENOMINATOR")
    require(type(entries) is list, "CMBA_UCM_INVENTORY")
    rows = {}
    for raw in entries:
        exact(raw, {"capability_id", "disposition", "adapter_id", "evidence_roots"})
        identifier(raw["capability_id"])
        require(raw["capability_id"] not in rows and raw["disposition"] in {"NATIVE_VERIFIED", "STRUCTURAL", "DECLARATION_ONLY", "UNSUPPORTED"}, "CMBA_UCM_INVENTORY")
        require(raw["adapter_id"] is None or (identifier(raw["adapter_id"]) and True), "CMBA_UCM_INVENTORY_ADAPTER")
        for value in raw["evidence_roots"]:
            hex_digest(value)
        rows[raw["capability_id"]] = clone(raw)
    missing = sorted(set(expected) - set(rows))
    extra = sorted(set(rows) - set(expected))
    body = {
        "schema": "cmba.ucm-support-inventory-body.v2", "inventory_id": inventory_id,
        "expected_capability_ids": expected,
        "entries": [rows[key] for key in sorted(rows)], "missing_capability_ids": missing,
        "unexpected_capability_ids": extra, "total": not missing and not extra,
        "unsupported_promoted": False, "authority_effect": "NONE",
    }
    return {"schema": "cmba.ucm-support-inventory.v2", "body": body, "inventory_root": _root("inventory", body)}
