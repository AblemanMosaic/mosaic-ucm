"""Release and realization qualification over exact supplied evidence bytes."""
from __future__ import annotations

import hashlib
from typing import Any

from .bindings import exact, hex_digest, identifier
from .codec import canonical, clone, decode
from .contract_types import multi_check_report
from .errors import require


EVIDENCE_CLASSES = {
    "RELEASE_ENVELOPE", "SOURCE_TEST", "INSTALLED_WHEEL_PROBE", "REPRODUCIBILITY",
    "REVIEW", "PUBLICATION", "NATIVE_OBSERVATION", "EXTERNAL_ACCEPTANCE", "FAILED_ATTEMPT",
}
EVIDENCE_STANDINGS = {"SAME_AUTHOR", "NATIVE", "INDEPENDENT", "EXTERNAL_OBSERVATION", "EXTERNAL_ACCEPTANCE"}
GATES = {
    "EXACT_ARTIFACTS", "SOURCE_TESTS", "INSTALLED_WHEEL", "REPRODUCIBLE_BUILD",
    "INDEPENDENT_REVIEW", "PUBLICATION",
}


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _root(domain: str, value: Any) -> str:
    return hashlib.sha256(("CMBA:V2:" + domain + "\0").encode("ascii") + canonical(value)).hexdigest()


def artifact(artifact_id: str, kind: str, name: str, size: int, sha256: str) -> dict[str, Any]:
    for value in (artifact_id, kind):
        identifier(value)
    require(type(name) is str and 0 < len(name) <= 256, "CMBA_RELEASE_ARTIFACT")
    require(type(size) is int and type(size) is not bool and size >= 0, "CMBA_RELEASE_ARTIFACT")
    hex_digest(sha256)
    return {"artifact_id": artifact_id, "kind": kind, "name": name, "bytes": size, "sha256": sha256}


def evidence(
    evidence_id: str,
    evidence_class: str,
    name: str,
    size: int,
    sha256: str,
    *,
    producer: str,
    standing: str,
    subject_artifact_ids: list[str],
) -> dict[str, Any]:
    identifier(evidence_id)
    require(evidence_class in EVIDENCE_CLASSES, "CMBA_RELEASE_EVIDENCE_CLASS")
    require(type(name) is str and name, "CMBA_RELEASE_EVIDENCE")
    require(type(size) is int and type(size) is not bool and size >= 0, "CMBA_RELEASE_EVIDENCE")
    hex_digest(sha256)
    identifier(producer)
    require(standing in EVIDENCE_STANDINGS, "CMBA_RELEASE_EVIDENCE_STANDING")
    require(type(subject_artifact_ids) is list and subject_artifact_ids == sorted(set(subject_artifact_ids)), "CMBA_RELEASE_EVIDENCE_SUBJECTS")
    for item in subject_artifact_ids:
        identifier(item)
    return {
        "evidence_id": evidence_id,
        "evidence_class": evidence_class,
        "name": name,
        "bytes": size,
        "sha256": sha256,
        "producer": producer,
        "standing": standing,
        "subject_artifact_ids": subject_artifact_ids,
    }


def release_record(
    release_id: str,
    distribution: str,
    version: str,
    artifacts: list[dict[str, Any]],
    evidence_records: list[dict[str, Any]],
    *,
    envelope_evidence_id: str,
    required_gates: list[str],
    declared_gaps: list[str],
) -> dict[str, Any]:
    for value in (release_id, distribution):
        identifier(value)
    require(type(version) is str and version, "CMBA_RELEASE_VERSION")
    require(type(artifacts) is list and artifacts, "CMBA_RELEASE_ARTIFACT")
    artifact_ids = set()
    for item in artifacts:
        exact(item, {"artifact_id", "kind", "name", "bytes", "sha256"})
        require(artifact(item["artifact_id"], item["kind"], item["name"], item["bytes"], item["sha256"]) == item, "CMBA_RELEASE_ARTIFACT")
        require(item["artifact_id"] not in artifact_ids, "CMBA_RELEASE_DUPLICATE")
        artifact_ids.add(item["artifact_id"])
    require({item["kind"] for item in artifacts} >= {"source-archive", "wheel"}, "CMBA_RELEASE_REQUIRED_ARTIFACTS")
    require(type(evidence_records) is list and evidence_records, "CMBA_RELEASE_EVIDENCE")
    evidence_ids = set()
    for item in evidence_records:
        exact(item, {"evidence_id", "evidence_class", "name", "bytes", "sha256", "producer", "standing", "subject_artifact_ids"})
        require(
            evidence(
                item["evidence_id"], item["evidence_class"], item["name"], item["bytes"], item["sha256"],
                producer=item["producer"], standing=item["standing"], subject_artifact_ids=item["subject_artifact_ids"],
            ) == item,
            "CMBA_RELEASE_EVIDENCE",
        )
        require(item["evidence_id"] not in evidence_ids, "CMBA_RELEASE_DUPLICATE")
        evidence_ids.add(item["evidence_id"])
        require(set(item["subject_artifact_ids"]) <= artifact_ids, "CMBA_RELEASE_EVIDENCE_SUBJECTS")
    require(envelope_evidence_id in evidence_ids, "CMBA_RELEASE_ENVELOPE_MISSING")
    envelope = next(item for item in evidence_records if item["evidence_id"] == envelope_evidence_id)
    require(envelope["evidence_class"] == "RELEASE_ENVELOPE", "CMBA_RELEASE_ENVELOPE_MISSING")
    require(type(required_gates) is list and required_gates == sorted(set(required_gates)), "CMBA_RELEASE_GATES")
    require(set(required_gates) <= GATES, "CMBA_RELEASE_GATES")
    require(type(declared_gaps) is list and declared_gaps == sorted(set(declared_gaps)), "CMBA_RELEASE_GAPS")
    for item in declared_gaps:
        identifier(item)
    body = {
        "schema": "cmba.release-record-body.v2",
        "release_id": release_id,
        "distribution": distribution,
        "version": version,
        "artifacts": sorted(clone(artifacts), key=lambda item: item["artifact_id"]),
        "evidence": sorted(clone(evidence_records), key=lambda item: item["evidence_id"]),
        "envelope_evidence_id": envelope_evidence_id,
        "required_gates": required_gates,
        "declared_gaps": declared_gaps,
        "authority_effect": "NONE",
    }
    return {"schema": "cmba.release-record.v2", "body": body, "release_root": _root("release-record", body)}


def validate_release(value: dict[str, Any]) -> None:
    canonical(value)
    exact(value, {"schema", "body", "release_root"})
    require(value["schema"] == "cmba.release-record.v2", "CMBA_RELEASE_SCHEMA")
    hex_digest(value["release_root"])
    body = value["body"]
    rebuilt = release_record(
        body["release_id"], body["distribution"], body["version"], body["artifacts"], body["evidence"],
        envelope_evidence_id=body["envelope_evidence_id"], required_gates=body["required_gates"],
        declared_gaps=body["declared_gaps"],
    )
    require(canonical(rebuilt) == canonical(value), "CMBA_RELEASE_ROOT")


def _json_evidence(raw: bytes) -> dict[str, Any]:
    value = decode(raw, canonical_required=False)
    require(type(value) is dict, "CMBA_RELEASE_EVIDENCE_FORMAT")
    return value


def evaluate_release(
    value: dict[str, Any],
    artifact_bytes: dict[str, bytes],
    evidence_bytes: dict[str, bytes],
    *,
    expected_artifact_hashes: dict[str, str],
) -> dict[str, Any]:
    validate_release(value)
    body = value["body"]
    artifacts = {item["artifact_id"]: item for item in body["artifacts"]}
    evidence_records = {item["evidence_id"]: item for item in body["evidence"]}
    require(type(artifact_bytes) is dict and type(evidence_bytes) is dict, "CMBA_RELEASE_INPUTS")
    require(type(expected_artifact_hashes) is dict, "CMBA_RELEASE_EXPECTED_ROOTS")
    checks: dict[str, str] = {}
    artifact_rows = []
    for artifact_id, record in artifacts.items():
        raw = artifact_bytes.get(artifact_id)
        observed = _sha(raw) if type(raw) is bytes else None
        reader_expected = expected_artifact_hashes.get(artifact_id)
        matched = raw is not None and len(raw) == record["bytes"] and observed == record["sha256"] and reader_expected == record["sha256"]
        checks["artifact." + artifact_id] = "MATCH" if matched else "CONTRADICTED" if raw is not None else "INSUFFICIENT"
        artifact_rows.append({"artifact_id": artifact_id, "declared_sha256": record["sha256"], "observed_sha256": observed, "reader_expected_sha256": reader_expected})
    parsed: dict[str, dict[str, Any]] = {}
    for evidence_id, record in evidence_records.items():
        raw = evidence_bytes.get(evidence_id)
        if type(raw) is not bytes:
            checks["evidence." + evidence_id] = "INSUFFICIENT"
            continue
        if len(raw) != record["bytes"] or _sha(raw) != record["sha256"]:
            checks["evidence." + evidence_id] = "CONTRADICTED"
            continue
        parsed[evidence_id] = _json_evidence(raw)
        checks["evidence." + evidence_id] = "MATCH"
    envelope_id = body["envelope_evidence_id"]
    envelope = parsed.get(envelope_id)
    envelope_rows = {}
    if envelope is not None:
        require(envelope.get("schema") == "cmba.publication-release-envelope.r001", "CMBA_RELEASE_ENVELOPE_SCHEMA")
        require(
            envelope.get("binding_root")
            == hashlib.sha256(b"CMBA:PUBLICATION:r001:release-envelope\0" + canonical(envelope["body"])).hexdigest(),
            "CMBA_RELEASE_ENVELOPE_ROOT",
        )
        envelope_rows = {item["name"]: item for item in envelope["body"]["artifacts"]}
        for record in list(artifacts.values()) + list(evidence_records.values()):
            if record.get("evidence_id") == envelope_id:
                continue
            if record.get("evidence_class") in {"PUBLICATION", "REVIEW", "EXTERNAL_ACCEPTANCE", "FAILED_ATTEMPT"}:
                continue
            row = envelope_rows.get(record["name"])
            checks["envelope." + record.get("artifact_id", record.get("evidence_id"))] = (
                "MATCH" if row is not None and row["sha256"] == record["sha256"] and row["bytes"] == record["bytes"] else "INSUFFICIENT"
            )
    else:
        checks["envelope.available"] = "INSUFFICIENT"
    source = next(item for item in artifacts.values() if item["kind"] == "source-archive")
    wheel = next(item for item in artifacts.values() if item["kind"] == "wheel")
    class_rows: dict[str, list[tuple[dict[str, Any], dict[str, Any]]]] = {}
    for evidence_id, record in evidence_records.items():
        if evidence_id in parsed:
            class_rows.setdefault(record["evidence_class"], []).append((record, parsed[evidence_id]))
    source_tests = [item for _, item in class_rows.get("SOURCE_TEST", []) if item.get("status") == "PASS" and item.get("counts", {}).get("failures") == 0 and item.get("counts", {}).get("errors") == 0]
    installed = [item for _, item in class_rows.get("INSTALLED_WHEEL_PROBE", []) if item.get("status") == "PASS" and item.get("wheel_sha256") == wheel["sha256"] and item.get("source_tree_on_pythonpath") is False]
    reproducible = [item for _, item in class_rows.get("REPRODUCIBILITY", []) if item.get("status") == "PASS" and item.get("source_archive_sha256") == source["sha256"] and item.get("primary_wheel_sha256") == wheel["sha256"] and item.get("independent_rebuild_sha256") == wheel["sha256"] and item.get("byte_identical") is True]
    reviews = class_rows.get("REVIEW", [])
    independent_reviews = [record for record, item in reviews if record["standing"] == "INDEPENDENT" and item.get("status") == "PASS"]
    publications = [item for _, item in class_rows.get("PUBLICATION", []) if item.get("status") == "PASS" and item.get("source_archive_sha256") == source["sha256"] and item.get("public") is True]
    gate_results = {
        "EXACT_ARTIFACTS": all(checks.get("artifact." + item, "") == "MATCH" for item in artifacts),
        "SOURCE_TESTS": bool(source_tests),
        "INSTALLED_WHEEL": bool(installed),
        "REPRODUCIBLE_BUILD": bool(reproducible),
        "INDEPENDENT_REVIEW": bool(independent_reviews),
        "PUBLICATION": bool(publications),
    }
    for gate in body["required_gates"]:
        checks["gate." + gate.lower()] = "MATCH" if gate_results[gate] else "INSUFFICIENT"
    report = multi_check_report(
        checks,
        details={
            "release_root": value["release_root"], "artifacts": artifact_rows,
            "gate_results": gate_results, "declared_gaps": body["declared_gaps"],
            "publication_state": "PUBLIC" if publications else "NOT_ESTABLISHED",
            "review_standing": "INDEPENDENT" if independent_reviews else "SAME_AUTHOR_OR_NOT_PERFORMED",
            "source_test_subject_relation": "COBOUND_BY_RELEASE_ENVELOPE_NOT_DIRECT_TEST_SUBJECT" if source_tests else "NOT_ESTABLISHED",
        },
        claim_ceiling="Exact supplied artifact/evidence association and required release gates only; no production trust, independent review, or universal platform claim beyond explicit evidence.",
    )
    report["schema"] = "cmba.release-assessment.v2"
    return report


def realization_record(
    realization_id: str,
    contract_root: str,
    implementation_root: str,
    platform_root: str,
    adapter_root: str,
    corpus_root: str,
    cases: list[dict[str, Any]],
    *,
    evidence_class: str,
) -> dict[str, Any]:
    identifier(realization_id)
    for value in (contract_root, implementation_root, platform_root, adapter_root, corpus_root):
        hex_digest(value)
    require(type(cases) is list and cases, "CMBA_REALIZATION_CASES")
    seen = set()
    for item in cases:
        exact(item, {"case_id", "expected_root", "observed_root", "status"})
        identifier(item["case_id"])
        require(item["case_id"] not in seen, "CMBA_REALIZATION_DUPLICATE")
        seen.add(item["case_id"])
        hex_digest(item["expected_root"])
        hex_digest(item["observed_root"])
        require(item["status"] in {"PASS", "FAIL", "NOT_RUN"}, "CMBA_REALIZATION_STATUS")
    require(evidence_class in {"SAME_AUTHOR_REPLAY", "NATIVE_OBSERVATION", "INDEPENDENT_REVIEW", "EXTERNAL_ACCEPTANCE"}, "CMBA_REALIZATION_EVIDENCE_CLASS")
    body = {
        "schema": "cmba.realization-record-body.v2", "realization_id": realization_id,
        "contract_root": contract_root, "implementation_root": implementation_root,
        "platform_root": platform_root, "adapter_root": adapter_root, "corpus_root": corpus_root,
        "cases": sorted(clone(cases), key=lambda item: item["case_id"]),
        "evidence_class": evidence_class, "authority_effect": "NONE",
    }
    return {"schema": "cmba.realization-record.v2", "body": body, "realization_root": _root("realization-record", body)}


def evaluate_realization(value: dict[str, Any], expected: dict[str, str]) -> dict[str, Any]:
    canonical(value)
    exact(value, {"schema", "body", "realization_root"})
    require(value["schema"] == "cmba.realization-record.v2", "CMBA_REALIZATION_SCHEMA")
    body = value["body"]
    rebuilt = realization_record(
        body["realization_id"], body["contract_root"], body["implementation_root"], body["platform_root"],
        body["adapter_root"], body["corpus_root"], body["cases"], evidence_class=body["evidence_class"],
    )
    require(canonical(rebuilt) == canonical(value), "CMBA_REALIZATION_ROOT")
    require(set(expected) == {"contract_root", "implementation_root", "platform_root", "adapter_root", "corpus_root"}, "CMBA_REALIZATION_EXPECTED")
    checks = {"identity." + key: "MATCH" if body[key] == expected[key] else "CONTRADICTED" for key in expected}
    for case in body["cases"]:
        checks["case." + case["case_id"]] = (
            "MATCH" if case["status"] == "PASS" and case["expected_root"] == case["observed_root"]
            else "CONTRADICTED" if case["status"] == "FAIL" or case["expected_root"] != case["observed_root"]
            else "INSUFFICIENT"
        )
    report = multi_check_report(
        checks,
        details={
            "realization_root": value["realization_root"], "contract_root": body["contract_root"],
            "implementation_root": body["implementation_root"], "platform_root": body["platform_root"],
            "adapter_root": body["adapter_root"], "corpus_root": body["corpus_root"],
            "evidence_class": body["evidence_class"], "case_count": len(body["cases"]),
            "equivalence": "FINITE_CORPUS_ONLY",
        },
        claim_ceiling="Agreement for the exact identified realization and finite corpus only; not universal program or semantic equivalence.",
    )
    report["schema"] = "cmba.realization-assessment.v2"
    return report
