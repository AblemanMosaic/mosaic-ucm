"""Finite Constitutional Curation Protocol records and stack assessment.

The profile keeps component, subsystem, closure, interface, and assembly
subjects distinct.  It evaluates exact supplied statements and coverage maps;
it does not infer prose, discover current state, or authorize an effect.
"""
from __future__ import annotations

import hashlib
from collections import defaultdict
from typing import Any

from .bindings import exact, hex_digest, identifier, validate_reference
from .codec import canonical, clone
from .contract_types import multi_check_report
from .errors import require


SUBJECT_KINDS = {"COMPONENT", "SUBSYSTEM", "CLOSURE", "ASSEMBLY", "INTERFACE"}
CLAIM_KINDS = {
    "VALIDITY", "NEGATIVE_FINDING", "RECOMMENDATION", "REPAIR",
    "REASSESSMENT", "WITHDRAWAL", "OPERATIONAL_EXPERIENCE", "SUITABILITY",
}
VERDICTS = {"SUPPORT", "CONTRADICT", "UNRESOLVED", "INAPPLICABLE"}
MAX_STATEMENTS = 128


def _root(domain: str, value: Any) -> str:
    return hashlib.sha256(("CMBA:CCP:v2:" + domain + "\0").encode("ascii") + canonical(value)).hexdigest()


def _roots(values: list[str], code: str, *, allow_empty: bool = False) -> list[str]:
    require(type(values) is list and (allow_empty or values), code)
    require(values == sorted(set(values)), code)
    for value in values:
        hex_digest(value)
    return list(values)


def _identifiers(values: list[str], code: str, *, allow_empty: bool = False) -> list[str]:
    require(type(values) is list and (allow_empty or values), code)
    require(values == sorted(set(values)), code)
    for value in values:
        identifier(value)
    return list(values)


def curation_statement(
    statement_id: str,
    subject_kind: str,
    subject: dict[str, Any],
    configuration_roots: list[str],
    constitution_root: str,
    claim_kind: str,
    claim_id: str,
    verdict: str,
    evidence_roots: list[str],
    *,
    issuer_id: str,
    independence_group: str,
    issued_at: int,
    relates_to_roots: list[str] | None = None,
    applicability_tags: list[str] | None = None,
) -> dict[str, Any]:
    identifier(statement_id)
    require(subject_kind in SUBJECT_KINDS, "CMBA_CCP_SUBJECT_KIND")
    validate_reference(subject)
    configurations = _roots(configuration_roots, "CMBA_CCP_CONFIGURATIONS")
    hex_digest(constitution_root)
    require(claim_kind in CLAIM_KINDS, "CMBA_CCP_CLAIM_KIND")
    identifier(claim_id)
    require(verdict in VERDICTS, "CMBA_CCP_VERDICT")
    evidence = _roots(evidence_roots, "CMBA_CCP_EVIDENCE", allow_empty=True)
    identifier(issuer_id)
    identifier(independence_group)
    require(type(issued_at) is int and type(issued_at) is not bool and issued_at >= 0, "CMBA_CCP_TIME")
    relations = _roots(relates_to_roots or [], "CMBA_CCP_RELATIONS", allow_empty=True)
    tags = _identifiers(applicability_tags or [], "CMBA_CCP_TAGS", allow_empty=True)
    body = {
        "schema": "cmba.ccp-curation-statement-body.v2",
        "statement_id": statement_id,
        "subject_kind": subject_kind,
        "subject": clone(subject),
        "configuration_roots": configurations,
        "constitution_root": constitution_root,
        "claim_kind": claim_kind,
        "claim_id": claim_id,
        "verdict": verdict,
        "evidence_roots": evidence,
        "issuer_id": issuer_id,
        "independence_group": independence_group,
        "issued_at": issued_at,
        "relates_to_roots": relations,
        "applicability_tags": tags,
        "authority_effect": "NONE",
    }
    return {
        "schema": "cmba.ccp-curation-statement.v2",
        "body": body,
        "statement_root": _root("statement", body),
    }


def validate_curation_statement(value: dict[str, Any]) -> None:
    canonical(value)
    exact(value, {"schema", "body", "statement_root"})
    require(value["schema"] == "cmba.ccp-curation-statement.v2", "CMBA_CCP_STATEMENT_SCHEMA")
    hex_digest(value["statement_root"])
    body = value["body"]
    exact(body, {
        "schema", "statement_id", "subject_kind", "subject", "configuration_roots",
        "constitution_root", "claim_kind", "claim_id", "verdict", "evidence_roots",
        "issuer_id", "independence_group", "issued_at", "relates_to_roots",
        "applicability_tags", "authority_effect",
    })
    require(body["schema"] == "cmba.ccp-curation-statement-body.v2", "CMBA_CCP_STATEMENT_SCHEMA")
    rebuilt = curation_statement(
        body["statement_id"], body["subject_kind"], body["subject"],
        body["configuration_roots"], body["constitution_root"], body["claim_kind"],
        body["claim_id"], body["verdict"], body["evidence_roots"],
        issuer_id=body["issuer_id"], independence_group=body["independence_group"],
        issued_at=body["issued_at"], relates_to_roots=body["relates_to_roots"],
        applicability_tags=body["applicability_tags"],
    )
    require(canonical(rebuilt) == canonical(value), "CMBA_CCP_STATEMENT_ROOT")


def coverage_map(
    map_id: str,
    constitution_root: str,
    subjects: list[dict[str, Any]],
    interfaces: list[dict[str, Any]],
    obligations: list[dict[str, Any]],
) -> dict[str, Any]:
    identifier(map_id)
    hex_digest(constitution_root)
    require(type(subjects) is list and 1 <= len(subjects) <= 64, "CMBA_CCP_SUBJECTS")
    require(type(interfaces) is list and len(interfaces) <= 128, "CMBA_CCP_INTERFACES")
    require(type(obligations) is list and 1 <= len(obligations) <= 128, "CMBA_CCP_OBLIGATIONS")
    subject_rows: list[dict[str, Any]] = []
    subject_ids: set[str] = set()
    for raw in subjects:
        exact(raw, {"subject_id", "subject_kind", "subject", "configuration_roots"})
        identifier(raw["subject_id"])
        require(raw["subject_id"] not in subject_ids, "CMBA_CCP_SUBJECT_DUPLICATE")
        subject_ids.add(raw["subject_id"])
        require(raw["subject_kind"] in SUBJECT_KINDS - {"INTERFACE"}, "CMBA_CCP_SUBJECT_KIND")
        validate_reference(raw["subject"])
        subject_rows.append({
            "subject_id": raw["subject_id"], "subject_kind": raw["subject_kind"],
            "subject": clone(raw["subject"]),
            "configuration_roots": _roots(raw["configuration_roots"], "CMBA_CCP_CONFIGURATIONS"),
        })
    interface_rows: list[dict[str, Any]] = []
    interface_ids: set[str] = set()
    for raw in interfaces:
        exact(raw, {"interface_id", "left_subject_id", "right_subject_id", "interface"})
        identifier(raw["interface_id"])
        require(raw["interface_id"] not in interface_ids, "CMBA_CCP_INTERFACE_DUPLICATE")
        interface_ids.add(raw["interface_id"])
        require(raw["left_subject_id"] in subject_ids and raw["right_subject_id"] in subject_ids, "CMBA_CCP_INTERFACE_SUBJECT")
        require(raw["left_subject_id"] != raw["right_subject_id"], "CMBA_CCP_INTERFACE_SUBJECT")
        validate_reference(raw["interface"])
        interface_rows.append(clone(raw))
    targets = subject_ids | interface_ids
    obligation_rows: list[dict[str, Any]] = []
    obligation_ids: set[str] = set()
    for raw in obligations:
        exact(raw, {"obligation_id", "target_id", "predicate_id", "required_claim_ids"})
        identifier(raw["obligation_id"])
        require(raw["obligation_id"] not in obligation_ids, "CMBA_CCP_OBLIGATION_DUPLICATE")
        obligation_ids.add(raw["obligation_id"])
        require(raw["target_id"] in targets, "CMBA_CCP_OBLIGATION_TARGET")
        identifier(raw["predicate_id"])
        obligation_rows.append({
            "obligation_id": raw["obligation_id"], "target_id": raw["target_id"],
            "predicate_id": raw["predicate_id"],
            "required_claim_ids": _identifiers(raw["required_claim_ids"], "CMBA_CCP_REQUIRED_CLAIMS"),
        })
    body = {
        "schema": "cmba.ccp-coverage-map-body.v2",
        "map_id": map_id,
        "constitution_root": constitution_root,
        "subjects": sorted(subject_rows, key=lambda row: row["subject_id"]),
        "interfaces": sorted(interface_rows, key=lambda row: row["interface_id"]),
        "obligations": sorted(obligation_rows, key=lambda row: row["obligation_id"]),
        "authority_effect": "NONE",
    }
    return {"schema": "cmba.ccp-coverage-map.v2", "body": body, "coverage_root": _root("coverage", body)}


def validate_coverage_map(value: dict[str, Any]) -> None:
    canonical(value)
    exact(value, {"schema", "body", "coverage_root"})
    require(value["schema"] == "cmba.ccp-coverage-map.v2", "CMBA_CCP_COVERAGE_SCHEMA")
    hex_digest(value["coverage_root"])
    body = value["body"]
    rebuilt = coverage_map(body["map_id"], body["constitution_root"], body["subjects"], body["interfaces"], body["obligations"])
    require(canonical(rebuilt) == canonical(value), "CMBA_CCP_COVERAGE_ROOT")


def evaluate_stack(
    statements: list[dict[str, Any]],
    coverage: dict[str, Any],
    *,
    recognized_issuers: list[str],
    target_subject_id: str,
    target_configuration_roots: list[str],
) -> dict[str, Any]:
    validate_coverage_map(coverage)
    require(type(statements) is list and len(statements) <= MAX_STATEMENTS, "CMBA_CCP_STATEMENTS")
    issuers = set(_identifiers(recognized_issuers, "CMBA_CCP_RECOGNIZED_ISSUERS", allow_empty=True))
    target_configs = _roots(target_configuration_roots, "CMBA_CCP_CONFIGURATIONS")
    subjects = {row["subject_id"]: row for row in coverage["body"]["subjects"]}
    interfaces = {row["interface_id"]: row for row in coverage["body"]["interfaces"]}
    require(target_subject_id in subjects, "CMBA_CCP_TARGET_SUBJECT")
    require(target_configs == subjects[target_subject_id]["configuration_roots"], "CMBA_CCP_TARGET_CONFIGURATION")
    statement_ids: set[str] = set()
    admitted: list[dict[str, Any]] = []
    for statement in statements:
        validate_curation_statement(statement)
        body = statement["body"]
        require(body["statement_id"] not in statement_ids, "CMBA_CCP_STATEMENT_DUPLICATE")
        statement_ids.add(body["statement_id"])
        if body["issuer_id"] in issuers and body["constitution_root"] == coverage["body"]["constitution_root"]:
            admitted.append(statement)
    subject_root_to_id = {canonical(row["subject"]): key for key, row in subjects.items()}
    interface_root_to_id = {canonical(row["interface"]): key for key, row in interfaces.items()}
    grouped: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    out_of_scope: list[str] = []
    for statement in admitted:
        body = statement["body"]
        key = canonical(body["subject"])
        target_id = subject_root_to_id.get(key) or interface_root_to_id.get(key)
        if target_id is None or (target_id in subjects and body["configuration_roots"] != subjects[target_id]["configuration_roots"]):
            out_of_scope.append(statement["statement_root"])
            continue
        grouped[(target_id, body["claim_id"])].append(statement)
    obligation_rows = []
    checks: dict[str, str] = {}
    for obligation in coverage["body"]["obligations"]:
        claim_rows = []
        obligation_status = "COVERED"
        for claim_id in obligation["required_claim_ids"]:
            rows = grouped.get((obligation["target_id"], claim_id), [])
            live = [row for row in rows if row["body"]["claim_kind"] != "WITHDRAWAL"]
            withdrawn_targets = {
                root for row in rows if row["body"]["claim_kind"] == "WITHDRAWAL"
                for root in row["body"]["relates_to_roots"]
            }
            live = [row for row in live if row["statement_root"] not in withdrawn_targets]
            verdicts = sorted({row["body"]["verdict"] for row in live})
            independence_groups = sorted({row["body"]["independence_group"] for row in live})
            if "CONTRADICT" in verdicts:
                state = "CONTRADICTED"
                obligation_status = "CONTRADICTED"
            elif "SUPPORT" not in verdicts:
                state = "UNCOVERED"
                if obligation_status != "CONTRADICTED":
                    obligation_status = "UNCOVERED"
            elif "UNRESOLVED" in verdicts:
                state = "DISAGREEMENT_UNRESOLVED"
                if obligation_status != "CONTRADICTED":
                    obligation_status = "UNCOVERED"
            else:
                state = "SUPPORTED"
            claim_rows.append({
                "claim_id": claim_id, "state": state, "verdicts": verdicts,
                "statement_roots": sorted(row["statement_root"] for row in live),
                "independent_support_count": len(independence_groups),
                "independence_groups": independence_groups,
            })
        checks["obligation." + obligation["obligation_id"]] = (
            "MATCH" if obligation_status == "COVERED"
            else "CONTRADICTED" if obligation_status == "CONTRADICTED"
            else "INSUFFICIENT"
        )
        obligation_rows.append({**clone(obligation), "status": obligation_status, "claims": claim_rows})
    direct_target_statements = [
        statement["statement_root"] for statement in admitted
        if canonical(statement["body"]["subject"]) == canonical(subjects[target_subject_id]["subject"])
        and statement["body"]["configuration_roots"] == target_configs
    ]
    checks["target.direct-scope"] = "MATCH" if direct_target_statements else "INSUFFICIENT"
    report = multi_check_report(
        checks,
        details={
            "coverage_root": coverage["coverage_root"],
            "target_subject_id": target_subject_id,
            "target_configuration_roots": target_configs,
            "direct_target_statement_roots": sorted(direct_target_statements),
            "component_claims_promoted": False,
            "obligations": obligation_rows,
            "out_of_scope_statement_roots": sorted(out_of_scope),
            "disagreement_preserved": True,
            "endorsement_count_rule": "ONE_PER_INDEPENDENCE_GROUP",
            "execution_authorized": False,
        },
        claim_ceiling="Exact reader-recognized curation statements and obligation coverage for one supplied constitution, subject, and configuration only; no prose entailment, whole-stack promotion, or execution authority.",
    )
    report["schema"] = "cmba.ccp-stack-assessment.v2"
    return report


def trace_repair_chain(
    statements: list[dict[str, Any]],
    *,
    counterexample_root: str,
    repair_root: str,
    reassessment_root: str,
) -> dict[str, Any]:
    for root in (counterexample_root, repair_root, reassessment_root):
        hex_digest(root)
    by_root = {}
    for statement in statements:
        validate_curation_statement(statement)
        by_root[statement["statement_root"]] = statement
    require(set((counterexample_root, repair_root, reassessment_root)) <= set(by_root), "CMBA_CCP_CHAIN_MISSING")
    counterexample = by_root[counterexample_root]["body"]
    repair = by_root[repair_root]["body"]
    reassessment = by_root[reassessment_root]["body"]
    checks = {
        "counterexample.kind": "MATCH" if counterexample["claim_kind"] == "NEGATIVE_FINDING" and counterexample["verdict"] == "CONTRADICT" else "CONTRADICTED",
        "repair.kind": "MATCH" if repair["claim_kind"] == "REPAIR" and counterexample_root in repair["relates_to_roots"] else "CONTRADICTED",
        "reassessment.kind": "MATCH" if reassessment["claim_kind"] == "REASSESSMENT" and repair_root in reassessment["relates_to_roots"] else "CONTRADICTED",
        "subject.same": "MATCH" if canonical(counterexample["subject"]) == canonical(repair["subject"]) == canonical(reassessment["subject"]) else "CONTRADICTED",
        "configuration.same": "MATCH" if counterexample["configuration_roots"] == repair["configuration_roots"] == reassessment["configuration_roots"] else "CONTRADICTED",
    }
    result = multi_check_report(
        checks,
        details={
            "chain": [counterexample_root, repair_root, reassessment_root],
            "historical_counterexample_preserved": True,
            "repair_does_not_erase_prior_finding": True,
            "execution_authorized": False,
        },
        claim_ceiling="Traceability of one exact counterexample-repair-reassessment chain only; the reassessment does not erase history or authorize deployment.",
    )
    result["schema"] = "cmba.ccp-repair-chain.v2"
    return result
