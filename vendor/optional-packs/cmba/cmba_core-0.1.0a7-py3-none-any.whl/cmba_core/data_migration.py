"""Governed data migration over exact inventories, transitions, and evidence."""
from __future__ import annotations

import hashlib
from typing import Any

from .bindings import exact, hex_digest, identifier
from .codec import canonical, clone
from .contract_types import multi_check_report
from .errors import require


MAX_OBJECTS = 256


def _root(domain: str, value: Any) -> str:
    return hashlib.sha256(("CMBA:V2:" + domain + "\0").encode("ascii") + canonical(value)).hexdigest()


def _ids(values: list[str], code: str, *, allow_empty: bool = True) -> list[str]:
    require(type(values) is list and (allow_empty or bool(values)), code)
    for value in values:
        identifier(value)
    require(values == sorted(set(values)), code)
    return list(values)


def data_inventory(inventory_id: str, objects: list[dict[str, Any]], *, observed_at: int) -> dict[str, Any]:
    identifier(inventory_id)
    require(type(observed_at) is int and type(observed_at) is not bool and observed_at >= 0, "CMBA_MIGRATION_TIME")
    require(type(objects) is list and 0 < len(objects) <= MAX_OBJECTS, "CMBA_MIGRATION_OBJECTS")
    seen = set()
    for item in objects:
        exact(item, {"object_id", "content_root", "bytes", "schema_id", "labels", "conditions", "residency"})
        identifier(item["object_id"])
        require(item["object_id"] not in seen, "CMBA_MIGRATION_DUPLICATE")
        seen.add(item["object_id"])
        hex_digest(item["content_root"])
        require(type(item["bytes"]) is int and type(item["bytes"]) is not bool and item["bytes"] >= 0, "CMBA_MIGRATION_BYTES")
        identifier(item["schema_id"])
        _ids(item["labels"], "CMBA_MIGRATION_LABELS")
        require(type(item["conditions"]) is dict, "CMBA_MIGRATION_CONDITIONS")
        for key in item["conditions"]:
            identifier(key)
        canonical(item["conditions"])
        _ids(item["residency"], "CMBA_MIGRATION_RESIDENCY", allow_empty=False)
    body = {
        "schema": "cmba.data-inventory-body.v2",
        "inventory_id": inventory_id,
        "objects": sorted(clone(objects), key=lambda item: item["object_id"]),
        "observed_at": observed_at,
        "authority_effect": "NONE",
    }
    return {"schema": "cmba.data-inventory.v2", "body": body, "inventory_root": _root("data-inventory", body)}


def validate_inventory(value: dict[str, Any]) -> None:
    canonical(value)
    exact(value, {"schema", "body", "inventory_root"})
    require(value["schema"] == "cmba.data-inventory.v2", "CMBA_MIGRATION_INVENTORY_SCHEMA")
    body = value["body"]
    rebuilt = data_inventory(body["inventory_id"], body["objects"], observed_at=body["observed_at"])
    require(canonical(rebuilt) == canonical(value), "CMBA_MIGRATION_INVENTORY_ROOT")


def schema_transition(
    transition_id: str,
    source_schema_id: str,
    target_schema_id: str,
    field_mapping: dict[str, str],
    transformations: list[str],
    *,
    retained_labels: list[str],
    retained_condition_keys: list[str],
    approved_relaxations: list[str],
) -> dict[str, Any]:
    for value in (transition_id, source_schema_id, target_schema_id):
        identifier(value)
    require(type(field_mapping) is dict, "CMBA_MIGRATION_FIELD_MAPPING")
    mapped = {}
    for source, target in field_mapping.items():
        identifier(source)
        identifier(target)
        mapped[source] = target
    _ids(transformations, "CMBA_MIGRATION_TRANSFORMS")
    _ids(retained_labels, "CMBA_MIGRATION_LABELS")
    _ids(retained_condition_keys, "CMBA_MIGRATION_CONDITIONS")
    _ids(approved_relaxations, "CMBA_MIGRATION_RELAXATIONS")
    body = {
        "schema": "cmba.schema-transition-body.v2",
        "transition_id": transition_id,
        "source_schema_id": source_schema_id,
        "target_schema_id": target_schema_id,
        "field_mapping": {key: mapped[key] for key in sorted(mapped)},
        "transformations": list(transformations),
        "retained_labels": list(retained_labels),
        "retained_condition_keys": list(retained_condition_keys),
        "approved_relaxations": list(approved_relaxations),
        "authority_effect": "NONE",
    }
    return {"schema": "cmba.schema-transition.v2", "body": body, "transition_root": _root("schema-transition", body)}


def validate_schema_transition(value: dict[str, Any]) -> None:
    canonical(value)
    exact(value, {"schema", "body", "transition_root"})
    require(value["schema"] == "cmba.schema-transition.v2", "CMBA_MIGRATION_TRANSITION_SCHEMA")
    body = value["body"]
    rebuilt = schema_transition(
        body["transition_id"], body["source_schema_id"], body["target_schema_id"],
        body["field_mapping"], body["transformations"], retained_labels=body["retained_labels"],
        retained_condition_keys=body["retained_condition_keys"], approved_relaxations=body["approved_relaxations"],
    )
    require(canonical(rebuilt) == canonical(value), "CMBA_MIGRATION_TRANSITION_ROOT")


def data_derivation(
    derivation_id: str,
    inputs: list[dict[str, str]],
    output_object_id: str,
    output_content_root: str,
    operation_id: str,
    schema_transition_root: str,
    *,
    redacted_fields: list[str],
) -> dict[str, Any]:
    for value in (derivation_id, output_object_id, operation_id):
        identifier(value)
    hex_digest(output_content_root)
    hex_digest(schema_transition_root)
    require(type(inputs) is list and 0 < len(inputs) <= MAX_OBJECTS, "CMBA_DERIVATION_INPUTS")
    seen = set()
    for item in inputs:
        exact(item, {"object_id", "content_root"})
        identifier(item["object_id"])
        require(item["object_id"] not in seen, "CMBA_MIGRATION_DUPLICATE")
        seen.add(item["object_id"])
        hex_digest(item["content_root"])
    _ids(redacted_fields, "CMBA_DERIVATION_REDACTIONS")
    body = {
        "schema": "cmba.data-derivation-body.v2",
        "derivation_id": derivation_id,
        "inputs": sorted(clone(inputs), key=lambda item: item["object_id"]),
        "output_object_id": output_object_id,
        "output_content_root": output_content_root,
        "operation_id": operation_id,
        "schema_transition_root": schema_transition_root,
        "redacted_fields": list(redacted_fields),
        "authority_effect": "NONE",
    }
    return {"schema": "cmba.data-derivation.v2", "body": body, "derivation_root": _root("data-derivation", body)}


def evaluate_data_derivation(
    derivation: dict[str, Any],
    source_inventory: dict[str, Any],
    destination_inventory: dict[str, Any],
    transition: dict[str, Any],
) -> dict[str, Any]:
    canonical(derivation)
    exact(derivation, {"schema", "body", "derivation_root"})
    require(derivation["schema"] == "cmba.data-derivation.v2", "CMBA_DERIVATION_SCHEMA")
    body = derivation["body"]
    rebuilt = data_derivation(
        body["derivation_id"], body["inputs"], body["output_object_id"], body["output_content_root"],
        body["operation_id"], body["schema_transition_root"], redacted_fields=body["redacted_fields"],
    )
    require(canonical(rebuilt) == canonical(derivation), "CMBA_DERIVATION_ROOT")
    validate_inventory(source_inventory)
    validate_inventory(destination_inventory)
    validate_schema_transition(transition)
    require(body["schema_transition_root"] == transition["transition_root"], "CMBA_DERIVATION_TRANSITION_ROOT")
    sources = {item["object_id"]: item for item in source_inventory["body"]["objects"]}
    destinations = {item["object_id"]: item for item in destination_inventory["body"]["objects"]}
    checks = {}
    for item in body["inputs"]:
        source = sources.get(item["object_id"])
        checks["input." + item["object_id"]] = (
            "MATCH" if source is not None and source["content_root"] == item["content_root"]
            else "CONTRADICTED" if source is not None else "INSUFFICIENT"
        )
    output = destinations.get(body["output_object_id"])
    checks["output.exact"] = (
        "MATCH" if output is not None and output["content_root"] == body["output_content_root"]
        else "CONTRADICTED" if output is not None else "INSUFFICIENT"
    )
    transition_body = transition["body"]
    checks["output.schema"] = (
        "MATCH" if output is not None and output["schema_id"] == transition_body["target_schema_id"]
        else "CONTRADICTED" if output is not None else "INSUFFICIENT"
    )
    approved = set(transition_body["approved_relaxations"])
    requested_redactions = {"field:" + field for field in body["redacted_fields"]}
    checks["redactions.approved"] = "MATCH" if requested_redactions <= approved else "CONTRADICTED"
    if output is not None:
        checks["labels.retained"] = "MATCH" if set(transition_body["retained_labels"]) <= set(output["labels"]) else "CONTRADICTED"
        checks["conditions.retained"] = "MATCH" if set(transition_body["retained_condition_keys"]) <= set(output["conditions"]) else "CONTRADICTED"
    else:
        checks["labels.retained"] = "INSUFFICIENT"
        checks["conditions.retained"] = "INSUFFICIENT"
    report = multi_check_report(
        checks,
        details={
            "derivation_root": derivation["derivation_root"],
            "source_inventory_root": source_inventory["inventory_root"],
            "destination_inventory_root": destination_inventory["inventory_root"],
            "schema_transition_root": transition["transition_root"],
            "operation_id": body["operation_id"],
            "redacted_fields": body["redacted_fields"],
        },
        claim_ceiling="Exact derivation input/output lineage, declared operation and supported schema/label/condition/redaction checks only; no semantic correctness of transformation.",
    )
    report["schema"] = "cmba.data-derivation-assessment.v2"
    return report


def obligation_set(
    obligation_id: str,
    purpose_ids: list[str],
    onward_transfer: str,
    retention_until: int | None,
    legal_hold: bool,
    residency: list[str],
    source_disposition: str,
    required_followup_evidence: list[str],
) -> dict[str, Any]:
    identifier(obligation_id)
    _ids(purpose_ids, "CMBA_MIGRATION_PURPOSE", allow_empty=False)
    require(onward_transfer in {"PROHIBITED", "APPROVAL_REQUIRED", "ALLOWED"}, "CMBA_MIGRATION_ONWARD")
    require(retention_until is None or (type(retention_until) is int and type(retention_until) is not bool and retention_until >= 0), "CMBA_MIGRATION_RETENTION")
    require(type(legal_hold) is bool, "CMBA_MIGRATION_HOLD")
    _ids(residency, "CMBA_MIGRATION_RESIDENCY", allow_empty=False)
    require(source_disposition in {"RETAIN", "ARCHIVE", "DELETE_AFTER_CUTOVER"}, "CMBA_MIGRATION_DISPOSITION")
    _ids(required_followup_evidence, "CMBA_MIGRATION_FOLLOWUP")
    body = {
        "schema": "cmba.obligation-set-body.v2",
        "obligation_id": obligation_id,
        "purpose_ids": list(purpose_ids),
        "onward_transfer": onward_transfer,
        "retention_until": retention_until,
        "legal_hold": legal_hold,
        "residency": list(residency),
        "source_disposition": source_disposition,
        "required_followup_evidence": list(required_followup_evidence),
        "authority_effect": "NONE",
    }
    return {"schema": "cmba.obligation-set.v2", "body": body, "obligation_root": _root("obligation-set", body)}


def validate_obligations(value: dict[str, Any]) -> None:
    canonical(value)
    exact(value, {"schema", "body", "obligation_root"})
    require(value["schema"] == "cmba.obligation-set.v2", "CMBA_MIGRATION_OBLIGATION_SCHEMA")
    body = value["body"]
    rebuilt = obligation_set(
        body["obligation_id"], body["purpose_ids"], body["onward_transfer"], body["retention_until"],
        body["legal_hold"], body["residency"], body["source_disposition"], body["required_followup_evidence"],
    )
    require(canonical(rebuilt) == canonical(value), "CMBA_MIGRATION_OBLIGATION_ROOT")


def data_migration_plan(
    plan_id: str,
    source_inventory_root: str,
    policy_transition_root: str,
    source_obligation_root: str,
    destination_obligation_root: str,
    object_mappings: list[dict[str, Any]],
    *,
    delta_procedure: str,
) -> dict[str, Any]:
    identifier(plan_id)
    for value in (source_inventory_root, policy_transition_root, source_obligation_root, destination_obligation_root):
        hex_digest(value)
    require(type(object_mappings) is list and 0 < len(object_mappings) <= MAX_OBJECTS, "CMBA_MIGRATION_MAPPINGS")
    source_ids = set()
    target_ids = set()
    for item in object_mappings:
        exact(item, {"source_object_id", "target_object_id", "snapshot_content_root", "expected_target_root", "schema_transition_root"})
        identifier(item["source_object_id"])
        identifier(item["target_object_id"])
        require(item["source_object_id"] not in source_ids and item["target_object_id"] not in target_ids, "CMBA_MIGRATION_DUPLICATE")
        source_ids.add(item["source_object_id"])
        target_ids.add(item["target_object_id"])
        for field in ("snapshot_content_root", "expected_target_root", "schema_transition_root"):
            hex_digest(item[field])
    require(delta_procedure in {"REFUSE_UNTIL_NEW_PLAN", "EXACT_DELTA_RECONCILIATION"}, "CMBA_MIGRATION_DELTA")
    body = {
        "schema": "cmba.data-migration-plan-body.v2",
        "plan_id": plan_id,
        "source_inventory_root": source_inventory_root,
        "policy_transition_root": policy_transition_root,
        "source_obligation_root": source_obligation_root,
        "destination_obligation_root": destination_obligation_root,
        "object_mappings": sorted(clone(object_mappings), key=lambda item: item["source_object_id"]),
        "delta_procedure": delta_procedure,
        "stages": ["SNAPSHOT", "TRANSFER", "STAGING_VERIFICATION", "CUTOVER", "SOURCE_DISPOSITION"],
        "authority_effect": "NONE",
    }
    return {"schema": "cmba.data-migration-plan.v2", "body": body, "plan_root": _root("data-migration-plan", body)}


def validate_plan(value: dict[str, Any]) -> None:
    canonical(value)
    exact(value, {"schema", "body", "plan_root"})
    require(value["schema"] == "cmba.data-migration-plan.v2", "CMBA_MIGRATION_PLAN_SCHEMA")
    body = value["body"]
    rebuilt = data_migration_plan(
        body["plan_id"], body["source_inventory_root"], body["policy_transition_root"],
        body["source_obligation_root"], body["destination_obligation_root"], body["object_mappings"],
        delta_procedure=body["delta_procedure"],
    )
    require(canonical(rebuilt) == canonical(value), "CMBA_MIGRATION_PLAN_ROOT")


def _validate_evidence(evidence: dict[str, Any]) -> None:
    exact(evidence, {
        "transfer_receipts", "delta_records", "staging", "cutover", "source_dispositions",
        "policy_assessment", "purpose_evidence", "residency_evidence", "followup_evidence", "interrupted",
    })
    require(type(evidence["transfer_receipts"]) is list and len(evidence["transfer_receipts"]) <= MAX_OBJECTS * 2, "CMBA_MIGRATION_RECEIPTS")
    seen = set()
    for item in evidence["transfer_receipts"]:
        exact(item, {"transfer_id", "attempt_id", "source_object_id", "target_object_id", "source_root", "target_root", "status"})
        for field in ("transfer_id", "attempt_id", "source_object_id", "target_object_id"):
            identifier(item[field])
        require(item["transfer_id"] not in seen, "CMBA_MIGRATION_DUPLICATE")
        seen.add(item["transfer_id"])
        hex_digest(item["source_root"])
        hex_digest(item["target_root"])
        require(item["status"] in {"COMPLETED", "FAILED"}, "CMBA_MIGRATION_RECEIPT_STATUS")
    require(type(evidence["delta_records"]) is list and len(evidence["delta_records"]) <= MAX_OBJECTS, "CMBA_MIGRATION_DELTA")
    delta_ids = set()
    for item in evidence["delta_records"]:
        exact(item, {"object_id", "snapshot_root", "current_root", "destination_root", "status"})
        identifier(item["object_id"])
        require(item["object_id"] not in delta_ids, "CMBA_MIGRATION_DUPLICATE")
        delta_ids.add(item["object_id"])
        for field in ("snapshot_root", "current_root", "destination_root"):
            hex_digest(item[field])
        require(item["status"] in {"RECONCILED", "UNRESOLVED"}, "CMBA_MIGRATION_DELTA")
    for field in ("staging", "cutover"):
        value = evidence[field]
        require(value is None or type(value) is dict, "CMBA_MIGRATION_STAGE_EVIDENCE")
        if value is not None:
            exact(value, {"status", "plan_root", "destination_inventory_root"})
            require(value["status"] in {"PASS", "FAIL"}, "CMBA_MIGRATION_STAGE_EVIDENCE")
            hex_digest(value["plan_root"])
            hex_digest(value["destination_inventory_root"])
    require(type(evidence["source_dispositions"]) is list, "CMBA_MIGRATION_DISPOSITION")
    disposition_ids = set()
    for item in evidence["source_dispositions"]:
        exact(item, {"object_id", "action", "status", "coverage"})
        identifier(item["object_id"])
        require(item["object_id"] not in disposition_ids, "CMBA_MIGRATION_DUPLICATE")
        disposition_ids.add(item["object_id"])
        require(item["action"] in {"RETAIN", "ARCHIVE", "DELETE"}, "CMBA_MIGRATION_DISPOSITION")
        require(item["status"] in {"COMPLETED", "FAILED", "NOT_PERFORMED"}, "CMBA_MIGRATION_DISPOSITION")
        require(item["coverage"] in {"EXACT_OBJECT", "PARTIAL", "UNKNOWN"}, "CMBA_MIGRATION_DISPOSITION")
    exact(evidence["policy_assessment"], {"transition_root", "status"})
    hex_digest(evidence["policy_assessment"]["transition_root"])
    require(evidence["policy_assessment"]["status"] in {"MATCH_FOR_SUPPLIED_EVIDENCE", "CONTRADICTED", "INSUFFICIENT", "UNSUPPORTED"}, "CMBA_MIGRATION_POLICY")
    for field in ("purpose_evidence", "residency_evidence", "followup_evidence"):
        _ids(evidence[field], "CMBA_MIGRATION_EVIDENCE")
    require(type(evidence["interrupted"]) is bool, "CMBA_MIGRATION_INTERRUPTED")


def evaluate_data_migration(
    plan: dict[str, Any],
    snapshot_inventory: dict[str, Any],
    current_source_inventory: dict[str, Any],
    destination_inventory: dict[str, Any],
    schema_transitions: list[dict[str, Any]],
    source_obligations: dict[str, Any],
    destination_obligations: dict[str, Any],
    evidence: dict[str, Any],
) -> dict[str, Any]:
    validate_plan(plan)
    for inventory in (snapshot_inventory, current_source_inventory, destination_inventory):
        validate_inventory(inventory)
    validate_obligations(source_obligations)
    validate_obligations(destination_obligations)
    _validate_evidence(evidence)
    body = plan["body"]
    require(body["source_inventory_root"] == snapshot_inventory["inventory_root"], "CMBA_MIGRATION_SOURCE_ROOT")
    require(body["source_obligation_root"] == source_obligations["obligation_root"], "CMBA_MIGRATION_OBLIGATION_ROOT")
    require(body["destination_obligation_root"] == destination_obligations["obligation_root"], "CMBA_MIGRATION_OBLIGATION_ROOT")
    require(evidence["policy_assessment"]["transition_root"] == body["policy_transition_root"], "CMBA_MIGRATION_POLICY_ROOT")
    transitions = {}
    for transition in schema_transitions:
        validate_schema_transition(transition)
        require(transition["transition_root"] not in transitions, "CMBA_MIGRATION_DUPLICATE")
        transitions[transition["transition_root"]] = transition
    require(set(transitions) == {item["schema_transition_root"] for item in body["object_mappings"]}, "CMBA_MIGRATION_TRANSITION_SET")
    snapshot = {item["object_id"]: item for item in snapshot_inventory["body"]["objects"]}
    current = {item["object_id"]: item for item in current_source_inventory["body"]["objects"]}
    destination = {item["object_id"]: item for item in destination_inventory["body"]["objects"]}
    receipts = [item for item in evidence["transfer_receipts"] if item["status"] == "COMPLETED"]
    deltas = {item["object_id"]: item for item in evidence["delta_records"]}
    require(snapshot_inventory["body"]["observed_at"] <= current_source_inventory["body"]["observed_at"], "CMBA_MIGRATION_TIME")
    mapped_source_ids = {item["source_object_id"] for item in body["object_mappings"]}
    mapped_target_ids = {item["target_object_id"] for item in body["object_mappings"]}
    checks = {
        "inventory.object-set": "MATCH" if set(snapshot) == mapped_source_ids else "CONTRADICTED",
        "inventory.current-object-set": "MATCH" if set(current) == set(snapshot) else "INSUFFICIENT",
        "inventory.destination-object-set": "MATCH" if set(destination) <= mapped_target_ids else "CONTRADICTED",
        "receipts.closed": "MATCH" if all(
            item["source_object_id"] in mapped_source_ids and item["target_object_id"] in mapped_target_ids
            for item in evidence["transfer_receipts"]
        ) else "CONTRADICTED",
        "deltas.closed": "MATCH" if set(deltas) <= mapped_source_ids else "CONTRADICTED",
        "policy.transition": "MATCH" if evidence["policy_assessment"]["status"] == "MATCH_FOR_SUPPLIED_EVIDENCE" else (
            "CONTRADICTED" if evidence["policy_assessment"]["status"] == "CONTRADICTED" else
            "UNSUPPORTED" if evidence["policy_assessment"]["status"] == "UNSUPPORTED" else "INSUFFICIENT"
        ),
    }
    object_rows = []
    observed_relaxations: dict[str, set[str]] = {root: set() for root in transitions}
    completed_effects = []
    remaining = []
    for mapping in body["object_mappings"]:
        source_id = mapping["source_object_id"]
        target_id = mapping["target_object_id"]
        snap = snapshot.get(source_id)
        cur = current.get(source_id)
        target = destination.get(target_id)
        transition = transitions.get(mapping["schema_transition_root"])
        status = "MATCH"
        transfer_eligible = True
        reasons = []
        required_source_root = mapping["snapshot_content_root"]
        required_target_root = mapping["expected_target_root"]
        if snap is None or snap["content_root"] != mapping["snapshot_content_root"]:
            status = "CONTRADICTED"
            transfer_eligible = False
            reasons.append("SNAPSHOT_MAPPING_MISMATCH")
        if cur is None:
            status = "INSUFFICIENT"
            transfer_eligible = False
            reasons.append("CURRENT_SOURCE_MISSING")
        elif snap is not None and cur["content_root"] != snap["content_root"]:
            delta = deltas.get(source_id)
            delta_matches = (
                body["delta_procedure"] == "EXACT_DELTA_RECONCILIATION"
                and delta is not None and delta["status"] == "RECONCILED"
                and delta["snapshot_root"] == snap["content_root"]
                and delta["current_root"] == cur["content_root"]
            )
            if delta_matches:
                required_source_root = delta["current_root"]
                required_target_root = delta["destination_root"]
                reasons.append("CONCURRENT_CHANGE_RECONCILED")
            else:
                status = "INSUFFICIENT"
                transfer_eligible = False
                reasons.append("CONCURRENT_CHANGE_UNRESOLVED")
        if transition is None:
            status = "INSUFFICIENT"
            transfer_eligible = False
            reasons.append("SCHEMA_TRANSITION_MISSING")
        elif snap is not None:
            transition_body = transition["body"]
            if snap["schema_id"] != transition_body["source_schema_id"]:
                status = "CONTRADICTED"
                reasons.append("SOURCE_SCHEMA_MISMATCH")
            if target is not None and target["schema_id"] != transition_body["target_schema_id"]:
                status = "CONTRADICTED"
                reasons.append("TARGET_SCHEMA_MISMATCH")
            if target is not None:
                removed_labels = set(snap["labels"]) - set(target["labels"])
                changed_conditions = {
                    key for key, value in snap["conditions"].items()
                    if key not in target["conditions"] or canonical(target["conditions"][key]) != canonical(value)
                }
                required_relaxations = {"label:" + value for value in removed_labels} | {"condition:" + value for value in changed_conditions}
                observed_relaxations[transition["transition_root"]].update(required_relaxations)
                approved = set(transition_body["approved_relaxations"])
                if not required_relaxations <= approved:
                    status = "CONTRADICTED"
                    reasons.append("UNAPPROVED_SECURITY_RELAXATION")
                if not set(transition_body["retained_labels"]) <= set(target["labels"]):
                    status = "CONTRADICTED"
                    reasons.append("REQUIRED_LABEL_MISSING")
                if not set(transition_body["retained_condition_keys"]) <= set(target["conditions"]):
                    status = "CONTRADICTED"
                    reasons.append("REQUIRED_CONDITION_MISSING")
                elif any(
                    canonical(target["conditions"][key]) != canonical(snap["conditions"].get(key))
                    for key in transition_body["retained_condition_keys"]
                ):
                    status = "CONTRADICTED"
                    reasons.append("REQUIRED_CONDITION_CHANGED")
        transfer = next((item for item in receipts if
            item["source_object_id"] == source_id and item["target_object_id"] == target_id
            and item["source_root"] == required_source_root and item["target_root"] == required_target_root
        ), None)
        if not transfer_eligible or target is None or target["content_root"] != required_target_root or transfer is None:
            if status == "MATCH":
                status = "INSUFFICIENT"
            reasons.append("TRANSFER_INCOMPLETE")
            remaining.append(source_id)
        else:
            completed_effects.append({"source_object_id": source_id, "target_object_id": target_id, "target_root": target["content_root"], "transfer_id": transfer["transfer_id"]})
        checks["object." + source_id] = status
        object_rows.append({"source_object_id": source_id, "target_object_id": target_id, "status": status, "reasons": sorted(set(reasons))})

    for transition_root, transition in transitions.items():
        checks["relaxations." + transition["body"]["transition_id"]] = (
            "MATCH" if observed_relaxations[transition_root] == set(transition["body"]["approved_relaxations"])
            else "CONTRADICTED"
        )

    staging = evidence["staging"]
    staging_match = staging is not None and staging["status"] == "PASS" and staging["plan_root"] == plan["plan_root"] and staging["destination_inventory_root"] == destination_inventory["inventory_root"]
    checks["stage.staging"] = "MATCH" if staging_match else "INSUFFICIENT"
    cutover = evidence["cutover"]
    objects_ready = all(checks["object." + item["source_object_id"]] == "MATCH" for item in body["object_mappings"])
    cutover_match = (
        cutover is not None and cutover["status"] == "PASS" and cutover["plan_root"] == plan["plan_root"]
        and cutover["destination_inventory_root"] == destination_inventory["inventory_root"]
        and not remaining and staging_match and objects_ready
    )
    checks["stage.cutover"] = "MATCH" if cutover_match else "INSUFFICIENT"

    source_o = source_obligations["body"]
    target_o = destination_obligations["body"]
    onward_rank = {"PROHIBITED": 0, "APPROVAL_REQUIRED": 1, "ALLOWED": 2}
    obligation_conflicts = []
    if not set(target_o["purpose_ids"]) <= set(source_o["purpose_ids"]):
        obligation_conflicts.append("PURPOSE_EXPANSION")
    if onward_rank[target_o["onward_transfer"]] > onward_rank[source_o["onward_transfer"]]:
        obligation_conflicts.append("ONWARD_TRANSFER_RELAXED")
    if source_o["retention_until"] is not None and (target_o["retention_until"] is None or target_o["retention_until"] < source_o["retention_until"]):
        obligation_conflicts.append("RETENTION_SHORTENED")
    if source_o["legal_hold"] and not target_o["legal_hold"]:
        obligation_conflicts.append("LEGAL_HOLD_DROPPED")
    if source_o["legal_hold"] and source_o["source_disposition"] == "DELETE_AFTER_CUTOVER":
        obligation_conflicts.append("HOLD_DELETE_CONFLICT")
    if not set(target_o["residency"]) <= set(source_o["residency"]):
        obligation_conflicts.append("RESIDENCY_EXPANDED")
    checks["obligations.compatible"] = "MATCH" if not obligation_conflicts else "CONTRADICTED"
    missing_purpose = sorted(set(target_o["purpose_ids"]) - set(evidence["purpose_evidence"]))
    missing_residency = sorted(set(target_o["residency"]) - set(evidence["residency_evidence"]))
    missing_followup = sorted(set(target_o["required_followup_evidence"]) - set(evidence["followup_evidence"]))
    checks["evidence.purpose"] = "MATCH" if not missing_purpose else "INSUFFICIENT"
    checks["evidence.residency"] = "MATCH" if not missing_residency else "INSUFFICIENT"
    checks["evidence.followup"] = "MATCH" if not missing_followup else "INSUFFICIENT"

    dispositions = {item["object_id"]: item for item in evidence["source_dispositions"]}
    disposition_rows = []
    expected_action = {
        "RETAIN": "RETAIN", "ARCHIVE": "ARCHIVE", "DELETE_AFTER_CUTOVER": "DELETE",
    }[source_o["source_disposition"]]
    for object_id in snapshot:
        row = dispositions.get(object_id)
        disposition_match = (
            row is not None and row["action"] == expected_action and row["status"] == "COMPLETED"
            and row["coverage"] == "EXACT_OBJECT"
            and (expected_action != "DELETE" or cutover_match)
        )
        checks["disposition." + object_id] = "MATCH" if disposition_match else "INSUFFICIENT"
        disposition_rows.append({"object_id": object_id, "expected_action": expected_action, "evidence": clone(row) if row else None})

    report = multi_check_report(
        checks,
        details={
            "plan_root": plan["plan_root"],
            "snapshot_inventory_root": snapshot_inventory["inventory_root"],
            "current_source_inventory_root": current_source_inventory["inventory_root"],
            "destination_inventory_root": destination_inventory["inventory_root"],
            "objects": object_rows,
            "completed_effects": completed_effects,
            "remaining_source_object_ids": sorted(set(remaining)),
            "interrupted": evidence["interrupted"],
            "retry_rule": "RECONCILE_COMPLETED_DESTINATION_EFFECTS_BEFORE_RETRY",
            "cutover_established": cutover_match,
            "obligation_conflicts": sorted(obligation_conflicts),
            "missing_purpose_evidence": missing_purpose,
            "missing_residency_evidence": missing_residency,
            "missing_followup_evidence": missing_followup,
            "source_dispositions": disposition_rows,
            "universal_erasure": "NOT_CLAIMED",
            "unobserved_behavior": "NOT_CLAIMED",
        },
        claim_ceiling="Exact supplied inventory, transfer, staging, cutover, schema, policy and obligation evidence only; no universal erasure, ambient compliance or unobserved behavior.",
    )
    report["schema"] = "cmba.data-migration-assessment.v2"
    return report
