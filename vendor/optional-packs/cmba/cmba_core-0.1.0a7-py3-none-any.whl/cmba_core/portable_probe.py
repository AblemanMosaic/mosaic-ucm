"""Installed-distribution probe for the Portable Evaluation Package."""
from __future__ import annotations

import hashlib
import json

from cmba_agent.protocol import dispatch, distribution_version

from .codec import canonical
from .demo import chc
from .portable import build_package, open_package, replay_invocation


def probe() -> dict:
    bundle = chc()
    request = {
        "schema": "cmba.request.v0.1-i1",
        "operation": "evaluate",
        "arguments": {
            "binding": bundle["binding"],
            "values": bundle["values"],
            "context": bundle["context"],
        },
    }
    response = dispatch("core", request)
    request_bytes = canonical(request)
    response_bytes = canonical(response)
    binding_bytes = canonical(bundle["binding"])
    members = {
        "evaluation/request.json": request_bytes,
        "evaluation/response.json": response_bytes,
        "records/binding.json": binding_bytes,
    }
    specs = {
        "evaluation/request.json": {"role": "evaluation_request", "media_type": "application/json", "required": True},
        "evaluation/response.json": {"role": "evaluation_response", "media_type": "application/json", "required": True},
        "records/binding.json": {"role": "binding", "media_type": "application/json", "required": True},
    }
    package = build_package(
        members,
        specs,
        invocations=[{
            "id": "installed-core-evaluation",
            "interface": "core",
            "request_member": "evaluation/request.json",
            "expected_response_member": "evaluation/response.json",
            "effect_class": "PURE_READ",
        }],
        coverage=["binding_integrity", "profile_evaluation", "receipt_reconstruction"],
    )
    opened = open_package(package)
    request_hash = hashlib.sha256(request_bytes).hexdigest()
    replay = replay_invocation(opened, "installed-core-evaluation", request_hash)
    return {
        "schema": "cmba.portable-installed-probe.v1",
        "status": "PASS",
        "distribution_version": distribution_version(),
        "package_sha256": hashlib.sha256(package).hexdigest(),
        "binding_root": bundle["binding"]["binding_root"],
        "request_sha256": request_hash,
        "response_sha256": hashlib.sha256(response_bytes).hexdigest(),
        "replay_status": replay["status"],
        "network": False,
        "filesystem_extraction": False,
        "authority_effect": "NONE",
    }


def main() -> int:
    print(json.dumps(probe(), sort_keys=True, separators=(",", ":")))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
