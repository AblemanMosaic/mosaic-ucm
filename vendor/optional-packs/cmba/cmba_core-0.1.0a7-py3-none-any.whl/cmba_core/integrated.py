"""Bounded integrated discovery, composition records, and shared views."""
from __future__ import annotations

import hashlib
from typing import Any

from .bindings import exact, hex_digest, identifier
from .codec import canonical, clone
from .errors import Refusal, require
from .extensions import capabilities


SENSITIVE_KEYS = {"private_key", "private_key_hex", "password", "credential", "credentials", "secret", "token", "access_token"}


def _root(domain: str, value: Any) -> str:
    return hashlib.sha256(("CMBA:INTEGRATED:v1:" + domain + "\0").encode("ascii") + canonical(value)).hexdigest()


def _no_sensitive(value: Any) -> None:
    if type(value) is dict:
        require(not (set(value) & SENSITIVE_KEYS), "CMBA_INTEGRATED_SENSITIVE_FIELD")
        for item in value.values():
            _no_sensitive(item)
    elif type(value) is list:
        for item in value:
            _no_sensitive(item)


def discovery() -> dict[str, Any]:
    rows = capabilities()
    return {
        "schema": "cmba.integrated-discovery.v1",
        "profiles": rows,
        "profile_count": len(rows),
        "operations": ["compose-data-governance", "compose-software-ccp", "view"],
        "limits": {"max_request_bytes": 1048576, "max_depth": 32, "max_nodes": 16384},
        "unsupported_operation_disposition": "TYPED_REFUSAL",
        "authority_effect": "NONE",
    }


def composition(
    composition_id: str,
    kind: str,
    stages: list[dict[str, Any]],
    findings: list[dict[str, Any]],
    *,
    native_reference_roots: list[str],
    changed_context_root: str | None,
) -> dict[str, Any]:
    identifier(composition_id)
    require(kind in {"SOFTWARE_CCP", "DATA_GOVERNANCE"}, "CMBA_INTEGRATED_KIND")
    require(type(stages) is list and 2 <= len(stages) <= 32, "CMBA_INTEGRATED_STAGES")
    stage_rows = []
    seen = set()
    for raw in stages:
        exact(raw, {"stage_id", "input_roots", "output_root", "status", "evidence_class"})
        identifier(raw["stage_id"])
        require(raw["stage_id"] not in seen, "CMBA_INTEGRATED_STAGE_DUPLICATE")
        seen.add(raw["stage_id"])
        require(type(raw["input_roots"]) is list and raw["input_roots"] == sorted(set(raw["input_roots"])), "CMBA_INTEGRATED_INPUTS")
        for value in [*raw["input_roots"], raw["output_root"]]:
            hex_digest(value)
        require(raw["status"] in {"PASS", "FAIL", "REFUSED", "REPAIRED", "UNSUPPORTED"}, "CMBA_INTEGRATED_STATUS")
        require(raw["evidence_class"] in {"DECLARATION", "STRUCTURAL", "NATIVE_OBSERVATION", "COMPOSED_ASSESSMENT"}, "CMBA_INTEGRATED_EVIDENCE_CLASS")
        stage_rows.append(clone(raw))
    require(type(findings) is list and findings, "CMBA_INTEGRATED_FINDINGS")
    finding_rows = []
    finding_ids = set()
    for raw in findings:
        exact(raw, {"finding_id", "generation", "status", "subject_root", "evidence_roots", "disclosure"})
        identifier(raw["finding_id"])
        require(raw["finding_id"] not in finding_ids, "CMBA_INTEGRATED_FINDING_DUPLICATE")
        finding_ids.add(raw["finding_id"])
        require(raw["generation"] in {"HISTORICAL", "CURRENT"}, "CMBA_INTEGRATED_GENERATION")
        require(raw["status"] in {"SUPPORT", "CONTRADICT", "UNRESOLVED", "REPAIRED"}, "CMBA_INTEGRATED_FINDING_STATUS")
        require(raw["disclosure"] in {"INCLUDED", "ROOT_ONLY", "EXCLUDED"}, "CMBA_INTEGRATED_DISCLOSURE")
        hex_digest(raw["subject_root"])
        for value in raw["evidence_roots"]:
            hex_digest(value)
        finding_rows.append(clone(raw))
    require(type(native_reference_roots) is list and native_reference_roots == sorted(set(native_reference_roots)), "CMBA_INTEGRATED_NATIVE_ROOTS")
    for value in native_reference_roots:
        hex_digest(value)
    native_set = set(native_reference_roots)
    require(all(row["output_root"] in native_set for row in stage_rows if row["evidence_class"] == "NATIVE_OBSERVATION"), "CMBA_INTEGRATED_NATIVE_EVIDENCE_UNBOUND")
    require(changed_context_root is None or (hex_digest(changed_context_root) and True), "CMBA_INTEGRATED_CONTEXT_ROOT")
    _no_sensitive({"stages": stage_rows, "findings": finding_rows})
    body = {
        "schema": "cmba.integrated-composition-body.v1", "composition_id": composition_id, "kind": kind,
        "stages": stage_rows, "findings": finding_rows, "native_reference_roots": native_reference_roots,
        "changed_context_root": changed_context_root, "references_only": False,
        "effect_authorized": False, "authority_effect": "NONE",
    }
    return {"schema": "cmba.integrated-composition.v1", "body": body, "composition_root": _root("composition", body)}


def validate_composition(value: dict[str, Any]) -> None:
    exact(value, {"schema", "body", "composition_root"})
    require(value["schema"] == "cmba.integrated-composition.v1", "CMBA_INTEGRATED_COMPOSITION_SCHEMA")
    body = value["body"]
    rebuilt = composition(
        body["composition_id"], body["kind"], body["stages"], body["findings"],
        native_reference_roots=body["native_reference_roots"], changed_context_root=body["changed_context_root"],
    )
    require(canonical(rebuilt) == canonical(value), "CMBA_INTEGRATED_COMPOSITION_ROOT")


def shared_view(composed: dict[str, Any], *, excluded_attachment_roots: list[str]) -> dict[str, Any]:
    _no_sensitive(composed)
    validate_composition(composed)
    require(type(excluded_attachment_roots) is list and excluded_attachment_roots == sorted(set(excluded_attachment_roots)), "CMBA_INTEGRATED_EXCLUSIONS")
    for value in excluded_attachment_roots:
        hex_digest(value)
    body = composed["body"]
    historical = [row for row in body["findings"] if row["generation"] == "HISTORICAL"]
    current = [row for row in body["findings"] if row["generation"] == "CURRENT"]
    view = {
        "schema": "cmba.integrated-view-body.v1", "composition_root": composed["composition_root"],
        "claim_scope": body["kind"], "evidence_coverage": [{"stage_id": row["stage_id"], "status": row["status"], "evidence_class": row["evidence_class"]} for row in body["stages"]],
        "historical_findings": historical, "current_findings": current,
        "native_roots": body["native_reference_roots"], "changed_context_root": body["changed_context_root"],
        "excluded_attachment_roots": excluded_attachment_roots, "excluded_attachment_payloads": [],
        "private_material_included": False, "effect_authorized": False, "authority_effect": "NONE",
    }
    view_root = _root("view", view)
    return {
        "schema": "cmba.integrated-shared-view.v1", "view_root": view_root,
        "agent_view": {"schema": "cmba.integrated-agent-view.v1", "body": clone(view), "view_root": view_root},
        "human_view": {"schema": "cmba.integrated-human-view.v1", "body": clone(view), "view_root": view_root},
        "authority_effect": "NONE",
    }


def dispatch(request: dict[str, Any]) -> dict[str, Any]:
    canonical(request)
    exact(request, {"schema", "operation", "arguments"})
    require(request["schema"] == "cmba.integrated-request.v1", "CMBA_INTEGRATED_REQUEST_SCHEMA")
    operation, arguments = request["operation"], request["arguments"]
    require(type(operation) is str and type(arguments) is dict, "CMBA_INTEGRATED_REQUEST_TYPE")
    if operation == "discover":
        exact(arguments, set())
        return discovery()
    if operation == "view":
        exact(arguments, {"composition", "excluded_attachment_roots"})
        return shared_view(arguments["composition"], excluded_attachment_roots=arguments["excluded_attachment_roots"])
    raise Refusal("CMBA_INTEGRATED_OPERATION_UNSUPPORTED")
