"""CMBA records for observable Pippi turns and faithful GenDev projection.

Only visible/native records are represented. Hidden reasoning, host mediation,
authenticated authorship, policy correctness, and effect success are never
inferred from declarations or structural roots.
"""
from __future__ import annotations

import hashlib
from typing import Any

from .bindings import exact, hex_digest, identifier
from .codec import canonical, clone
from .contract_types import multi_check_report
from .errors import require


DECISIONS = {"PASS", "ADVISORY", "HELD", "REFUSED"}
TOOL_STATUSES = {"PROPOSED", "DISPATCHED", "SUCCEEDED", "FAILED", "UNCERTAIN"}
EFFECT_CLASSES = {
    "NONE", "PURE_COMPUTATION", "READ_ONLY", "LOCAL_ARTIFACT_PREPARATION",
    "WRITE_WORKSPACE", "DELETE_WORKSPACE", "NETWORK", "INSTALL",
    "PERSISTENT_HOST_STATE", "AUTHORITY_CHANGE",
}


def _root(domain: str, value: Any) -> str:
    return hashlib.sha256(("CMBA:PIPPI:v2:" + domain + "\0").encode("ascii") + canonical(value)).hexdigest()


def _ids(values: list[str], code: str, *, allow_empty: bool = False) -> list[str]:
    require(type(values) is list and (allow_empty or values) and values == sorted(set(values)), code)
    for value in values:
        identifier(value)
    return list(values)


def _optional_root(value: str | None) -> None:
    require(value is None or (hex_digest(value) and True), "CMBA_PIPPI_ROOT")


def observable_turn(
    turn_id: str,
    sequence: int,
    previous_turn_root: str | None,
    context_root: str,
    draft_root: str,
    decision_root: str,
    projection_root: str,
    declared_proposal_ids: list[str],
    proposals: list[dict[str, Any]],
    tools: list[dict[str, Any]],
    expected_journal_head: str,
    observed_journal_head: str,
    native_turn_root: str,
) -> dict[str, Any]:
    identifier(turn_id)
    require(type(sequence) is int and type(sequence) is not bool and sequence >= 1, "CMBA_PIPPI_SEQUENCE")
    require((sequence == 1) == (previous_turn_root is None), "CMBA_PIPPI_PREDECESSOR")
    _optional_root(previous_turn_root)
    for value in (context_root, draft_root, decision_root, projection_root, expected_journal_head, observed_journal_head, native_turn_root):
        hex_digest(value)
    denominator = _ids(declared_proposal_ids, "CMBA_PIPPI_PROPOSAL_DENOMINATOR", allow_empty=True)
    proposal_rows = []
    seen = set()
    require(type(proposals) is list and len(proposals) <= 64, "CMBA_PIPPI_PROPOSALS")
    for raw in proposals:
        exact(raw, {"proposal_id", "payload_root", "effect_class", "decision", "policy_evaluation_root", "policy_recomputed"})
        identifier(raw["proposal_id"])
        require(raw["proposal_id"] not in seen, "CMBA_PIPPI_PROPOSAL_DUPLICATE")
        seen.add(raw["proposal_id"])
        hex_digest(raw["payload_root"])
        require(raw["effect_class"] in EFFECT_CLASSES and raw["decision"] in DECISIONS, "CMBA_PIPPI_PROPOSAL")
        _optional_root(raw["policy_evaluation_root"])
        require(type(raw["policy_recomputed"]) is bool, "CMBA_PIPPI_POLICY_RECOMPUTED")
        proposal_rows.append(clone(raw))
    require(seen == set(denominator), "CMBA_PIPPI_PROPOSAL_DENOMINATOR")
    tool_rows = []
    tool_ids = set()
    require(type(tools) is list and len(tools) <= 64, "CMBA_PIPPI_TOOLS")
    for raw in tools:
        exact(raw, {"tool_id", "proposal_id", "proposal_root", "dispatch_root", "terminal_root", "status"})
        identifier(raw["tool_id"])
        require(raw["tool_id"] not in tool_ids and raw["proposal_id"] in seen, "CMBA_PIPPI_TOOL")
        tool_ids.add(raw["tool_id"])
        identifier(raw["proposal_id"])
        hex_digest(raw["proposal_root"])
        _optional_root(raw["dispatch_root"])
        _optional_root(raw["terminal_root"])
        require(raw["status"] in TOOL_STATUSES, "CMBA_PIPPI_TOOL_STATUS")
        require((raw["status"] == "PROPOSED") == (raw["dispatch_root"] is None), "CMBA_PIPPI_TOOL_DISPATCH")
        if raw["status"] in {"SUCCEEDED", "FAILED"}:
            require(raw["terminal_root"] is not None, "CMBA_PIPPI_TOOL_TERMINAL")
        if raw["terminal_root"] is None:
            require(raw["status"] not in {"SUCCEEDED", "FAILED"}, "CMBA_PIPPI_TOOL_TERMINAL")
        tool_rows.append(clone(raw))
    body = {
        "schema": "cmba.pippi-observable-turn-body.v2",
        "turn_id": turn_id, "sequence": sequence, "previous_turn_root": previous_turn_root,
        "context_root": context_root, "draft_root": draft_root, "decision_root": decision_root,
        "projection_root": projection_root, "declared_proposal_ids": denominator,
        "proposals": sorted(proposal_rows, key=lambda row: row["proposal_id"]),
        "tools": sorted(tool_rows, key=lambda row: row["tool_id"]),
        "expected_journal_head": expected_journal_head,
        "observed_journal_head": observed_journal_head,
        "native_turn_root": native_turn_root,
        "observable_only": True, "authority_effect": "NONE",
    }
    return {"schema": "cmba.pippi-observable-turn.v2", "body": body, "turn_root": _root("turn", body)}


def validate_observable_turn(value: dict[str, Any]) -> None:
    canonical(value)
    exact(value, {"schema", "body", "turn_root"})
    require(value["schema"] == "cmba.pippi-observable-turn.v2", "CMBA_PIPPI_TURN_SCHEMA")
    hex_digest(value["turn_root"])
    body = value["body"]
    rebuilt = observable_turn(
        body["turn_id"], body["sequence"], body["previous_turn_root"], body["context_root"],
        body["draft_root"], body["decision_root"], body["projection_root"],
        body["declared_proposal_ids"], body["proposals"], body["tools"],
        body["expected_journal_head"], body["observed_journal_head"], body["native_turn_root"],
    )
    require(canonical(rebuilt) == canonical(value), "CMBA_PIPPI_TURN_ROOT")


def assess_turn_chain(turns: list[dict[str, Any]], *, expected_context_root: str, expected_initial_journal_head: str) -> dict[str, Any]:
    hex_digest(expected_context_root)
    hex_digest(expected_initial_journal_head)
    require(type(turns) is list and turns, "CMBA_PIPPI_TURN_CHAIN")
    checks = {}
    rows = []
    previous_turn = None
    previous_journal = expected_initial_journal_head
    for index, turn in enumerate(turns, 1):
        validate_observable_turn(turn)
        body = turn["body"]
        checks[f"turn.{index}.sequence"] = "MATCH" if body["sequence"] == index else "CONTRADICTED"
        checks[f"turn.{index}.predecessor"] = "MATCH" if body["previous_turn_root"] == previous_turn else "CONTRADICTED"
        checks[f"turn.{index}.context"] = "MATCH" if body["context_root"] == expected_context_root else "CONTRADICTED"
        checks[f"turn.{index}.journal"] = "MATCH" if body["expected_journal_head"] == previous_journal else "CONTRADICTED"
        checks[f"turn.{index}.proposal-denominator"] = "MATCH"
        unrecomputed = [row["proposal_id"] for row in body["proposals"] if row["policy_evaluation_root"] is not None and not row["policy_recomputed"]]
        uncertain = [row["tool_id"] for row in body["tools"] if row["status"] in {"DISPATCHED", "UNCERTAIN"} and row["terminal_root"] is None]
        checks[f"turn.{index}.policy-recomputation"] = "MATCH" if not unrecomputed else "INSUFFICIENT"
        checks[f"turn.{index}.tool-terminal"] = "MATCH" if not uncertain else "INSUFFICIENT"
        rows.append({
            "turn_root": turn["turn_root"], "native_turn_root": body["native_turn_root"],
            "unrecomputed_policy_proposal_ids": unrecomputed,
            "uncertain_tool_ids": uncertain,
            "retry_disposition": "NO_BLIND_REPLAY_RECONCILE_FIRST" if uncertain else "NO_RETRY_REQUIRED",
        })
        previous_turn = turn["turn_root"]
        previous_journal = body["observed_journal_head"]
    report = multi_check_report(
        checks,
        details={
            "turns": rows, "final_turn_root": previous_turn,
            "final_journal_head": previous_journal,
            "mixed_turn_records_accepted": False,
            "hidden_reasoning": "NOT_OBSERVED_OR_CLAIMED",
            "policy_root_rule": "STRUCTURAL_REFERENCE_NEVER_SUBSTITUTES_FOR_RECOMPUTATION",
            "execution_authorized": False,
        },
        claim_ceiling="Observable turn cross-links, complete proposal denominator, supplied policy recomputation status, and journal continuity only; no hidden reasoning, host enforcement, effect success, or execution authority.",
    )
    report["schema"] = "cmba.pippi-turn-chain-assessment.v2"
    return report


def gendev_projection(
    turn: dict[str, Any],
    sources: list[dict[str, Any]],
    spans: list[dict[str, Any]],
    interpretations: list[dict[str, Any]],
    *,
    required_proposal_ids: list[str],
    selected_proposal_ids: list[str],
) -> dict[str, Any]:
    validate_observable_turn(turn)
    source_rows = []
    source_map = {}
    require(type(sources) is list and sources, "CMBA_PIPPI_GENDEV_SOURCES")
    for raw in sources:
        exact(raw, {"source_id", "text", "attribution_kind", "attribution_label", "native_reference_root"})
        identifier(raw["source_id"])
        require(raw["source_id"] not in source_map and type(raw["text"]) is str, "CMBA_PIPPI_GENDEV_SOURCE")
        require(raw["attribution_kind"] in {"SUPPLIED", "NATIVE_RECORD", "GENERATED"}, "CMBA_PIPPI_GENDEV_ATTRIBUTION")
        require(type(raw["attribution_label"]) is str and raw["attribution_label"], "CMBA_PIPPI_GENDEV_ATTRIBUTION")
        hex_digest(raw["native_reference_root"])
        encoded = raw["text"].encode("utf-8")
        row = {**clone(raw), "text_sha256": hashlib.sha256(encoded).hexdigest(), "utf8_bytes": len(encoded)}
        source_rows.append(row)
        source_map[raw["source_id"]] = row
    span_rows = []
    require(type(spans) is list, "CMBA_PIPPI_GENDEV_SPANS")
    for raw in spans:
        exact(raw, {"span_id", "source_id", "start_byte", "end_byte", "quoted_utf8_hex", "native_reference_root"})
        identifier(raw["span_id"])
        require(raw["source_id"] in source_map, "CMBA_PIPPI_GENDEV_SPAN_SOURCE")
        identifier(raw["source_id"])
        require(type(raw["start_byte"]) is int and type(raw["end_byte"]) is int and 0 <= raw["start_byte"] < raw["end_byte"], "CMBA_PIPPI_GENDEV_SPAN")
        encoded = source_map[raw["source_id"]]["text"].encode("utf-8")
        require(raw["end_byte"] <= len(encoded) and encoded[raw["start_byte"]:raw["end_byte"]].hex() == raw["quoted_utf8_hex"], "CMBA_PIPPI_GENDEV_QUOTE")
        require(raw["native_reference_root"] == source_map[raw["source_id"]]["native_reference_root"], "CMBA_PIPPI_GENDEV_NATIVE_REFERENCE")
        span_rows.append(clone(raw))
    interpretation_rows = []
    require(type(interpretations) is list, "CMBA_PIPPI_GENDEV_INTERPRETATIONS")
    span_ids = {row["span_id"] for row in span_rows}
    for raw in interpretations:
        exact(raw, {"interpretation_id", "text", "supporting_span_ids", "authorship"})
        identifier(raw["interpretation_id"])
        require(type(raw["text"]) is str and raw["text"] and raw["authorship"] == "GENERATED_INTERPRETATION", "CMBA_PIPPI_GENDEV_INTERPRETATION")
        supports = _ids(raw["supporting_span_ids"], "CMBA_PIPPI_GENDEV_SUPPORT", allow_empty=True)
        require(set(supports) <= span_ids, "CMBA_PIPPI_GENDEV_SUPPORT")
        interpretation_rows.append({**clone(raw), "supporting_span_ids": supports})
    required = _ids(required_proposal_ids, "CMBA_PIPPI_GENDEV_COVERAGE", allow_empty=True)
    selected = _ids(selected_proposal_ids, "CMBA_PIPPI_GENDEV_COVERAGE", allow_empty=True)
    declared = set(turn["body"]["declared_proposal_ids"])
    require(set(required) <= declared and set(selected) <= declared, "CMBA_PIPPI_GENDEV_COVERAGE")
    body = {
        "schema": "cmba.pippi-gendev-projection-body.v2",
        "turn_root": turn["turn_root"], "native_turn_root": turn["body"]["native_turn_root"],
        "sources": sorted(source_rows, key=lambda row: row["source_id"]),
        "spans": sorted(span_rows, key=lambda row: row["span_id"]),
        "interpretations": sorted(interpretation_rows, key=lambda row: row["interpretation_id"]),
        "coverage": {
            "required_proposal_ids": required, "selected_proposal_ids": selected,
            "omitted_proposal_ids": sorted(set(required) - set(selected)),
            "complete": set(required) <= set(selected),
        },
        "exact_quoted_bytes_preserved": True,
        "hidden_reasoning": "NOT_INCLUDED",
        "authority_effect": "NONE",
    }
    return {"schema": "cmba.pippi-gendev-projection.v2", "body": body, "projection_root": _root("gendev", body)}


def assess_host_coverage(
    *,
    declared_channels: list[str],
    claimed_mode: str,
    expected_host_policy_root: str | None,
    observed_host_policy_root: str | None,
    host_attestation_root: str | None,
    attestation_verified: bool,
    policy_recomputed: bool,
    authenticated_actor_root: str | None,
) -> dict[str, Any]:
    channels = _ids(declared_channels, "CMBA_PIPPI_CHANNELS", allow_empty=True)
    require(claimed_mode in {"SIDECAR_PARTIAL", "ENFORCED_HOST"}, "CMBA_PIPPI_HOST_MODE")
    for value in (expected_host_policy_root, observed_host_policy_root, host_attestation_root, authenticated_actor_root):
        _optional_root(value)
    require(type(attestation_verified) is bool and type(policy_recomputed) is bool, "CMBA_PIPPI_HOST_EVIDENCE")
    anchored = expected_host_policy_root is not None and observed_host_policy_root == expected_host_policy_root
    enforced = claimed_mode == "ENFORCED_HOST" and anchored and host_attestation_root is not None and attestation_verified and policy_recomputed
    checks = {
        "host.policy-anchor": "MATCH" if anchored else "INSUFFICIENT",
        "host.attestation": "MATCH" if host_attestation_root is not None and attestation_verified else "INSUFFICIENT",
        "host.policy-recomputed": "MATCH" if policy_recomputed else "INSUFFICIENT",
    }
    if claimed_mode == "SIDECAR_PARTIAL":
        checks = {name: "NOT_CHECKED" for name in checks}
    result = multi_check_report(
        checks,
        details={
            "declared_channels": channels,
            "claimed_mode": claimed_mode,
            "effective_mode": "ENFORCED_HOST" if enforced else "SIDECAR_PARTIAL",
            "declarations_are_proof": False,
            "authenticated_authorship": "ESTABLISHED_FOR_SUPPLIED_ACTOR_ROOT" if authenticated_actor_root is not None and enforced else "NOT_ESTABLISHED",
            "policy_correctness": "NOT_ESTABLISHED",
            "execution_authorized": False,
        },
        claim_ceiling="Exact supplied host-policy anchor and attestation checks only; channel declarations alone never establish host enforcement, authorship, policy correctness, or authority.",
    )
    result["schema"] = "cmba.pippi-host-coverage-assessment.v2"
    return result
