"""Installed-runtime probe for the release and realization v2 contracts."""
from __future__ import annotations

import hashlib
import json
import platform
from pathlib import Path

from . import __version__
from .codec import canonical
from .extensions import contracts
from .qualification import evaluate_realization, realization_record


def _sha(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def probe() -> dict:
    installed = {
        row["body"]["identity"]["extension_id"]: row
        for row in contracts()
    }
    contract = installed["cmba.realization"]
    implementation_path = Path(__file__).with_name("qualification.py")
    adapter_path = Path(__file__).with_name("__init__.py")
    platform_facts = {
        "implementation": platform.python_implementation(),
        "python": platform.python_version(),
        "system": platform.system(),
        "machine": platform.machine(),
    }
    case_root = _sha(canonical({"profile_ids": sorted(installed), "count": len(installed)}))
    roots = {
        "contract_root": contract["contract_hash"],
        "implementation_root": _sha(implementation_path.read_bytes()),
        "platform_root": _sha(canonical(platform_facts)),
        "adapter_root": _sha(adapter_path.read_bytes()),
        "corpus_root": _sha(canonical({"cases": ["installed-extension-registry"]})),
    }
    record = realization_record(
        "installed-python-reference", roots["contract_root"], roots["implementation_root"],
        roots["platform_root"], roots["adapter_root"], roots["corpus_root"],
        [{
            "case_id": "installed-extension-registry",
            "expected_root": case_root,
            "observed_root": case_root,
            "status": "PASS",
        }],
        evidence_class="NATIVE_OBSERVATION",
    )
    assessment = evaluate_realization(record, roots)
    return {
        "schema": "cmba.installed-qualification-probe.v1",
        "status": "PASS" if assessment["status"] == "MATCH_FOR_SUPPLIED_EVIDENCE" else "FAIL",
        "version": __version__,
        "module_path": str(Path(__file__).resolve()),
        "extension_count": len(installed),
        "required_extensions": {
            name: installed[name]["contract_hash"]
            for name in ["cmba.release", "cmba.realization"]
        },
        "realization_record": record,
        "realization_assessment": assessment,
        "platform": platform_facts,
        "authority_effect": "NONE",
    }


def main() -> int:
    result = probe()
    print(json.dumps(result, sort_keys=True, separators=(",", ":")))
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
