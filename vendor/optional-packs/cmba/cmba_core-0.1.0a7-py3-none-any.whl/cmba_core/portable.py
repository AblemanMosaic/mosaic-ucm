"""Portable Evaluation Package v1: finite in-memory admission and replay.

Import never extracts files, retrieves references, installs trust, or loads code
named by package data. Invocation replay requires an independently supplied
request hash and uses only the closed installed agent interfaces.
"""
from __future__ import annotations

import hashlib
import io
import re
import stat
import zipfile
from typing import Any

from .codec import canonical, clone, decode
from .errors import Refusal, require


MANIFEST = "CMBA-PACKAGE.json"
SCHEMA = "cmba.portable-evaluation-package.v1"
MAX_ARCHIVE_BYTES = 20 * 1024 * 1024
MAX_MEMBERS = 128
MAX_MEMBER_BYTES = 4 * 1024 * 1024
MAX_TOTAL_BYTES = 16 * 1024 * 1024
MAX_NESTING = 3
_PATH = re.compile(r"[A-Za-z0-9][A-Za-z0-9._/-]*\Z")
_ROLES = {
    "binding",
    "values",
    "document_context",
    "profile_contract",
    "schema",
    "evidence",
    "endorsement",
    "evaluation_request",
    "evaluation_response",
    "receipt",
    "native_record",
    "attachment",
    "nested_package",
}
_INTERFACES = {"core", "app", "workbench"}


def _hash(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _manifest_hash(body: dict[str, Any]) -> str:
    return hashlib.sha256(b"CMBA:portable-package-manifest:v1\0" + canonical(body)).hexdigest()


def _path(value: Any) -> str:
    require(type(value) is str and _PATH.fullmatch(value) is not None, "CMBA_PACKAGE_PATH")
    require("\\" not in value and ":" not in value and "//" not in value, "CMBA_PACKAGE_PATH")
    parts = value.split("/")
    require(all(part not in ("", ".", "..") for part in parts), "CMBA_PACKAGE_PATH")
    require(value != MANIFEST, "CMBA_PACKAGE_RESERVED_PATH")
    return value


def _member_spec(path: str, data: bytes, spec: dict[str, Any]) -> dict[str, Any]:
    require(type(data) is bytes, "CMBA_PACKAGE_MEMBER_BYTES")
    require(type(spec) is dict and set(spec) == {"role", "media_type", "required"}, "CMBA_PACKAGE_MEMBER_SPEC")
    require(spec["role"] in _ROLES, "CMBA_PACKAGE_MEMBER_ROLE")
    require(type(spec["media_type"]) is str and 0 < len(spec["media_type"]) <= 128, "CMBA_PACKAGE_MEDIA_TYPE")
    require(type(spec["required"]) is bool, "CMBA_PACKAGE_MEMBER_SPEC")
    require(len(data) <= MAX_MEMBER_BYTES, "CMBA_PACKAGE_MEMBER_LIMIT")
    if spec["media_type"] == "application/json":
        decode(data)
    if spec["role"] == "nested_package":
        require(spec["media_type"] == "application/vnd.cmba.package+zip", "CMBA_PACKAGE_NESTED_TYPE")
    return {
        "path": _path(path),
        "role": spec["role"],
        "media_type": spec["media_type"],
        "required": spec["required"],
        "bytes": len(data),
        "sha256": _hash(data),
    }


def _references(values: list[dict[str, Any]]) -> list[dict[str, Any]]:
    require(type(values) is list, "CMBA_PACKAGE_REFERENCE_TYPE")
    result = []
    ids = set()
    for value in values:
        require(type(value) is dict, "CMBA_PACKAGE_REFERENCE_TYPE")
        require(set(value) == {"id", "role", "sha256", "bytes", "required", "locator"}, "CMBA_PACKAGE_REFERENCE_FIELDS")
        require(type(value["id"]) is str and 0 < len(value["id"]) <= 128, "CMBA_PACKAGE_REFERENCE_ID")
        require(value["id"] not in ids, "CMBA_PACKAGE_REFERENCE_DUPLICATE")
        ids.add(value["id"])
        require(type(value["role"]) is str and 0 < len(value["role"]) <= 128, "CMBA_PACKAGE_REFERENCE_ROLE")
        require(type(value["sha256"]) is str and len(value["sha256"]) == 64, "CMBA_PACKAGE_REFERENCE_HASH")
        try:
            int(value["sha256"], 16)
        except ValueError as exc:
            raise Refusal("CMBA_PACKAGE_REFERENCE_HASH") from exc
        require(type(value["bytes"]) is int and 0 <= value["bytes"] <= MAX_TOTAL_BYTES, "CMBA_PACKAGE_REFERENCE_SIZE")
        require(type(value["required"]) is bool, "CMBA_PACKAGE_REFERENCE_TYPE")
        require(value["locator"] is None or type(value["locator"]) is str, "CMBA_PACKAGE_REFERENCE_LOCATOR")
        result.append(clone(value))
    return sorted(result, key=lambda item: item["id"])


def _omissions(values: list[dict[str, Any]]) -> list[dict[str, Any]]:
    require(type(values) is list, "CMBA_PACKAGE_OMISSION_TYPE")
    result = []
    paths = set()
    for value in values:
        require(type(value) is dict, "CMBA_PACKAGE_OMISSION_TYPE")
        require(set(value) == {"path", "role", "sha256", "bytes", "reason"}, "CMBA_PACKAGE_OMISSION_FIELDS")
        path = _path(value["path"])
        require(path not in paths, "CMBA_PACKAGE_OMISSION_DUPLICATE")
        paths.add(path)
        require(value["role"] in _ROLES, "CMBA_PACKAGE_MEMBER_ROLE")
        require(type(value["sha256"]) is str and len(value["sha256"]) == 64, "CMBA_PACKAGE_OMISSION_HASH")
        try:
            int(value["sha256"], 16)
        except ValueError as exc:
            raise Refusal("CMBA_PACKAGE_OMISSION_HASH") from exc
        require(type(value["bytes"]) is int and value["bytes"] >= 0, "CMBA_PACKAGE_OMISSION_SIZE")
        require(type(value["reason"]) is str and 0 < len(value["reason"]) <= 256, "CMBA_PACKAGE_OMISSION_REASON")
        result.append(clone(value))
    return sorted(result, key=lambda item: item["path"])


def _invocations(values: list[dict[str, Any]], members: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
    require(type(values) is list, "CMBA_PACKAGE_INVOCATION_TYPE")
    result = []
    ids = set()
    for value in values:
        require(type(value) is dict, "CMBA_PACKAGE_INVOCATION_TYPE")
        require(set(value) == {"id", "interface", "request_member", "expected_response_member", "effect_class"}, "CMBA_PACKAGE_INVOCATION_FIELDS")
        require(type(value["id"]) is str and 0 < len(value["id"]) <= 128, "CMBA_PACKAGE_INVOCATION_ID")
        require(value["id"] not in ids, "CMBA_PACKAGE_INVOCATION_DUPLICATE")
        ids.add(value["id"])
        require(value["interface"] in _INTERFACES, "CMBA_PACKAGE_INTERFACE")
        request_path = _path(value["request_member"])
        require(request_path in members and members[request_path]["role"] == "evaluation_request", "CMBA_PACKAGE_REQUEST_MEMBER")
        require(members[request_path]["media_type"] == "application/json" and members[request_path]["required"], "CMBA_PACKAGE_REQUEST_MEMBER")
        response_path = value["expected_response_member"]
        require(response_path is None or type(response_path) is str, "CMBA_PACKAGE_RESPONSE_MEMBER")
        if response_path is not None:
            response_path = _path(response_path)
            require(response_path in members and members[response_path]["role"] == "evaluation_response", "CMBA_PACKAGE_RESPONSE_MEMBER")
            require(members[response_path]["media_type"] == "application/json" and members[response_path]["required"], "CMBA_PACKAGE_RESPONSE_MEMBER")
        require(value["effect_class"] == "PURE_READ", "CMBA_PACKAGE_EFFECT_CLASS")
        item = clone(value)
        item["request_member"] = request_path
        item["expected_response_member"] = response_path
        result.append(item)
    return sorted(result, key=lambda item: item["id"])


def build_package(
    members: dict[str, bytes],
    member_specs: dict[str, dict[str, Any]],
    *,
    invocations: list[dict[str, Any]] | None = None,
    external_references: list[dict[str, Any]] | None = None,
    omissions: list[dict[str, Any]] | None = None,
    coverage: list[str] | None = None,
    mode: str = "SELF_CONTAINED",
) -> bytes:
    """Build deterministic package bytes without interpreting member claims."""
    require(type(members) is dict and type(member_specs) is dict, "CMBA_PACKAGE_ARGUMENT")
    require(set(members) == set(member_specs), "CMBA_PACKAGE_MEMBER_SPEC_MISSING")
    require(0 < len(members) <= MAX_MEMBERS - 1, "CMBA_PACKAGE_MEMBER_COUNT")
    require(mode in ("SELF_CONTAINED", "REFERENCE_BEARING"), "CMBA_PACKAGE_MODE")
    rows = [_member_spec(path, members[path], member_specs[path]) for path in members]
    rows.sort(key=lambda item: item["path"])
    require(len({row["path"].casefold() for row in rows}) == len(rows), "CMBA_PACKAGE_PATH_ALIAS")
    require(sum(row["bytes"] for row in rows) <= MAX_TOTAL_BYTES, "CMBA_PACKAGE_TOTAL_LIMIT")
    for row in rows:
        if row["role"] == "nested_package":
            open_package(members[row["path"]], _depth=1)
    row_map = {row["path"]: row for row in rows}
    references = _references(external_references or [])
    if mode == "SELF_CONTAINED":
        require(not any(item["required"] for item in references), "CMBA_PACKAGE_NOT_SELF_CONTAINED")
    omitted = _omissions(omissions or [])
    require(not (set(row_map) & {item["path"] for item in omitted}), "CMBA_PACKAGE_OMISSION_PRESENT")
    cover = coverage or []
    require(type(cover) is list and all(type(item) is str and item for item in cover), "CMBA_PACKAGE_COVERAGE")
    require(len(cover) == len(set(cover)), "CMBA_PACKAGE_COVERAGE")
    body = {
        "schema": SCHEMA,
        "mode": mode,
        "members": rows,
        "invocations": _invocations(invocations or [], row_map),
        "external_references": references,
        "omissions": omitted,
        "coverage": sorted(cover),
        "trust_adoption": "READER_SELECTED_EXTERNAL",
        "network_retrieval": "NOT_PERFORMED",
        "code_loading": "CLOSED_INSTALLED_INTERFACES_ONLY",
        "authority_effect": "NONE",
    }
    manifest = {"schema": SCHEMA + ".manifest", "body": body, "manifest_hash": _manifest_hash(body)}
    manifest_bytes = canonical(manifest)
    output = io.BytesIO()
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_STORED, allowZip64=False) as archive:
        for path, data in [(MANIFEST, manifest_bytes)] + [(row["path"], members[row["path"]]) for row in rows]:
            info = zipfile.ZipInfo(path, date_time=(1980, 1, 1, 0, 0, 0))
            info.create_system = 3
            info.external_attr = (stat.S_IFREG | 0o644) << 16
            info.compress_type = zipfile.ZIP_STORED
            archive.writestr(info, data)
    result = output.getvalue()
    require(len(result) <= MAX_ARCHIVE_BYTES, "CMBA_PACKAGE_ARCHIVE_LIMIT")
    return result


def _preflight(blob: bytes) -> tuple[zipfile.ZipFile, io.BytesIO, list[zipfile.ZipInfo]]:
    require(type(blob) is bytes, "CMBA_PACKAGE_BYTES_REQUIRED")
    require(len(blob) <= MAX_ARCHIVE_BYTES, "CMBA_PACKAGE_ARCHIVE_LIMIT")
    source = io.BytesIO(blob)
    try:
        archive = zipfile.ZipFile(source, "r")
        infos = archive.infolist()
    except (zipfile.BadZipFile, OSError, ValueError) as exc:
        raise Refusal("CMBA_PACKAGE_ARCHIVE_INVALID") from exc
    require(0 < len(infos) <= MAX_MEMBERS, "CMBA_PACKAGE_MEMBER_COUNT")
    names = []
    total = 0
    for info in infos:
        require(not info.is_dir(), "CMBA_PACKAGE_MEMBER_KIND")
        require(info.flag_bits & 1 == 0, "CMBA_PACKAGE_ENCRYPTED_MEMBER")
        require(info.compress_type in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED), "CMBA_PACKAGE_COMPRESSION")
        require(info.file_size <= MAX_MEMBER_BYTES, "CMBA_PACKAGE_MEMBER_LIMIT")
        total += info.file_size
        require(total <= MAX_TOTAL_BYTES, "CMBA_PACKAGE_TOTAL_LIMIT")
        mode = (info.external_attr >> 16) & 0xFFFF
        require(mode == 0 or stat.S_ISREG(mode), "CMBA_PACKAGE_MEMBER_KIND")
        require(info.filename == MANIFEST or _path(info.filename) == info.filename, "CMBA_PACKAGE_PATH")
        names.append(info.filename)
    require(len(names) == len(set(names)), "CMBA_PACKAGE_DUPLICATE_MEMBER")
    require(len(names) == len({name.casefold() for name in names}), "CMBA_PACKAGE_PATH_ALIAS")
    require(MANIFEST in names, "CMBA_PACKAGE_MANIFEST_MISSING")
    return archive, source, infos


def open_package(blob: bytes, *, _depth: int = 0) -> dict[str, Any]:
    """Admit package bytes in memory. No member is extracted or retrieved."""
    require(type(_depth) is int and 0 <= _depth <= MAX_NESTING, "CMBA_PACKAGE_NESTING_LIMIT")
    archive, source, infos = _preflight(blob)
    try:
        raw_manifest = archive.read(MANIFEST)
        manifest = decode(raw_manifest)
        require(type(manifest) is dict, "CMBA_PACKAGE_MANIFEST_FIELDS")
        require(set(manifest) == {"schema", "body", "manifest_hash"}, "CMBA_PACKAGE_MANIFEST_FIELDS")
        require(manifest["schema"] == SCHEMA + ".manifest", "CMBA_PACKAGE_MANIFEST_SCHEMA")
        require(_manifest_hash(manifest["body"]) == manifest["manifest_hash"], "CMBA_PACKAGE_MANIFEST_HASH")
        body = manifest["body"]
        require(type(body) is dict, "CMBA_PACKAGE_BODY_FIELDS")
        require(
            set(body)
            == {
                "schema", "mode", "members", "invocations", "external_references",
                "omissions", "coverage", "trust_adoption", "network_retrieval",
                "code_loading", "authority_effect",
            },
            "CMBA_PACKAGE_BODY_FIELDS",
        )
        require(body["schema"] == SCHEMA, "CMBA_PACKAGE_SCHEMA")
        require(body["mode"] in ("SELF_CONTAINED", "REFERENCE_BEARING"), "CMBA_PACKAGE_MODE")
        require(body["trust_adoption"] == "READER_SELECTED_EXTERNAL", "CMBA_PACKAGE_TRUST_BOUNDARY")
        require(body["network_retrieval"] == "NOT_PERFORMED", "CMBA_PACKAGE_NETWORK_BOUNDARY")
        require(body["code_loading"] == "CLOSED_INSTALLED_INTERFACES_ONLY", "CMBA_PACKAGE_CODE_BOUNDARY")
        require(body["authority_effect"] == "NONE", "CMBA_PACKAGE_AUTHORITY_BOUNDARY")
        rows = body["members"]
        require(type(rows) is list and 0 < len(rows) <= MAX_MEMBERS - 1, "CMBA_PACKAGE_MEMBER_COUNT")
        require(all(type(item) is dict for item in rows), "CMBA_PACKAGE_MEMBER_FIELDS")
        require(canonical(rows) == canonical(sorted(rows, key=lambda item: item.get("path", ""))), "CMBA_PACKAGE_MEMBER_ORDER")
        member_data: dict[str, bytes] = {}
        specs: dict[str, dict[str, Any]] = {}
        for row in rows:
            require(type(row) is dict and set(row) == {"path", "role", "media_type", "required", "bytes", "sha256"}, "CMBA_PACKAGE_MEMBER_FIELDS")
            path = _path(row["path"])
            require(type(row["bytes"]) is int and row["bytes"] >= 0, "CMBA_PACKAGE_MEMBER_SIZE")
            require(type(row["sha256"]) is str and len(row["sha256"]) == 64, "CMBA_PACKAGE_MEMBER_HASH")
            spec = {key: row[key] for key in ("role", "media_type", "required")}
            data = archive.read(path)
            expected = _member_spec(path, data, spec)
            require(expected == row, "CMBA_PACKAGE_MEMBER_MISMATCH")
            member_data[path] = data
            specs[path] = expected
        expected_names = {MANIFEST, *member_data}
        require(expected_names == {info.filename for info in infos}, "CMBA_PACKAGE_UNDECLARED_MEMBER")
        references = _references(body["external_references"])
        require(references == body["external_references"], "CMBA_PACKAGE_REFERENCE_ORDER")
        omissions = _omissions(body["omissions"])
        require(omissions == body["omissions"], "CMBA_PACKAGE_OMISSION_ORDER")
        require(not (set(member_data) & {item["path"] for item in omissions}), "CMBA_PACKAGE_OMISSION_PRESENT")
        invocations = _invocations(body["invocations"], specs)
        require(invocations == body["invocations"], "CMBA_PACKAGE_INVOCATION_ORDER")
        require(
            type(body["coverage"]) is list
            and all(type(item) is str and item for item in body["coverage"])
            and body["coverage"] == sorted(set(body["coverage"])),
            "CMBA_PACKAGE_COVERAGE",
        )
        if body["mode"] == "SELF_CONTAINED":
            require(not any(item["required"] for item in references), "CMBA_PACKAGE_NOT_SELF_CONTAINED")
        for row in rows:
            if row["role"] == "nested_package":
                require(_depth < MAX_NESTING, "CMBA_PACKAGE_NESTING_LIMIT")
                open_package(member_data[row["path"]], _depth=_depth + 1)
        missing = [item["id"] for item in references if item["required"]]
        return {
            "schema": "cmba.portable-evaluation-package.opened.v1",
            "manifest": clone(manifest),
            "members": member_data,
            "archive_sha256": _hash(blob),
            "completeness": "MISSING_REQUIRED_REFERENCES" if missing else "COMPLETE",
            "missing_required_references": missing,
            "authority_effect": "NONE",
        }
    except (KeyError, RuntimeError, zipfile.BadZipFile, OSError) as exc:
        raise Refusal("CMBA_PACKAGE_ARCHIVE_INVALID") from exc
    finally:
        archive.close()
        source.close()


def replay_invocation(opened: dict[str, Any], invocation_id: str, expected_request_sha256: str) -> dict[str, Any]:
    """Replay one closed read-only invocation under an external request pin."""
    require(type(opened) is dict and opened.get("schema") == "cmba.portable-evaluation-package.opened.v1", "CMBA_PACKAGE_OPENED")
    require(opened["completeness"] == "COMPLETE", "CMBA_PACKAGE_INCOMPLETE")
    require(type(expected_request_sha256) is str and len(expected_request_sha256) == 64, "CMBA_PACKAGE_EXPECTED_REQUEST")
    invocations = [item for item in opened["manifest"]["body"]["invocations"] if item["id"] == invocation_id]
    require(len(invocations) == 1, "CMBA_PACKAGE_INVOCATION_UNKNOWN")
    invocation = invocations[0]
    request_bytes = opened["members"][invocation["request_member"]]
    require(_hash(request_bytes) == expected_request_sha256, "CMBA_PACKAGE_EXPECTED_REQUEST_MISMATCH")
    request = decode(request_bytes)
    from cmba_agent.protocol import dispatch

    response = dispatch(invocation["interface"], request)
    response_bytes = canonical(response)
    expected_path = invocation["expected_response_member"]
    if expected_path is not None:
        require(response_bytes == opened["members"][expected_path], "CMBA_PACKAGE_RESPONSE_MISMATCH")
    return {
        "schema": "cmba.portable-evaluation-package.replay.v1",
        "invocation_id": invocation_id,
        "request_sha256": expected_request_sha256,
        "response_sha256": _hash(response_bytes),
        "status": "MATCH_EXACT_INSTALLED_REPLAY",
        "authority_effect": "NONE",
    }


def select_package(blob: bytes, selected_optional_members: list[str], coverage: list[str]) -> bytes:
    """Create a new package containing required members plus named optionals."""
    opened = open_package(blob)
    body = opened["manifest"]["body"]
    require(type(selected_optional_members) is list, "CMBA_PACKAGE_SELECTION")
    selected = {_path(item) for item in selected_optional_members}
    rows = {item["path"]: item for item in body["members"]}
    optional = {path for path, row in rows.items() if not row["required"]}
    require(selected <= optional, "CMBA_PACKAGE_SELECTION")
    require(type(coverage) is list and set(coverage) <= set(body["coverage"]), "CMBA_PACKAGE_COVERAGE_EXPANSION")
    included = {path for path, row in rows.items() if row["required"]} | selected
    members = {path: opened["members"][path] for path in included}
    specs = {path: {key: rows[path][key] for key in ("role", "media_type", "required")} for path in included}
    omitted = list(body["omissions"])
    for path in sorted(optional - selected):
        row = rows[path]
        omitted.append({
            "path": path,
            "role": row["role"],
            "sha256": row["sha256"],
            "bytes": row["bytes"],
            "reason": "NOT_SELECTED_FOR_DISCLOSURE",
        })
    return build_package(
        members,
        specs,
        invocations=body["invocations"],
        external_references=body["external_references"],
        omissions=omitted,
        coverage=coverage,
        mode=body["mode"],
    )
