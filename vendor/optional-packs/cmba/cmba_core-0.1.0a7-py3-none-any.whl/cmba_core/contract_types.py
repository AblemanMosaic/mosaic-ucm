"""Common finite record constructors for successor profile contracts."""
from __future__ import annotations

from typing import Any

from .bindings import hex_digest, identifier, validate_reference
from .codec import canonical, clone
from .errors import require


def _strings(values: list[str], code: str, *, allow_empty: bool = False) -> list[str]:
    require(type(values) is list and (allow_empty or len(values) > 0), code)
    result = []
    for value in values:
        identifier(value)
        result.append(value)
    require(len(result) == len(set(result)), code)
    return sorted(result)


def scope(
    subject: dict[str, Any],
    *,
    actions: list[str],
    resources: list[str],
    jurisdictions: list[str],
    configurations: list[str] | None = None,
) -> dict[str, Any]:
    validate_reference(subject)
    return {
        "schema": "cmba.scope.v2",
        "subject": clone(subject),
        "actions": _strings(actions, "CMBA_SCOPE_ACTIONS"),
        "resources": _strings(resources, "CMBA_SCOPE_RESOURCES"),
        "jurisdictions": _strings(jurisdictions, "CMBA_SCOPE_JURISDICTIONS"),
        "configurations": _strings(configurations or [], "CMBA_SCOPE_CONFIGURATIONS", allow_empty=True),
    }


def dependency(
    dependency_id: str,
    kind: str,
    root: str,
    *,
    required: bool,
) -> dict[str, Any]:
    identifier(dependency_id)
    identifier(kind)
    hex_digest(root)
    require(type(required) is bool, "CMBA_DEPENDENCY_REQUIRED")
    return {
        "schema": "cmba.dependency.v2",
        "dependency_id": dependency_id,
        "kind": kind,
        "root": root,
        "required": required,
    }


def evidence_reference(
    evidence_id: str,
    kind: str,
    sha256: str,
    size: int,
    *,
    producer: str,
    independence_group: str,
) -> dict[str, Any]:
    identifier(evidence_id)
    identifier(kind)
    hex_digest(sha256)
    require(type(size) is int and type(size) is not bool and size >= 0, "CMBA_EVIDENCE_SIZE")
    identifier(producer)
    identifier(independence_group)
    return {
        "schema": "cmba.evidence-reference.v2",
        "evidence_id": evidence_id,
        "kind": kind,
        "sha256": sha256,
        "bytes": size,
        "producer": producer,
        "independence_group": independence_group,
    }


def evaluation_time(epoch: int, clock_source: str) -> dict[str, Any]:
    require(type(epoch) is int and type(epoch) is not bool and epoch >= 0, "CMBA_TIME_INVALID")
    identifier(clock_source)
    return {"schema": "cmba.evaluation-time.v2", "epoch": epoch, "clock_source": clock_source}


def multi_check_report(
    checks: dict[str, str],
    *,
    details: dict[str, Any],
    claim_ceiling: str,
) -> dict[str, Any]:
    require(type(checks) is dict and checks, "CMBA_CHECKS")
    allowed = {"MATCH", "CONTRADICTED", "INSUFFICIENT", "UNSUPPORTED", "NOT_CHECKED"}
    admitted = {}
    for name, value in checks.items():
        identifier(name)
        require(value in allowed, "CMBA_CHECK_RESULT")
        admitted[name] = value
    canonical(details)
    require(type(claim_ceiling) is str and claim_ceiling, "CMBA_CLAIM_CEILING")
    values = set(admitted.values())
    if "CONTRADICTED" in values:
        status = "CONTRADICTED"
    elif "UNSUPPORTED" in values:
        status = "UNSUPPORTED"
    elif values & {"INSUFFICIENT", "NOT_CHECKED"}:
        status = "INSUFFICIENT"
    else:
        status = "MATCH_FOR_SUPPLIED_EVIDENCE"
    return {
        "schema": "cmba.multi-check-report.v2",
        "status": status,
        "checks": {name: admitted[name] for name in sorted(admitted)},
        "details": clone(details),
        "claim_ceiling": claim_ceiling,
        "authority_effect": "NONE",
    }
