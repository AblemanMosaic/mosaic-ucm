"""Finite access-policy evaluation and policy-transition comparison."""
from __future__ import annotations

import hashlib
from collections import defaultdict
from typing import Any

from .bindings import exact, hex_digest, identifier
from .codec import canonical, clone
from .contract_types import multi_check_report
from .errors import require


MAX_ITEMS = 128


def _root(domain: str, value: Any) -> str:
    return hashlib.sha256(("CMBA:V2:" + domain + "\0").encode("ascii") + canonical(value)).hexdigest()


def _ids(values: list[str], code: str, *, allow_empty: bool = True) -> list[str]:
    require(type(values) is list and (allow_empty or bool(values)), code)
    for value in values:
        identifier(value)
    require(values == sorted(set(values)), code)
    return list(values)


def _mapping(value: dict[str, str], code: str) -> dict[str, str]:
    require(type(value) is dict, code)
    result = {}
    for key, target in value.items():
        identifier(key)
        identifier(target)
        result[key] = target
    return {key: result[key] for key in sorted(result)}


def access_policy(
    policy_id: str,
    platform: str,
    principals: list[dict[str, Any]],
    groups: list[dict[str, Any]],
    resources: list[dict[str, Any]],
    actions: list[str],
    rules: list[dict[str, Any]],
    public_links: list[dict[str, Any]],
    request_universe: list[dict[str, Any]],
    *,
    supported_condition_keys: list[str],
) -> dict[str, Any]:
    identifier(policy_id)
    identifier(platform)
    require(type(principals) is list and 0 < len(principals) <= MAX_ITEMS, "CMBA_POLICY_PRINCIPALS")
    principal_ids = set()
    for item in principals:
        exact(item, {"principal_id", "identity_root", "kind"})
        identifier(item["principal_id"])
        hex_digest(item["identity_root"])
        require(item["kind"] in {"USER", "SERVICE", "EXTERNAL", "ANONYMOUS"}, "CMBA_POLICY_PRINCIPAL_KIND")
        require(item["principal_id"] not in principal_ids, "CMBA_POLICY_DUPLICATE")
        principal_ids.add(item["principal_id"])
    require(type(groups) is list and len(groups) <= MAX_ITEMS, "CMBA_POLICY_GROUPS")
    group_ids = set()
    for item in groups:
        exact(item, {"group_id", "members", "parent_group_ids"})
        identifier(item["group_id"])
        require(item["group_id"] not in group_ids, "CMBA_POLICY_DUPLICATE")
        group_ids.add(item["group_id"])
        _ids(item["members"], "CMBA_POLICY_GROUP_MEMBERS")
        require(set(item["members"]) <= principal_ids, "CMBA_POLICY_PRINCIPAL_UNKNOWN")
        _ids(item["parent_group_ids"], "CMBA_POLICY_GROUP_PARENTS")
    for item in groups:
        require(set(item["parent_group_ids"]) <= group_ids - {item["group_id"]}, "CMBA_POLICY_GROUP_UNKNOWN")
    require(type(resources) is list and 0 < len(resources) <= MAX_ITEMS, "CMBA_POLICY_RESOURCES")
    resource_ids = set()
    for item in resources:
        exact(item, {"resource_id", "parent_resource_id", "owner_principal_id"})
        identifier(item["resource_id"])
        require(item["resource_id"] not in resource_ids, "CMBA_POLICY_DUPLICATE")
        resource_ids.add(item["resource_id"])
        if item["parent_resource_id"] is not None:
            identifier(item["parent_resource_id"])
        if item["owner_principal_id"] is not None:
            identifier(item["owner_principal_id"])
            require(item["owner_principal_id"] in principal_ids, "CMBA_POLICY_PRINCIPAL_UNKNOWN")
    for item in resources:
        require(item["parent_resource_id"] is None or item["parent_resource_id"] in resource_ids - {item["resource_id"]}, "CMBA_POLICY_RESOURCE_UNKNOWN")
    _ids(actions, "CMBA_POLICY_ACTIONS", allow_empty=False)
    _ids(supported_condition_keys, "CMBA_POLICY_CONDITIONS")
    require(type(rules) is list and len(rules) <= MAX_ITEMS, "CMBA_POLICY_RULES")
    rule_ids = set()
    for item in rules:
        exact(item, {"rule_id", "subject_kind", "subject_id", "resource_id", "actions", "effect", "inheritance", "conditions"})
        identifier(item["rule_id"])
        require(item["rule_id"] not in rule_ids, "CMBA_POLICY_DUPLICATE")
        rule_ids.add(item["rule_id"])
        require(item["subject_kind"] in {"PRINCIPAL", "GROUP"}, "CMBA_POLICY_SUBJECT_KIND")
        identifier(item["subject_id"])
        require(
            item["subject_id"] in (principal_ids if item["subject_kind"] == "PRINCIPAL" else group_ids),
            "CMBA_POLICY_SUBJECT_UNKNOWN",
        )
        require(item["resource_id"] in resource_ids, "CMBA_POLICY_RESOURCE_UNKNOWN")
        _ids(item["actions"], "CMBA_POLICY_ACTIONS", allow_empty=False)
        require(set(item["actions"]) <= set(actions), "CMBA_POLICY_ACTION_UNKNOWN")
        require(item["effect"] in {"ALLOW", "DENY"}, "CMBA_POLICY_EFFECT")
        require(item["inheritance"] in {"SELF", "SUBTREE"}, "CMBA_POLICY_INHERITANCE")
        require(type(item["conditions"]) is dict, "CMBA_POLICY_CONDITIONS")
        for key in item["conditions"]:
            identifier(key)
        canonical(item["conditions"])
    require(type(public_links) is list and len(public_links) <= MAX_ITEMS, "CMBA_POLICY_LINKS")
    link_ids = set()
    for item in public_links:
        exact(item, {"link_id", "resource_id", "actions", "active", "conditions"})
        identifier(item["link_id"])
        require(item["link_id"] not in link_ids, "CMBA_POLICY_DUPLICATE")
        link_ids.add(item["link_id"])
        require(item["resource_id"] in resource_ids, "CMBA_POLICY_RESOURCE_UNKNOWN")
        _ids(item["actions"], "CMBA_POLICY_ACTIONS", allow_empty=False)
        require(set(item["actions"]) <= set(actions), "CMBA_POLICY_ACTION_UNKNOWN")
        require(type(item["active"]) is bool and type(item["conditions"]) is dict, "CMBA_POLICY_LINKS")
        for key in item["conditions"]:
            identifier(key)
        canonical(item["conditions"])
    require(type(request_universe) is list and 0 < len(request_universe) <= MAX_ITEMS, "CMBA_POLICY_REQUESTS")
    request_ids = set()
    for item in request_universe:
        exact(item, {"request_id", "principal_id", "resource_id", "action", "context", "public_link_id"})
        identifier(item["request_id"])
        require(item["request_id"] not in request_ids, "CMBA_POLICY_DUPLICATE")
        request_ids.add(item["request_id"])
        for field in ("principal_id", "resource_id", "action"):
            identifier(item[field])
        require(type(item["context"]) is dict, "CMBA_POLICY_CONTEXT")
        for key in item["context"]:
            identifier(key)
        canonical(item["context"])
        if item["public_link_id"] is not None:
            identifier(item["public_link_id"])
    body = {
        "schema": "cmba.access-policy-body.v2",
        "policy_id": policy_id,
        "platform": platform,
        "principals": sorted(clone(principals), key=lambda item: item["principal_id"]),
        "groups": sorted(clone(groups), key=lambda item: item["group_id"]),
        "resources": sorted(clone(resources), key=lambda item: item["resource_id"]),
        "actions": list(actions),
        "rules": sorted(clone(rules), key=lambda item: item["rule_id"]),
        "public_links": sorted(clone(public_links), key=lambda item: item["link_id"]),
        "request_universe": sorted(clone(request_universe), key=lambda item: item["request_id"]),
        "supported_condition_keys": list(supported_condition_keys),
        "default": "DENY",
        "precedence": "EXPLICIT_DENY_THEN_ALLOW_OWNER_OR_PUBLIC_LINK_THEN_DEFAULT_DENY",
        "authority_effect": "NONE",
    }
    return {"schema": "cmba.access-policy.v2", "body": body, "policy_root": _root("access-policy", body)}


def validate_access_policy(value: dict[str, Any]) -> None:
    canonical(value)
    exact(value, {"schema", "body", "policy_root"})
    require(value["schema"] == "cmba.access-policy.v2", "CMBA_POLICY_SCHEMA")
    body = value["body"]
    rebuilt = access_policy(
        body["policy_id"], body["platform"], body["principals"], body["groups"], body["resources"],
        body["actions"], body["rules"], body["public_links"], body["request_universe"],
        supported_condition_keys=body["supported_condition_keys"],
    )
    require(canonical(rebuilt) == canonical(value), "CMBA_POLICY_ROOT")


def _cycles(edges: dict[str, list[str]]) -> set[str]:
    cyclic = set()
    visiting = []
    visited = set()

    def visit(node: str) -> None:
        if node in visiting:
            cyclic.update(visiting[visiting.index(node):])
            return
        if node in visited:
            return
        visiting.append(node)
        for child in edges[node]:
            visit(child)
        visiting.pop()
        visited.add(node)

    for node in edges:
        visit(node)
    return cyclic


def _condition(rule: dict[str, Any], request: dict[str, Any], supported: set[str]) -> tuple[str, list[str]]:
    unsupported = sorted(set(rule["conditions"]) - supported)
    if unsupported:
        return "UNSUPPORTED", unsupported
    matched = all(key in request["context"] and canonical(request["context"][key]) == canonical(value) for key, value in rule["conditions"].items())
    return ("MATCH" if matched else "NO_MATCH"), []


def evaluate_access_policy(value: dict[str, Any]) -> dict[str, Any]:
    validate_access_policy(value)
    body = value["body"]
    principals = {item["principal_id"]: item for item in body["principals"]}
    groups = {item["group_id"]: item for item in body["groups"]}
    resources = {item["resource_id"]: item for item in body["resources"]}
    links = {item["link_id"]: item for item in body["public_links"]}
    group_cycles = _cycles({group_id: item["parent_group_ids"] for group_id, item in groups.items()})
    resource_cycles = _cycles({resource_id: ([item["parent_resource_id"]] if item["parent_resource_id"] else []) for resource_id, item in resources.items()})
    memberships = defaultdict(set)
    for group_id, group in groups.items():
        for principal_id in group["members"]:
            memberships[principal_id].add(group_id)
    for _ in range(len(groups)):
        for principal_id, member_groups in list(memberships.items()):
            for group_id in list(member_groups):
                member_groups.update(groups[group_id]["parent_group_ids"])
    ancestors = {}
    for resource_id in resources:
        chain = []
        node = resource_id
        while node is not None and node not in chain:
            chain.append(node)
            node = resources[node]["parent_resource_id"]
        ancestors[resource_id] = chain
    supported = set(body["supported_condition_keys"])
    rows = []
    checks = {
        "groups.acyclic": "CONTRADICTED" if group_cycles else "MATCH",
        "resources.acyclic": "CONTRADICTED" if resource_cycles else "MATCH",
    }
    for request in body["request_universe"]:
        request_id = request["request_id"]
        unknown = []
        if request["principal_id"] not in principals:
            unknown.append("UNKNOWN_PRINCIPAL")
        if request["resource_id"] not in resources:
            unknown.append("UNKNOWN_RESOURCE")
        if request["action"] not in body["actions"]:
            unknown.append("UNKNOWN_ACTION")
        if request["public_link_id"] is not None and request["public_link_id"] not in links:
            unknown.append("UNKNOWN_PUBLIC_LINK")
        if group_cycles:
            unknown.append("GROUP_CYCLE")
        if resource_cycles:
            unknown.append("RESOURCE_CYCLE")
        matched_allow = []
        matched_deny = []
        unsupported_conditions = []
        if not unknown:
            for rule in body["rules"]:
                subject_match = (
                    request["principal_id"] == rule["subject_id"] if rule["subject_kind"] == "PRINCIPAL"
                    else rule["subject_id"] in memberships[request["principal_id"]]
                )
                resource_match = (
                    request["resource_id"] == rule["resource_id"] if rule["inheritance"] == "SELF"
                    else rule["resource_id"] in ancestors[request["resource_id"]]
                )
                if not subject_match or not resource_match or request["action"] not in rule["actions"]:
                    continue
                condition, unsupported = _condition(rule, request, supported)
                if condition == "UNSUPPORTED":
                    unsupported_conditions.extend(f"rule:{rule['rule_id']}:{key}" for key in unsupported)
                elif condition == "MATCH":
                    (matched_deny if rule["effect"] == "DENY" else matched_allow).append("rule:" + rule["rule_id"])
            owner = resources[request["resource_id"]]["owner_principal_id"]
            if owner == request["principal_id"]:
                matched_allow.append("owner:" + request["resource_id"])
            if request["public_link_id"] is not None:
                link = links[request["public_link_id"]]
                if link["active"] and link["resource_id"] == request["resource_id"] and request["action"] in link["actions"]:
                    condition, unsupported = _condition(link, request, supported)
                    if condition == "UNSUPPORTED":
                        unsupported_conditions.extend(f"link:{link['link_id']}:{key}" for key in unsupported)
                    elif condition == "MATCH":
                        matched_allow.append("public-link:" + link["link_id"])
        if unknown or unsupported_conditions:
            decision = "UNKNOWN"
            status = "UNSUPPORTED"
        elif matched_deny:
            decision = "DENY"
            status = "MATCH"
        elif matched_allow:
            decision = "ALLOW"
            status = "MATCH"
        else:
            decision = "DENY"
            status = "MATCH"
        checks["request." + request_id] = status
        rows.append({
            "request_id": request_id,
            "decision": decision,
            "allow_paths": sorted(matched_allow),
            "deny_paths": sorted(matched_deny),
            "unknown_semantics": sorted(set(unknown + unsupported_conditions)),
        })
    report = multi_check_report(
        checks,
        details={
            "policy_root": value["policy_root"],
            "platform": body["platform"],
            "decisions": rows,
            "request_universe_complete": True,
            "default": body["default"],
            "precedence": body["precedence"],
        },
        claim_ceiling="Decisions for the exact enumerated principals, groups, resources, actions, conditions, links and request universe only; no ambient platform semantics.",
    )
    report["schema"] = "cmba.access-policy-assessment.v2"
    return report


def policy_transition(
    transition_id: str,
    source_policy_root: str,
    target_policy_root: str,
    *,
    principal_mapping: dict[str, str],
    group_mapping: dict[str, str],
    resource_mapping: dict[str, str],
    action_mapping: dict[str, str],
    rule_mapping: dict[str, str],
    public_link_mapping: dict[str, str],
    request_mapping: dict[str, str],
    required_continuity_request_ids: list[str],
    approved_deltas: list[str],
) -> dict[str, Any]:
    identifier(transition_id)
    hex_digest(source_policy_root)
    hex_digest(target_policy_root)
    body = {
        "schema": "cmba.policy-transition-body.v2",
        "transition_id": transition_id,
        "source_policy_root": source_policy_root,
        "target_policy_root": target_policy_root,
        "principal_mapping": _mapping(principal_mapping, "CMBA_TRANSITION_MAPPING"),
        "group_mapping": _mapping(group_mapping, "CMBA_TRANSITION_MAPPING"),
        "resource_mapping": _mapping(resource_mapping, "CMBA_TRANSITION_MAPPING"),
        "action_mapping": _mapping(action_mapping, "CMBA_TRANSITION_MAPPING"),
        "rule_mapping": _mapping(rule_mapping, "CMBA_TRANSITION_MAPPING"),
        "public_link_mapping": _mapping(public_link_mapping, "CMBA_TRANSITION_MAPPING"),
        "request_mapping": _mapping(request_mapping, "CMBA_TRANSITION_MAPPING"),
        "required_continuity_request_ids": _ids(required_continuity_request_ids, "CMBA_TRANSITION_CONTINUITY"),
        "approved_deltas": _ids(approved_deltas, "CMBA_TRANSITION_DELTAS"),
        "authority_effect": "NONE",
    }
    return {"schema": "cmba.policy-transition.v2", "body": body, "transition_root": _root("policy-transition", body)}


def validate_policy_transition(value: dict[str, Any]) -> None:
    canonical(value)
    exact(value, {"schema", "body", "transition_root"})
    require(value["schema"] == "cmba.policy-transition.v2", "CMBA_TRANSITION_SCHEMA")
    body = value["body"]
    rebuilt = policy_transition(
        body["transition_id"], body["source_policy_root"], body["target_policy_root"],
        principal_mapping=body["principal_mapping"], group_mapping=body["group_mapping"],
        resource_mapping=body["resource_mapping"], action_mapping=body["action_mapping"],
        rule_mapping=body["rule_mapping"], public_link_mapping=body["public_link_mapping"],
        request_mapping=body["request_mapping"],
        required_continuity_request_ids=body["required_continuity_request_ids"],
        approved_deltas=body["approved_deltas"],
    )
    require(canonical(rebuilt) == canonical(value), "CMBA_TRANSITION_ROOT")


def _decision_map(report: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {item["request_id"]: item for item in report["details"]["decisions"]}


def _mapped_rule(source: dict[str, Any], transition: dict[str, Any]) -> dict[str, Any] | None:
    body = transition["body"]
    subject_mapping = body["principal_mapping"] if source["subject_kind"] == "PRINCIPAL" else body["group_mapping"]
    if source["subject_id"] not in subject_mapping or source["resource_id"] not in body["resource_mapping"]:
        return None
    if any(action not in body["action_mapping"] for action in source["actions"]):
        return None
    return {
        "subject_kind": source["subject_kind"],
        "subject_id": subject_mapping[source["subject_id"]],
        "resource_id": body["resource_mapping"][source["resource_id"]],
        "actions": sorted(body["action_mapping"][action] for action in source["actions"]),
        "effect": source["effect"],
        "inheritance": source["inheritance"],
        "conditions": source["conditions"],
    }


def compare_policy_transition(
    source_policy: dict[str, Any],
    target_policy: dict[str, Any],
    transition: dict[str, Any],
) -> dict[str, Any]:
    validate_access_policy(source_policy)
    validate_access_policy(target_policy)
    validate_policy_transition(transition)
    body = transition["body"]
    require(body["source_policy_root"] == source_policy["policy_root"], "CMBA_TRANSITION_SOURCE_ROOT")
    require(body["target_policy_root"] == target_policy["policy_root"], "CMBA_TRANSITION_TARGET_ROOT")
    source_body = source_policy["body"]
    target_body = target_policy["body"]
    source = evaluate_access_policy(source_policy)
    target = evaluate_access_policy(target_policy)
    source_decisions = _decision_map(source)
    target_decisions = _decision_map(target)
    def report_check(report: dict[str, Any]) -> str:
        if report["status"] == "CONTRADICTED":
            return "CONTRADICTED"
        if report["status"] == "UNSUPPORTED":
            return "UNSUPPORTED"
        if report["status"] == "INSUFFICIENT":
            return "INSUFFICIENT"
        return "MATCH"
    checks = {
        "source.evaluable": report_check(source),
        "target.evaluable": report_check(target),
    }
    observed_deltas = set()
    counterexamples = []
    losses = []
    mapped_targets = set()

    source_ids = {item["principal_id"] for item in source_body["principals"]}
    target_ids = {item["principal_id"] for item in target_body["principals"]}
    if not set(body["principal_mapping"]) <= source_ids or not set(body["principal_mapping"].values()) <= target_ids:
        checks["mapping.principals"] = "CONTRADICTED"
    else:
        checks["mapping.principals"] = "MATCH"
    inverse = defaultdict(list)
    for source_id, target_id in body["principal_mapping"].items():
        inverse[target_id].append(source_id)
    for target_id, values in inverse.items():
        if len(values) > 1:
            observed_deltas.add("identity-collision:" + target_id)
    request_inverse = defaultdict(list)
    for source_request_id, target_request_id in body["request_mapping"].items():
        request_inverse[target_request_id].append(source_request_id)
    for target_request_id, values in request_inverse.items():
        if len(values) > 1:
            observed_deltas.add("request-collision:" + target_request_id)
    require(set(body["required_continuity_request_ids"]) <= set(source_decisions), "CMBA_TRANSITION_CONTINUITY_UNKNOWN")
    source_requests = {item["request_id"]: item for item in source_body["request_universe"]}
    target_requests = {item["request_id"]: item for item in target_body["request_universe"]}

    for source_request_id, source_row in source_decisions.items():
        target_request_id = body["request_mapping"].get(source_request_id)
        if target_request_id is None or target_request_id not in target_decisions:
            checks["request-map." + source_request_id] = "INSUFFICIENT"
            continue
        source_request = source_requests[source_request_id]
        target_request = target_requests[target_request_id]
        expected_link = (
            None if source_request["public_link_id"] is None
            else body["public_link_mapping"].get(source_request["public_link_id"])
        )
        mapping_exact = (
            body["principal_mapping"].get(source_request["principal_id"]) == target_request["principal_id"]
            and body["resource_mapping"].get(source_request["resource_id"]) == target_request["resource_id"]
            and body["action_mapping"].get(source_request["action"]) == target_request["action"]
            and canonical(source_request["context"]) == canonical(target_request["context"])
            and expected_link == target_request["public_link_id"]
        )
        checks["request-map." + source_request_id] = "MATCH" if mapping_exact else "CONTRADICTED"
        mapped_targets.add(target_request_id)
        target_row = target_decisions[target_request_id]
        if source_row["decision"] == "UNKNOWN" or target_row["decision"] == "UNKNOWN":
            checks["decision." + source_request_id] = "UNSUPPORTED"
        elif source_row["decision"] == "DENY" and target_row["decision"] == "ALLOW":
            delta = "decision-widening:" + source_request_id
            observed_deltas.add(delta)
            counterexamples.append({
                "source_request_id": source_request_id,
                "target_request_id": target_request_id,
                "source_decision": "DENY",
                "target_decision": "ALLOW",
                "source_policy_root": source_policy["policy_root"],
                "target_policy_root": target_policy["policy_root"],
            })
            checks["decision." + source_request_id] = "MATCH" if delta in body["approved_deltas"] else "CONTRADICTED"
        elif source_row["decision"] == "ALLOW" and target_row["decision"] == "DENY":
            losses.append({"source_request_id": source_request_id, "target_request_id": target_request_id})
            checks["decision." + source_request_id] = (
                "CONTRADICTED" if source_request_id in body["required_continuity_request_ids"] else "MATCH"
            )
        else:
            checks["decision." + source_request_id] = "MATCH"
    for target_request_id, row in target_decisions.items():
        if target_request_id not in mapped_targets and row["decision"] == "ALLOW":
            delta = "new-destination-allow:" + target_request_id
            observed_deltas.add(delta)
            counterexamples.append({
                "source_request_id": None,
                "target_request_id": target_request_id,
                "source_decision": "OUTSIDE_SOURCE_UNIVERSE",
                "target_decision": "ALLOW",
                "source_policy_root": source_policy["policy_root"],
                "target_policy_root": target_policy["policy_root"],
            })
            checks["target-extra." + target_request_id] = "MATCH" if delta in body["approved_deltas"] else "CONTRADICTED"

    source_groups = {item["group_id"]: item for item in source_body["groups"]}
    target_groups = {item["group_id"]: item for item in target_body["groups"]}
    for group_id, group in source_groups.items():
        target_group_id = body["group_mapping"].get(group_id)
        if target_group_id is None or target_group_id not in target_groups:
            observed_deltas.add("group-unmapped:" + group_id)
            continue
        mapped_members = sorted(body["principal_mapping"].get(member, "unmapped:" + member) for member in group["members"])
        mapped_parents = sorted(body["group_mapping"].get(parent, "unmapped:" + parent) for parent in group["parent_group_ids"])
        target_group = target_groups[target_group_id]
        if mapped_members != target_group["members"] or mapped_parents != target_group["parent_group_ids"]:
            observed_deltas.add("group-change:" + group_id)

    source_resources = {item["resource_id"]: item for item in source_body["resources"]}
    target_resources = {item["resource_id"]: item for item in target_body["resources"]}
    for resource_id, resource in source_resources.items():
        target_resource_id = body["resource_mapping"].get(resource_id)
        if target_resource_id is None or target_resource_id not in target_resources:
            observed_deltas.add("resource-unmapped:" + resource_id)
            continue
        target_resource = target_resources[target_resource_id]
        expected_parent = (
            None if resource["parent_resource_id"] is None
            else body["resource_mapping"].get(resource["parent_resource_id"])
        )
        expected_owner = (
            None if resource["owner_principal_id"] is None
            else body["principal_mapping"].get(resource["owner_principal_id"])
        )
        if expected_parent != target_resource["parent_resource_id"]:
            observed_deltas.add("resource-inheritance-change:" + resource_id)
        if expected_owner != target_resource["owner_principal_id"]:
            observed_deltas.add("ownership-change:" + resource_id)

    source_rules = {item["rule_id"]: item for item in source_body["rules"]}
    target_rules = {item["rule_id"]: item for item in target_body["rules"]}
    for rule_id, rule in source_rules.items():
        target_rule_id = body["rule_mapping"].get(rule_id)
        if target_rule_id is None or target_rule_id not in target_rules:
            observed_deltas.add(("deny-dropped:" if rule["effect"] == "DENY" else "rule-unmapped:") + rule_id)
            continue
        expected = _mapped_rule(rule, transition)
        target_rule = {key: target_rules[target_rule_id][key] for key in (
            "subject_kind", "subject_id", "resource_id", "actions", "effect", "inheritance", "conditions"
        )}
        if expected is None or canonical(expected) != canonical(target_rule):
            observed_deltas.add("rule-change:" + rule_id)
            if expected is not None and expected["inheritance"] != target_rule["inheritance"]:
                observed_deltas.add("inheritance-change:" + rule_id)

    source_links = {item["link_id"]: item for item in source_body["public_links"]}
    target_links = {item["link_id"]: item for item in target_body["public_links"]}
    for link_id, link in source_links.items():
        target_link_id = body["public_link_mapping"].get(link_id)
        if target_link_id is None or target_link_id not in target_links:
            observed_deltas.add("public-link-unmapped:" + link_id)
            continue
        mapped = {
            "resource_id": body["resource_mapping"].get(link["resource_id"]),
            "actions": sorted(body["action_mapping"].get(action, "unmapped:" + action) for action in link["actions"]),
            "active": link["active"],
            "conditions": link["conditions"],
        }
        target_link = {key: target_links[target_link_id][key] for key in ("resource_id", "actions", "active", "conditions")}
        if canonical(mapped) != canonical(target_link):
            observed_deltas.add("public-link-change:" + link_id)

    for label, policy in (("source", source_body), ("target", target_body)):
        supported = set(policy["supported_condition_keys"])
        for rule in policy["rules"]:
            for key in sorted(set(rule["conditions"]) - supported):
                observed_deltas.add(f"unsupported-condition:{label}:{rule['rule_id']}:{key}")
        for link in policy["public_links"]:
            for key in sorted(set(link["conditions"]) - supported):
                observed_deltas.add(f"unsupported-condition:{label}:{link['link_id']}:{key}")

    approved = set(body["approved_deltas"])
    unapproved = sorted(observed_deltas - approved)
    unused_approvals = sorted(approved - observed_deltas)
    checks["semantic-deltas.exact"] = "MATCH" if not unapproved and not unused_approvals else "CONTRADICTED"
    report = multi_check_report(
        checks,
        details={
            "transition_root": transition["transition_root"],
            "source_policy_root": source_policy["policy_root"],
            "target_policy_root": target_policy["policy_root"],
            "counterexamples": counterexamples,
            "access_losses": losses,
            "observed_semantic_deltas": sorted(observed_deltas),
            "unapproved_semantic_deltas": unapproved,
            "unused_delta_approvals": unused_approvals,
            "required_continuity_request_ids": body["required_continuity_request_ids"],
        },
        claim_ceiling="Finite policy decision and structural transition comparison over exact supplied policies, mappings and request universes only; no unmodeled platform semantics or migration permission.",
    )
    report["schema"] = "cmba.policy-transition-assessment.v2"
    return report
