"""Tests of the portable packet tools, not the future CCP product."""
import copy
import hashlib
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('programctl', ROOT / 'tools/programctl.py')
p = importlib.util.module_from_spec(spec)
spec.loader.exec_module(p)

class PacketTests(unittest.TestCase):
    def setUp(self):
        self.bundle = p.load_bundle(ROOT)

    def refused(self, callable_, code=None):
        with self.assertRaises(p.Refusal) as got:
            callable_()
        if code is not None:
            self.assertEqual(got.exception.code, code)

    def test_001_valid_structure(self):
        result = p.validate_bundle(self.bundle)
        self.assertEqual(result['stage_count'], 13)
        self.assertEqual(result['product_case_count'], 116)
        self.assertFalse(result['may_advance_product_gate'])

    def test_002_frozen_inputs_verify(self):
        hashes = p.verify_inputs(ROOT, self.bundle)
        self.assertIn('sources/CHC-paper.md', hashes)

    def test_003_canonical_key_order(self):
        self.assertEqual(p.canonical({'b': 1, 'a': 2}), p.canonical({'a': 2, 'b': 1}))

    def test_004_duplicate_keys_refused(self):
        self.refused(lambda: p.parse_bytes(b'{"x":1,"x":2}'), 'DUPLICATE_KEY')

    def test_005_floats_refused(self):
        self.refused(lambda: p.parse_bytes(b'{"x":0.1}'), 'FLOAT_OR_NONFINITE_FORBIDDEN')

    def test_006_nonfinite_refused(self):
        self.refused(lambda: p.parse_bytes(b'{"x":NaN}'), 'FLOAT_OR_NONFINITE_FORBIDDEN')

    def test_007_large_integer_refused(self):
        self.refused(lambda: p.parse_bytes(str(2**63).encode()), 'INTEGER_OUT_OF_RANGE')

    def test_008_surrogate_refused(self):
        self.refused(lambda: p.parse_bytes(b'"\\ud800"'), 'INVALID_UNICODE_SCALAR')

    def test_009_malformed_json_refused(self):
        self.refused(lambda: p.parse_bytes(b'{'), 'MALFORMED_JSON')

    def test_010_invalid_utf8_refused(self):
        self.refused(lambda: p.parse_bytes(b'"\xff"'), 'MALFORMED_JSON')

    def test_011_depth_bound(self):
        self.refused(lambda: p.parse_bytes(b'[' * 70 + b'0' + b']' * 70), 'JSON_RESOURCE_BOUND')

    def test_012_size_bound(self):
        self.refused(lambda: p.parse_bytes(b' ' * (p.MAX_JSON_BYTES + 1)), 'JSON_SIZE_BOUND')

    def test_013_domain_separation(self):
        self.assertNotEqual(p.digest('A', {'x': 1}), p.digest('B', {'x': 1}))

    def test_014_boolean_not_integer(self):
        self.assertNotEqual(p.canonical(True), p.canonical(1))

    def test_015_path_traversal(self):
        self.refused(lambda: p.relpath('../x'), 'UNSAFE_PATH')

    def test_016_absolute_path(self):
        self.refused(lambda: p.relpath('/tmp/x'), 'UNSAFE_PATH')

    def test_017_windows_path(self):
        self.refused(lambda: p.relpath('C:\\x'), 'UNSAFE_PATH')

    def test_018_empty_path_component(self):
        self.refused(lambda: p.relpath('a//b'), 'UNSAFE_PATH')

    def test_019_symlink_file(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / 'target').write_bytes(b'x')
            try:
                (root / 'link').symlink_to(root / 'target')
            except OSError as exc:
                self.skipTest('Symlink creation unavailable: ' + type(exc).__name__)
            self.refused(lambda: p.local_file(root, 'link'), 'SYMLINK_REFUSED')

    def test_020_unknown_program_field(self):
        self.bundle['program']['activate_now'] = True
        self.refused(lambda: p.validate_bundle(self.bundle), 'FIELD_SET_MISMATCH')

    def test_021_authority_promotion(self):
        self.bundle['program']['authority_effect'] = 'ADMIT'
        self.refused(lambda: p.validate_bundle(self.bundle), 'AUTHORITY_CEILING_EXCEEDED')

    def test_022_activation_promotion(self):
        self.bundle['program']['activation_allowed'] = True
        self.refused(lambda: p.validate_bundle(self.bundle), 'AUTHORITY_CEILING_EXCEEDED')

    def test_023_native_import_overclaim(self):
        self.bundle['program']['native_import_status'] = 'IMPORTED'
        self.refused(lambda: p.validate_bundle(self.bundle), 'NATIVE_BINDING_NOT_ESTABLISHED')

    def test_024_duplicate_stage(self):
        self.bundle['program']['stages'].append(copy.deepcopy(self.bundle['program']['stages'][0]))
        self.refused(lambda: p.validate_bundle(self.bundle), 'DUPLICATE_ID')

    def test_025_unknown_dependency(self):
        self.bundle['program']['stages'][1]['depends_on'] = ['NOT_A_STAGE']
        self.refused(lambda: p.validate_bundle(self.bundle), 'UNKNOWN_OR_SELF_DEPENDENCY')

    def test_026_cycle(self):
        self.bundle['program']['stages'][0]['depends_on'] = ['S01']
        self.refused(lambda: p.validate_bundle(self.bundle), 'DEPENDENCY_CYCLE')

    def test_027_product_execution_overclaim(self):
        self.bundle['program']['stages'][1]['state'] = 'PASS'
        self.refused(lambda: p.validate_bundle(self.bundle), 'STAGE_EXECUTION_OVERCLAIM')

    def test_028_product_case_overclaim(self):
        self.bundle['acceptance_catalog']['cases'][0]['status'] = 'PASS'
        self.refused(lambda: p.validate_bundle(self.bundle), 'PRODUCT_EVIDENCE_OVERCLAIM')

    def test_029_missing_gate_case(self):
        self.bundle['program']['stages'][0]['gate_cases'].pop()
        self.refused(lambda: p.validate_bundle(self.bundle), 'CASE_NOT_IN_GATE')

    def test_030_unknown_requirement(self):
        self.bundle['program']['stages'][0]['requirements'].append('R99')
        self.refused(lambda: p.validate_bundle(self.bundle), 'UNKNOWN_REQUIREMENT')

    def test_031_unknown_binding(self):
        self.bundle['program']['stages'][0]['required_bindings'].append('NEW_KERNEL')
        self.refused(lambda: p.validate_bundle(self.bundle), 'UNKNOWN_BINDING')

    def test_032_binding_overclaim(self):
        self.bundle['bindings']['bindings'][0]['status'] = 'BOUND'
        self.refused(lambda: p.validate_bundle(self.bundle), 'PPI_BINDING_UNSUPPORTED')

    def test_033_output_escape(self):
        self.bundle['program']['stages'][0]['outputs'][0]['path'] = '../escape'
        self.refused(lambda: p.validate_bundle(self.bundle), 'UNSAFE_PATH')

    def test_034_wrong_output_stage(self):
        self.bundle['program']['stages'][0]['outputs'][0]['path'] = 'product/S99/a'
        self.refused(lambda: p.validate_bundle(self.bundle), 'OUTPUT_SCOPE_MISMATCH')

    def test_035_batch_order(self):
        self.bundle['program']['batches'][0]['stages'].reverse()
        self.refused(lambda: p.validate_bundle(self.bundle), 'BATCH_DEPENDENCY_ORDER')

    def test_036_missing_freshness_mode(self):
        self.bundle['runtime_flow']['source_modes'].remove('P2P')
        self.refused(lambda: p.validate_bundle(self.bundle), 'FRESHNESS_MODE_COVERAGE')

    def test_037_jurisdiction_collapse(self):
        self.bundle['runtime_flow']['distinct_types'].remove('StateJurisdiction')
        self.refused(lambda: p.validate_bundle(self.bundle), 'JURISDICTION_TYPE_COLLAPSE')

    def test_038_runtime_overclaim(self):
        self.bundle['runtime_flow']['status'] = 'IMPLEMENTED'
        self.refused(lambda: p.validate_bundle(self.bundle), 'RUNTIME_IMPLEMENTATION_OVERCLAIM')

    def test_039_source_mutation(self):
        self.bundle['source_lock']['sources'][0]['sha256'] = '0' * 64
        self.refused(lambda: p.verify_inputs(ROOT, self.bundle), 'SOURCE_DIGEST_MISMATCH')

    def test_040_plan_replay(self):
        self.assertEqual(p.canonical(p.make_plan(ROOT)), p.canonical(p.make_plan(ROOT)))

    def test_041_parallel_branches(self):
        stages = p.indexed(self.bundle['program']['stages'], 'stages')
        self.assertEqual(stages['S05']['depends_on'], ['S03', 'S04'])
        self.assertEqual(stages['S06']['depends_on'], ['S04'])
        self.assertEqual(stages['S07']['depends_on'], ['S04'])
        self.assertEqual(stages['S08']['depends_on'], ['S05', 'S06', 'S07'])

    def test_042_dispatch_not_execution(self):
        result = p.dispatch(ROOT, 'A')
        self.assertEqual(result['dispatch_kind'], 'WORK_ORDER_PRESENTATION_NOT_EXECUTION')
        self.assertFalse(result['may_execute_product'])
        self.assertEqual(len(result['work_orders']), 2)

    def test_043_unknown_batch(self):
        self.refused(lambda: p.dispatch(ROOT, 'Z'), 'UNKNOWN_BATCH')

    def make_return(self, status='PASS'):
        return {'schema': 'ccp.stage_return.draft.v1', 'program_digest': p.make_plan(ROOT)['program_digest'],
                'stage_id': 'S00', 'attempt_id': 'local-test-only', 'authority_effect': 'NONE',
                'case_results': [{'case_id': c, 'status': status, 'evidence_kind': 'BUILDER_REPORTED_UNVERIFIED'}
                                 for c in self.bundle['program']['stages'][0]['gate_cases']],
                'artifact_claims': []}

    def test_044_reported_pass_cannot_advance(self):
        result = p.check_return(ROOT, self.make_return(), ROOT)
        self.assertEqual(result['status'], 'STRUCTURALLY_VALID_UNVERIFIED')
        self.assertFalse(result['may_advance'])
        self.assertFalse(result['product_outcomes_independently_verified'])
        self.assertFalse(result['required_output_completeness_verified'])

    def test_045_incomplete_return(self):
        result = p.check_return(ROOT, self.make_return('NOT_RUN'), ROOT)
        self.assertEqual(result['status'], 'INCOMPLETE_RETURN')
        self.assertFalse(result['may_advance'])

    def test_046_return_wrong_program(self):
        env = self.make_return()
        env['program_digest'] = '0' * 64
        self.refused(lambda: p.check_return(ROOT, env, ROOT), 'RETURN_PROGRAM_MISMATCH')

    def test_047_return_missing_case(self):
        env = self.make_return()
        env['case_results'].pop()
        self.refused(lambda: p.check_return(ROOT, env, ROOT), 'RETURN_CASE_SET_MISMATCH')

    def test_048_return_duplicate_case(self):
        env = self.make_return()
        env['case_results'].append(copy.deepcopy(env['case_results'][0]))
        self.refused(lambda: p.check_return(ROOT, env, ROOT), 'RETURN_DUPLICATE_CASE')

    def test_049_return_fake_independent(self):
        env = self.make_return()
        env['case_results'][0]['evidence_kind'] = 'INDEPENDENTLY_VERIFIED'
        self.refused(lambda: p.check_return(ROOT, env, ROOT), 'RETURN_EVIDENCE_OVERCLAIM')

    def test_050_return_artifact_integrity(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / 'evidence.bin').write_bytes(b'local fixture')
            env = self.make_return()
            env['artifact_claims'] = [{'path': 'evidence.bin', 'sha256': hashlib.sha256(b'local fixture').hexdigest(), 'bytes': 13}]
            result = p.check_return(ROOT, env, root)
            self.assertEqual(result['checked_artifact_claims'], 1)
            self.assertFalse(result['may_advance'])
            (root / 'evidence.bin').write_bytes(b'changed')
            self.refused(lambda: p.check_return(ROOT, env, root), 'RETURN_ARTIFACT_MISMATCH')

    def test_051_return_authority_overclaim(self):
        env = self.make_return()
        env['authority_effect'] = 'EXECUTE'
        self.refused(lambda: p.check_return(ROOT, env, ROOT), 'RETURN_AUTHORITY_OVERCLAIM')

    def test_052_source_claim_ceiling(self):
        self.bundle['program']['claim_ceiling'] = 'FULL_SECURITY'
        self.refused(lambda: p.validate_bundle(self.bundle), 'CLAIM_CEILING_EXCEEDED')

    def test_053_no_automatic_issue_closure(self):
        self.bundle['open_issues']['issues'][0]['status'] = 'RESOLVED'
        self.refused(lambda: p.validate_bundle(self.bundle), 'UNVERIFIED_ISSUE_CLOSURE')

    def test_054_packet_integrity_tamper(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            payload = b'abc'
            (root / 'x').write_bytes(payload)
            entries = [{'path': 'x', 'bytes': len(payload), 'sha256': hashlib.sha256(payload).hexdigest()}]
            manifest = {'schema': 'ccp.packet_manifest.v1', 'excludes': ['PACKAGE_MANIFEST.json'],
                        'files': entries, 'content_root': p.digest('PACKAGE_FILES', entries), 'authority_effect': 'NONE'}
            (root / 'PACKAGE_MANIFEST.json').write_text(json.dumps(manifest), encoding='utf-8')
            result = p.verify_package(root)
            self.assertFalse(result['authenticity_established'])
            (root / 'x').write_bytes(b'def')
            self.refused(lambda: p.verify_package(root), 'PACKAGE_FILE_MISMATCH')

    def test_055_packet_extra_file(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            manifest = {'schema': 'ccp.packet_manifest.v1', 'excludes': ['PACKAGE_MANIFEST.json'],
                        'files': [], 'content_root': p.digest('PACKAGE_FILES', []), 'authority_effect': 'NONE'}
            (root / 'PACKAGE_MANIFEST.json').write_text(json.dumps(manifest), encoding='utf-8')
            (root / 'unexpected').write_bytes(b'x')
            self.refused(lambda: p.verify_package(root), 'PACKAGE_CLOSED_WORLD_MISMATCH')

    def test_056_different_context_changes_plan_identity(self):
        original = p.verify_inputs(ROOT, self.bundle)
        altered = dict(original)
        altered['program/BINDINGS.json'] = '0' * 64
        self.assertNotEqual(p.digest('PROGRAM_INPUTS', original), p.digest('PROGRAM_INPUTS', altered))

if __name__ == '__main__':
    unittest.main()
