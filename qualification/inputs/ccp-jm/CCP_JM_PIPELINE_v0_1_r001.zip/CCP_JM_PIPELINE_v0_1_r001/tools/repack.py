#!/usr/bin/env python3
"""Reproduce the sealed packet ZIP. Output must be outside the packet root."""
import argparse
import importlib.util
import json
import zipfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('programctl', ROOT / 'tools/programctl.py')
p = importlib.util.module_from_spec(spec)
spec.loader.exec_module(p)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    target = args.output.resolve()
    if target == ROOT or ROOT in target.parents:
        raise SystemExit('Refused: output must be outside the closed-world packet.')
    if target.exists():
        raise SystemExit('Refused: output already exists.')
    report = p.verify_package(ROOT)
    paths = sorted(x.relative_to(ROOT).as_posix() for x in ROOT.rglob('*') if x.is_file())
    with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_STORED) as archive:
        for rel in paths:
            item = zipfile.ZipInfo('CCP_JM_PIPELINE_v0_1_r001/' + rel, date_time=(1980, 1, 1, 0, 0, 0))
            item.create_system = 3
            item.external_attr = 0o100644 << 16
            item.compress_type = zipfile.ZIP_STORED
            archive.writestr(item, p.local_file(ROOT, rel).read_bytes())
    print(json.dumps({'status': 'PACKED', 'content_root': report['content_root'],
                      'file_count': len(paths), 'authority_effect': 'NONE'}, sort_keys=True))
if __name__ == '__main__':
    main()
