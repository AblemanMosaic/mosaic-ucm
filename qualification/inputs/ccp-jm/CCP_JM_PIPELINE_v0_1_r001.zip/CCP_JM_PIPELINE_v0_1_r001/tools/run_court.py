#!/usr/bin/env python3
"""Run local packet-tool tests and emit their actual results. No product tests."""
import argparse
import hashlib
import importlib.util
import json
import platform
import sys
import unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('programctl', ROOT / 'tools/programctl.py')
p = importlib.util.module_from_spec(spec)
spec.loader.exec_module(p)

class Results(unittest.TextTestResult):
    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.records = []
    def addSuccess(self, test):
        super().addSuccess(test)
        self.records.append({'id': test.id(), 'status': 'PASS'})
    def addFailure(self, test, err):
        super().addFailure(test, err)
        self.records.append({'id': test.id(), 'status': 'FAIL', 'error': self._exc_info_to_string(err, test)})
    def addError(self, test, err):
        super().addError(test, err)
        self.records.append({'id': test.id(), 'status': 'ERROR', 'error': self._exc_info_to_string(err, test)})
    def addSkip(self, test, reason):
        super().addSkip(test, reason)
        self.records.append({'id': test.id(), 'status': 'SKIP', 'reason': reason})

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    suite = unittest.defaultTestLoader.discover(str(ROOT / 'tests'))
    result = unittest.TextTestRunner(resultclass=Results, verbosity=2).run(suite)
    rows = sorted(result.records, key=lambda r: r['id'])
    out = {'schema': 'ccp.packet_tool_court.v1', 'scope': 'PORTABLE_PACKET_TOOLS_ONLY',
           'status': 'PASS' if result.wasSuccessful() and not result.skipped else 'FAIL_OR_INCOMPLETE',
           'executed': result.testsRun, 'passed': sum(r['status'] == 'PASS' for r in rows),
           'failed': len(result.failures), 'errors': len(result.errors), 'skipped': len(result.skipped),
           'cases': rows, 'case_result_root': p.digest('PACKET_TEST_RESULTS', rows),
           'program_digest': p.make_plan(ROOT)['program_digest'],
           'test_file_sha256': hashlib.sha256((ROOT / 'tests/test_programctl.py').read_bytes()).hexdigest(),
           'runtime': {'python': platform.python_version(), 'implementation': platform.python_implementation(),
                       'system': platform.system(), 'machine': platform.machine(), 'optimization': sys.flags.optimize},
           'product_acceptance_cases_executed': 0, 'native_P_PPI_import': 'NOT_RUN',
           'windows_native': 'NOT_RUN', 'arm_linux_native': 'NOT_RUN',
           'independent_review': 'NOT_RUN', 'authority_effect': 'NONE'}
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(out, sort_keys=True, indent=2)+'\n', encoding='utf-8', newline='\n')
    return 0 if out['status'] == 'PASS' else 1
if __name__ == '__main__':
    raise SystemExit(main())
