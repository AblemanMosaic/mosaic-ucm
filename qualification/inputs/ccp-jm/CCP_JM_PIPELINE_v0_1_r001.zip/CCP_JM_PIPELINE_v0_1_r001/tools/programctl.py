#!/usr/bin/env python3
"""Offline CCP construction-program planner; NOT a CCP/CHC security runtime.

Python 3.10+ standard library. No network, shell dispatch, native imports,
authority updates, program admission, or product-stage execution.
All successful return checks remain unverified and cannot advance a gate.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import re
import sys
from pathlib import Path, PurePosixPath
from typing import Any

MAX_JSON_BYTES = 4 * 1024 * 1024
MAX_DEPTH = 64
MAX_NODES = 100000
HEX = re.compile(r'^[0-9a-f]{64}$')
ROOT = Path(__file__).resolve().parents[1]
PROGRAM_FIELDS = {
    'schema', 'program_id', 'revision', 'date', 'title', 'status',
    'authority_effect', 'activation_allowed', 'native_program_binding',
    'native_import_status', 'claim_ceiling', 'objective', 'inputs',
    'batches', 'stages', 'nonclaims'
}
STAGE_FIELDS = {
    'id', 'batch', 'title', 'depends_on', 'requirements', 'required_bindings',
    'outputs', 'work_order', 'instruction', 'exit_criterion', 'gate_cases',
    'state', 'claim_ceiling', 'effects', 'halt_on'
}
INPUT_FILES = {
    'source_lock', 'bindings', 'requirements', 'acceptance_catalog',
    'runtime_flow', 'open_issues'
}

class Refusal(ValueError):
    def __init__(self, code: str, detail: str = '') -> None:
        self.code = code
        self.detail = detail
        super().__init__(code + (': ' + detail if detail else ''))

def require(condition: bool, code: str, detail: str = '') -> None:
    if not condition:
        raise Refusal(code, detail)

def exact(obj: Any, fields: set[str], where: str) -> dict[str, Any]:
    require(type(obj) is dict, 'OBJECT_REQUIRED', where)
    require(set(obj) == fields, 'FIELD_SET_MISMATCH', where)
    return obj

def text(value: Any, where: str) -> str:
    require(type(value) is str and bool(value), 'NONEMPTY_STRING_REQUIRED', where)
    return value

def sequence(value: Any, where: str) -> list[Any]:
    require(type(value) is list, 'ARRAY_REQUIRED', where)
    return value

def string_list(value: Any, where: str, *, nonempty: bool = False) -> list[str]:
    sequence(value, where)
    require(all(type(v) is str and bool(v) for v in value), 'STRING_ARRAY_REQUIRED', where)
    require(len(value) == len(set(value)), 'DUPLICATE_REFERENCE', where)
    if nonempty:
        require(bool(value), 'EMPTY_REFERENCE_SET', where)
    return value

def check_value(value: Any, depth: int = 0, budget: list[int] | None = None) -> None:
    if budget is None:
        budget = [MAX_NODES]
    budget[0] -= 1
    require(budget[0] >= 0 and depth <= MAX_DEPTH, 'JSON_RESOURCE_BOUND')
    if value is None or type(value) is bool:
        return
    if type(value) is int:
        require(-(2**63) <= value < 2**63, 'INTEGER_OUT_OF_RANGE')
        return
    if type(value) is str:
        require(not any(0xD800 <= ord(c) <= 0xDFFF for c in value), 'INVALID_UNICODE_SCALAR')
        return
    if type(value) is list:
        for item in value:
            check_value(item, depth + 1, budget)
        return
    if type(value) is dict:
        require(all(type(k) is str for k in value), 'NONSTRING_KEY')
        for key, item in value.items():
            check_value(key, depth + 1, budget)
            check_value(item, depth + 1, budget)
        return
    raise Refusal('UNSUPPORTED_JSON_TYPE', type(value).__name__)

def _pairs(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        require(key not in result, 'DUPLICATE_KEY', key)
        result[key] = value
    return result

def _reject_number(token: str) -> Any:
    raise Refusal('FLOAT_OR_NONFINITE_FORBIDDEN', token)

def parse_bytes(raw: bytes) -> Any:
    require(len(raw) <= MAX_JSON_BYTES, 'JSON_SIZE_BOUND')
    try:
        value = json.loads(raw.decode('utf-8'), object_pairs_hook=_pairs,
                           parse_float=_reject_number, parse_constant=_reject_number)
        check_value(value)
        return value
    except Refusal:
        raise
    except (ValueError, UnicodeError, RecursionError) as exc:
        raise Refusal('MALFORMED_JSON', type(exc).__name__) from exc

def canonical(value: Any) -> bytes:
    """Packet-only profile. This is NOT an asserted CHC/THR canonical format."""
    check_value(value)
    return json.dumps(value, sort_keys=True, ensure_ascii=True,
                      separators=(',', ':'), allow_nan=False).encode('ascii')

def digest(domain: str, value: Any) -> str:
    body = canonical(value)
    prefix = ('CCP-PROGRAM-DRAFT/v0.1/' + domain).encode('ascii')
    return hashlib.sha256(prefix + b'\0' + len(body).to_bytes(8, 'big') + body).hexdigest()

def relpath(value: Any) -> str:
    path = text(value, 'relative path')
    require('\\' not in path and ':' not in path and '\x00' not in path,
            'UNSAFE_PATH', path)
    require(not path.startswith('/') and all(p not in ('', '.', '..') for p in path.split('/')),
            'UNSAFE_PATH', path)
    require(PurePosixPath(path).as_posix() == path, 'NONCANONICAL_PATH', path)
    return path

def local_file(root: Path, relative: Any) -> Path:
    relative = relpath(relative)
    root = root.resolve()
    candidate = root
    for part in relative.split('/'):
        candidate = candidate / part
        require(not candidate.is_symlink(), 'SYMLINK_REFUSED', relative)
    require(candidate.is_file(), 'FILE_UNAVAILABLE', relative)
    require(root in candidate.resolve().parents, 'PATH_ESCAPE', relative)
    return candidate

def read_json(root: Path, relative: str) -> Any:
    p = local_file(root, relative)
    require(p.stat().st_size <= MAX_JSON_BYTES, 'JSON_SIZE_BOUND', relative)
    return parse_bytes(p.read_bytes())

def indexed(rows: Any, where: str) -> dict[str, dict[str, Any]]:
    sequence(rows, where)
    out: dict[str, dict[str, Any]] = {}
    for row in rows:
        require(type(row) is dict, 'OBJECT_REQUIRED', where)
        key = text(row.get('id'), where + '.id')
        require(key not in out, 'DUPLICATE_ID', where + ':' + key)
        out[key] = row
    return out

def load_bundle(root: Path = ROOT) -> dict[str, Any]:
    program = read_json(root, 'program/PROGRAM.json')
    exact(program, PROGRAM_FIELDS, 'program')
    exact(program['inputs'], INPUT_FILES, 'program.inputs')
    bundle: dict[str, Any] = {'program': program}
    for key, relative in program['inputs'].items():
        bundle[key] = read_json(root, relpath(relative))
    return bundle

def topological(stages: dict[str, dict[str, Any]]) -> list[str]:
    pending = set(stages)
    order: list[str] = []
    while pending:
        ready = sorted(s for s in pending if set(stages[s]['depends_on']) <= set(order))
        require(bool(ready), 'DEPENDENCY_CYCLE')
        order.extend(ready)
        pending.difference_update(ready)
    return order

def validate_bundle(bundle: dict[str, Any]) -> dict[str, Any]:
    p = exact(bundle['program'], PROGRAM_FIELDS, 'program')
    require(p['schema'] == 'ccp.construction_program.draft.v1', 'UNSUPPORTED_PROGRAM_SCHEMA')
    require(p['program_id'] == 'CCP-JM', 'WRONG_PROGRAM')
    for field in ['revision', 'date', 'title', 'status', 'objective', 'claim_ceiling']:
        text(p[field], 'program.' + field)
    require(p['authority_effect'] == 'NONE' and p['activation_allowed'] is False,
            'AUTHORITY_CEILING_EXCEEDED')
    require(p['native_import_status'] == 'UNBOUND' and p['native_program_binding'] == 'P_PPI',
            'NATIVE_BINDING_NOT_ESTABLISHED')
    require(p['claim_ceiling'] == 'SOURCE_BOUND_PROGRAM_SPECIFICATION_AND_OFFLINE_PLANNING_ONLY',
            'CLAIM_CEILING_EXCEEDED')
    string_list(p['nonclaims'], 'nonclaims', nonempty=True)
    exact(p['inputs'], INPUT_FILES, 'inputs')
    for path in p['inputs'].values():
        relpath(path)
    sources = indexed(bundle['source_lock']['sources'], 'sources')
    require(bundle['source_lock']['authority_effect'] == 'NONE', 'SOURCE_AUTHORITY_CLAIM')
    for row in sources.values():
        relpath(row['path'])
        require(type(row['sha256']) is str and HEX.fullmatch(row['sha256']) is not None, 'INVALID_DIGEST')
        require(type(row['bytes']) is int and row['bytes'] > 0, 'INVALID_BYTE_COUNT')
    bindings = indexed(bundle['bindings']['bindings'], 'bindings')
    require('P_PPI' in bindings and bindings['P_PPI']['status'] == 'UNBOUND', 'PPI_BINDING_UNSUPPORTED')
    for row in bindings.values():
        require(row['status'] in ['UNBOUND', 'SOURCE_PINNED'], 'BINDING_PROMOTION_UNSUPPORTED')
        require(row['interface_digest'] is None and row['native_compatibility'] == 'NOT_ESTABLISHED',
                'BINDING_PROMOTION_UNSUPPORTED')
    requirements = indexed(bundle['requirements']['requirements'], 'requirements')
    require(bool(requirements), 'EMPTY_REQUIREMENTS')
    for req in requirements.values():
        exact(req, {'id', 'text', 'basis'}, 'requirement')
        text(req['text'], 'requirement.text')
        text(req['basis'], 'requirement.basis')
    cases = indexed(bundle['acceptance_catalog']['cases'], 'cases')
    require(bool(cases), 'EMPTY_ACCEPTANCE_CATALOG')
    require(bundle['acceptance_catalog']['status'] == 'SPECIFIED_NOT_EXECUTED', 'PRODUCT_EVIDENCE_OVERCLAIM')
    stages = indexed(p['stages'], 'stages')
    require(bool(stages), 'EMPTY_PROGRAM')
    outputs: set[str] = set()
    output_ids: set[str] = set()
    referenced_requirements: set[str] = set()
    for sid, stage in stages.items():
        exact(stage, STAGE_FIELDS, 'stage.' + sid)
        for field in ['batch', 'title', 'work_order', 'instruction', 'exit_criterion', 'claim_ceiling']:
            text(stage[field], sid + '.' + field)
        require(stage['state'] == 'NOT_RUN', 'STAGE_EXECUTION_OVERCLAIM', sid)
        string_list(stage['depends_on'], sid + '.depends_on')
        require(sid not in stage['depends_on'] and set(stage['depends_on']) <= set(stages),
                'UNKNOWN_OR_SELF_DEPENDENCY', sid)
        string_list(stage['requirements'], sid + '.requirements', nonempty=True)
        require(set(stage['requirements']) <= set(requirements), 'UNKNOWN_REQUIREMENT', sid)
        referenced_requirements.update(stage['requirements'])
        string_list(stage['required_bindings'], sid + '.bindings', nonempty=True)
        require(set(stage['required_bindings']) <= set(bindings), 'UNKNOWN_BINDING', sid)
        string_list(stage['gate_cases'], sid + '.gate_cases', nonempty=True)
        require(set(stage['gate_cases']) <= set(cases), 'UNKNOWN_GATE_CASE', sid)
        string_list(stage['halt_on'], sid + '.halt_on', nonempty=True)
        relpath(stage['work_order'])
        sequence(stage['outputs'], sid + '.outputs')
        require(bool(stage['outputs']), 'EMPTY_OUTPUTS', sid)
        for art in stage['outputs']:
            exact(art, {'id', 'path', 'kind'}, 'output')
            ident, path = text(art['id'], 'output.id'), relpath(art['path'])
            require(ident not in output_ids and path not in outputs, 'DUPLICATE_OUTPUT', sid)
            require(path.startswith('product/' + sid + '/'), 'OUTPUT_SCOPE_MISMATCH', sid)
            require(art['kind'] == 'PROPOSED_PRODUCT_ARTIFACT', 'OUTPUT_OVERCLAIM', sid)
            output_ids.add(ident)
            outputs.add(path)
        exact(stage['effects'], {'construction_workspace', 'external_network', 'live_stack_changes', 'authority_effect'}, 'effects')
        require(stage['effects']['construction_workspace'] == 'ISOLATED_WORKSPACE_ONLY', 'EFFECT_SCOPE_MISMATCH')
        require(stage['effects']['external_network'] in ['NOT_REQUIRED', 'SEPARATE_AUTHORIZATION_REQUIRED'], 'NETWORK_AUTHORITY_OVERCLAIM')
        require(stage['effects']['live_stack_changes'] in ['PROHIBITED', 'SEPARATE_AUTHORIZATION_REQUIRED'], 'LIVE_EFFECT_OVERCLAIM')
        require(stage['effects']['authority_effect'] == 'NONE_UNLESS_SEPARATELY_AUTHORIZED_IN_S11_OR_S12', 'AUTHORITY_CEILING_EXCEEDED')
        if stage['effects']['live_stack_changes'] != 'PROHIBITED':
            require(sid in ['S11', 'S12'], 'PREMATURE_LIVE_EFFECT')
    require(referenced_requirements == set(requirements), 'UNOWNED_REQUIREMENT')
    order = topological(stages)
    covered: set[str] = set()
    for cid, case in cases.items():
        exact(case, {'id', 'stage', 'requirements', 'title', 'stimulus', 'expected', 'status', 'evidence_ref', 'case_kind'}, 'case.' + cid)
        require(case['stage'] in stages, 'CASE_UNKNOWN_STAGE', cid)
        require(cid in stages[case['stage']]['gate_cases'], 'CASE_NOT_IN_GATE', cid)
        require(case['status'] == 'NOT_RUN' and case['evidence_ref'] is None,
                'PRODUCT_EVIDENCE_OVERCLAIM', cid)
        require(case['case_kind'] == 'PRODUCT_ACCEPTANCE_SPECIFICATION', 'WRONG_CASE_KIND', cid)
        string_list(case['requirements'], cid + '.requirements', nonempty=True)
        require(set(case['requirements']) <= set(stages[case['stage']]['requirements']), 'CASE_REQUIREMENT_SCOPE', cid)
        covered.update(case['requirements'])
        for field in ['title', 'stimulus', 'expected']:
            text(case[field], cid + '.' + field)
    require(covered == set(requirements), 'UNTESTED_REQUIREMENT')
    for sid, stage in stages.items():
        require(set(stage['gate_cases']) == {cid for cid, c in cases.items() if c['stage'] == sid},
                'GATE_CASE_SET_MISMATCH', sid)
    batches = indexed(p['batches'], 'batches')
    flattened: list[str] = []
    for bid, batch in batches.items():
        exact(batch, {'id', 'title', 'stages'}, 'batch')
        text(batch['title'], 'batch.title')
        string_list(batch['stages'], 'batch.stages', nonempty=True)
        require(set(batch['stages']) <= set(stages), 'BATCH_UNKNOWN_STAGE')
        require(all(stages[s]['batch'] == bid for s in batch['stages']), 'BATCH_MEMBERSHIP_MISMATCH')
        flattened.extend(batch['stages'])
    require(len(flattened) == len(set(flattened)) and set(flattened) == set(stages), 'BATCH_COVERAGE_MISMATCH')
    positions = {sid: i for i, sid in enumerate(flattened)}
    require(all(positions[d] < positions[sid] for sid, s in stages.items() for d in s['depends_on']), 'BATCH_DEPENDENCY_ORDER')
    flow = bundle['runtime_flow']
    require(flow['status'] == 'SPECIFIED_NOT_IMPLEMENTED' and flow['authority_effect'] == 'NONE', 'RUNTIME_IMPLEMENTATION_OVERCLAIM')
    require(set(flow['source_modes']) == {'LOCAL', 'LAN', 'INTERNET', 'P2P'} and len(flow['source_modes']) == 4,
            'FRESHNESS_MODE_COVERAGE')
    require({'StateJurisdiction', 'GovernanceJurisdiction', 'EnforcementPerimeter'} <= set(flow['distinct_types']),
            'JURISDICTION_TYPE_COLLAPSE')
    issues = indexed(bundle['open_issues']['issues'], 'issues')
    require(bool(issues) and all(i['status'] == 'OPEN' for i in issues.values()), 'UNVERIFIED_ISSUE_CLOSURE')
    return {'status': 'PASS_STRUCTURE_ONLY', 'stage_count': len(stages), 'batch_count': len(batches),
            'requirement_count': len(requirements), 'product_case_count': len(cases), 'product_cases_executed': 0,
            'order': order, 'authority_effect': 'NONE', 'native_import_status': 'UNBOUND',
            'may_advance_product_gate': False}

def verify_inputs(root: Path, bundle: dict[str, Any]) -> dict[str, str]:
    files = {'program/PROGRAM.json', 'tools/programctl.py', 'contracts/STAGE_RETURN_CONTRACT.json',
             *bundle['program']['inputs'].values()}
    files.update(s['work_order'] for s in bundle['program']['stages'])
    for source in bundle['source_lock']['sources']:
        path = local_file(root, source['path'])
        data = path.read_bytes()
        require(len(data) == source['bytes'] and hashlib.sha256(data).hexdigest() == source['sha256'],
                'SOURCE_DIGEST_MISMATCH', source['path'])
        files.add(source['path'])
    summary_ref = bundle['source_lock']['conversation_requirements']['path']
    files.add(summary_ref)
    return {p: hashlib.sha256(local_file(root, p).read_bytes()).hexdigest() for p in sorted(files)}

def make_plan(root: Path = ROOT) -> dict[str, Any]:
    bundle = load_bundle(root)
    validation = validate_bundle(bundle)
    inputs = verify_inputs(root, bundle)
    program_digest = digest('PROGRAM_INPUTS', inputs)
    rows = []
    binds = indexed(bundle['bindings']['bindings'], 'bindings')
    for stage in bundle['program']['stages']:
        rows.append({'stage_id': stage['id'], 'batch': stage['batch'], 'state': 'NOT_RUN',
                     'entry_status': 'READY_FOR_BINDING_WORK_ONLY' if stage['id'] == 'S00' else 'BLOCKED_BY_PREDECESSORS',
                     'unpassed_predecessors': sorted(stage['depends_on']),
                     'unbound_interfaces': sorted(b for b in stage['required_bindings'] if binds[b]['status'] == 'UNBOUND'),
                     'required_product_cases': len(stage['gate_cases']), 'work_order': stage['work_order'],
                     'may_execute_product': False})
    result = {'schema': 'ccp.portable_plan.draft.v1', 'program_id': 'CCP-JM',
              'program_digest': program_digest, 'input_file_hashes': inputs,
              'validation': validation, 'stages': rows, 'next_batch': 'A',
              'next_work_order': 'work_orders/S00.md', 'native_import': 'UNBOUND',
              'authority_effect': 'NONE', 'product_execution_performed': False}
    result['plan_digest'] = digest('PLAN', result)
    return result

def dispatch(root: Path, batch_id: str) -> dict[str, Any]:
    plan = make_plan(root)
    bundle = load_bundle(root)
    batches = indexed(bundle['program']['batches'], 'batches')
    require(batch_id in batches, 'UNKNOWN_BATCH', batch_id)
    selected = set(batches[batch_id]['stages'])
    return {'schema': 'ccp.work_order_bundle.draft.v1', 'program_digest': plan['program_digest'],
            'batch': batch_id, 'dispatch_kind': 'WORK_ORDER_PRESENTATION_NOT_EXECUTION',
            'work_orders': [{'stage_id': s['id'], 'text': local_file(root, s['work_order']).read_text(encoding='utf-8')}
                            for s in bundle['program']['stages'] if s['id'] in selected],
            'entry_status': [s for s in plan['stages'] if s['stage_id'] in selected],
            'authority_effect': 'NONE', 'may_execute_product': False}

def check_return(root: Path, envelope: Any, artifact_root: Path) -> dict[str, Any]:
    exact(envelope, {'schema', 'program_digest', 'stage_id', 'attempt_id', 'authority_effect', 'case_results', 'artifact_claims'}, 'stage_return')
    require(envelope['schema'] == 'ccp.stage_return.draft.v1', 'UNSUPPORTED_RETURN_SCHEMA')
    plan = make_plan(root)
    require(envelope['program_digest'] == plan['program_digest'], 'RETURN_PROGRAM_MISMATCH')
    require(envelope['authority_effect'] == 'NONE', 'RETURN_AUTHORITY_OVERCLAIM')
    text(envelope['attempt_id'], 'attempt_id')
    stages = indexed(load_bundle(root)['program']['stages'], 'stages')
    sid = text(envelope['stage_id'], 'stage_id')
    require(sid in stages, 'RETURN_UNKNOWN_STAGE')
    sequence(envelope['case_results'], 'case_results')
    reported: dict[str, str] = {}
    for row in envelope['case_results']:
        exact(row, {'case_id', 'status', 'evidence_kind'}, 'case_result')
        cid = text(row['case_id'], 'case_id')
        require(cid not in reported, 'RETURN_DUPLICATE_CASE')
        require(row['status'] in ['PASS', 'FAIL', 'BLOCKED', 'NOT_RUN'], 'RETURN_INVALID_STATUS')
        require(row['evidence_kind'] == 'BUILDER_REPORTED_UNVERIFIED', 'RETURN_EVIDENCE_OVERCLAIM')
        reported[cid] = row['status']
    require(set(reported) == set(stages[sid]['gate_cases']), 'RETURN_CASE_SET_MISMATCH')
    sequence(envelope['artifact_claims'], 'artifact_claims')
    seen: set[str] = set()
    for item in envelope['artifact_claims']:
        exact(item, {'path', 'sha256', 'bytes'}, 'artifact_claim')
        path = relpath(item['path'])
        require(path not in seen, 'RETURN_DUPLICATE_ARTIFACT')
        seen.add(path)
        require(type(item['bytes']) is int and item['bytes'] >= 0, 'INVALID_BYTE_COUNT')
        require(type(item['sha256']) is str and HEX.fullmatch(item['sha256']) is not None, 'INVALID_DIGEST')
        artifact = local_file(artifact_root, path)
        raw = artifact.read_bytes()
        require(len(raw) == item['bytes'] and hashlib.sha256(raw).hexdigest() == item['sha256'], 'RETURN_ARTIFACT_MISMATCH', path)
    all_claimed_pass = all(v == 'PASS' for v in reported.values())
    return {'schema': 'ccp.return_structure_result.draft.v1',
            'status': 'STRUCTURALLY_VALID_UNVERIFIED' if all_claimed_pass else 'INCOMPLETE_RETURN',
            'program_digest': plan['program_digest'], 'stage_id': sid,
            'reported_cases': len(reported), 'checked_artifact_claims': len(seen),
            'product_outcomes_independently_verified': False,
            'required_output_completeness_verified': False,
            'cryptographic_witness_authority_verified': False,
            'may_advance': False, 'authority_effect': 'NONE',
            'limits': ['Structural and claimed-file-custody checks only.',
                       'Does not verify that product tests ran or that required outputs are complete.',
                       'Does not accept native program returns or mutate stage state.']}

def verify_package(root: Path) -> dict[str, Any]:
    manifest = read_json(root, 'PACKAGE_MANIFEST.json')
    exact(manifest, {'schema', 'excludes', 'files', 'content_root', 'authority_effect'}, 'package_manifest')
    require(manifest['schema'] == 'ccp.packet_manifest.v1', 'UNSUPPORTED_PACKAGE_SCHEMA')
    require(manifest['excludes'] == ['PACKAGE_MANIFEST.json'], 'PACKAGE_EXCLUSION_MISMATCH')
    require(manifest['authority_effect'] == 'NONE', 'PACKAGE_AUTHORITY_OVERCLAIM')
    require(manifest['content_root'] == digest('PACKAGE_FILES', manifest['files']), 'PACKAGE_ROOT_MISMATCH')
    expected: set[str] = set()
    for entry in sequence(manifest['files'], 'manifest.files'):
        exact(entry, {'path', 'bytes', 'sha256'}, 'manifest.file')
        rel = relpath(entry['path'])
        require(rel != 'PACKAGE_MANIFEST.json' and rel not in expected, 'PACKAGE_DUPLICATE_OR_SELF')
        expected.add(rel)
        require(type(entry['bytes']) is int and entry['bytes'] >= 0, 'INVALID_BYTE_COUNT')
        require(type(entry['sha256']) is str and HEX.fullmatch(entry['sha256']) is not None, 'INVALID_DIGEST')
        raw = local_file(root, rel).read_bytes()
        require(len(raw) == entry['bytes'] and hashlib.sha256(raw).hexdigest() == entry['sha256'], 'PACKAGE_FILE_MISMATCH', rel)
    require([e['path'] for e in manifest['files']] == sorted(expected), 'PACKAGE_ORDER_MISMATCH')
    actual: set[str] = set()
    for path in root.rglob('*'):
        require(not path.is_symlink(), 'SYMLINK_REFUSED', path.relative_to(root).as_posix())
        if path.is_file():
            actual.add(path.relative_to(root).as_posix())
    require(actual == expected | {'PACKAGE_MANIFEST.json'}, 'PACKAGE_CLOSED_WORLD_MISMATCH')
    return {'status': 'PASS_PACKET_INTEGRITY_ONLY', 'file_count': len(actual),
            'content_root': manifest['content_root'], 'authenticity_established': False, 'authority_effect': 'NONE'}

def cli() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    sub = parser.add_subparsers(dest='command', required=True)
    for name in ('validate', 'plan', 'replay', 'verify-package'):
        sub.add_parser(name)
    dis = sub.add_parser('dispatch')
    dis.add_argument('--batch', required=True)
    ret = sub.add_parser('check-return')
    ret.add_argument('envelope', type=Path)
    ret.add_argument('--artifact-root', type=Path, required=True)
    args = parser.parse_args()
    try:
        if args.command == 'validate':
            bundle = load_bundle(args.root)
            out = validate_bundle(bundle)
            verify_inputs(args.root, bundle)
        elif args.command == 'plan':
            out = make_plan(args.root)
        elif args.command == 'dispatch':
            out = dispatch(args.root, args.batch)
        elif args.command == 'check-return':
            require(not args.envelope.is_symlink(), 'SYMLINK_REFUSED')
            require(args.envelope.stat().st_size <= MAX_JSON_BYTES, 'JSON_SIZE_BOUND')
            out = check_return(args.root, parse_bytes(args.envelope.read_bytes()), args.artifact_root)
        elif args.command == 'verify-package':
            out = verify_package(args.root)
        else:
            first, second = make_plan(args.root), make_plan(args.root)
            require(canonical(first) == canonical(second), 'REPLAY_DIVERGENCE')
            out = {'status': 'PASS_SAME_IMPLEMENTATION_PLAN_REPLAY_ONLY', 'plan_digest': first['plan_digest'],
                   'program_digest': first['program_digest'], 'authority_effect': 'NONE',
                   'independent_implementation': False, 'product_cases_executed': 0}
        print(json.dumps(out, sort_keys=True, ensure_ascii=True, indent=2))
        return 0
    except Refusal as exc:
        print(json.dumps({'status': 'REFUSED', 'code': exc.code, 'detail': exc.detail, 'authority_effect': 'NONE'}, sort_keys=True))
        return 2
    except (OSError, KeyError, TypeError, RecursionError) as exc:
        print(json.dumps({'status': 'TOOL_FAULT', 'fault_class': type(exc).__name__, 'authority_effect': 'NONE'}, sort_keys=True))
        return 1

if __name__ == '__main__':
    sys.exit(cli())
