# CCP-JM pipeline program — v0.1.0 r001

**Proposed construction program · Native P/PPI binding UNBOUND · Authority effect NONE**

This package turns the CCP jurisdiction roadmap into a source-bound construction program: 13 stages, six maximum-batched work groups, 32 requirements, 116 product acceptance specifications, individual work orders, a source/issue ledger, and executable offline planning tools.

**What runs now:** packet validation, source-integrity checks, deterministic plan/replay, work-order presentation, bounded structural checks on builder returns, packet-integrity verification, and 56 local packet-tool tests.

**What does not run now:** the CCP jurisdiction engine, CHC proof verification, a UCM/GOORRT/UGK/THR/DKN integration, native P/PPI import, network collectors, OS enforcement, or any of the 116 product acceptance cases. No stage is marked completed. Nothing is installed, published, admitted, activated, or granted authority.

The exact P/PPI schema and accepted example were not recovered. This is an explicit portable program-definition packet for binding into that existing system, **not a claimed implementation of its syntax**. The offline planner is a temporary authoring/inspection aid, not a new universal pipeline kernel.

## Start here

- `PROGRAM.md`: complete construction program and batch strategy.
- `work_orders/BATCH_A_HANDOFF.md`: ready-to-use instruction for the agent with access to the existing P/PPI/UCM workspace.
- `program/PROGRAM.json`: machine-readable stage DAG.
- `program/ACCEPTANCE_CATALOG.json`: all 116 product cases, all `NOT_RUN`.
- `program/OPEN_ISSUES.json`: seven explicit unresolved integration/source issues.
- `contracts/NATIVE_BINDING_CONTRACT.md`: lossless native import obligations.
- `contracts/CHC_PROFILE.md`: source-backed CHC constraints and open interpretation issues.
- `evidence/`: actual packet-tool results and replay records, with narrow claim ceilings.

## Run the offline tools

Review the scripts before running this unadmitted candidate. Use Python 3.10 or later in a trusted, extracted workspace; no pip install is required. These commands are written for the package root and work as ordinary Python commands on supported platforms:

```text
python -B tools/programctl.py verify-package
python -B tools/programctl.py validate
python -B tools/programctl.py plan
python -B tools/programctl.py replay
python -B tools/programctl.py dispatch --batch A
python -B -m unittest discover -s tests -v
```

`dispatch` prints work orders; it does not execute them. `validate` validates this draft packet format; it does not admit the program to P/PPI. `check-return` verifies only its explicitly documented structural/custody conditions and always returns `may_advance: false`.

Use `-B` to prevent Python bytecode caches inside the closed-world packet. Send any new reports outside the packet, for example:

```text
python -B tools/run_court.py --out ../ccp-local-packet-results.json
python -B tools/programctl.py check-return ../stage-return.json --artifact-root ../candidate-output
```

Outputs use exit 0 for a completed tool operation, 2 for a typed refusal, and 1 for a tool fault. Exit 0 is never product admission. Inspect the result status, scope and `may_advance` fields.

## Exact source

`sources/CHC-paper.md` retains the retrieved paper bytes. The paper names CHC **Cryptographic Homological Compilation**. It separates state identity, typed semantic identity and freshness/admissibility. The earlier conversational expansion “Holomorphic” is not used here.

The source is pinned, not declared the latest or ratified release. Source identity is not source correctness. Its normative ambiguities and implementation obligations remain visible.

## Integrity and authenticity

`PACKAGE_MANIFEST.json` lists every package file except itself with exact byte count and SHA-256. The content root is a packet-only commitment. It is not a CHC state hash, a THR role, a signature, or authority evidence. The external ZIP checksum binds the complete transport including the manifest.

A self-contained digest verifies consistency against the supplied manifest; it does not authenticate its author or prove security. The trusted copy of a transport digest must come from an independently accepted channel under the recipient's policy.

## Immediate frontier

**Batch A: bind the actual P/PPI program system and controlling native interfaces; then freeze the UCM jurisdiction profile and CHC interpretation.** Native admission, hardware witnessing, independent review and pilot authorization remain later, separate gates.
