# Agent handoff — CCP-JM Batch A

Treat this as a proposed construction work order for the agent that has access to the owner's existing P/PPI/UCM workspace. Reading it grants no live-system authority.

## Objective

Convert this source-bound CCP program packet into a genuine program of the existing P/PPI system, then freeze the CCP jurisdiction metamodel and the CHC operational profile for subsequent maximum-batched construction.

## Execute within the authorized development workspace

1. Inspect this packet, verify its supplied custody manifest, and identify its narrow claim ceiling. Preserve it unchanged as a predecessor.
2. Locate the actual P/PPI program schema/interpreter and an accepted sample. Record exact paths, native identities, custody hashes, supported gates, effect envelopes and return rules. Do not invent the expansion of P/PPI, its syntax, API or native state labels.
3. Locate owner-selected UCM, GOORRT, UGK/THR, CHC and DKN interfaces. Record which are reused, which are merely modeled, and which remain missing. Do not contact live external endpoints or import unreviewed donor code merely to discover an interface.
4. Build the native CCP program representation from `program/PROGRAM.json`, preserving all 13 stages, six batches, 32 requirements and 116 case specifications, their dependencies, source pins, nonclaims and separate authority gates. Use the native validator and retain the exact findings.
5. Compare the translation semantically, including round-trip/coverage evidence. Unsupported fields produce typed blockers. Do not remove a requirement to achieve native acceptance.
6. Explicate the jurisdiction profile through UCM. Distinguish the state boundary, governing jurisdiction and enforced perimeter. Preserve the declared GOML/GSOL model and MCIR realization relationship or emit an explicit source-role conflict.
7. Resolve or retain the CHC binding/active-policy issue, exact canonical wire/proof profile, and CHC-to-THR role mapping. A proposed interpretation is not an approved source change.
8. Freeze the governing law/oracle set only through the existing authorized non-effectful process. Package all candidate outputs, receipts, gaps, nonclaims and the next construction frontier together.

## Batching

Complete all authorized, unblocked Batch A work in one consolidated attempt. Do not stop for conversational approval after each local inspection or test. Halt at a missing controlling artifact, unresolved normative rule, authority conflict or external-effect boundary. Continue independent work that does not depend on the blocker, but do not claim the blocked gate passed.

## Return

Return source inventory, native program binding, source-reconciliation ledger, native program artifact, UCM jurisdiction profile, GOORRT mapping, authority matrix and law/oracle lock status. Include exact source/native tool versions, actual invocations, per-case outcomes, created files and custody roots. Mark unperformed product/hardware/review work `NOT_RUN`.

**Ceiling:** construction candidate and verified native representation only. No source ratification by implication, program activation, kernel hook installation, public publication, local-stack modification or production authority.

**Successful next frontier:** Batch B, only after the actual native system's required dispositions accept the bindings and frozen model. A portable planner pass alone cannot unlock it.
