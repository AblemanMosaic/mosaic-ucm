# Product acceptance index

All cases in this index are **NOT_RUN**. The 56 executable packet-tool tests belong to a different court.

| Stage | Cases | Status |
|---|---:|---|
| S00 — Source custody and native program binding | 8 | NOT_RUN |
| S01 — Jurisdiction metamodel and law freeze | 8 | NOT_RUN |
| S02 — Canonical objects, dependency graphs and stack manifests | 10 | NOT_RUN |
| S03 — Jurisdiction and scoped authority evaluation | 8 | NOT_RUN |
| S04 — CHC point-of-use decision core | 20 | NOT_RUN |
| S05 — Curation, stack selection and portable publication | 8 | NOT_RUN |
| S06 — Local/LAN/Internet/P2P evidence acquisition | 10 | NOT_RUN |
| S07 — Point-of-use broker and observed-stack reconciliation | 10 | NOT_RUN |
| S08 — Integrated shadow qualification and frozen handoff | 8 | NOT_RUN |
| S09 — Real target and independent witness qualification | 6 | NOT_RUN |
| S10 — Consolidated independent review and repair | 6 | NOT_RUN |
| S11 — Scoped pilot authorization and reversible activation | 6 | NOT_RUN |
| S12 — Continuity, incidents and scoped requalification | 8 | NOT_RUN |

Total: **116 specified product cases**; **0 executed product cases**. Complete stimuli, expected outcomes and requirement mappings are in `program/ACCEPTANCE_CATALOG.json`.
