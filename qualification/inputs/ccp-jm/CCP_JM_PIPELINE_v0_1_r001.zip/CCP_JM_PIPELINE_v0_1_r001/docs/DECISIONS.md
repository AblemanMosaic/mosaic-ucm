# Construction decisions and unresolved boundaries

| Decision | Rationale | Status |
|---|---|---|
| Preserve the exact CHC paper as a source | Avoid building from the prior assistant's paraphrase | Implemented as custody, not source ratification |
| Use Homological, not earlier Holomorphic expansion | The retrieved paper explicitly names it | Corrected in this packet |
| Keep state jurisdiction distinct from governing jurisdiction | The paper defines both at different levels | Normative proposed type separation |
| Make P/PPI binding the first gate | Exact schema and accepted sample were not recovered | UNBOUND |
| Build a portable packet rather than invent native compatibility | Enables useful construction preparation without false claims | Implemented local planning aid |
| Separate construction from point-of-use execution | A program gate cannot become a runtime permit | Preserved in artifacts and tool output |
| Author the full system in six batches | Avoid repeated design turns and a perpetually partial vertical slice | 13 stage work orders authored |
| Leave all product cases NOT_RUN | No CCP product implementation was executed | 116 explicit case specifications |
| Retain CHC policy/root binding ambiguity | §5.1 and §§8–9 need an explicit operational interpretation | OPEN I03 |
| Reject native/authority promotion in this tool version | No controlling signatures or native verification interfaces are bound | Enforced by local packet checks |
| Keep filesystem and runtime trust assumptions explicit | A planning script is not an OS security boundary | Documented limitation |
| Carry narrow upstream/evidence claims | Reusing code or passing fixtures does not confer broader maturity | Required across every work order |
