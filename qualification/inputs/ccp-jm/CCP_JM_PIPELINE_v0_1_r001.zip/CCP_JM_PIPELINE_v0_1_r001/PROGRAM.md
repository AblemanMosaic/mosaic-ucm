# CCP Jurisdiction Metamodel and CHC Point-of-Use Curation Pipeline

## 1. Program charter

**Identifier:** `CCP-JM`  
**Revision:** `0.1.0-r001`  
**Date:** 2026-11-05  
**Posture:** proposed shadow construction program  
**Current authority effect:** `NONE`  
**Native P/PPI import:** `UNBOUND`

The objective is to construct a deterministic system that explicates, carries, validates and governs CCP jurisdictional relationships. It connects compact constitutional stack manifests, model/realization correspondence, scoped curatorial claims, point-of-use CHC evaluation, and storage-agnostic evidence exchange.

This is a construction program, not a declaration that CCP is implemented. It includes the complete intended system rather than narrowing the objective to a toy capability. The early executable tools inspect and validate the program definition; they do not substitute for its future product.

The existing P/PPI program system is the intended home. Because its exact schema/interpreter was not available, this packet uses an explicitly provisional portable format. Native binding is the first gate. The new planner must not be elevated into a replacement for the user's existing pipeline, constitutional kernel, or program registry.

## 2. Architectural obligations

UCM is the intended metamodel/explication integration point. GOORRT carries the user's declared GOML/GSOL model and MCIR realization correspondence. UGK/THR mechanisms must be reused through their exact native contracts. CHC supplies state/claim binding and policy-relative freshness/admissibility. DKN supplies the appropriate publication/discovery/evidence pathways. CCP specializes those capabilities for curation and local adoption.

These are intended integration roles. This packet makes no claim that their current release schemas, APIs or capabilities have been bound. Previous conversational descriptions are not substitutes for controlling artifacts. If the actual upstream role definitions differ, source reconciliation must resolve the conflict before implementation.

### Three jurisdiction-related types

1. **StateJurisdiction:** the deterministically described boundary whose state is fingerprinted. CHC §4.1 includes files, binaries, repositories, runtime states and manifest graphs.
2. **GovernanceJurisdiction:** the policy domain in which an authority predicate is evaluated. CHC §22 allows flat, hierarchical and overlapping domains.
3. **EnforcementPerimeter:** the concrete execution or file-access paths actually mediated by a qualified implementation. This is a CCP implementation concern, not proof supplied by a manifest.

Containment in a state graph does not imply authority. A governance claim does not prove OS mediation. A successful broker check does not establish that every alternative loader/open path is mediated.

### Three forms of completion

- **Program validity:** the pipeline description is well formed and source-bound.
- **Product qualification:** the implementation satisfies particular obligations under recorded test/proof/target conditions.
- **Operational authorization:** the competent authority permits exact effects in an exact jurisdiction.

Neither of the first two silently produces the third. A builder's reported result is evidence to examine, not its own acceptance certificate.

## 3. Construction pipeline and runtime pipeline

The construction pipeline takes governing sources and frozen requirements through implementation, evidence, review and separately authorized deployment.

The runtime pipeline takes a request to launch/open/use something, acquires policy-permitted evidence, evaluates the exact context, and performs only a separately authorized operation through a qualified adapter.

They must remain separate. Construction tests may simulate a runtime `ADMIT` while having no real authority effect. Passing a construction gate cannot produce an unscoped runtime permit.

The runtime specification is `contracts/RUNTIME_FLOW.json`. Its core distinction is between effectful collection and deterministic evaluation. Network replies, timestamps/epochs, policy/root/schema identities, revocation state and prior checkpoint heads enter as explicit frozen inputs. The core does not consult live ambient state during replay.

## 4. Program shape

The program has 13 stages grouped into six batches. Every stage has named prerequisites, required native bindings, planned output artifacts, a claim ceiling, acceptance-case references, an effect envelope, typed halts and an individual work order.

| Batch | Stages | Construction objective | Required boundary |
|---|---|---|---|
| A | S00–S01 | Source/native-program binding; jurisdiction model and law freeze | No invented native syntax; unresolved law blocks affected implementation |
| B | S02–S04 | Canonical objects; scoped authority; CHC decision core | Exact encodings/proof algorithms; no fixture-based security claims |
| C | S05–S07 | Curation; four evidence-source modes; launch/open/reconciliation adapters | Independent branches may run in parallel within their capabilities |
| D | S08 | Integrated shadow court and frozen candidate | Local fixture passes never become real witness or authority claims |
| E | S09–S10 | Physical/native witness legs; consolidated independent review and repair | Independent evidence and exact review subject; no activation |
| F | S11–S12 | Separately authorized pilot; continuity/recovery/requalification | Explicit local authorization and a recoverable effect boundary |

The DAG allows S05, S06 and S07 to proceed independently once their predecessors are qualified. S08 joins them. Batching is a scheduling convenience, not a waiver of dependencies or authority gates.

### S00 — Source custody and native program binding

Find the current P/PPI program schema, interpreter, accepted sample, execution/effect contract and review return conventions in the owner's authorized workspace. Pin their bytes before import. Obtain the controlling UCM, GOORRT, UGK/THR, CHC and DKN interfaces.

Produce a source inventory, native binding record and source reconciliation ledger. Translate this packet into native constructs, preserving every requirement, prerequisite, claim ceiling and effect restriction. Native validation and a lossless round-trip or equivalent semantic comparison are required. Unknown fields may not be discarded to make an import succeed.

**Current standing:** exact CHC reference bytes are retained; P/PPI and native runtime bindings remain unavailable. S00 has not passed.

### S01 — Jurisdiction metamodel and law freeze

Explicate actors, state jurisdictions, governing jurisdictions, claims, delegations, scopes, conflicts, witnesses, manifests, evidence, evaluation contexts, operations and receipts using the actual UCM profile mechanism. Map object/operation/realization roles through the selected GOORRT contract.

Define precedence only where an explicit rule authorizes it. Preserve legitimate disagreement across jurisdictions. Freeze the requirements, oracle interpretation and acceptance matrix. Preserve source ambiguities as issues for disposition rather than letting an implementation choice quietly decide them.

### S02 — Canonical objects and manifests

Implement the selected native canonical encoding, identifier and hash-domain rules. Keep packet transport hashes distinct from CHC/THR cryptographic roles. Define exact treatment of absence, numeric and string normalization, duplicate fields, schema versions and resource bounds.

Build manifests with separate construction, runtime, evidence and authority dependency relationships. A compact commitment is not evidence that referenced objects are available. Distinguish model-only, source-bearing, binary-bearing, post-hoc and fully qualified publication profiles.

### S03 — Jurisdiction and authority

Implement scope and operation-sensitive predicates, lawful delegation, validity intervals, root interpretation, revocation classes, and declared composition/conflict rules. Avoid universal precedence by organization size, key identity, curator reputation or signature count.

Support a person, an institution, a publisher, a curator and a witness participating in one evidence graph while retaining different powers. A recommendation is not a deployment authorization. A containment edge is not a delegation edge.

### S04 — CHC core

Implement the source-bound two-identity/freshness architecture using the selected normative profile. State hashing precedes semantic attachment; optional claims affect semantic binding according to their schema. Freshness is an evaluation over policy, roots, manifests, epochs, receipts and evidence.

Support the paper's five named freshness failures, four revocation classes, checkpoint continuity, authenticated genesis, constrained equal-checkpoint rechecks, strict/grace/emergency modes, and partial-verification risk envelopes. Policy evaluation is total within declared resource limits.

The proposed distinction between original binding context and current evaluation context must be resolved in the governing profile. Do not remove the policy/root fields included in the paper's Hm construction or silently rewrite historical identities to evade the question.

### S05 — Curation and publication

Implement typed endorsement, observation, qualification, adoption, revocation and comparison records. Keep semantic equivalence proposals distinguishable from admitted, scope-limited relations. Produce deterministic registry projections from frozen evidence and policy.

Support private inventories, selectively shared attestations and public catalogs. Retain conflicts, unresolved relations and model forks. Publication of hashes can be parsimonious without making material availability or complete assurance automatic.

### S06 — Evidence-source adapters

Implement local, LAN, Internet and P2P sources as adapters feeding the same evaluator interface. The source type is not a trust rank. A local manifest can be stale; a signed remote response can be out of scope; a large peer set can lack independence.

Collectors capture raw evidence, provenance and availability failures. Proof verifiers establish accepted predicates; no collector boolean such as `trusted: true` may become the proof. Bound redirects, destinations, response sizes, parsing, privacy and resource usage. Test network behavior in disposable environments before authorized remote participation.

### S07 — Point-of-use and drift

Begin with cooperative launch/file-open brokers in isolated environments, then qualify particular OS enforcement adapters. Bind the exact target, operation, subject, handler/interpreter, required dependencies and state/policy/checkpoint context. Handle replacement between check and use, mutable content during reads and active-content transitions.

The scope of a broker remains explicit. System-wide enforcement requires evidence of its actual interception perimeter and bypass resistance. Long-running processes, dynamic loads and continuing reads need separately defined recheck or lease behavior; launch approval is not an eternal permit.

### S08 — Integrated shadow qualification

Join the implementations, run the frozen cases and negative controls, exercise restart/concurrency/commit faults, compare deterministic outputs, and build one immutable review candidate. Preserve all failed attempts and the exact changes made to repair them.

Fixtures never become real keys or witnesses. The builder cannot increase a claim ceiling by accumulating test counts. A cryptographically intact implementation that violates the model must fail the appropriate behavioral gate.

### S09 — Native and independent witnesses

Run exact candidates on the required native targets with environment, commands, identities and recovery conditions recorded. Initially target the Windows x86-64 and ARM/Linux pathways named in the roadmap; additional devices become separate qualification profiles.

Keep emulated, virtualized and physical evidence distinct. Collect independent rebuild and custody evidence where required. Absence of a device or independent witness remains `NOT_RUN`/`BLOCKED`, not a simulated pass.

### S10 — Consolidated review

Submit the frozen integrated candidate and complete evidence once for broad independent review. Consolidate findings, construct a repair successor if necessary, and replay affected plus non-regression obligations. Do not hide earlier failures or overwrite the reviewed candidate.

Review acceptance applies to exact bytes and scope. It does not publish, register, deploy, activate or grant general trust to future successors.

### S11 — Pilot disposition

Present the qualified candidate, chosen stack, target, effect envelope, disclosure policy and recovery method for explicit local disposition. Only that disposition can authorize the bounded pilot. Keep a tested independently reachable recovery path.

No passing test suite authorizes a system-wide hook. No curator can force a successor merely because the network published it. Newer evidence can cause a warning or scoped refusal under the selected policy without silently replacing the user's chosen version.

### S12 — Continuity

Implement the admitted operating policy for drift, freshness, revocation, incident response, recovery, requalification and successor publication. Persist relevant checkpoint continuity and identify what a local-state rollback could defeat under the chosen trust assumptions.

Requalification follows the dependency/evidence/authority graph. A status change can invalidate admissibility without requiring binary mutation. A build change can require reconstruction without rewriting the governing law. Continual operation never implies global knowledge of unseen network events.

## 5. Stage state and evidence contracts

The current packet contains planned stage state only: `NOT_RUN`. The native runner's controlling state machine must be used after binding. This draft does not invent a native completed/admitted state or mutate any registry.

A native stage attempt must identify its exact program, law, input roots, candidate outputs, environment, effects, required cases, results and receipts. Distinguish at least:

- an implementation claim;
- a builder-reported result;
- a cryptographically checked evidence record;
- an independently witnessed observation;
- a scoped qualification disposition;
- a separate operational authority disposition.

The packet's `check-return` deliberately stops at structural and claimed-file-custody checking. It does not determine output completeness, verify execution of tests, authenticate witnesses, judge semantic correspondence or advance a gate. This makes it useful for preparing a native return without laundering a builder's assertion into accepted evidence.

Successful native progress requires the controlling verifier to check actual evidence against the frozen gate. Missing required cases or unknown outcomes must remain incomplete. Law/oracle changes create successor identities and invalidate the appropriate evidence; they are not ordinary code fixes.

## 6. Determinism contract

A decision is deterministic over a complete, explicit snapshot: target and operation, model/realization identities, schema registry, binding context, active policy/root context, verified evidence, manifest scope, anti-rollback head, authenticated epoch/checkpoint, and declared budgets.

Acquisition is not promised to be deterministic. Different networks, times and evidence sets can legitimately produce different snapshots and outcomes. Replay begins after the inputs have been captured and bound.

Likewise, two independent curators need not agree under different policies. Determinism means equal complete inputs and equal interpretation produce equal deterministic outputs. Cross-implementation parity is an additional qualification obligation. A same-process replay cannot establish it.

External effects are outside a pure evaluation function. Before effect, an adapter must preserve the verified object's identity and recheck versioned state/authority conditions at a defined point. The transaction protocol must specify what happens when an effect occurs but its acknowledgement or receipt is lost. No generic receipt ledger establishes exactly-once physical or network effects.

## 7. CHC-derived rules retained

The exact paper is retained in `sources/CHC-paper.md`, with source identity in `sources/SOURCE_LOCK.json`.

The construction program preserves the following boundaries from the paper: state hashing independent of semantic attachments; typed schema-governed semantic claims; policy-evaluable rather than self-authorizing evidence; freshness at point of use; explicit roots, policy and schema; checkpoint continuity; separate revocation classes; explicit grace/availability tradeoffs; and partial-verification risk handling.

The paper is a governing research reference, not evidence that the product already satisfies those rules. This packet does not adopt broad claims that recursive hashing alone eliminates malicious compiler behavior or makes an arbitrary claimed meaning true. It carries the underlying assumptions and requires scoped implementation evidence.

## 8. Acceptance and coverage

`program/REQUIREMENTS.json` contains 32 requirements. `program/ACCEPTANCE_CATALOG.json` contains 116 product acceptance specifications assigned to 13 gates. Each stage and each case references the requirements it addresses. The offline validator checks cross-reference closure and exact case ownership.

All 116 product cases are `NOT_RUN`. Their stimuli and expected outcomes define the construction target; they are not generated evidence.

The separate packet-tool court has 56 executable tests. It examines this packet's parser, graph validation, source integrity, refusal behavior, replay, work-order presentation, return-claim limits and closed-world manifests. Its result cannot be reported as a CCP product court result.

Required future measurements include false acceptances/refusals against independent oracles, decision replay divergence, revocation observation/action latency, cache/manifest bandwidth, startup/open overhead, dependency-impact precision, recovery success, required-service liveness, and actual effort to integrate an ordinary coding agent. Any performance budget must be selected explicitly and tested on its declared target; this packet invents no hardware performance results.

## 9. Batching and agent operation

The agent with access to the existing workspace should take one batch instruction and perform all authorized, unblocked work it contains. It should not ask for approval after every local fixture. It must stop at missing controlling material, unresolved law, conflicting authority, exhausted budgets or an effect outside its granted capability envelope.

Parallelize disjoint construction branches while keeping immutable shared inputs. Submit one integrated local candidate before requesting independent review. Introduce external custody and hardware through explicit witness work orders rather than simulated identities. A review repair is a successor with a preserved predecessor.

The initial agent instruction is `work_orders/BATCH_A_HANDOFF.md`. It begins with retrieval and native binding because exact P/PPI compatibility cannot honestly be inferred from an analogy.

## 10. Publication, privacy and recovery

Manifest publication, source publication and binary publication are distinct operations. Default personal inventory remains local. A curator can advocate for software it did not author, but its claim type and jurisdiction must say so. A mirror transports objects; it does not confer authority on them.

Storage independence requires authenticated identity plus actual retrievable objects. Checkpoints can make conflicting histories accountable within their scope; they cannot establish a globally current history under arbitrary partition. Peer count does not establish independence, and a hash-only manifest may still fingerprint a stack.

Recovery is a first-class deliverable. Keep separately reachable tools and authorization for repairing the freshness service, key state, manifest store, verifier and launch mechanism themselves. Do not make the new gate the sole route by which a broken gate can be repaired.

## 11. Current result and next frontier

This revision delivers the program definition, portable planning tools, acceptance specifications and scoped local tool evidence. It does not close S00, import into P/PPI, construct the product, witness hardware, or request production admission.

The immediate frontier is **Batch A**: exact native program binding, controlling-source reconciliation, and the UCM jurisdiction/law freeze. That converts this packet into an executable program of the existing system without silently creating a parallel constitution.
