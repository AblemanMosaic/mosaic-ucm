# Portable packet-tool format and limits

This is a draft local format, not P/PPI, UCM, CHC, THR or a general JSON Schema implementation.

`program/PROGRAM.json` declares the program and refers to source locks, bindings, requirements, the product acceptance catalog, runtime-flow specification and open issues. Each stage carries predecessors, requirement IDs, binding IDs, output contracts, its work-order path, gate cases, effect bounds and halt conditions. `tools/programctl.py` is the executable validator for the supported packet profile.

The supported JSON subset uses objects, arrays, Unicode-scalar strings, signed 64-bit integers, booleans and null. Duplicate keys, floats, nonfinite numbers, unpaired surrogates, excessive size/nesting and non-JSON types are refused by the parser. Limits: 4 MiB per JSON input, depth 64 and 100,000 visited JSON nodes. These are packet limits, not automatically the future product's limits.

Packet canonical bytes are ASCII JSON with sorted keys, escaped Unicode, compact separators, no trailing newline, and no implicit string normalization. Different Unicode sequences remain different values. File storage formatting may be indented; a file custody hash binds exact stored bytes, while a domain commitment binds the defined canonical value.

A packet-only domain digest is SHA-256 over the ASCII prefix `CCP-PROGRAM-DRAFT/v0.1/` plus the domain name, NUL, an unsigned eight-byte big-endian canonical-body length, then canonical-body bytes. It is not a claimed CHC or THR hash role.

Paths are relative POSIX-style paths within the specified root; empty components, dot/parent components, backslashes, colons, NULs and symlinks are refused for the supported local reads. Work only in a trusted, quiescent workspace. The inspection tools do not claim protection against concurrent hostile filesystem mutation, hardlink aliasing, a compromised Python runtime or a malicious local administrator. Those are future qualified execution/custody concerns.

The plan binds exact program inputs, source bytes, work orders, return contract and the planner's own source. Deterministic replay is established only for this implementation on the tested host. Independent implementations and native P/PPI compatibility remain separate gates.

`check-return` requires exact fields listed in `STAGE_RETURN_CONTRACT.json`, exact required case IDs and explicitly unverified builder reports. It can verify claimed local artifact hashes, but it cannot verify that the required product artifacts exist as complete outputs, that a test ran, that an oracle is sound or that an issuer has authority. A structurally valid return always has `may_advance: false`.

CLI exit 0 means the requested local tool operation completed. Exit 2 reports a typed refusal; exit 1 reports a tool fault. These codes are local tool conventions, not asserted native P/PPI conventions.
