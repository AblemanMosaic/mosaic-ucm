# CHC source profile for CCP-JM

## Source

`../sources/CHC-paper.md`, identified by `../sources/SOURCE_LOCK.json`. Section numbers below refer to the retained paper. It names CHC **Cryptographic Homological Compilation**. Source custody establishes exact bytes, not ratification, truth, or latest-version status.

## Source-derived obligations

| Source | Obligation carried into the program |
|---|---|
| §4.1 | State Jurisdiction is a deterministic boundary; Hs excludes semantic dimensions, manifests, policy, freshness and attestations. |
| §4.2 and §22 | State-boundary composition and the governing jurisdiction dimension are distinct; policy declares compatible composition or a conflict. |
| §§4.3–4.4,10–11 | Dimensions are typed, registry ordered, explicitly normalized, versioned and bound; duplicates/defaults are not silently accepted. |
| §§7–9 | Two identity hashes plus freshness evaluation; hash domains are separate. Hm binds Hs, dimension encoding and the declared policy/root context. |
| §§14–16 | Verify actual schema-specific evidence; identity, signatures and root membership do not independently authorize an effect. |
| §17 | Six canonical core dimensions and two canonical optional dimensions; extensions obey the same schema/evidence rules. |
| §§27–28 | Schema state and caches are freshness-bound; local, organizational, public and P2P sources feed policy-selected evidence. |
| §29 | Preserve STALE_STATE, STALE_SEMANTIC_ATTESTATION, STALE_REVOCATION_STATE, STALE_CHECKPOINT and POLICY_STALE. |
| §§30–31 | Proof-specific verification, checkpoint consistency, persistent maximum and restricted equal-checkpoint rechecks. |
| §32 | Strict/grace/emergency behavior is explicit; ordinary grace does not bypass known revocation. |
| §33 | Claim, dimension-value, signer-future-authority and trust-root revocations remain separate unless explicit cascade rules apply. |
| §§34–35 | Ordered typed manifest commitments; conflict/equivocation is scoped and legitimate different-context manifests coexist. |
| §§36–38 | Deterministic total policy, explicit partial verification risk, and scoped policy-enabled semantic equivalence only. |
| §40 | Selective disclosure does not imply absence of linkability. |
| §§41–43 | Clean build before semantic attachment; source/environment/dependency evidence; recursively declared toolchain boundary. |
| §§51,53 | Named failure modes and empirical evaluation are obligations, not existing success evidence. |

## Open interpretation: binding context and active evaluation context

Section 5.1 permits a policy change without mutating state or semantic identity. Sections 8–9 explicitly include H_P and H_R in H_m. These can potentially be reconciled by distinguishing the immutable policy/root context originally bound into a semantic object from the active policy/root context evaluating that historical object now, with an explicit transition rule. **That reconciliation is proposed, not silently adopted.**

The source-binding gate must select the exact governing interpretation and tests. Until then, native cross-context CHC interoperability remains blocked. Never delete the policy/root commitment from Hm, recompute it while claiming historical identity is unchanged, or accept old context under new law without an authorized rule.

## No invented CHC/THR wire compatibility

The packet tool uses its own simple draft JSON and hash-domain conventions for planning and package integrity. Those conventions are not CHC encodings, not THR hash-role mappings, and not proof verifiers. The future native binding must use the actual selected schemas and golden vectors.

The CHC paper's Two-Hash Rule does not by itself define the user's UGK/THR interfaces. Similar field names require explicit semantic comparison and role mapping.

## Runtime context

The future operation request must carry target/operation, Hs/Hm, dimensions, bound context, active context, schema state, exact manifest scope, raw/verified evidence references, prior checkpoint state, authenticated evaluation epoch and resource budget. The collector is an evidence producer; the evaluator validates it. Context changes before effect require the declared atomic/versioned recheck.

A fresh local manifest is only fresh relative to its admitted local context. An offline host does not discover unseen remote revocation. P2P consistency is not universal agreement or Sybil resistance by node count. These limits belong in policy and result records.
