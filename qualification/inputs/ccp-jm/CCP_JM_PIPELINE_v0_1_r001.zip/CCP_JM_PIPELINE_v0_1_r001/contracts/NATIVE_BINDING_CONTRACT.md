# Native P/PPI and constitutional-stack binding contract

**Status: UNBOUND.** This document specifies the work needed; it does not assert a native API.

## Required inputs

Obtain the exact native P/PPI schema, interpreter/runtime, accepted sample program, admission and execution-effect contract, stage-return schema, resumption/retry model, and evidence/claim rules. Pin every controlling artifact by its native identity and raw custody digest. Do not expand P/PPI or rename its mechanisms from memory.

Bind owner-selected UCM, GOORRT, UGK/THR, CHC and DKN artifacts separately. A previous implementation's maturity or admission does not automatically transfer to the new composition.

## Required mappings

The native translation must carry: program identity and revisions; source pins; requirements; stage dependencies; batch presentation; required input/output artifacts; acceptance/oracle references; effect/capability envelopes; authority and claim ceilings; blockers; retries; independent review; pilot authorization; and continuity/requalification routes.

The distinction between StateJurisdiction, GovernanceJurisdiction and EnforcementPerimeter must survive. CHC source semantics and the user's GOML/GSOL/MCIR mapping must survive or produce an explicit schema-role conflict requiring disposition.

## Translation evidence

Use the native importer/validator. Retain original portable packet, native representation, mapping version, interpreter identity, findings, and a semantic round-trip comparison or equivalent conformance witness. Unknown fields and unsupported native constructs produce blockers; they cannot be dropped, approximated or broadened automatically.

The portable packet's hash is a custody link, not a replacement for native program identity. Its `PASS_STRUCTURE_ONLY` result cannot be imported as native admission.

## Reuse rule

Once bound, use the existing native scheduler, journal, verifier, authority and return mechanisms. Keep the packet planner only as a demonstrably compatible inspection/authoring aid or retire it. Do not maintain two subtly different jurisdiction kernels or two competing admission state machines.

## Completion

The binding is established only when the exact native system accepts the representation at its appropriate non-effectful stage and the trace/mapping obligations are verified. Actual program admission, activation and product deployment remain separate dispositions under the native rules.
