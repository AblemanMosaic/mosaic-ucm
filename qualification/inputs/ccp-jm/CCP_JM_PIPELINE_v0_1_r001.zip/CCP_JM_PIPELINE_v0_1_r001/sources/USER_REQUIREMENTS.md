# User requirements retained from the conversation

This is a concise requirements summary, not a verbatim transcript and not an authority grant.

- Build the CCP jurisdiction effort as a pipeline program like P/PPI.
- Use UCM and the existing constitutional stack rather than creating a competing universal kernel.
- Preserve the current user mapping: GOML and GSOL are model representations; MCIR is computational realization in the GOORRT account. Any differing upstream schema must be reconciled explicitly.
- Explicate, carry, validate, compose, and govern jurisdictional relationships for curators, contributors, institutions, witnesses, publishers, and local adopters.
- Keep state boundaries, claims, endorsements, qualification, and execution authority distinguishable.
- CHC supplies point-of-use freshness/admissibility for running programs and opening files. Include local manifests, LAN servers, Internet servers, and P2P sources.
- Allow compact model/stack manifests that reference realizations and evidence; source and binary publication are optional publication choices, not proof that dependencies are available.
- Permit legitimate centralized administration within a jurisdiction and decentralized publication, evidence exchange, and independent local adoption outside it.
- Preserve version sovereignty, explicit drift/freshness findings, source transparency requirements, privacy, and storage-agnostic DKN publication.
- Build and test in maximally batched shadow mode before introducing independently controlled identities, external effects, target hardware, and a consolidated independent review.
- No wording in this packet grants production authority, changes a live stack, installs a hook, publishes to DKN, or admits a native program.
