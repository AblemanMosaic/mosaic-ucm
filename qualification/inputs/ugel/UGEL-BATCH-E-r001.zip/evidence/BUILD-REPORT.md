# UGEL Batch E r001 — bounded delivery report

## Delivered

- Immutable predecessor: exact UGEL Batch D r001 ZIP, and its byte-matching extracted source tree.
- Host-side component-call policy, verifier and adapter to unchanged D EffectSession and Batch A Effect IR.
- WIT interface declaration for `governed-guest` and explicit unbound WASI runtime.
- Standard-library independent structural export verifier and standalone package verifier.
- Optional local Ed25519 witness statement, explicit untrusted local time, optional regime root.
- Ordinary tests of policy boundaries, one actual mediated `sim.add` effect, independently checked D structural custody, D original semantic replay, and local signature verification.

## Actually executed

- 20/20 Batch E unit/integration tests on prepared Linux Python 3.13.5.
- 20/20 of the same tests from a clean source copy.
- One ordinary mediated Batch D `sim.add` request, with D replay and E independent structural verification.
- One local signed witness demo with ephemeral private key, verified against its public key.

## Not executed or not qualified

- Rust compilation, Rust unit tests or runtime conformance: NOT_RUN (toolchain missing).
- Wasmtime/WASI guest installation or execution: NOT_RUN (runtime unavailable).
- Host enforcement of WASI imports: NOT_ESTABLISHED. Guest-shaped JSON cannot prove actual guest isolation.
- Independent full semantic verifier: NOT_IMPLEMENTED. The independent checker validates custody and cross-links only; original D replayer supplies D semantics.
- External timestamping, ZKP, remote attestation, legally recognized notarization, production signatures: NOT_ESTABLISHED.
- Batch A-D complete suites: NOT_RERUN in this batch. Previous recorded results retain their original scoped meanings.
- Adversarial, denied-operation, forced-interruption, containment escape and cross-host tests: NOT_RUN.

## Standing

INFORMATION_ONLY; authority effect NONE; real A5 false; G0 CLOSED; native UGK binding NOT_BOUND.
