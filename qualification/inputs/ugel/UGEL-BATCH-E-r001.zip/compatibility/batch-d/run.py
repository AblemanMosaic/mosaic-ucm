"""Source-checkout entry point; no installation or implicit package download."""
import sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'compatibility/batch-c/src'),str(ROOT/'compatibility/batch-c/compatibility/batch-b/src')]
from ugel_native.cli import main
if __name__=='__main__':raise SystemExit(main())
