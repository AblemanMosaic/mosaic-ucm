"""Integer-cent invoice helper with one intentionally documented repair target."""
def total_cents(lines, discount_cents=0):
    if type(discount_cents) is not int or discount_cents < 0:
        raise ValueError('discount must be nonnegative integer cents')
    for unit_cents, quantity in lines:
        if type(unit_cents) is not int or type(quantity) is not int or unit_cents < 0 or quantity < 0:
            raise ValueError('invalid line')
    subtotal = sum(unit_cents for unit_cents, quantity in lines)
    return max(0, subtotal - discount_cents)
