# Batch B architecture

## A cooperative Python layer, not an interpreter modification

The host accepts a rooted task plan: actual source manifest and full source text,
exact candidate manifest and text, trusted test identities, allowed changed paths,
and explicit bounded objective. Source/candidate contents can be checked without
importing either project. The host supplies resource directories, time, local
pins, interpreter and a one-run trusted execution grant.

`TaskSession` owns two independent ledgers:

1. **Batch A file-effect ledger.** The original `Broker`, effect registry, gates,
   observations, receipts and replay are reused unchanged. It mediates exact
   original-source reads and exclusive creation/readback of the candidate.
   Separate grants permit source reads only and candidate read/create only.
2. **Batch B task ledger.** It binds materialization to the A receipts, reserves
   one test dispatch, records the test observation, and derives the final task
   receipt. It uses its own schema and does not introduce a hidden fifth Batch A
   effect or reinterpret Batch A observations.

The context root includes real project/candidate manifests, actual engine file
hashes, interpreter path/hash/version, checker hash, both grants, and host resource
bindings. This prevents a fixture label from standing in for the project identity.
It does not supply an authenticated real-world issuer.

## Predictable path

```
Accepted plan + host pins
  -> explicit task/custody initialization
  -> A: read exact source / create candidate / read exact candidate
  -> B: MATERIALIZED (verified A prefix and exact manifests)
  -> B: CHECK_STARTED (one exact, currently permitted test request)
  -> trusted child Python interpreter (-I -S -B, no shell)
  -> B: CHECK_OBSERVED (child record, return code, post-run manifests)
  -> B: CHECK_FINALIZED (shared deterministic derivation)
```

Every new effect is preceded by its respective durable dispatch record. Admission
is not an observation that execution happened. A lost acknowledgment is not a
reason to repeat a child process. Materialization's individual operations resume
only through Batch A's existing lifecycle rules. A terminal file receipt is not
re-executed just to recover its response.

Task-journal mutation uses SQLite transactions and expected heads. There is no
atomic transaction spanning the two databases, child process, and filesystem.
Completion is split deliberately so `CHECK_OBSERVED` can be finalized from a fresh
process. No generic process reconciliation is claimed for `CHECK_STARTED`.

## Python API

`FileCapability` carries a fixed resource, grant, effect subset and name subset.
`restrict()` can narrow but not enlarge these fields. The actual Batch A grant
still controls effect admission. Handles and decorators are cooperative APIs,
not secrets or a Python security boundary. Code with arbitrary host access can
bypass them; Batch C must provide host containment for stronger claims.

`@governed_task(requires=(...))` checks SDK availability and current heads before
entering the task. Actual time-sensitive grant checks occur at dispatch. It does
not inspect Python function bodies or prevent use of ambient APIs.

`current_task()` is a read-only deterministic projection of accepted context and
replayed records, supplemented by current on-disk manifest observations. It gives
an explicit next action and never treats a historical test result as applicable
to different current bytes.

## Trusted child boundary

The fixed checker discovers the actual unittest set, compares it with the accepted
AST-derived set, runs it, and records all outcomes. The parent verifies the record
shape/root/request link and independently derives completeness and pass conditions.
It also compares original and candidate manifests after execution. Passing tests
have a bounded empirical meaning, not a theorem about the implementation.

The candidate and tests run with the same OS user's ambient permissions. There is
no claim that they cannot tamper with custody, forge an output record, read other
files or access the network. The accepted trust model excludes such behavior.
Interpreter isolation flags are not a sandbox. A production agent integration
must not pass untrusted generated code into this reference execution profile.

## Effect accounting

Initialization creates local directories, JSON context and two SQLite databases.
File operations carry A receipts. Test execution can cause local process and
filesystem effects; its observation explicitly says so. Exceptional paths do not
translate lack of an acknowledgment into `effect_scope: NONE`.

Export is plaintext disclosure of full source and grants. Archive verification is
record/custody verification only. All constitutional ceilings remain closed.
