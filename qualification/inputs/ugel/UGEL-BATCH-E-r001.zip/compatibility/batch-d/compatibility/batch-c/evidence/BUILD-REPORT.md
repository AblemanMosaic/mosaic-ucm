# UGEL Batch C r001 — build report

## Disposition

Built as an additive local host reference. The exact final source passed the
ordinary 45-test C suite and all 73 unchanged Batch B tests, then passed both suites
again from a clean source-only archive extraction. This is 118 distinct identities,
not 236 distinct tests and not independent or adversarial qualification.

## Final identities

- Source root: `c9fce8ed78cad8d42fd29909250cea8e4a2ea6fc517eded21dbbf90636054530`
- Source files: 125; logical source bytes: 1666461.
- Reference-check root: `e10e308ec0b6eaa3f7ede32229ca139efcf3b0a237903358f635ebb4aaca1d99`.
- Frozen Batch B archive: `dd18f578332d7f45341a3f2e0801f0ea839c12369d78134addb50fe47cdb3edc`.
- All 86 carried Batch B members remain byte-identical. Its original Batch A archive remains intact.
- The final transport identity and two-build equality are recorded in the external receipt,
  avoiding a self-referential archive-hash claim inside the archive.

## Delivered

1. One explicit Linux x86_64 memory-only Python host policy, using a default-deny
   seccomp filter, no_new_privs, capability/credential reduction, resource bounds,
   controlled descriptor inheritance and a parent-observed kernel entry witness.
2. Real Ed25519 local issuer/observer keys, exact signed one-attempt grants,
   current epoch/revocation checks at admission and signed candidate-entry authorization.
3. Integration with the exact Batch B accepted materialization, preserving source,
   candidate, test, context, and head identities. No retroactive upgrade of B receipts.
4. Signed process observations and journal events, shared terminal derivation,
   explicit expected heads, durable cancellation, no blind redispatch, and
   separately authorized observation/finalization recovery.
5. Directly composable CLI export and permit output, Python interfaces, explicit
   capability/effect descriptions, support contracts, and a passive package verifier.

## Executed results

| Check | Result |
|---|---|
| Final C suite | 45/45 PASS |
| Exact inherited B suite | 73/73 PASS |
| Clean-extracted C suite | 45/45 PASS |
| Clean-extracted inherited B suite | 73/73 PASS |
| Failures/errors/skips in the final complete lanes | Zero |
| Source before/after both lanes | Unchanged |
| Check records between both lanes | Byte-identical |
| Baseline invoice under the installed profile | 6 tests, 2 expected regression failures |
| Repaired invoice under the installed profile | 6/6 PASS |
| Parent witness before candidate GO | Seccomp 2; NoNewPrivs 1; zero capabilities; UID/GID 65534 on this host |
| Finalization in a different interpreter | PASS without process redispatch |
| Signed bundle replay | PASS with explicitly supplied issuer/observer/context/head pins |

The demonstration proposal is Batch B's prewritten repair. No LLM or external AI
provider was called. The original source and trusted tests remain unchanged. The
published demonstration contains only public keys and signed/public records; its
temporary private keys were removed after use.

## Host

- Linux-6.18.57-x86_64-with-glibc2.41
- CPython 3.13.5 (main, Jul 15 2026, 20:25:40) [GCC 14.2.0]
- cryptography 46.0.4; libseccomp 2.6.0; SQLite 3.46.1
- Parent UID 0; restricted children ran unprivileged.
- Landlock was unavailable; it is not part of the chosen profile.

## Boundaries

The positive runs establish that the kernel accepted the configured filter and that
the supported ordinary workloads ran inside it. No prohibited-effect attempts,
container/host escapes, network probing, forced crashes, power loss, resource stress,
or adversarial review was performed. Kernel/host-admin and side-channel threats
remain outside this reference's established assurance.

The unittest oracle shares Python state with the candidate. A malicious candidate
could falsify its functional report. This batch limits the candidate's host effects;
it does not prove hostile code correct or make the in-process test oracle independent.

The signatures authenticate records under local owner-pinned keys. Issuer legal
identity, hardware custody, remote witnesses, secure remote heads, trusted timestamping
and anti-rollback against an administrator remain unbound. There is no automatic
revocation of a computation after its signed entry decision. Its CPU/wall budgets
remain in force. Source and runtime administrative owners remain trusted.

Recovery from a normal persisted observation is implemented and demonstrated.
DISPATCH_INTENT/ADMITTED without an observation remain unresolved. Their tests use
authored model states, not induced interruptions. The authority and host stores
are not a single global transaction. No uncertainty is converted to nonexecution.

Windows, Python 3.12, other architectures, native UGK/AOK integration, the private
agent harness, C/Rust adapters, and WASI are not qualified by this build.

## Development transparency

`DEVELOPMENT-NOTES.json` and the preserved development record document preliminary
issues and corrections. The first CLI round-trip test correctly refused a permit
issued later than its fixed fixture clock; the fixture clock was aligned without
weakening production validation. Those earlier subjects are not credited toward
the final result. No original A/B artifact was modified.

## Standing

INFORMATION_ONLY; constitutional authority effect NONE; real A5 false; G0 CLOSED.
Physical local files, custody, signatures, processes and pipe effects are separately
recorded. This report is a builder result; independent review remains open.
