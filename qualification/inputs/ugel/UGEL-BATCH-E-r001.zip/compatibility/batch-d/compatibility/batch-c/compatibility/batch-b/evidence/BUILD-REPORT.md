# UGEL Batch B r001 — build report

## Delivered scope

A cooperative Python SDK and controlled task harness over the exact UGEL Batch A
r001 file broker. Actual source/candidate identities replace the fixture subject
at the integration layer. Trusted unittest execution has a separate, explicit
Batch B one-run grant and durable dispatch/observation/finalization path.

Source root:
`a867250f7eb8289754babfb0b0b342809ca996d15ffd02705d4b864f2217cb52`

Ordinary reference-check root:
`7fc77f343e4e982754e0a5f96bba06f457936a41d10cb3709f9f37c3115e3828`

## Actual results

| Observation | Result |
|---|---|
| Distinct ordinary reference tests | 73 |
| Inherited Batch A tests | 38, unchanged |
| New Python/distribution tests | 35 |
| Primary complete suite | 73/73 PASS |
| Clean-extraction complete suite | 73/73 PASS |
| Failure/error/skip/expected-failure/unexpected-success counters | Zero in both complete runs |
| Source before/after both runs | Identical |
| Deterministic check result across runs | Byte-identical |
| Candidate code executed | The exact accepted local invoice candidate and six pinned tests |
| Baseline observation | 6 tests, 2 failures, no errors/skips |
| Accepted repaired candidate | 6/6 pass, no errors/skips |
| Original project | Unchanged |
| Separate-process terminal finalization | PASS, no test redispatch |
| Portable task-bundle semantic replay | PASS, using explicit host pins |
| Frozen Batch A engine, tests and required descriptors | 15 inherited files byte-identical |
| Frozen original Batch A ZIP | Unchanged |

Actual host: CPython 3.13.5, Linux x86_64, SQLite 3.46.1. The precise host record is
`HOST.json`. No Windows, Python 3.12, C/Rust, WASI or native UGK execution was run.

These are 73 unique tests executed twice on one host, not 146 different tests and
not independent acceptance. The clean extraction uses a staged archive carrying
the same final source; the later reproduction records do not modify that source.
The archive producer performs two byte-identical serializations of the same
frozen inputs. It does not claim two independently reproduced host observations.

## Demonstrated integration

Each task materializes a two-file project through six Batch A operations, creating
24 file-ledger events. Four B events bind materialization, reserve the test run,
record its observation and finalize the receipt. The repaired demo pauses at the
normal `CHECK_OBSERVED` boundary, then another Python process finalizes it.

The baseline-to-repair proposal is prewritten and explicit. No LLM or private
coding harness generated it. The Python and CLI APIs accept such proposals from
an external agent, subject to host acceptance. No automatic installation into the
original project, publication, release or policy relaxation occurs.

## Development observations retained

`DEVELOPMENT-NOTES.json` records an early helper-parameter collision and an early
CLI-test fixture clock mismatch. Both were corrected before the source-bound
73-test qualification. Those unpinned development trials are not relabeled as
final-source evidence.

## Outstanding boundaries

No adversarial testing, malformed-evidence attacks, fault injection, crash or
power-loss testing, independent review, native identity ceremony, OS containment,
or actual external application/harness integration was performed. Model-state
pending fixtures are explicitly authored states. The child runs trusted code
with ambient OS permissions. Full library/OS closure is not hashed. Host records
are unsigned; a pinned record is not an authenticated real-world grant.

`CHECK_STARTED` remains uncertain without a persisted observation and is never
blindly retried. New execution after expiration needs an explicit successor
configuration; no renewal service is implemented. Arbitrary nested repositories,
dynamic test inventories, external dependencies, and hostile code are unsupported.

## Delivery verification

The external archive build receipt and passive verification result accompany the
ZIP. The verifier checks custody, full source, actual test identities, result
counters, repeatability-record equality, and inherited-byte preservation. It does
not execute candidate code or independently witness the recorded process effects.

Standing remains INFORMATION_ONLY; authority effect NONE; real A5 false; G0 CLOSED.
Real local custody/filesystem/process effects are described separately.
