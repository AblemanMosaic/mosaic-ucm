"""Common production/replay derivations. Signature validity is not proof of truth."""
from __future__ import annotations
from .common import *
from .policy import policy
from .trust import verify_signed,validate_grant
from ugel_python.model import validate_plan,tree_from_texts,test_ids
from ugel_python.semantics import verify_task_bundle,replay_task

REQUEST_FIELDS={'operation_id','batch_b_context_root','batch_b_task_head','batch_b_effects_head','plan_root',
 'source_root','candidate_root','candidate_texts','test_ids','policy','host','child_sha256','engine_root'}
CONTEXT_FIELDS={'request','batch_b_bundle','grant','issuer_public','observer_public','created_at','disclosure'}

def make_request(b_bundle,pins,operation_id,host,child_sha256,engine_root):
    checked_b=verify_task_bundle(b_bundle,expected_context_root=pins['context_root'],expected_task_head=pins['task_head'],expected_effects_head=pins['effects_head'])
    require(checked_b['task_state']=='MATERIALIZED','B_MATERIALIZED_UNEXECUTED_TASK_REQUIRED')
    p=b_bundle['context']['plan'];validate_plan(p,p['root']);identifier(operation_id)
    return record('execution-request',operation_id=operation_id,batch_b_context_root=pins['context_root'],
        batch_b_task_head=pins['task_head'],batch_b_effects_head=pins['effects_head'],plan_root=p['root'],
        source_root=p['source_manifest']['root'],candidate_root=p['candidate_manifest']['root'],
        candidate_texts=p['candidate_texts'],test_ids=p['test_ids'],policy=policy(),host=host,
        child_sha256=hash_value(child_sha256),engine_root=hash_value(engine_root))

def validate_context(c,expected_root):
    c=check(c,'context',CONTEXT_FIELDS);require(c['root']==hash_value(expected_root),'CONTEXT_PIN')
    q=check(c['request'],'execution-request',REQUEST_FIELDS)
    pins={'context_root':q['batch_b_context_root'],'task_head':q['batch_b_task_head'],'effects_head':q['batch_b_effects_head']}
    require(q==make_request(c['batch_b_bundle'],pins,q['operation_id'],q['host'],q['child_sha256'],q['engine_root']),'REQUEST_NOT_REDERIVED')
    check(q['host'],'host-identity');require(q['host']['policy_root']==q['policy']['root'] and q['host']['engine_root']==q['engine_root'],'HOST_REQUEST_BINDING')
    require(c['issuer_public']['role']=='LOCAL_ISSUER' and c['observer_public']['role']=='HOST_OBSERVER','KEY_ROLE_BINDING')
    g=validate_grant(c['grant'],c['issuer_public'],c['issuer_public']['root'],q['root'],c['observer_public']['root'],c['created_at'])
    require(g['operation_id']==q['operation_id'],'OPERATION_GRANT_BINDING')
    require(c['disclosure']=='FULL_SOURCE_AND_PUBLIC_SIGNED_RECORDS_NO_PRIVATE_KEYS','DISCLOSURE_SCOPE')
    return c

ADMISSION_FIELDS={'grant_root','request_root','observer_root','at','decision','authority_epoch','authority_sequence'}

def validate_admission(c,a,kind='admission'):
    body=verify_signed(a,c['issuer_public'],c['issuer_public']['root'],kind);exact(body,ADMISSION_FIELDS)
    q=c['request'];g=validate_grant(c['grant'],c['issuer_public'],c['issuer_public']['root'],q['root'],c['observer_public']['root'],body['at'])
    require(body['grant_root']==c['grant']['root'] and body['authority_epoch']==g['epoch'],'ADMISSION_BINDING')
    require(body['request_root']==q['root'] and body['observer_root']==c['observer_public']['root'],'ADMISSION_SUBJECT')
    decision='AUTHORIZED_ONE_LAUNCH_ATTEMPT' if kind=='admission' else 'ALLOW_ENTER_FIXED_CANDIDATE'
    require(body['decision']==decision,'ADMISSION_DECISION');integer(body['authority_sequence'],1)
    return body

OBS_FIELDS={'request_root','admission_root','entry_authorization','started_at','finished_at','returncode','stdout_hex','stderr_hex',
 'stop_reason','parent_witness','ready_frame','child_result','source_after_root','candidate_after_root','observation_kind'}

def _child_status(result,q,returncode):
    if result is None:return 'NO_ACCEPTED_CHILD_REPORT'
    if result.get('schema')=='mosaic.ugel.batch-c.child-error.v1':
        check(result,'child-error',{'request_root','status','error','detail'})
        require(result['request_root']==q['root'] and result['status']=='CHECK_ERROR','CHILD_ERROR_BINDING')
        return 'CHECK_ERROR'
    c=check(result,'child-result',{'request_root','status','test_ids','started_ids','rows','tests_run','failures','errors','skips','expected_failures','unexpected_successes','subtest_failures','log'})
    require(c['request_root']==q['root'],'CHILD_SUBJECT')
    for k in ['tests_run','failures','errors','skips','expected_failures','unexpected_successes']:integer(c[k])
    require(type(c['log']) is str and len(c['log'])<=210000,'CHILD_LOG_BOUND')
    require(type(c['rows']) is list and type(c['subtest_failures']) is list,'CHILD_ROWS')
    for row in c['rows']:
        exact(row,{'id','status'});require(type(row['id']) is str and row['status'] in {'PASS','FAIL','ERROR','SKIP','EXPECTED_FAILURE','UNEXPECTED_SUCCESS'},'CHILD_ROW')
    inventory=c['test_ids']==q['test_ids'] and c['started_ids']==q['test_ids'] and sorted(r['id'] for r in c['rows'])==q['test_ids'] and c['tests_run']==len(q['test_ids'])
    counters_zero=all(c[k]==0 for k in ['failures','errors','skips','expected_failures','unexpected_successes'])
    good=inventory and counters_zero and not c['subtest_failures'] and all(r['status']=='PASS' for r in c['rows'])
    require(c['status'] in {'PASS','FAIL','INVENTORY_MISMATCH'} and (c['status']=='PASS')==good,'CHILD_OUTCOME_NOT_REDERIVED')
    for key,label in [('failures','FAIL'),('errors','ERROR'),('skips','SKIP'),('expected_failures','EXPECTED_FAILURE'),('unexpected_successes','UNEXPECTED_SUCCESS')]:
        require(c[key]>=sum(r['status']==label for r in c['rows']),'CHILD_COUNTER_INCONSISTENT')
    return 'TRUSTED_CODE_REPORT_PASS' if good and returncode==0 else 'DECLARED_TESTS_NOT_ALL_PASSED'

def derive_receipt(c,admission,signed_observation):
    validate_admission(c,admission);q=c['request']
    o=verify_signed(signed_observation,c['observer_public'],c['observer_public']['root'],'observation');exact(o,OBS_FIELDS)
    require(o['request_root']==q['root'] and o['admission_root']==admission['root'],'OBSERVATION_BINDING')
    require(o['observation_kind']=='LOCAL_SUPERVISOR_NOT_HARDWARE_ATTESTATION','OBSERVATION_SCOPE')
    integer(o['started_at']);integer(o['finished_at']);require(o['finished_at']>=o['started_at'],'OBSERVATION_TIME_ORDER')
    require(o['returncode'] is None or type(o['returncode']) is int,'EXIT_CODE')
    require(o['stop_reason'] is None or type(o['stop_reason']) is str,'STOP_REASON')
    out=bytes.fromhex(o['stdout_hex']);err=bytes.fromhex(o['stderr_hex'])
    require(len(out)+len(err)<=q['policy']['max_output_bytes'],'OUTPUT_BOUND')
    ready=o['ready_frame'];w=o['parent_witness'];entry=o['entry_authorization'];entered=False
    if entry is not None:
        e=validate_admission(c,entry,'entry-authorized')
        require(e['authority_sequence']>admission['body']['authority_sequence'] and e['at']>=admission['body']['at'],'ENTRY_SEQUENCE')
        require(type(ready) is dict and ready.get('kind')=='READY' and ready.get('request_root')==q['root'] and ready.get('policy_root')==q['policy']['root'],'READY_BINDING')
        require(ready.get('candidate_started') is False and ready.get('seccomp_mode')==2 and ready.get('no_new_privs')==1,'READY_STATE')
        hash_value(ready['filter_bpf_sha256'])
        require(type(w) is dict and w.get('Seccomp')=='2' and w.get('NoNewPrivs')=='1' and int(w.get('CapEff','1'),16)==0 and w.get('Threads')=='1','HOST_FILTER_WITNESS')
        require(int(w['Uid'].split()[1])==ready['uid'] and ready['uid']!=0,'CHILD_CREDENTIALS')
        entered=True
    # Exact output frames support the carried child-result fields. Logs are untrusted.
    try:frames=[load_bytes(line) for line in out.splitlines() if line]
    except (Refusal,ValueError):frames=[]
    if ready is not None:require(frames and frames[0]==ready,'READY_FRAME_BYTES')
    result_frames=[f for f in frames if type(f) is dict and f.get('kind')=='RESULT']
    if o['child_result'] is not None:
        require(len(frames)==2 and len(result_frames)==1 and result_frames[0].get('request_root')==q['root'] and result_frames[0].get('result')==o['child_result'],'RESULT_FRAME_BYTES')
        require(entered,'RESULT_WITHOUT_AUTHORIZED_ENTRY')
    report=_child_status(o['child_result'],q,o['returncode'])
    source_same=o['source_after_root']==q['source_root'];candidate_same=o['candidate_after_root']==q['candidate_root']
    if not entered:status='HOST_ENTRY_NOT_COMPLETED'
    elif o['returncode'] is None or o['stop_reason'] is not None or o['child_result'] is None:status='RECONCILIATION_REQUIRED'
    elif not source_same or not candidate_same:status='SUBJECT_CHANGED_HOLD'
    elif report=='TRUSTED_CODE_REPORT_PASS':status='CHECKED_NOT_RELEASED'
    else:status='CHECK_FAILED'
    return record('receipt',request_root=q['root'],plan_root=q['plan_root'],source_root=q['source_root'],candidate_root=q['candidate_root'],
        grant_root=c['grant']['root'],admission_root=admission['root'],observation_root=signed_observation['root'],
        host_policy_root=q['policy']['root'],host_identity_root=q['host']['root'],test_ids=q['test_ids'],status=status,
        entry_observed=entered,source_unchanged=source_same,candidate_unchanged=candidate_same,test_outcome=report,
        physical_effects='LOCAL_PROCESS_PIPES_HOST_CUSTODY',candidate_path_effects='DENIED_BY_DECLARED_KERNEL_FILTER' if entered else 'NOT_ENTERED',
        observation_authentication='ED25519_LOCAL_OBSERVER_PIN',test_oracle='TRUSTED_CODE_SAME_INTERPRETER',
        no_automatic_redispatch=True,release_authorized=False,native_ugk_binding='NOT_BOUND',
        remaining=['INDEPENDENT_CONTAINMENT_REVIEW','ADVERSARIAL_HOST_QUALIFICATION','NATIVE_UGK_BINDING','REAL_IDENTITY_OR_HSM','RELEASE_AUTHORIZATION'],**BOUNDARY)

def replay(context,events,*,expected_context_root,expected_head,issuer_root,observer_root):
    c=validate_context(context,expected_context_root)
    require(c['issuer_public']['root']==hash_value(issuer_root) and c['observer_public']['root']==hash_value(observer_root),'EXTERNAL_KEY_PINS')
    head=ZERO;phase='PREPARED';admission=None;observation=None;receipt=None
    require(type(events) is list and len(events)<=12,'EVENT_BOUND')
    for seq,signed in enumerate(events,1):
        e=verify_signed(signed,c['observer_public'],observer_root,'journal-event')
        exact(e,{'sequence','previous','context_root','kind','data'})
        require(e['sequence']==seq and e['previous']==head and e['context_root']==c['root'],'JOURNAL_CHAIN')
        k=e['kind'];data=e['data']
        if k=='DISPATCH_INTENT':
            require(phase=='PREPARED','STATE_TRANSITION');exact(data,{'request_root'});require(data['request_root']==c['request']['root'],'INTENT_SUBJECT');phase=k
        elif k=='ADMITTED':
            require(phase=='DISPATCH_INTENT','STATE_TRANSITION');exact(data,{'admission'});admission=data['admission'];validate_admission(c,admission);phase=k
        elif k=='OBSERVED':
            require(phase=='ADMITTED','STATE_TRANSITION');exact(data,{'observation'});observation=data['observation'];derive_receipt(c,admission,observation);phase=k
        elif k=='FINALIZED':
            require(phase=='OBSERVED','STATE_TRANSITION');exact(data,{'receipt','recovery_permit','recovery_at'})
            if data['recovery_permit'] is not None:
                p=verify_signed(data['recovery_permit'],c['issuer_public'],issuer_root,'recovery-permit')
                exact(p,{'action','request_root','operation_id','expected_head','epoch','not_before','not_after','new_execution_permitted'})
                require(p['action']=='FINALIZE_OR_OBSERVE_ONLY' and p['new_execution_permitted'] is False and p['expected_head']==head and p['request_root']==c['request']['root'] and p['operation_id']==c['request']['operation_id'],'RECOVERY_SCOPE')
                require(p['not_before']<=integer(data['recovery_at'])<p['not_after'] and 0<p['not_after']-p['not_before']<=600,'RECOVERY_TIME')
            else:require(data['recovery_at'] is None,'RECOVERY_TIME_WITHOUT_PERMIT')
            receipt=derive_receipt(c,admission,observation)
            require(receipt==data['receipt'],'RECEIPT_NOT_REDERIVED');phase=k
        elif k=='CANCELLED':
            require(phase=='PREPARED','STATE_TRANSITION');exact(data,{'reason'});require(type(data['reason']) is str,'CANCELLATION_REASON');phase=k
        elif k=='ADMISSION_REFUSED':
            require(phase=='DISPATCH_INTENT','STATE_TRANSITION');exact(data,{'reason'});require(type(data['reason']) is str,'REFUSAL_REASON');phase=k
        else:raise Refusal('EVENT_KIND')
        head=signed['root']
    require(head==hash_value(expected_head),'HEAD_PIN')
    return {'phase':phase,'head':head,'admission':admission,'observation':observation,'receipt':receipt,'event_count':len(events)}

def verify_bundle(b,*,expected_context_root,expected_head,issuer_root,observer_root):
    b=check(b,'bundle',{'context','events','head','disclosure'})
    require(b['head']==expected_head and b['disclosure']==b['context']['disclosure'],'BUNDLE_BINDING')
    s=replay(b['context'],b['events'],expected_context_root=expected_context_root,expected_head=expected_head,issuer_root=issuer_root,observer_root=observer_root)
    return record('verification',status='SIGNATURES_AND_RECORD_DERIVATION_VERIFIED',context_root=expected_context_root,head=expected_head,
        phase=s['phase'],receipt_root=s['receipt']['root'] if s['receipt'] else None,
        current_authority_verified=False,independent_execution_verified=False,hardware_attestation=False,
        result=s['receipt']['status'] if s['receipt'] else 'INCOMPLETE',**BOUNDARY)
