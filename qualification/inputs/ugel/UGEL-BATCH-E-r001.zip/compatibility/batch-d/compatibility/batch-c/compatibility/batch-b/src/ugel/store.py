"""Explicit SQLite custody. Opening for inspection never initializes storage."""
from __future__ import annotations
import os
import sqlite3
from contextlib import closing
from pathlib import Path
from .canonical import *
from .contracts import SCHEMAS
from .history import ZERO

class Ledger:
    def __init__(self,path:Path,binding_root:str):
        self.path=Path(path).absolute(); self.binding_root=hash_value(binding_root)
        require(self.path.is_file() and not self.path.is_symlink(),"LEDGER_ABSENT_OR_UNSUPPORTED")
        with closing(self._connect(False)) as db:
            row=db.execute("SELECT value FROM metadata WHERE key='binding_root'").fetchone()
            require(row is not None and row[0]==binding_root,"LEDGER_BINDING_MISMATCH")

    @classmethod
    def initialize(cls,path:Path,binding_root:str):
        """Explicit custody creation; no parent directory creation or overwrite."""
        path=Path(path).absolute(); hash_value(binding_root)
        fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600); os.close(fd)
        try:
            with closing(sqlite3.connect(str(path))) as db:
                db.execute("PRAGMA synchronous=FULL")
                db.execute("CREATE TABLE metadata(key TEXT PRIMARY KEY,value TEXT NOT NULL)")
                db.execute("CREATE TABLE events(sequence INTEGER PRIMARY KEY, body TEXT NOT NULL)")
                db.execute("INSERT INTO metadata VALUES('binding_root',?)",(binding_root,))
                db.commit()
        except Exception as exc:
            # File creation is already an effect; never silently delete it.
            raise Refusal("LEDGER_INITIALIZATION_INCOMPLETE",str(path)) from exc
        return cls(path,binding_root)

    def _connect(self,write:bool):
        # mode=rw refuses a missing database instead of quietly reinitializing it.
        db=sqlite3.connect(self.path.as_uri()+ ("?mode=rw" if write else "?mode=ro"),uri=True,timeout=5)
        if write: db.execute("PRAGMA synchronous=FULL")
        return db

    def events(self)->list[dict]:
        try:
            with closing(self._connect(False)) as db:
                rows=db.execute("SELECT sequence,body FROM events ORDER BY sequence").fetchall()
            require([n for n,_ in rows]==list(range(1,len(rows)+1)),"LEDGER_SEQUENCE_INVALID")
            return [load_bytes(text.encode("ascii")) for _,text in rows]
        except sqlite3.Error as exc:
            raise Refusal("LEDGER_READ_UNAVAILABLE") from exc

    @property
    def head(self):
        events=self.events()
        return events[-1]["root"] if events else ZERO

    def append(self,operation_id:str,kind:str,body:dict,*,expected_head:str)->dict:
        identifier(operation_id); hash_value(expected_head)
        db=self._connect(True)
        try:
            db.execute("BEGIN IMMEDIATE")
            row=db.execute("SELECT sequence,body FROM events ORDER BY sequence DESC LIMIT 1").fetchone()
            number=row[0]+1 if row else 1
            head=load_bytes(row[1].encode("ascii"))["root"] if row else ZERO
            require(head==expected_head,"STALE_LEDGER_HEAD")
            event=seal({"schema":SCHEMAS["event"],"sequence":number,"previous":head,
                        "operation_id":operation_id,"kind":kind,"body":body})
            db.execute("INSERT INTO events VALUES(?,?)",(number,canonical(event).decode("ascii")))
            db.commit()
            return event
        except Refusal:
            db.rollback(); raise
        except sqlite3.Error as exc:
            try: db.rollback()
            except sqlite3.Error: pass
            raise Refusal("CUSTODY_COMMIT_UNCERTAIN") from exc
        finally:
            db.close()
