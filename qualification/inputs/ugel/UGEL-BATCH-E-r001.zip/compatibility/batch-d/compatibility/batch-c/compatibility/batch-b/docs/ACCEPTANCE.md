# Builder check scope

The executed lane is ordinary, local, standard-library reference checking.
It calls the actual inherited broker and new task/SDK implementation. Existing
Batch A tests are included unchanged, along with Python workflow and distribution
checks. `spec/REFERENCE-CHECK-CONTRACT.json` is the exact inventory.

No adversarial corpus, malformed-evidence mutation, fault injection, network
probe, live application, or credential operation is included. A naturally failing
baseline invoice test is a normal development observation, not an adversarial run.

Expected negative outcomes such as expired authority, a missing task, or absent
export acknowledgement are ordinary API contract checks. Pending-state fixtures
in the inherited A suite are authored model states, not induced crash evidence.

The scope includes: actual source/candidate binding; exact trusted test preservation;
capability attenuation; mediated creation and reads; idempotent ordinary resume;
current task views; child test failures and passes; source stability; explicit
expiry; late finalization; separate-process finalization; record-only replay;
correct CLI domain-failure code; predecessor preservation and standard-library
orientation. No independent qualification or cross-host outcome is inferred.

Output records are bound to source inventories computed before and after testing.
Qualification reads no prior result cache. A separate clean-extraction run repeats
the exact identities. Its deterministic result record should match the first;
host observations and duration-bearing log text are reported separately.

## Explicit non-claims

No sandbox, OS enforcement, real authentication, native UGK integration, arbitrary
Python correctness, model-generated repair success, proof of absence of effects,
external application integration, process-tree containment, power-loss guarantee,
Windows execution, Python 3.12 execution, or formal independent acceptance.
