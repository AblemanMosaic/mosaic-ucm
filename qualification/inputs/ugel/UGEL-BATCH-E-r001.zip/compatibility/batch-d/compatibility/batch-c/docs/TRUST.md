# Local signed authority and custody

Two roles are used: LOCAL_ISSUER and HOST_OBSERVER. Both use Ed25519 through a
prepared cryptography installation. Private keys are generated locally with the
library CSPRNG, stored mode 0600 under mode 0700 directories, and never copied into
the child or exported bundles. Public key records are domain-separated, versioned,
and pinned by the host outside candidate-controlled input.

This is a real asymmetric-signature implementation with a local single-owner trust
service. It is not a deployed remote identity provider, an independently witnessed
issuer, a legal identity check, a credential recovery service or a hardware vault.
Private key files are unencrypted; protecting the owner account, disk and backups is
a host obligation. Losing or compromising keys is not repaired automatically.

The issuer's SQLite store serializes grant issuance, one-attempt consumption,
revocation and epoch changes. A one-run grant binds the exact request, operation ID,
observer, epoch and bounded validity interval. An admission and a later GO decision
are separately signed and persisted. A replayed old grant cannot authorize a new
attempt through an intact current store.

The observer signs the process observation and every host journal event. Event
sequence, predecessor, context, transitions, full derived receipt and signatures
are checked on opening and offline replay. A separately retained expected head
rejects ordinary stale callers. Signed origin is not freshness: a privileged host
can roll back both local state and its locally saved head. Hardware monotonic state
and independent remote head custody remain unbound. `recover_head` is an explicit
local inspection, not an automatically trusted freshness oracle.

The authority store and host journal do not commit atomically together. Durable
intent precedes consumption/launch. Interruption in an uncertain interval leaves a
hold rather than minting new execution authority. Store-level locks serialize
cooperating callers; the private owner and host filesystem remain trusted.

Recovery permits bind the exact operation/request and expected head, allow only
observation/finalization, and have a maximum 600-second window. They are checked
against the issuer's current epoch during live use. Offline verification checks the
signed historical permit and its bindings; it does not attest current revocation.

Time is local host time. Neither signed wall-clock values nor sequence numbers
provide independent timestamping or a globally ordered history.
