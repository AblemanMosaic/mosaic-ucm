"""Single-owner signed host journal. No initialization on read paths."""
from __future__ import annotations
from contextlib import closing
import contextlib,fcntl,sqlite3
from pathlib import Path
from .common import *
from .semantics import replay

class HostStore:
    def __init__(self,folder:Path,pins:dict):
        self.folder=private_dir(folder);self.path=private_file(self.folder/'host.sqlite')
        self.context=read_json(private_file(self.folder/'CONTEXT.json'));self.pins=dict(pins)
        self.state() # validates every committed event against external pins
    @classmethod
    def create(cls,folder,context):
        folder=Path(folder);folder.mkdir(mode=0o700);write_json(folder/'CONTEXT.json',context)
        write_new(folder/'LOCK',b'');write_new(folder/'host.sqlite',b'')
        with closing(sqlite3.connect(folder/'host.sqlite')) as db:
            db.executescript('PRAGMA journal_mode=DELETE; PRAGMA synchronous=FULL; CREATE TABLE events(seq INTEGER PRIMARY KEY,root TEXT UNIQUE NOT NULL,record TEXT NOT NULL);')
        pins={'context_root':context['root'],'head':ZERO,'issuer_root':context['issuer_public']['root'],'observer_root':context['observer_public']['root']}
        write_json(folder/'INITIAL-PINS.json',pins);return cls(folder,pins)
    def _db(self,ro=False):
        private_file(self.path)
        db=sqlite3.connect(('file:'+str(self.path)+'?mode=ro') if ro else self.path,uri=ro,isolation_level=None,timeout=5)
        if not ro:db.execute('PRAGMA synchronous=FULL')
        return db
    def events(self):
        with closing(self._db(True)) as db:return [load_bytes(x[0].encode()) for x in db.execute('SELECT record FROM events ORDER BY seq')]
    def state(self):
        return replay(self.context,self.events(),expected_context_root=self.pins['context_root'],expected_head=self.pins['head'],issuer_root=self.pins['issuer_root'],observer_root=self.pins['observer_root'])
    @contextlib.contextmanager
    def exclusive(self):
        fd=os.open(private_file(self.folder/'LOCK'),os.O_RDWR|os.O_NOFOLLOW)
        try:
            try:fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
            except BlockingIOError as e:raise Refusal('HOST_OPERATION_BUSY') from e
            self.state();yield
        finally:os.close(fd) # process exit also releases; persistent file is not a stale lease
    def append(self,key,kind,data):
        require(key.public['root']==self.pins['observer_root'],'OBSERVER_PIN')
        db=self._db()
        try:
            db.execute('BEGIN IMMEDIATE');rows=db.execute('SELECT record FROM events ORDER BY seq').fetchall();events=[load_bytes(r[0].encode()) for r in rows]
            s=replay(self.context,events,expected_context_root=self.pins['context_root'],expected_head=self.pins['head'],issuer_root=self.pins['issuer_root'],observer_root=self.pins['observer_root'])
            event=key.sign('journal-event',{'sequence':len(events)+1,'previous':s['head'],'context_root':self.context['root'],'kind':kind,'data':data})
            replay(self.context,events+[event],expected_context_root=self.context['root'],expected_head=event['root'],issuer_root=self.pins['issuer_root'],observer_root=self.pins['observer_root'])
            db.execute('INSERT INTO events VALUES(?,?,?)',(len(events)+1,event['root'],canonical(event).decode()));db.execute('COMMIT')
            self.pins['head']=event['root'];return event
        finally:
            if db.in_transaction:db.execute('ROLLBACK')
            db.close()
    def export(self,*,acknowledge_plaintext=False):
        require(acknowledge_plaintext is True,'EXPLICIT_SOURCE_DISCLOSURE_REQUIRED');self.state()
        return record('bundle',context=self.context,events=self.events(),head=self.pins['head'],disclosure=self.context['disclosure'])
    @staticmethod
    def recover_head(folder,*,expected_context_root,issuer_root,observer_root):
        """Observe a locally held journal head; caller must accept/store this checkpoint.
        A signature authenticates origin, not freshness against a rolled-back host.
        """
        folder=private_dir(folder);context=read_json(private_file(folder/'CONTEXT.json'))
        path=private_file(folder/'host.sqlite')
        with closing(sqlite3.connect('file:'+str(path)+'?mode=ro',uri=True)) as db:
            events=[load_bytes(r[0].encode()) for r in db.execute('SELECT record FROM events ORDER BY seq')]
        head=events[-1]['root'] if events else ZERO
        replay(context,events,expected_context_root=expected_context_root,expected_head=head,issuer_root=issuer_root,observer_root=observer_root)
        return {'context_root':expected_context_root,'head':head,'issuer_root':issuer_root,'observer_root':observer_root}
