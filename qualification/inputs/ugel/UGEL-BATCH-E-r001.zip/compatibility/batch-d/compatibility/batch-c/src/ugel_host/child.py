"""Trusted bootstrap for a fresh Linux/x86_64 interpreter.

No candidate module is executed until: exact input validation, preloading,
credential/capability reduction, limits, seccomp installation, host /proc witness,
and an explicit GO on the inherited input pipe. Only this process is restricted.
The unittest result remains a report from code sharing an interpreter, not a
proof against a malicious candidate falsifying the report.
"""
from __future__ import annotations
import ctypes,hashlib,importlib,importlib.abc,importlib.util,io,json,linecache,os,platform,resource,sys,types,unittest
from pathlib import Path

def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('ascii')
def root(x):return hashlib.sha256(b'MOSAIC-UGEL-C1\0'+canonical(x)).hexdigest()
def sealed(kind,**body):
    b={'schema':'mosaic.ugel.batch-c.'+kind+'.v1',**body};return {**b,'root':root(b)}
def emit(x):
    data=canonical(x)+b'\n'
    while data:
        n=os.write(1,data);data=data[n:]

def install_filter(profile,libpath):
    class ArgCmp(ctypes.Structure):
        _fields_=[('arg',ctypes.c_uint),('op',ctypes.c_int),('a',ctypes.c_uint64),('b',ctypes.c_uint64)]
    lib=ctypes.CDLL(libpath,use_errno=True)
    lib.seccomp_init.argtypes=[ctypes.c_uint32];lib.seccomp_init.restype=ctypes.c_void_p
    lib.seccomp_rule_add_array.argtypes=[ctypes.c_void_p,ctypes.c_uint32,ctypes.c_int,ctypes.c_uint,ctypes.POINTER(ArgCmp)]
    lib.seccomp_syscall_resolve_name.argtypes=[ctypes.c_char_p];lib.seccomp_syscall_resolve_name.restype=ctypes.c_int
    lib.seccomp_load.argtypes=[ctypes.c_void_p];lib.seccomp_release.argtypes=[ctypes.c_void_p]
    lib.seccomp_export_bpf.argtypes=[ctypes.c_void_p,ctypes.c_int]
    ctx=lib.seccomp_init(0x00050001) # default ERRNO(EPERM), not TRAP/log notification
    if not ctx:raise RuntimeError('FILTER_ALLOCATION')
    try:
        for name in profile['allowed_unconditional_syscalls']:
            nr=lib.seccomp_syscall_resolve_name(name.encode())
            if nr<0 or lib.seccomp_rule_add_array(ctx,0x7fff0000,nr,0,None)<0:raise RuntimeError('FILTER_RULE:'+name)
        for name,values in profile['argument_limited_syscalls'].items():
            nr=lib.seccomp_syscall_resolve_name(name.encode())
            for value in values:
                arg=ArgCmp(0,4,value,0) # SCMP_CMP_EQ on argument zero
                if nr<0 or lib.seccomp_rule_add_array(ctx,0x7fff0000,nr,1,ctypes.byref(arg))<0:raise RuntimeError('FILTER_ARGUMENT_RULE:'+name)
        fd=os.memfd_create('ugel-filter',getattr(os,'MFD_CLOEXEC',1))
        try:
            if lib.seccomp_export_bpf(ctx,fd)<0:raise RuntimeError('FILTER_EXPORT')
            os.lseek(fd,0,os.SEEK_SET);bpf=os.read(fd,1000000)
        finally:os.close(fd)
        resource.setrlimit(resource.RLIMIT_FSIZE,(0,0))
        if lib.seccomp_load(ctx)<0:raise RuntimeError('FILTER_INSTALLATION_UNAVAILABLE')
        return hashlib.sha256(bpf).hexdigest()
    finally:lib.seccomp_release(ctx)

class MemoryModules(importlib.abc.MetaPathFinder,importlib.abc.Loader):
    def __init__(self,texts):
        self.texts={n[:-3]:t for n,t in texts.items()}
        self.codes={n:compile(t,'<ugel:'+n+'.py>','exec',dont_inherit=True) for n,t in self.texts.items()}
        for n,t in self.texts.items():linecache.cache['<ugel:'+n+'.py>']=(len(t),None,t.splitlines(True),'<ugel:'+n+'.py>')
    def find_spec(self,fullname,path=None,target=None):
        if fullname in self.codes:return importlib.util.spec_from_loader(fullname,self,origin='<ugel-memory>')
        raise ImportError('MODULE_NOT_IN_MEMORY_PROFILE:'+fullname)
    def create_module(self,spec):return None
    def exec_module(self,module):
        module.__file__='<ugel:'+module.__name__+'.py>';exec(self.codes[module.__name__],module.__dict__)
    def get_source(self,name):return self.texts.get(name)

def flatten(suite):
    for t in suite:
        if isinstance(t,unittest.TestSuite):yield from flatten(t)
        else:yield t
class BoundedLog(io.StringIO):
    def write(self,text):
        if self.tell()+len(text)>200000:raise RuntimeError('IN_MEMORY_LOG_BOUND')
        return super().write(text)
class Result(unittest.TextTestResult):
    def __init__(self,*a,**kw):super().__init__(*a,**kw);self.rows=[];self.started=[];self.subtest_failures=[]
    def startTest(self,t):self.started.append(t.id());super().startTest(t)
    def addSuccess(self,t):self.rows.append({'id':t.id(),'status':'PASS'});super().addSuccess(t)
    def addFailure(self,t,e):self.rows.append({'id':t.id(),'status':'FAIL'});super().addFailure(t,e)
    def addError(self,t,e):self.rows.append({'id':t.id(),'status':'ERROR'});super().addError(t,e)
    def addSkip(self,t,r):self.rows.append({'id':t.id(),'status':'SKIP'});super().addSkip(t,r)
    def addExpectedFailure(self,t,e):self.rows.append({'id':t.id(),'status':'EXPECTED_FAILURE'});super().addExpectedFailure(t,e)
    def addUnexpectedSuccess(self,t):self.rows.append({'id':t.id(),'status':'UNEXPECTED_SUCCESS'});super().addUnexpectedSuccess(t)
    def addSubTest(self,t,s,e):
        if e is not None:self.subtest_failures.append(t.id())
        super().addSubTest(t,s,e)

def main():
    # Request and pipe are the only input from the host. No private keys are loaded.
    raw=sys.stdin.buffer.readline(5000001)
    if len(raw)>5000000 or not raw.endswith(b'\n'):raise RuntimeError('INPUT_LIMIT')
    q=json.loads(raw)
    if q['root']!=root({k:v for k,v in q.items() if k!='root'}):raise RuntimeError('REQUEST_ROOT')
    policy=q['policy'];host=q['host']
    if policy['root']!=root({k:v for k,v in policy.items() if k!='root'}):raise RuntimeError('POLICY_ROOT')
    if platform.system()!='Linux' or platform.machine()!='x86_64':raise RuntimeError('HOST_UNSUPPORTED')
    if hashlib.sha256(Path(host['libseccomp_path']).read_bytes()).hexdigest()!=host['libseccomp_sha256']:raise RuntimeError('SECCOMP_BYTES_CHANGED')
    if hashlib.sha256(Path(sys.executable).resolve().read_bytes()).hexdigest()!=host['executable_sha256']:raise RuntimeError('INTERPRETER_CHANGED')
    for name in policy['preloaded_stdlib']:importlib.import_module(name)
    loader=MemoryModules(q['candidate_texts'])
    if set(loader.codes)&set(sys.modules):raise RuntimeError('CANDIDATE_MODULE_COLLISION')
    expected=q['test_ids'];test_modules=sorted(n for n in loader.codes if n.startswith('test_'))
    libc=ctypes.CDLL(None,use_errno=True)
    # Trusted initialization ends before user code can execute.
    os.chdir('/');os.environ.clear();sys.path=[];sys.dont_write_bytecode=True
    os.closerange(3,65536)
    if os.geteuid()==0:
        os.setgroups([]);os.setgid(policy['root_child_gid']);os.setuid(policy['root_child_uid'])
    class CapHeader(ctypes.Structure):_fields_=[('version',ctypes.c_uint32),('pid',ctypes.c_int)]
    class CapData(ctypes.Structure):_fields_=[('effective',ctypes.c_uint32),('permitted',ctypes.c_uint32),('inheritable',ctypes.c_uint32)]
    header=CapHeader(0x20080522,0);caps=(CapData*2)()
    if libc.capset(ctypes.byref(header),ctypes.byref(caps))!=0:raise RuntimeError('CAPABILITY_DROP_FAILED')
    if libc.prctl(38,1,0,0,0)!=0 or libc.prctl(4,0,0,0,0)!=0:raise RuntimeError('PRIVILEGE_BOUNDARY_FAILED')
    resource.setrlimit(resource.RLIMIT_CORE,(0,0))
    resource.setrlimit(resource.RLIMIT_AS,(policy['address_space_bytes'],policy['address_space_bytes']))
    resource.setrlimit(resource.RLIMIT_CPU,(policy['cpu_seconds'],policy['cpu_seconds']))
    resource.setrlimit(resource.RLIMIT_NOFILE,(16,16))
    sys.meta_path=[loader]
    bpf=install_filter(policy,host['libseccomp_path'])
    if libc.prctl(21,0,0,0,0)!=2 or libc.prctl(39,0,0,0,0)!=1:raise RuntimeError('FILTER_STATE_UNCONFIRMED')
    emit({'kind':'READY','request_root':q['root'],'policy_root':policy['root'],'filter_bpf_sha256':bpf,
          'seccomp_mode':2,'no_new_privs':1,'uid':os.getuid(),'gid':os.getgid(),'candidate_started':False})
    if sys.stdin.buffer.readline(32)!=b'GO\n':
        emit({'kind':'ENTRY_REFUSED','request_root':q['root'],'candidate_started':False});return 3
    # Only the exact supplied source text is imported, from memory, after GO.
    out=BoundedLog();oldout,olderr=sys.stdout,sys.stderr;sys.stdout=sys.stderr=out
    try:
        suite=unittest.TestSuite()
        for n in test_modules:suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(importlib.import_module(n)))
        ids=sorted(t.id() for t in flatten(suite))
        if ids!=expected:
            r=sealed('child-result',request_root=q['root'],status='INVENTORY_MISMATCH',test_ids=ids,started_ids=[],rows=[],
                tests_run=0,failures=0,errors=0,skips=0,expected_failures=0,unexpected_successes=0,subtest_failures=[],log='')
            rc=2
        else:
            result=unittest.TextTestRunner(stream=out,verbosity=2,resultclass=Result).run(suite)
            ok=result.wasSuccessful() and not result.skipped and not result.expectedFailures and not result.unexpectedSuccesses and not result.subtest_failures and sorted(result.started)==expected and sorted(x['id'] for x in result.rows)==expected and all(x['status']=='PASS' for x in result.rows)
            r=sealed('child-result',request_root=q['root'],status='PASS' if ok else 'FAIL',test_ids=ids,
                started_ids=sorted(result.started),rows=sorted(result.rows,key=lambda x:x['id']),tests_run=result.testsRun,
                failures=len(result.failures),errors=len(result.errors),skips=len(result.skipped),
                expected_failures=len(result.expectedFailures),unexpected_successes=len(result.unexpectedSuccesses),
                subtest_failures=sorted(result.subtest_failures),log=out.getvalue())
            rc=0 if ok else 1
    except BaseException as exc:
        r=sealed('child-error',request_root=q['root'],status='CHECK_ERROR',error=type(exc).__name__,detail=str(exc)[:1000]);rc=2
    finally:sys.stdout,sys.stderr=oldout,olderr
    emit({'kind':'RESULT','request_root':q['root'],'result':r})
    return rc

if __name__=='__main__':
    try:rc=main()
    except BaseException as e:
        try:emit({'kind':'BOOT_REFUSED','error':type(e).__name__,'detail':str(e)[:1000]})
        except BaseException:pass
        rc=4
    os._exit(rc)
