"""Reproducible ZIP packaging of a checked source/evidence snapshot."""
from __future__ import annotations
import argparse,hashlib,io,json,zipfile
from pathlib import Path
from source_inventory import inventory,canonical,seal
ROOT=Path(__file__).resolve().parents[1]

def archive_bytes(files):
    stream=io.BytesIO()
    with zipfile.ZipFile(stream,"w",compression=zipfile.ZIP_STORED) as z:
        for name,data in sorted(files.items()):
            info=zipfile.ZipInfo(name,(1980,1,1,0,0,0)); info.create_system=3
            info.external_attr=0o100644<<16; info.compress_type=zipfile.ZIP_STORED
            z.writestr(info,data)
    return stream.getvalue()

def main():
    p=argparse.ArgumentParser(); p.add_argument("--output",type=Path,required=True); a=p.parse_args()
    source=inventory(ROOT)
    checks=json.loads((ROOT/"evidence/REFERENCE-CHECKS.json").read_bytes())
    from source_inventory import root
    if checks["root"] != root({k:v for k,v in checks.items() if k!="root"}):
        raise SystemExit("CHECK_RECORD_ROOT_INVALID")
    if checks["status"]!="PASS" or checks["source_root"]!=source["root"] or not checks["source_stable"]:
        raise SystemExit("FRESH_SOURCE_BOUND_CHECKS_REQUIRED")
    (ROOT/"release").mkdir(exist_ok=True)
    (ROOT/"release/SOURCE-MANIFEST.json").write_bytes(canonical(source)+b"\n")
    files={}
    for path in sorted(ROOT.rglob("*")):
        rel=path.relative_to(ROOT)
        if any(p in {"__pycache__",".git"} for p in rel.parts): continue
        if path.is_symlink(): raise SystemExit("PACKAGE_SYMLINK_REFUSED")
        if not path.is_file() or rel.as_posix()=="PACKAGE-MANIFEST.json": continue
        if path.suffix in {".pyc",".pyo"}: raise SystemExit("BYTECODE_REFUSED")
        files[rel.as_posix()]=path.read_bytes()
    rows=[{"path":n,"bytes":len(d),"sha256":hashlib.sha256(d).hexdigest()} for n,d in sorted(files.items())]
    manifest=seal({"schema":"mosaic.ugel.batch-b.package-manifest.v1","source_root":source["root"],
        "reference_checks_root":checks["root"],"files":rows,"standing":"INFORMATION_ONLY",
        "authority_effect":"NONE","real_a5":False,"g0":"CLOSED"})
    files["PACKAGE-MANIFEST.json"]=canonical(manifest)+b"\n"
    first=archive_bytes(files); second=archive_bytes(files)
    if first!=second: raise SystemExit("PACKAGING_NOT_REPRODUCIBLE")
    a.output.parent.mkdir(parents=True,exist_ok=True); a.output.write_bytes(first)
    receipt=seal({"schema":"mosaic.ugel.batch-b.build-receipt.v1","archive_sha256":hashlib.sha256(first).hexdigest(),
        "archive_bytes":len(first),"package_root":manifest["root"],"source_root":source["root"],
        "source_files":source["file_count"],"package_files":len(files),"reference_checks_root":checks["root"],
        "packaging_comparison":"TWO_BYTE_IDENTICAL_BUILDS_FROM_SAME_FROZEN_INPUTS", "compression":"ZIP_STORED",
        "independent_review":"NOT_PERFORMED","native_ugk_binding":"NOT_BOUND","standing":"INFORMATION_ONLY",
        "authority_effect":"NONE","real_a5":False,"g0":"CLOSED"})
    a.output.with_suffix(".receipt.json").write_bytes(canonical(receipt)+b"\n")
    print(json.dumps(receipt,indent=2,sort_keys=True))
if __name__=="__main__": main()
