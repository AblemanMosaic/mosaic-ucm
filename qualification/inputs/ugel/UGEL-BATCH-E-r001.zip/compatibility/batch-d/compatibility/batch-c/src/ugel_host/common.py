"""Canonical records and safe local file helpers. No implicit authority."""
from __future__ import annotations
import hashlib,json,os,stat
from pathlib import Path
from ugel.canonical import canonical,load_bytes,require,Refusal,exact,integer,identifier,hash_value
DOMAIN=b"MOSAIC-UGEL-C1\x00"
BOUNDARY={"standing":"INFORMATION_ONLY","authority_effect":"NONE","real_a5":False,"g0":"CLOSED"}
ZERO="0"*64
def digest(x):return hashlib.sha256(DOMAIN+canonical(x)).hexdigest()
def byte_hash(b):return hashlib.sha256(b).hexdigest()
def record(record_kind,**body):
    b={"schema":"mosaic.ugel.batch-c."+record_kind+".v1",**body}
    return {**b,"root":digest(b)}
def check(x,kind,fields=None):
    require(type(x) is dict and x.get("schema")=="mosaic.ugel.batch-c."+kind+".v1","SCHEMA_INVALID")
    if fields is not None:exact(x,set(fields)|{"schema","root"})
    require(x.get("root")==digest({k:v for k,v in x.items() if k!="root"}),"ROOT_INVALID")
    return load_bytes(canonical(x))
def write_new(path,data):
    path=Path(path);fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|getattr(os,"O_NOFOLLOW",0),0o600)
    with os.fdopen(fd,"wb") as f:f.write(data);f.flush();os.fsync(f.fileno())
def write_json(path,value):write_new(path,canonical(value)+b"\n")
def private_dir(path):
    path=Path(path);s=path.lstat()
    require(stat.S_ISDIR(s.st_mode) and not path.is_symlink(),"PRIVATE_DIRECTORY_REQUIRED")
    require(s.st_uid==os.getuid() and (s.st_mode&0o077)==0,"PRIVATE_DIRECTORY_CUSTODY_REQUIRED")
    return path
def private_file(path):
    path=Path(path);s=path.lstat()
    require(stat.S_ISREG(s.st_mode) and not path.is_symlink() and s.st_nlink==1,"PRIVATE_FILE_REQUIRED")
    require(s.st_uid==os.getuid() and (s.st_mode&0o077)==0,"PRIVATE_FILE_CUSTODY_REQUIRED")
    return path
def read_json(path):return load_bytes(Path(path).read_bytes())
def canonical_integer_clock():
    import time
    return int(time.time())
