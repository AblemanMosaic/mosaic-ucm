# Mechanism references

Checked while constructing this reference on 2026-11-06. These documents motivate
the mechanism; they do not certify this implementation or its threat model.

- Linux kernel, Seccomp BPF: https://docs.kernel.org/userspace-api/seccomp_filter.html
  Filtering needs PR_SET_NO_NEW_PRIVS or the appropriate privilege; syscall
  filtering alone is not a complete sandbox or information-flow policy.
- libseccomp upstream, seccomp_rule_add manual:
  https://github.com/seccomp/libseccomp/blob/main/doc/man/man3/seccomp_rule_add.3
  Rule construction and integer syscall-argument constraints.
- Cryptography 46.0.4, Ed25519:
  https://cryptography.io/en/46.0.4/hazmat/primitives/asymmetric/ed25519/
  Library-backed generation, signing, raw serialization and verification.
- CPython 3.13, resource:
  https://docs.python.org/3.13/library/resource.html
  OS-dependent limits. Limits do not establish correctness of child results.
- Linux Landlock documentation:
  https://docs.kernel.org/userspace-api/landlock.html
  Considered alternative. The local ABI query returned ENOSYS; NOT used here.
