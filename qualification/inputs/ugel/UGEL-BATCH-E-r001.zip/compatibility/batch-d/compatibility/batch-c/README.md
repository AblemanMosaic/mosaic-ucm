# UGEL Batch C r001 — signed local host execution

**INFORMATION_ONLY. Constitutional authority effect NONE; real A5 false; G0 CLOSED.**

Batch C connects the exact Batch B materialized candidate to a **new** signed host
operation, `python.memory-unittest`. A fresh Linux/x86_64 child preloads the exact
source into memory, removes privileges, applies resource limits and a default-deny
seccomp filter, and waits. The supervisor reads that child's kernel status and
obtains a current issuer-signed entry authorization before sending GO.

The child has no file-open, socket, or process-creation syscalls in this profile.
Its only descriptor operations are reads on the host control pipe and bounded
output through inherited pipes. The host persists a signed observation before
finalization. A fresh process can verify and finalize that observation without
launching another child. An uncertain operation is never automatically retried.

**This is a narrowly supported, positive-workflow-tested host integration, not a
production sandbox qualification.** No escape probes, denied-syscall tests, forced
crashes, power-loss tests, or adversarial containment review were performed.

## Prepared host

- Linux x86_64, `/proc` available, seccomp filter support, and `libseccomp.so.2`.
- Prepared CPython 3.12 or 3.13. Only the actual host in `evidence/HOST.json` was run.
- Prepared `cryptography >=46,<47` for Ed25519 signing and verification.
- A trusted, single local owner for the host, its source, issuer, keys and custody.

No dependency is installed automatically. Basic orientation is standard-library
only. Windows, other architectures, native UGK/AOK services, hardware key custody,
and a remote identity provider are **not bound or qualified** by this batch.
Landlock was unavailable on the build host. This profile does not silently use a
weaker fallback: it instead uses an explicitly different, memory-only operation.

## Quick start

```console
python -B run.py orient
python -B run.py inspect-host
python -B run.py demo --output ../ugel-host-demo
python -B tools/check.py --output ../ugel-host-checks
```

The output directory for `demo` must not exist. The demo uses Batch B's known
invoice fixture: baseline and repaired candidates run under the new host profile.
It exports **public** keys, signed records, plaintext source, receipts and pinned
heads. Private keys and temporary workspaces are removed afterward (not a claim
of forensic secure erasure). A second interpreter performs finalization.

`inspect-host` does not install a filter or run code; successful preflight means
only that the named setup is a candidate. Actual filter installation and kernel
observation occur in the disposable child before candidate entry.

## Integrating an accepted Batch B task

Materialize an exact task with the unchanged Batch B API. Do **not** run its
cooperative `execute_check()` and then label that execution as contained.
Batch C requires the Batch B task to remain `MATERIALIZED` and creates a separate
host journal and separately signed one-attempt execution grant.

```python
from pathlib import Path
from ugel_python import TaskSession
from ugel_host.trust import Authority, LocalKey
from ugel_host.service import HostSession

# Establish these keys once under a trusted host workflow. Retain the PUBLIC key
# roots separately. Never accept a replacement pin from an untrusted proposal.
authority = Authority.create(Path("new-private-issuer"))
observer = LocalKey.create(Path("new-private-observer"), "HOST_OBSERVER")

# b_session is an already accepted and materialized Batch B TaskSession.
host = HostSession.prepare(
    b_session, "check-001", Path("new-host-task"),
    authority=authority, observer=observer,
)
initial_pins = host.pins()
result = host.execute(finalize=False)
observed_pins = host.pins()  # save each returned head outside candidate custody
permit = authority.recovery_permit(
    host.context["request"]["root"], "check-001", observed_pins["head"],
    now=host.clock(),
)
receipt = host.reconcile(permit)
bundle = host.export(acknowledge_plaintext=True)
```

For source checkout, set `PYTHONPATH` to `src` and
`compatibility/batch-b/src`. `run.py` configures those paths for CLI use. The full
original Batch B payload and archive are retained byte-identically.

CLI equivalents exist for `create-authority`, `create-observer`, `prepare`,
`execute`, `inspect`, `permit`, `reconcile`, `cancel`, `export`, and `verify-bundle`.
Run any command with `--help`. `permit` and `export` emit the raw signed permit
and bundle respectively, directly consumable by `reconcile` and `verify-bundle`.
The mutation results return current pins; retain
these before the next operation. `verify-bundle` requires a separate pins file.
A pins file obtained from the same untrusted bundle is not an external trust basis.

## What the result means

`CHECKED_NOT_RELEASED` means the signed local host observation reports the exact
accepted tests passing over the exact in-memory candidate, under the observed
entry profile, with the original/candidate path snapshots still matching afterward.

The test code and candidate share an interpreter. **A malicious candidate could
falsify the test report by modifying Python state.** Kernel effect restrictions do
not turn this test oracle into a malicious-code correctness proof. This batch's
functional verdict is for trusted test/candidate behavior; the OS boundary limits
host effects even when application behavior is accidental or buggy. Its resistance
to hostile code is an unperformed independent qualification leg.

Ed25519 verifies record origin under the locally pinned key. It establishes neither
a legal identity nor independent truth of the observation. No hardware attestation,
remote witness, trusted time service, anti-rollback device, production authority,
or native UGK receipt equivalence is claimed.

## Recovery

- `OBSERVED` -> derive the receipt in a new process, using a new exact recovery permit.
- `FINALIZED` -> return the same receipt; no child is run again.
- `DISPATCH_INTENT` / `ADMITTED` with no observation -> unresolved; no redispatch.
- `PREPARED` -> execute once or cancel durably.
- `CANCELLED` -> no execution on this host-operation record.

A signed recovery permit never renews execution authority. Missing observation,
missing PID, absent files, and matching current bytes are not proof of nonexecution.
The issuer-store/journal boundary is intentionally not claimed globally atomic.

## Verification and remaining work

```console
python -B VERIFY.py ../UGEL-BATCH-C-r001.zip --expected-sha256 EXTERNAL_ARCHIVE_SHA256
python -B run.py verify-bundle DEMO_BUNDLE.json --pins INDEPENDENTLY_RETAINED_PINS.json
```

The standalone verifier is passive, standard-library only, and imports no candidate
modules. Bundle verification uses the crypto dependency and rederives signed history;
it does not replay effects or establish empirical truth independently.

See `docs/SECURITY-BOUNDARY.md`, `docs/TRUST.md`, `docs/RECOVERY.md`,
`docs/ACCEPTANCE.md`, and the build report for the exact supported and unperformed
boundaries. Batch D can add C/Rust adapters against these contracts; widening the
host's effect profile requires a separately qualified successor.
