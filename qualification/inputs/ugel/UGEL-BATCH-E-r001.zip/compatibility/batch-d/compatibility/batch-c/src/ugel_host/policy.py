"""One explicit host profile. No fallback to cooperative execution."""
from __future__ import annotations
import ctypes,hashlib,os,platform,sys
from pathlib import Path
from .common import *
MEMORY_SYSCALLS=["brk","clock_gettime","clock_nanosleep","close","exit","exit_group","futex",
 "getegid","geteuid","getgid","getpid","getrandom","getrusage","gettid","getuid",
 "madvise","mmap","mprotect","mremap","munmap","nanosleep","restart_syscall",
 "rt_sigaction","rt_sigprocmask","rt_sigreturn","sched_yield","sigaltstack"]
STDLIB_MODULES=["base64","collections","contextlib","dataclasses","datetime","decimal","difflib",
 "enum","fractions","functools","hashlib","hmac","io","itertools","json","math","operator",
 "pprint","re","statistics","string","textwrap","time","traceback","typing","unittest"]
def policy():
 return record("host-policy",profile="LINUX_X86_64_SECCOMP_MEMORY_CHECK_V1",
  platform="Linux",architecture="x86_64",default_syscall_action="ERRNO_EPERM",
  allowed_unconditional_syscalls=sorted(MEMORY_SYSCALLS),
  argument_limited_syscalls={"read":[0],"write":[1,2],"fstat":[1,2],"prctl":[21,39]},
  candidate_imports="PRECOMPILED_MEMORY_MODULES_ONLY",preloaded_stdlib=STDLIB_MODULES,
  stdin="BOUNDED_HOST_CONTROL_PIPE",stdout="UNTRUSTED_BOUNDED_RESULT_PIPE",stderr="BOUNDED_DIAGNOSTIC_PIPE",
  no_new_privileges=True,drop_capabilities=True,root_child_uid=65534,root_child_gid=65534,
  cpu_seconds=5,wall_seconds=10,address_space_bytes=536870912,max_output_bytes=1048576,
  filesystem_access_after_entry="NO_OPEN_SYSCALLS_OR_FILE_DESCRIPTORS",
  external_network="NO_SOCKET_SYSCALLS_OR_INHERITED_SOCKETS",
  process_creation="NO_FORK_CLONE_EXEC_SYSCALLS",
  candidate_result_integrity="TRUSTED_TEST_CODE_SAME_INTERPRETER_NOT_MALICIOUS_RESULT_PROOF",
  host_admin_threat="OUT_OF_SCOPE",side_channels="OUT_OF_SCOPE",
  runtime_closure="PINNED_EXECUTABLE_HELPERS_LIBSECCOMP_NOT_FULL_OS",
  forbidden_effect_tests="NOT_RUN_WITHOUT_SEPARATE_AUTHORIZATION",**BOUNDARY)
def engine_identity():
 r=Path(__file__).resolve().parent
 return record("host-engine",files=[{"path":p.name,"sha256":byte_hash(p.read_bytes())} for p in sorted(r.glob("*.py"))])
def host_identity():
 require(platform.system()=="Linux" and platform.machine()=="x86_64","HOST_PROFILE_UNSUPPORTED")
 require(platform.python_implementation()=="CPython" and sys.version_info[:2] in {(3,12),(3,13)},"HOST_PYTHON_UNSUPPORTED")
 try:lib=ctypes.CDLL("libseccomp.so.2")
 except OSError as e:raise Refusal("LIBSECCOMP_UNAVAILABLE") from e
 paths=sorted({line.split()[-1] for line in Path("/proc/self/maps").read_text().splitlines()
               if "libseccomp.so" in line and line.split()[-1].startswith("/")})
 require(len(paths)==1,"LIBSECCOMP_IDENTITY_UNRESOLVED")
 p=Path(paths[0]);ex=Path(sys.executable).resolve()
 return record("host-identity",kernel=platform.release(),machine=platform.machine(),
  python=platform.python_version(),executable=str(ex),executable_sha256=byte_hash(ex.read_bytes()),
  libseccomp_path=str(p),libseccomp_sha256=byte_hash(p.read_bytes()),policy_root=policy()["root"],
  engine_root=engine_identity()["root"],complete_runtime_closure=False)
def inspect_host():
 try:
  h=host_identity();return record("host-preflight",status="SETUP_CANDIDATE_NOT_YET_ENTERED",host=h,
   enforcement_installed=False,requires_positive_child_entry=True,**BOUNDARY)
 except (Refusal,OSError) as e:
  return record("host-preflight",status="REFUSED_HOST_UNAVAILABLE",reason=getattr(e,"code",type(e).__name__),
   enforcement_installed=False,fallback="NONE",**BOUNDARY)
