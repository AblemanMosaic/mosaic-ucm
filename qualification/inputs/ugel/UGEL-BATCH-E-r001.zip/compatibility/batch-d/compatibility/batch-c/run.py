"""Batch C host CLI. Candidate code is never imported here."""
from pathlib import Path
import sys
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parent
sys.path[:0]=[str(R/"src"),str(R/"compatibility/batch-b/src")]
from ugel_host.cli import main
if __name__=="__main__": raise SystemExit(main())
