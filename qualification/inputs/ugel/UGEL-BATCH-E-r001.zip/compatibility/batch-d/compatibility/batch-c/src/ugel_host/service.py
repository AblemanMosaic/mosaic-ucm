"""Synchronous local host service with separately persisted, signed observation.

No network daemon is created. Commands are separable processes and use a common
private store. A process-held lock plus durable intent prevent automatic replay.
"""
from __future__ import annotations
import os,selectors,subprocess,time
from pathlib import Path
from .common import *
from .policy import policy,host_identity,engine_identity
from .trust import Authority,LocalKey,validate_grant
from .semantics import make_request,validate_context,derive_receipt,verify_bundle
from .store import HostStore
from ugel_python.model import snapshot


def process_witness(pid):
    text=Path(f'/proc/{pid}/status').read_text()
    all_fields={line.split(':',1)[0]:line.split(':',1)[1].strip() for line in text.splitlines() if ':' in line}
    fields={k:all_fields[k] for k in ['Name','Uid','Gid','NoNewPrivs','Seccomp','Seccomp_filters','CapEff','CapPrm','CapInh','Threads']}
    require(fields['NoNewPrivs']=='1' and fields['Seccomp']=='2' and int(fields['Seccomp_filters'])>=1 and fields['Threads']=='1','KERNEL_ENTRY_NOT_ESTABLISHED')
    require(all(int(fields[k],16)==0 for k in ['CapEff','CapPrm','CapInh']),'CHILD_CAPABILITIES_REMAIN')
    require(int(fields['Uid'].split()[1])!=0,'PRIVILEGED_CHILD_REFUSED')
    return fields


def perform(context,admission,authority,clock):
    q=context['request'];host=q['host'];p=q['policy'];driver=Path(__file__).with_name('child.py')
    require(engine_identity()['root']==q['engine_root'] and host_identity()==host,'HOST_IDENTITY_CHANGED')
    require(byte_hash(driver.read_bytes())==q['child_sha256'],'CHILD_CODE_CHANGED')
    b=context['batch_b_bundle']['context']
    require(snapshot(Path(b['source_path']))[0]['root']==q['source_root'],'SOURCE_DRIFT')
    require(snapshot(Path(b['candidate_path']))[0]['root']==q['candidate_root'],'CANDIDATE_DRIFT')
    started=clock();out=bytearray();err=bytearray();reason=None;ready=None;witness=None;entry=None;result=None
    proc=None;returncode=None;selector=selectors.DefaultSelector();input_bytes=canonical(q)+b'\n';pending=bytearray(input_bytes)
    partial=bytearray();deadline=time.monotonic()+min(p['wall_seconds'],max(1,context['grant']['body']['not_after']-started))
    try:
        proc=subprocess.Popen([host['executable'],'-I','-S','-B',str(driver)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
            cwd='/',env={'LANG':'C.UTF-8','LC_ALL':'C.UTF-8'},close_fds=True,start_new_session=True,shell=False)
        for stream in [proc.stdin,proc.stdout,proc.stderr]:os.set_blocking(stream.fileno(),False)
        selector.register(proc.stdin,selectors.EVENT_WRITE,'input');selector.register(proc.stdout,selectors.EVENT_READ,'stdout');selector.register(proc.stderr,selectors.EVENT_READ,'stderr')
        while selector.get_map():
            if time.monotonic()>deadline:reason='WALL_DEADLINE';break
            for key,_ in selector.select(.05):
                stream=key.fileobj;kind=key.data
                if kind=='input':
                    try:n=os.write(stream.fileno(),pending[:65536])
                    except BrokenPipeError:
                        selector.unregister(stream);stream.close();continue
                    del pending[:n]
                    if not pending:
                        selector.unregister(stream)
                        if entry is not None:stream.close()
                else:
                    try:block=os.read(stream.fileno(),65536)
                    except BlockingIOError:continue
                    if not block:selector.unregister(stream);stream.close();continue
                    room=p['max_output_bytes']-len(out)-len(err)
                    target=out if kind=='stdout' else err;target.extend(block[:max(0,room)])
                    if len(block)>room:reason='OUTPUT_BOUND';break
                    if kind=='stdout' and ready is None:
                        partial.extend(block)
                        if b'\n' in partial:
                            first=partial.split(b'\n',1)[0]
                            try:frame=load_bytes(first)
                            except Refusal:reason='BOOT_PROTOCOL';break
                            if frame.get('kind')!='READY':reason='BOOT_REFUSED';break
                            require(frame['request_root']==q['root'] and frame['policy_root']==p['root'] and frame['candidate_started'] is False,'READY_SUBJECT')
                            ready=frame
                            # Read-only observation of our own child. No forbidden-action probe.
                            witness=process_witness(proc.pid)
                            entry=authority.release_entry(context['grant'],q['root'],context['observer_public']['root'],now=clock())
                            pending=bytearray(b'GO\n')
                            selector.register(proc.stdin,selectors.EVENT_WRITE,'input')
            if reason:break
            if proc.poll() is not None:
                if proc.stdin and not proc.stdin.closed:
                    try:selector.unregister(proc.stdin)
                    except KeyError:pass
                    proc.stdin.close()
        if reason and proc.poll() is None:proc.kill()
        returncode=proc.wait(timeout=3)
        # Finite post-exit drain to retain already written bounded output.
        for stream,target in [(proc.stdout,out),(proc.stderr,err)]:
            if stream and not stream.closed:
                while True:
                    try:block=os.read(stream.fileno(),65536)
                    except BlockingIOError:break
                    if not block:break
                    room=p['max_output_bytes']-len(out)-len(err);target.extend(block[:max(0,room)])
                    if len(block)>room:reason=reason or 'OUTPUT_BOUND';break
    except (OSError,Refusal,subprocess.TimeoutExpired,ValueError,KeyError) as exc:
        reason=getattr(exc,'code','HOST_PROCESS_UNCERTAIN:'+type(exc).__name__)
    finally:
        selector.close()
        if proc is not None:
            if proc.poll() is None:
                proc.kill()
                try:proc.wait(timeout=3)
                except subprocess.TimeoutExpired:reason='PROCESS_TERMINATION_UNRESOLVED'
            returncode=proc.returncode
            for stream in [proc.stdin,proc.stdout,proc.stderr]:
                if stream and not stream.closed:stream.close()
    try:
        frames=[load_bytes(line) for line in bytes(out).splitlines() if line]
        if len(frames)==2 and frames[0]==ready and frames[1].get('kind')=='RESULT' and frames[1].get('request_root')==q['root']:
            result=frames[1]['result']
        elif entry is not None:reason=reason or 'CHILD_REPORT_UNAVAILABLE'
    except (Refusal,AttributeError,KeyError):reason=reason or 'CHILD_REPORT_UNREADABLE'
    def after(path):
        try:return snapshot(Path(path))[0]['root']
        except (Refusal,OSError):return None
    return dict(request_root=q['root'],admission_root=admission['root'],entry_authorization=entry,
        started_at=started,finished_at=clock(),returncode=returncode,stdout_hex=bytes(out).hex(),stderr_hex=bytes(err).hex(),
        stop_reason=reason,parent_witness=witness,ready_frame=ready,child_result=result,
        source_after_root=after(b['source_path']),candidate_after_root=after(b['candidate_path']),
        observation_kind='LOCAL_SUPERVISOR_NOT_HARDWARE_ATTESTATION')


class HostSession:
    def __init__(self,folder,pins,*,observer:LocalKey|None=None,authority:Authority|None=None,clock=None):
        self.store=HostStore(Path(folder),pins);self.context=self.store.context;self.observer=observer;self.authority=authority
        self.clock=clock or canonical_integer_clock
        if observer is not None:require(observer.public['root']==pins['observer_root'],'OBSERVER_PIN')
        if authority is not None:require(authority.public['root']==pins['issuer_root'],'ISSUER_PIN')
    @classmethod
    def prepare(cls,batch_b_session,operation_id,folder,*,authority,observer,valid_seconds=120,clock=None):
        clock=clock or canonical_integer_clock;now=clock()
        require(observer.public['role']=='HOST_OBSERVER','OBSERVER_ROLE')
        bundle=batch_b_session.export(acknowledge_plaintext=True);pins=batch_b_session.pins()
        q=make_request(bundle,pins,operation_id,host_identity(),byte_hash(Path(__file__).with_name('child.py').read_bytes()),engine_identity()['root'])
        c=bundle['context']
        require(snapshot(Path(c['source_path']))[0]['root']==q['source_root'],'SOURCE_DRIFT')
        require(snapshot(Path(c['candidate_path']))[0]['root']==q['candidate_root'],'CANDIDATE_DRIFT')
        grant=authority.issue(operation_id,q['root'],observer.public['root'],now=now,valid_seconds=valid_seconds)
        context=record('context',request=q,batch_b_bundle=bundle,grant=grant,issuer_public=authority.public,
            observer_public=observer.public,created_at=now,disclosure='FULL_SOURCE_AND_PUBLIC_SIGNED_RECORDS_NO_PRIVATE_KEYS')
        validate_context(context,context['root']);store=HostStore.create(folder,context)
        return cls(folder,store.pins,observer=observer,authority=authority,clock=clock)
    def pins(self):return dict(self.store.pins)
    def current_task(self):
        s=self.store.state();next_action={'PREPARED':'RUN_ONCE_OR_CANCEL','DISPATCH_INTENT':'RECONCILE_NO_REDISPATCH',
            'ADMITTED':'RECONCILE_NO_REDISPATCH','OBSERVED':'FINALIZE_EXISTING_OBSERVATION',
            'FINALIZED':'EXPORT_OR_CREATE_SEPARATE_SUCCESSOR','CANCELLED':'NO_EXECUTION','ADMISSION_REFUSED':'NEW_ACCEPTANCE_REQUIRED'}[s['phase']]
        return record('current-task',phase=s['phase'],next_action=next_action,request_root=self.context['request']['root'],
            pins=self.pins(),receipt=s['receipt'],new_execution_permitted=s['phase']=='PREPARED',
            current_authority_not_established_by_read=True,**BOUNDARY)
    def execute(self,*,finalize=True):
        require(self.observer is not None and self.authority is not None,'HOST_SERVICES_REQUIRED')
        with self.store.exclusive():
            s=self.store.state()
            if s['phase']=='FINALIZED':return s['receipt']
            require(s['phase']=='PREPARED','ONE_ATTEMPT_ONLY_RECONCILE_REQUIRED')
            require(host_identity()==self.context['request']['host'],'HOST_CHANGED')
            self.store.append(self.observer,'DISPATCH_INTENT',{'request_root':self.context['request']['root']})
            try:
                admission=self.authority.consume(self.context['grant'],self.context['request']['root'],self.observer.public['root'],now=self.clock())
            except Refusal as exc:
                self.store.append(self.observer,'ADMISSION_REFUSED',{'reason':exc.code});return self.current_task()
            self.store.append(self.observer,'ADMITTED',{'admission':admission})
            observation=perform(self.context,admission,self.authority,self.clock)
            signed=self.observer.sign('observation',observation)
            # Validate before journaling; errors retain ADMITTED and prevent replay.
            derive_receipt(self.context,admission,signed)
            self.store.append(self.observer,'OBSERVED',{'observation':signed})
            return self._finalize() if finalize else self.current_task()
    def _finalize(self,permit=None):
        s=self.store.state()
        if s['phase']=='FINALIZED':return s['receipt']
        require(s['phase']=='OBSERVED','NO_TERMINAL_OBSERVATION_NO_REDISPATCH')
        receipt=derive_receipt(self.context,s['admission'],s['observation'])
        self.store.append(self.observer,'FINALIZED',{'receipt':receipt,'recovery_permit':permit,'recovery_at':self.clock() if permit is not None else None})
        return receipt
    def reconcile(self,permit):
        require(self.observer is not None and self.authority is not None,'RECOVERY_SERVICES_REQUIRED')
        with self.store.exclusive():
            s=self.store.state()
            if s['phase']=='FINALIZED':return s['receipt']
            self.authority.validate_recovery(permit,self.context['request'],self.pins()['head'],now=self.clock())
            if s['phase']=='OBSERVED':return self._finalize(permit)
            return record('reconciliation',status='UNRESOLVED_NO_REDISPATCH',phase=s['phase'],head=self.pins()['head'],
                permit_root=permit['root'],observed_absence_is_not_nonexecution=True,new_execution_permitted=False,**BOUNDARY)
    def cancel(self,reason='OWNER_CANCELLED_BEFORE_DISPATCH'):
        require(self.observer is not None,'OBSERVER_REQUIRED')
        with self.store.exclusive():
            require(self.store.state()['phase']=='PREPARED','CANCEL_BEFORE_DISPATCH_ONLY')
            self.store.append(self.observer,'CANCELLED',{'reason':reason});return self.current_task()
    def export(self,*,acknowledge_plaintext=False):return self.store.export(acknowledge_plaintext=acknowledge_plaintext)
    def verify(self):return verify_bundle(self.export(acknowledge_plaintext=True),expected_context_root=self.pins()['context_root'],expected_head=self.pins()['head'],issuer_root=self.pins()['issuer_root'],observer_root=self.pins()['observer_root'])
