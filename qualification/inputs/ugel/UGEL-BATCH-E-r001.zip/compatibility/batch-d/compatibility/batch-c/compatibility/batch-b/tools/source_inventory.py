"""Source custody helpers. Never imports the reference engine."""
from __future__ import annotations
import hashlib,json
from pathlib import Path
PREFIX=b"MOSAIC-UGEL-A1\x00"
def canonical(value): return json.dumps(value,ensure_ascii=True,sort_keys=True,separators=(",",":"),allow_nan=False).encode("ascii")
def root(value): return hashlib.sha256(PREFIX+canonical(value)).hexdigest()
def seal(value): return {**value,"root":root(value)}
def inventory(folder:Path):
    rows=[]
    for path in sorted(folder.rglob("*")):
        rel=path.relative_to(folder)
        if rel.as_posix()=="PACKAGE-MANIFEST.json": continue
        if any(p in {"__pycache__",".git"} for p in rel.parts) or rel.parts[0] in {"evidence","release"}: continue
        if path.is_symlink(): raise ValueError("SOURCE_SYMLINK_NOT_ALLOWED")
        if not path.is_file(): continue
        if path.suffix in {".pyc",".pyo"}: raise ValueError("BYTECODE_IN_SOURCE")
        data=path.read_bytes()
        rows.append({"path":rel.as_posix(),"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest()})
    return seal({"schema":"mosaic.ugel.batch-b.source-manifest.v1","files":rows,
                 "file_count":len(rows),"logical_bytes":sum(x["bytes"] for x in rows)})
