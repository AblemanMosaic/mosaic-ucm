"""Pinned unittest child. Trusted code only; -I/-S are import controls, not a sandbox.

No dependency on the installed parent package: this executable's bytes are pinned
by the host context. The candidate's direct unittest set must match the plan.
"""
from __future__ import annotations
import hashlib,io,json,os,sys,unittest
from pathlib import Path

def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('ascii')
def seal(x):return {**x,'root':hashlib.sha256(b'MOSAIC-UGEL-A1\x00'+canonical(x)).hexdigest()}
def flatten(suite):
    for test in suite:
        if isinstance(test,unittest.TestSuite):yield from flatten(test)
        else:yield test
class Result(unittest.TextTestResult):
    def __init__(self,*a,**kw):super().__init__(*a,**kw);self.rows=[];self.started=[];self.subtest_failures=[]
    def startTest(self,t):self.started.append(t.id());super().startTest(t)
    def addSuccess(self,t):self.rows.append({'id':t.id(),'status':'PASS'});super().addSuccess(t)
    def addFailure(self,t,e):self.rows.append({'id':t.id(),'status':'FAIL'});super().addFailure(t,e)
    def addError(self,t,e):self.rows.append({'id':t.id(),'status':'ERROR'});super().addError(t,e)
    def addSkip(self,t,r):self.rows.append({'id':t.id(),'status':'SKIP'});super().addSkip(t,r)
    def addExpectedFailure(self,t,e):self.rows.append({'id':t.id(),'status':'EXPECTED_FAILURE'});super().addExpectedFailure(t,e)
    def addUnexpectedSuccess(self,t):self.rows.append({'id':t.id(),'status':'UNEXPECTED_SUCCESS'});super().addUnexpectedSuccess(t)
    def addSubTest(self,t,sub,e):
        if e is not None:self.subtest_failures.append(t.id())
        super().addSubTest(t,sub,e)

def main():
    sys.dont_write_bytecode=True
    if len(sys.argv)!=3:raise SystemExit('REQUEST_AND_RESULT_REQUIRED')
    request=json.loads(Path(sys.argv[1]).read_bytes());result_path=Path(sys.argv[2])
    candidate=Path(request['candidate_path']).resolve()
    sys.path.insert(0,str(candidate));os.chdir(candidate)
    suite=unittest.defaultTestLoader.discover(str(candidate),pattern='test_*.py',top_level_dir=str(candidate))
    ids=sorted(t.id() for t in flatten(suite));expected=request['test_ids']
    if ids!=expected:
        result=seal({'schema':'mosaic.ugel.batch-b.child-result.v1','request_root':request['root'],
            'status':'INVENTORY_MISMATCH','discovered_ids':ids,'started_ids':[],'rows':[],
            'tests_run':0,'failures':0,'errors':0,'skips':0,'expected_failures':0,'unexpected_successes':0,
            'subtest_failures':[], 'log_sha256':hashlib.sha256(b'').hexdigest(),'log_bytes':0})
        rc=2
    else:
        log=io.StringIO(); run=unittest.TextTestRunner(stream=log,verbosity=2,resultclass=Result).run(suite)
        text=log.getvalue().encode('utf-8');print(log.getvalue(),end='')
        passed=(run.wasSuccessful() and not run.skipped and not run.expectedFailures and not run.unexpectedSuccesses
                and not run.subtest_failures and sorted(run.started)==expected
                and sorted(r['id'] for r in run.rows)==expected and all(r['status']=='PASS' for r in run.rows))
        result=seal({'schema':'mosaic.ugel.batch-b.child-result.v1','request_root':request['root'],
            'status':'PASS' if passed else 'FAIL','discovered_ids':ids,'started_ids':sorted(run.started),
            'rows':sorted(run.rows,key=lambda r:r['id']),'tests_run':run.testsRun,
            'failures':len(run.failures),'errors':len(run.errors),'skips':len(run.skipped),
            'expected_failures':len(run.expectedFailures),'unexpected_successes':len(run.unexpectedSuccesses),
            'subtest_failures':sorted(run.subtest_failures),'log_sha256':hashlib.sha256(text).hexdigest(),'log_bytes':len(text)})
        rc=0 if passed else 1
    fd=os.open(result_path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'wb') as f:f.write(canonical(result)+b'\n');f.flush();os.fsync(f.fileno())
    return rc
if __name__=='__main__':raise SystemExit(main())
