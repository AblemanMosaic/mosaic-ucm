"""Pure admission calculation. Inputs are host-pinned; no model is a checker."""
from __future__ import annotations
from .canonical import *
from .contracts import *


def evaluate(*, binding: dict, contract: dict, authority: dict, request: dict,
             evidence: dict[str, dict], now: int, used_operations: int,
             used_bytes: int, reserved: bool = False) -> dict:
    b=validate("binding",binding); c=validate("contract",contract)
    a=validate("authority",authority); q=validate("request",request)
    integer(now); integer(used_operations); integer(used_bytes)
    require(type(reserved) is bool,"RESERVATION_FLAG_INVALID")
    require(c["root"] == b["contract_root"] and c["subject_root"] == b["subject_root"]
            and c["jurisdiction_root"] == b["jurisdiction_root"],"HOST_BINDING_INVALID")
    cost=validate_parameters(q["effect"],q["parameters"])
    resources={r["id"]:r for r in b["resources"]}
    grant=next((g for g in a["grants"] if g["root"] == q["grant_root"]),None)
    checks=[]
    def check(name, ok, failure):
        checks.append({"id":name,"satisfied":bool(ok),"on_failure":failure})
    check("PROFILE",b["profile"] != "VERIFY_ONLY" and
          (b["profile"] == "LOCAL_REFERENCE" or q["effect"] in {ECHO,ADD}),"PROFILE_REFUSED")
    check("SUBJECT_CONTRACT",q["subject_root"] == b["subject_root"] and
          q["contract_root"] == c["root"],"STALE_CONTEXT")
    check("POLICY_EPOCH",q["epoch"] == c["epoch"] == a["epoch"],"STALE_CONTEXT")
    check("AUTHORITY_FRESH",a["valid_from"] <= now < a["valid_until"] and
          a["jurisdiction_root"] == b["jurisdiction_root"],"NEEDS_AUTHORIZATION")
    resource=resources.get(q["resource_id"])
    check("RESOURCE_BOUND",resource is not None and q["resource_id"] in c["resources"],"RESOURCE_REFUSED")
    adapter="simulation-v1" if q["effect"] in {ECHO,ADD} else "private-directory-v1"
    check("ADAPTER_BOUND",resource is not None and resource["adapter"] == adapter,"RESOURCE_REFUSED")
    check("CONTRACT_EFFECT",q["effect"] in c["effects"],"EFFECT_REFUSED")
    check("PER_OPERATION_LIMIT",cost <= c["max_operation_bytes"],"BUDGET_REFUSED")
    grant_ok=grant is not None
    if grant:
        grant_ok=(grant["ledger_id"] == b["ledger_id"] and grant["subject_root"] == b["subject_root"]
                  and grant["contract_root"] == c["root"] and grant["epoch"] == c["epoch"]
                  and grant["valid_from"] <= now < grant["valid_until"]
                  and grant["root"] not in a["revoked_grants"] and "EXECUTE" in grant["actions"]
                  and set(grant["effects"]) <= set(c["effects"])
                  and set(grant["resources"]) <= set(c["resources"])
                  and q["effect"] in grant["effects"] and q["resource_id"] in grant["resources"])
    check("GRANT",grant_ok,"NEEDS_AUTHORIZATION")
    check("BUDGET",grant is not None and
          used_operations + (0 if reserved else 1) <= grant["max_operations"] and
          used_bytes + (0 if reserved else cost) <= grant["max_total_bytes"],"BUDGET_REFUSED")
    required=c["obligations"].get(q["effect"],[])
    accepted=[]
    evidence_ok=True
    for reference in q["evidence_roots"]:
        candidate=evidence.get(reference)
        if candidate is None:
            evidence_ok=False; continue
        try:
            ev=validate("evidence",candidate)
            expected=make_evidence(q,ev["valid_until"])
            good=(reference == ev["root"] and ev == expected and now < ev["valid_until"])
        except Refusal:
            good=False
        if good: accepted.append(ev["checker_id"])
        else: evidence_ok=False
    check("EXACT_SUBJECT_EVIDENCE",evidence_ok and sorted(accepted) == sorted(required),"NEEDS_EVIDENCE")
    failed=[r["on_failure"] for r in checks if not r["satisfied"]]
    status=failed[0] if failed else "PERMITTED"
    return seal({"schema":SCHEMAS["decision"],"request_root":q["root"],
        "binding_root":b["root"],"authority_root":a["root"],"contract_root":c["root"],
        "at":now,"used_operations":used_operations,"used_bytes":used_bytes,
        "reserved":reserved,"reservation_bytes":cost,"checks":checks,"status":status,
        "execution_observed":False,"authorization_basis":"HOST_PINNED_REFERENCE_NO_SIGNATURE",**BOUNDARY})


def recovery_authorized(*, binding: dict, authority: dict, request: dict,
                        operation_head: str, permit_root: str, now: int) -> dict:
    b=validate("binding",binding); a=validate("authority",authority); q=validate("request",request)
    integer(now); hash_value(permit_root); hash_value(operation_head)
    require(b["profile"] != "VERIFY_ONLY","PROFILE_REFUSED")
    require(a["jurisdiction_root"] == b["jurisdiction_root"] and a["valid_from"] <= now < a["valid_until"],
            "RECOVERY_AUTHORITY_NOT_CURRENT")
    permit=next((x for x in a["recoveries"] if x["root"] == permit_root),None)
    require(permit is not None,"RECOVERY_PERMIT_MISSING")
    for k,v in {"ledger_id":b["ledger_id"],"operation_id":q["operation_id"],"request_root":q["root"],
                "operation_head":operation_head,"contract_root":b["contract_root"],"subject_root":b["subject_root"]}.items():
        require(permit[k] == v,"RECOVERY_BINDING_MISMATCH",k)
    require(permit["valid_from"] <= now < permit["valid_until"],"RECOVERY_PERMIT_NOT_CURRENT")
    return permit
