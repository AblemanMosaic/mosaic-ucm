# Process custody and recovery

| Persisted phase | Supported continuation |
|---|---|
| PREPARED | Execute once or cancel under the trusted local host API |
| DISPATCH_INTENT | Reconcile only; missing admission/observation does not establish nonexecution |
| ADMITTED | Reconcile only; the child may not have started, may run, or may have finished |
| OBSERVED | Verify the signed observation; derive and append the exact receipt |
| FINALIZED | Return the recorded receipt, never run the child again |
| CANCELLED / ADMISSION_REFUSED | Retain historical state; a new accepted operation is required |

An OS-held file lock covers execution or settlement in one host store. It releases
when the process exits; its persistent filename is not itself a lease. A durable
DISPATCH_INTENT is committed before the issuer is asked to spend the grant. The
issuer spends it once in its own transaction. ADMITTED is recorded before launch.
Even if a response between these stores is lost, another invocation cannot blindly
launch again from the existing host state.

The supervisor journals a signed OBSERVED event in one SQLite commit. Finalization
uses the same receipt derivation as offline verification. It requires no effect
adapter. A failed response to a successful finalization is handled by inspecting
and accepting the advanced head, then retrieving the recorded receipt.

A fresh caller may settle OBSERVED with a new recovery permit after execution
authority has expired. This does not refresh the old grant. If observation is
missing, reconciliation returns UNRESOLVED_NO_REDISPATCH. PID absence, current file
content, output absence and a timeout do not become historical nonexecution proof.
No destructive cleanup or replacement operation is automatically authorized.

The demonstration uses a normal process boundary: one interpreter records a real
observation and exits normally; another finalizes it. Tests of DISPATCH_INTENT and
ADMITTED are explicitly authored model-state fixtures. No abrupt crash, lost fsync,
forced kill or power-loss behavior is established by those fixtures.

If the supervisor itself disappears while a child runs, no future supervisor adopts
that PID by numeric identifier or repeats the action. The child retains its filter
and resource limits; absent a signed terminal observation, custody remains held.
This conservative boundary deliberately leaves some operations unresolved.
