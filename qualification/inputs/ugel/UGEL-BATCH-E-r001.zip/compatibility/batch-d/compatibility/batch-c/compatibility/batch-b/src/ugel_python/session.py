"""Controlled source-bound Python task/harness. All underlying Batch A code is unchanged."""
from __future__ import annotations
import os,time
from pathlib import Path
from ugel.canonical import *
from ugel.contracts import record,validate,REGISTRY,CHECKER,BOUNDARY
from ugel.adapters import PrivateDirectoryAdapter
from ugel.broker import Broker
from ugel.store import Ledger
from .model import (make,checked,validate_plan,snapshot,engine_manifest,runtime_manifest)
from .custody import TaskJournal,ZERO
from .semantics import (validate_context,replay_task,materialized_body,check_request,
                        derive_check_receipt,verify_task_bundle)
from .sdk import FileCapability,governed_task

class TaskSession:
    def __init__(self,folder:Path,*,expected_context_root:str,expected_task_head:str,
                 expected_effects_head:str,clock=None):
        self.folder=Path(folder).absolute();self.clock=clock or (lambda:int(time.time()))
        require(self.folder.is_dir() and not self.folder.is_symlink(),'TASK_ABSENT')
        self.context=validate_context(load_bytes((self.folder/'CONTEXT.json').read_bytes()),expected_context_root)
        self.task_head=hash_value(expected_task_head);self.effect_head=hash_value(expected_effects_head)
        self.journal=TaskJournal(self.folder/'task.sqlite',expected_context_root)
        self.ledger=Ledger(self.folder/'effects.sqlite',self.context['effect_binding']['root'])
        self._check_heads()
    @classmethod
    def initialize(cls,*,project:Path,plan:dict,expected_plan_root:str,output:Path,
                   acknowledge_trusted_code_execution:bool,clock=None,valid_seconds:int=3600,
                   timeout_ms:int=10000,max_output_bytes:int=100000):
        require(acknowledge_trusted_code_execution is True,'TRUSTED_CODE_EXECUTION_ACK_REQUIRED')
        p=validate_plan(plan,expected_plan_root);project=Path(project).resolve();output=Path(output).absolute()
        require(snapshot(project)[0]==p['source_manifest'],'SOURCE_DOES_NOT_MATCH_ACCEPTED_PLAN')
        require(not output.exists() and not output.is_symlink() and not output.is_relative_to(project)
                and not project.is_relative_to(output),'NEW_EXTERNAL_TASK_DIRECTORY_REQUIRED')
        now=integer((clock or (lambda:int(time.time())))());integer(valid_seconds,1,86400)
        integer(timeout_ms,100,120000);integer(max_output_bytes,1024,1000000)
        output.mkdir(mode=0o700)
        try:
            source=PrivateDirectoryAdapter(project,'source')
            candidate=PrivateDirectoryAdapter.initialize(output/'candidate','candidate')
            jurisdiction=digest({'host_reference':'local-owner-unbound-ugk','task_id':p['task_id']})
            contract=validate('contract',record('contract',subject_root=p['root'],jurisdiction_root=jurisdiction,
                epoch=1,effects=['fs.create','fs.read'],resources=['candidate','source'],max_operation_bytes=1000000,
                obligations={'fs.create':[CHECKER],'fs.read':[]}))
            binding=validate('binding',record('binding',ledger_id=p['task_id'],subject_root=p['root'],
                jurisdiction_root=jurisdiction,contract_root=contract['root'],profile='LOCAL_REFERENCE',
                registry_root=REGISTRY['root'],resources=[candidate.descriptor,source.descriptor],ugk_binding='NOT_BOUND'))
            grants=[];n=len(p['source_texts'])
            for rid,effects,count,total in [
                ('source',['fs.read'],n,sum(max(1,len(t.encode('utf-8'))) for t in p['source_texts'].values())),
                ('candidate',['fs.create','fs.read'],2*n,2*sum(max(1,len(t.encode('utf-8'))) for t in p['candidate_texts'].values()))]:
                grants.append(validate('grant',record('grant',grant_id=p['task_id']+'-'+rid,ledger_id=p['task_id'],
                    subject_root=p['root'],contract_root=contract['root'],epoch=1,effects=effects,resources=[rid],
                    actions=['CANCEL','EXECUTE'],valid_from=now,valid_until=now+valid_seconds,
                    max_operations=count,max_total_bytes=total)))
            authority=validate('authority',record('authority',issuer_id='local-owner-reference',jurisdiction_root=jurisdiction,
                epoch=1,valid_from=now,valid_until=now+valid_seconds,grants=sorted(grants,key=lambda g:g['root']),
                revoked_grants=[],recoveries=[]))
            engine=engine_manifest();runtime=runtime_manifest()
            checker=byte_digest(Path(__file__).with_name('checker_child.py').read_bytes())
            process_grant=make('process-grant',task_id=p['task_id'],plan_root=p['root'],
                source_root=p['source_manifest']['root'],candidate_root=p['candidate_manifest']['root'],
                engine_root=engine['root'],checker_sha256=checker,runtime_root=runtime['root'],test_ids=p['test_ids'],
                valid_from=now,valid_until=now+valid_seconds,max_runs=1,timeout_ms=timeout_ms,max_output_bytes=max_output_bytes,
                action='RUN_EXACT_TRUSTED_UNITTEST_SET',containment='COOPERATIVE_NOT_SANDBOXED',issuer='LOCAL_OWNER_REFERENCE_PIN')
            context=make('task-context',plan=p,source_path=str(project),candidate_path=str((output/'candidate').resolve()),
                engine=engine,runtime=runtime,checker_sha256=checker,effect_binding=binding,effect_contract=contract,
                effect_authority=authority,process_grant=process_grant,created_at=now,
                host_profile='COOPERATIVE_TRUSTED_PYTHON',native_ugk_binding='NOT_BOUND',
                authority_authentication='UNSIGNED_LOCAL_OWNER_PIN',disclosure='FULL_SOURCE_PARAMETERS_AND_GRANTS_NO_REDACTION')
            validate_context(context,context['root'])
            (output/'CONTEXT.json').write_bytes(canonical(context)+b'\n')
            Ledger.initialize(output/'effects.sqlite',binding['root'])
            TaskJournal.initialize(output/'task.sqlite',context['root'])
            session=cls(output,expected_context_root=context['root'],expected_task_head=ZERO,expected_effects_head=ZERO,clock=clock)
            (output/'INITIAL-PINS.json').write_bytes(canonical(session.pins())+b'\n')
            return session
        except Exception as exc:
            # The directory and possibly custody already exist. Never report no effects.
            raise Refusal('TASK_INITIALIZATION_INCOMPLETE_LOCAL_EFFECTS_PRESERVED',str(output)) from exc
    def pins(self):
        return {'context_root':self.context['root'],'task_head':self.task_head,'effects_head':self.effect_head,
                'trust_basis':'LOCAL_HOST_CHECKPOINT_NOT_INDEPENDENT_AUTHENTICATION'}
    def _check_heads(self):
        require(self.journal.head==self.task_head,'STALE_TASK_HEAD')
        require(self.ledger.head==self.effect_head,'STALE_EFFECTS_HEAD')
    def _check_engine(self):require(engine_manifest()==self.context['engine'],'TASK_ENGINE_CHANGED')
    def _broker(self,evidence=None,*,adapters=True):
        c=self.context;actual={}
        if adapters:
            for rid,key in [('source','source_path'),('candidate','candidate_path')]:
                actual[rid]=PrivateDirectoryAdapter(Path(c[key]),rid)
        return Broker(ledger=self.ledger,binding=c['effect_binding'],expected_binding_root=c['effect_binding']['root'],
                      contract=c['effect_contract'],authority=c['effect_authority'],
                      expected_authority_root=c['effect_authority']['root'],
                      trusted_authority_roots={c['effect_authority']['root']},evidence=evidence or {},
                      adapters=actual,clock=self.clock)
    def _effect_bundle(self):
        return self._broker(adapters=False).export(expected_head=self.effect_head,acknowledge_plaintext=True)
    def state(self):
        self._check_heads();return replay_task(self.context,self.journal.events(),self._effect_bundle())
    def available_capabilities(self):
        return ('source.read','candidate.create','candidate.read','python.check')
    def _handle(self,rid,effects):
        g=next(g for g in self.context['effect_authority']['grants'] if g['resources']==[rid])
        return FileCapability(self,rid,g['root'],tuple(effects),tuple(sorted(self.context['plan']['source_texts'])))
    @property
    def source(self):return self._handle('source',['fs.read'])
    @property
    def candidate(self):return self._handle('candidate',['fs.create','fs.read'])
    def current_task(self):
        state=self.state();phase=state['phase'];p=self.context['plan'];fresh={}
        for name,key,expected in [('source','source_path',p['source_manifest']),('candidate','candidate_path',p['candidate_manifest'])]:
            try:fresh[name]=snapshot(Path(self.context[key]))[0]==expected
            except (OSError,Refusal):fresh[name]=False
        next_action={'INITIALIZED':'MATERIALIZE_ACCEPTED_CANDIDATE','MATERIALIZED':'RUN_EXACT_TRUSTED_TESTS',
                     'CHECK_STARTED':'RECONCILE_CHECK_NO_AUTOMATIC_REDISPATCH','CHECK_OBSERVED':'FINALIZE_RECORDED_OBSERVATION',
                     'CHECKED_NOT_RELEASED':'EXPORT_FOR_REVIEW','CHECK_FAILED':'PROPOSE_SUCCESSOR_TASK',
                     'RECONCILIATION_REQUIRED':'REVIEW_UNRESOLVED_CHECK','SUBJECT_CHANGED_HOLD':'REVIEW_SUBJECT_DRIFT'}[phase]
        effects=self._broker(adapters=False).inspect(self.effect_head)
        unresolved=[k for k,o in effects['operations'].items() if o['state'] in {'STARTED','UNCERTAIN'}]
        if unresolved:next_action='RECONCILE_FILE_EFFECT_NO_REDISPATCH'
        grant_current=self.context['process_grant']['valid_from']<=self.clock()<self.context['process_grant']['valid_until']
        if not grant_current and phase in {'INITIALIZED','MATERIALIZED'}:next_action='CURRENT_AUTHORIZATION_REQUIRED'
        return make('current-task',task_id=p['task_id'],objective=p['objective'],phase=phase,context_root=self.context['root'],
            plan_root=p['root'],source_root=p['source_manifest']['root'],candidate_root=p['candidate_manifest']['root'],
            changed_paths=p['changed_paths'],protected_tests=p['protected_tests'],test_ids=p['test_ids'],
            task_head=self.task_head,effects_head=self.effect_head,current_content_matches=fresh,
            current_evidence_applicable=bool(state['receipt'] and all(fresh.values())),
            process_grant_current=grant_current,unresolved_file_operations=sorted(unresolved),next_action=next_action,
            supported_receipt=state['receipt'],native_ugk_binding='NOT_BOUND',host_containment='NOT_ESTABLISHED',**BOUNDARY)
    def _append(self,kind,body):
        event=self.journal.append(kind,body,expected_head=self.task_head);self.task_head=event['root'];return event
    @governed_task(requires=('source.read','candidate.create','candidate.read'))
    def materialize(self):
        self._check_engine();state=self.state()
        if state['phase']!='INITIALIZED':return self.current_task()
        p=self.context['plan']
        require(snapshot(Path(self.context['source_path']))[0]==p['source_manifest'],'SOURCE_CHANGED')
        for i,name in enumerate(sorted(p['source_texts'])):
            self.source.read(name,operation_id=f'read-source-{i}')
            self.candidate.create(name,p['candidate_texts'][name],operation_id=f'create-candidate-{i}')
            self.candidate.read(name,operation_id=f'read-candidate-{i}')
        require(snapshot(Path(self.context['candidate_path']))[0]==p['candidate_manifest'],'CANDIDATE_CHANGED')
        body=materialized_body(self.context,self._effect_bundle());self._append('MATERIALIZED',body)
        return self.current_task()
    def execute_check(self,*,finalize=True):
        from .process import TrustedPythonChecker
        self._check_heads();self._check_engine();state=self.state()
        if state['phase']=='CHECK_OBSERVED':return self.finalize() if finalize else self.current_task()
        if state['receipt'] is not None:return state['receipt']
        require(state['phase']=='MATERIALIZED','CHECK_NOT_READY_OR_RECONCILIATION_REQUIRED')
        p=self.context['plan']
        require(snapshot(Path(self.context['source_path']))[0]==p['source_manifest'],'SOURCE_CHANGED')
        require(snapshot(Path(self.context['candidate_path']))[0]==p['candidate_manifest'],'CANDIDATE_CHANGED')
        require(runtime_manifest()==self.context['runtime'],'PYTHON_RUNTIME_CHANGED')
        q=check_request(self.context,integer(self.clock()));self._append('CHECK_STARTED',{'request':q})
        try:
            obs=TrustedPythonChecker(self.context,self.folder).perform(q)
            derive_check_receipt(self.context,q,obs)
        except Exception as exc:
            obs=make('check-observation',request_root=q['root'],returncode=None,child_result=None,
                source_after=None,candidate_after=None,output_sha256=byte_digest(b''),output_bytes=0,
                stop_reason='ADAPTER_UNCERTAIN:'+type(exc).__name__,
                scope='COOPERATIVE_HOST_OBSERVATION_NOT_INDEPENDENT_ATTESTATION',
                effect_scope='LOCAL_PROCESS_AND_CUSTODY_POSSIBLE_FILESYSTEM_EFFECTS',
                host_containment='NOT_ESTABLISHED',external_network_prevention='NOT_ESTABLISHED')
        try:self._append('CHECK_OBSERVED',{'observation':obs})
        except Exception as exc:
            return make('pending-check',status='OBSERVATION_PENDING',context_root=self.context['root'],
                        last_committed_task_head=self.task_head,effects_head=self.effect_head,pending_observation=obs,
                        no_redispatch=True,error=type(exc).__name__,**BOUNDARY)
        return self.finalize() if finalize else self.current_task()
    def finalize(self):
        self._check_heads();self._check_engine();state=self.state()
        if state['receipt'] is not None:return state['receipt']
        require(state['phase']=='CHECK_OBSERVED','RECORDED_CHECK_OBSERVATION_REQUIRED')
        receipt=derive_check_receipt(self.context,state['request'],state['observation'])
        self._append('CHECK_FINALIZED',{'receipt':receipt});return receipt
    def run(self):
        self.materialize();return self.execute_check()
    def export(self,*,acknowledge_plaintext=False):
        require(acknowledge_plaintext is True,'EXPLICIT_SOURCE_AND_GRANT_DISCLOSURE_REQUIRED')
        self._check_heads()
        return make('task-bundle',context=self.context,task_events=self.journal.events(),effects_bundle=self._effect_bundle(),
                    task_head=self.task_head,effects_head=self.effect_head,disclosure=self.context['disclosure'])
    def verify_export(self,bundle):
        return verify_task_bundle(bundle,expected_context_root=self.context['root'],expected_task_head=self.task_head,
                                  expected_effects_head=self.effect_head)
