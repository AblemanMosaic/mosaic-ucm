"""Passive package/source consistency and ordinary CLI entrypoint checks."""
import hashlib,json,subprocess,sys,unittest,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
class DistributionTests(unittest.TestCase):
    def test_batch_a_archive_pin(self):
        archive=ROOT/'predecessors/UGEL-BATCH-A-r001.zip'
        self.assertEqual(hashlib.sha256(archive.read_bytes()).hexdigest(),
                         '4fc49f0a9cf46a0b83d2de593768981991413434c6726ae7351ae611a076df27')
    def test_all_batch_a_engine_and_test_bytes_unchanged(self):
        with zipfile.ZipFile(ROOT/'predecessors/UGEL-BATCH-A-r001.zip') as z:
            names=[n for n in z.namelist() if n.startswith('src/ugel/') or n in {'tests/test_reference.py','tests/__init__.py'}]
            for n in names:self.assertEqual((ROOT/n).read_bytes(),z.read(n),n)
    def test_standard_library_orientation_entrypoint(self):
        p=subprocess.run([sys.executable,'-I','-S','-B',str(ROOT/'run.py'),'orient'],capture_output=True,text=True,timeout=10)
        self.assertEqual(p.returncode,0,p.stderr)
        self.assertFalse(json.loads(p.stdout)['os_sandbox'])
    def test_module_entrypoint_is_present(self):
        text=(ROOT/'src/ugel_python/__main__.py').read_text()
        self.assertIn('raise SystemExit(main())',text)
    def test_batch_b_machine_fields_match_implementation(self):
        from ugel_python import semantics
        doc=json.loads((ROOT/'spec/PYTHON-CONTRACTS.json').read_bytes())
        expected={'context':semantics.CONTEXT_FIELDS,'process_grant':semantics.PROCESS_GRANT_FIELDS,
                  'child_result':semantics.CHILD_FIELDS,'check_observation':semantics.OBS_FIELDS}
        self.assertEqual(doc['required_fields'],{k:sorted(v|{'schema','root'}) for k,v in expected.items()})
    def test_native_bridge_is_explicitly_unbound(self):
        record=json.loads((ROOT/'spec/NATIVE-BINDING.json').read_bytes())
        self.assertEqual(record['status'],'NOT_BOUND')
        self.assertEqual(record['host_containment'],'NOT_ESTABLISHED')
        self.assertFalse(record['release_authorized'])
