"""Transparent fixture hosts. No real identity, UGK authority, or application binding."""
from __future__ import annotations
from pathlib import Path
from .canonical import *
from .contracts import *
from .adapters import SimulationAdapter, PrivateDirectoryAdapter
from .broker import Broker
from .store import Ledger
from .history import verify_bundle

class ReferenceHost:
    """A host fixture for demonstrations and normal-workflow unit checks.

    Authority is injected by trusted host code, NOT derived from requests.
    This is not a credential system or a real application deployment.
    """
    def __init__(self, folder:Path, *, profile="LOCAL_REFERENCE", now=1000,
                 max_operations=20,max_total_bytes=2_000_000, grant_until=2000,
                 require_text_evidence=True):
        self.folder=Path(folder); self.now=now
        require(self.folder.is_dir(),"HOST_PARENT_REQUIRED")
        sim=SimulationAdapter("simulation")
        local=PrivateDirectoryAdapter.initialize(self.folder/"workspace","workspace")
        self.adapters={"simulation":sim,"workspace":local}
        subject=digest({"fixture_subject":"batch-a-example-not-application-source"})
        jurisdiction=digest({"fixture_jurisdiction":"no-external-authority"})
        obligations={e:([CHECKER] if require_text_evidence and e in {ECHO,CREATE} else []) for e in sorted(EFFECTS)}
        self.contract=validate("contract",record("contract",subject_root=subject,jurisdiction_root=jurisdiction,
            epoch=1,effects=sorted(EFFECTS),resources=["simulation","workspace"],max_operation_bytes=1_000_000,obligations=obligations))
        self.binding=validate("binding",record("binding",ledger_id="demo-ledger",subject_root=subject,jurisdiction_root=jurisdiction,
            contract_root=self.contract["root"],profile=profile,registry_root=REGISTRY["root"],
            resources=[sim.descriptor,local.descriptor],ugk_binding="NOT_BOUND"))
        self.grant=validate("grant",record("grant",grant_id="fixture-execution",ledger_id="demo-ledger",subject_root=subject,
            contract_root=self.contract["root"],epoch=1,effects=sorted(EFFECTS),resources=["simulation","workspace"],
            actions=["CANCEL","EXECUTE"],valid_from=900,valid_until=grant_until,max_operations=max_operations,max_total_bytes=max_total_bytes))
        self.authority=self._authority([],[])
        self.trusted={self.authority["root"]}; self.evidence={}
        self.ledger=Ledger.initialize(self.folder/"ledger.sqlite",self.binding["root"])
        self.broker=self.reopen()

    def _authority(self,revoked:list,recoveries:list):
        return validate("authority",record("authority",issuer_id="fixture-owner",jurisdiction_root=self.binding["jurisdiction_root"],
            epoch=1,valid_from=0,valid_until=10000,grants=[self.grant],revoked_grants=sorted(revoked),
            recoveries=sorted(recoveries,key=lambda x:x["root"])))

    def reopen(self):
        self.broker=Broker(ledger=Ledger(self.folder/"ledger.sqlite",self.binding["root"]),binding=self.binding,
            expected_binding_root=self.binding["root"],contract=self.contract,authority=self.authority,
            expected_authority_root=self.authority["root"],trusted_authority_roots=self.trusted,
            evidence=self.evidence,adapters=self.adapters,clock=lambda:self.now)
        return self.broker

    def request(self,operation_id:str,effect:str,parameters:dict,*,with_evidence=True,evidence_until=2000):
        q=record("request",operation_id=operation_id,subject_root=self.binding["subject_root"],contract_root=self.contract["root"],
                 grant_root=self.grant["root"],epoch=1,effect=effect,
                 resource_id="simulation" if effect in {ECHO,ADD} else "workspace",parameters=parameters,evidence_roots=[])
        if with_evidence and self.contract["obligations"][effect]:
            ev=make_evidence(q,evidence_until); self.evidence[ev["root"]]=ev
            q=seal({**{k:v for k,v in q.items() if k!="root"},"evidence_roots":[ev["root"]]})
        self.reopen()
        return validate("request",q)

    def run(self,q):
        admitted=self.broker.admit(q,expected_head=self.ledger.head)
        if admitted["status"]!="ADMITTED": return admitted
        dispatched=self.broker.dispatch(q["operation_id"],expected_head=admitted["head"])
        if dispatched["status"] not in {"OBSERVED","DECLINED"}: return dispatched
        return self.broker.finalize(q["operation_id"],expected_head=dispatched["head"])

    def revoke(self):
        self.authority=self._authority([self.grant["root"]],[]); self.trusted.add(self.authority["root"]); self.reopen()

    def recovery(self,operation_id):
        op=self.broker.inspect()["operations"][operation_id]
        permit=record("recovery",permit_id="recovery-"+operation_id,ledger_id=self.binding["ledger_id"],
            operation_id=operation_id,request_root=op["request"]["root"],operation_head=op["operation_head"],
            contract_root=self.contract["root"],subject_root=self.binding["subject_root"],
            valid_from=self.now,valid_until=self.now+60,action="OBSERVE_ONLY")
        self.authority=self._authority([], [permit]); self.trusted.add(self.authority["root"]); self.reopen()
        return permit

    def export(self):
        return self.broker.export(expected_head=self.ledger.head,acknowledge_plaintext=True)


def run_demo(output:Path)->dict:
    output=Path(output)
    require(not output.exists(),"DEMO_OUTPUT_MUST_BE_NEW")
    output.mkdir(mode=0o700)
    host=ReferenceHost(output)
    outcomes=[]
    for oid,effect,params in [
        ("echo",ECHO,{"text":"Explicit intent; bounded effect."}),
        ("sum",ADD,{"left":19,"right":23}),
        ("create-report",CREATE,{"name":"report.txt","text":"UGEL Batch A controlled local demonstration.\n"})]:
        q=host.request(oid,effect,params); result=host.run(q)
        outcomes.append({"operation":oid,"receipt":result["receipt"]})
    data=(output/"workspace"/"report.txt").read_bytes()
    q=host.request("read-report",READ,{"name":"report.txt","expected_sha256":byte_digest(data),"max_bytes":4096})
    admitted=host.broker.admit(q,expected_head=host.ledger.head)
    observed=host.broker.dispatch(q["operation_id"],expected_head=admitted["head"])
    require(observed["data"]==data,"DEMO_READBACK_MISMATCH")
    # Supported phase boundary: reopen and derive final receipt without execution.
    host.reopen()
    finalized=host.broker.finalize(q["operation_id"],expected_head=host.ledger.head)
    outcomes.append({"operation":"read-report","receipt":finalized["receipt"]})
    q=host.request("cancelled",ADD,{"left":1,"right":2})
    a=host.broker.admit(q,expected_head=host.ledger.head)
    cancelled=host.broker.cancel(q["operation_id"],expected_head=a["head"])
    outcomes.append({"operation":"cancelled","receipt":cancelled["receipt"]})
    missing=host.request("await-evidence",ECHO,{"text":"No approval implied."},with_evidence=False)
    decision=host.broker.preview(missing,expected_head=host.ledger.head)
    bundle=host.export()
    checked=verify_bundle(bundle,expected_binding_root=host.binding["root"],expected_head=host.ledger.head,
                          trusted_authority_roots=host.trusted)
    pins={"binding_root":host.binding["root"],"head":host.ledger.head,"authority_roots":sorted(host.trusted),
          "trust_basis":"DEMONSTRATION_HOST_PIN_ONLY"}
    for name,value in [("BUNDLE.json",bundle),("PINS.json",pins),("REPLAY.json",checked),("PENDING-DECISION.json",decision),("BINDING.json",host.binding),("CONTRACT.json",host.contract)]:
        (output/name).write_bytes(canonical(value)+b"\n")
    report=seal({"schema":PREFIX+"demo-result.v1","status":"PASS_REFERENCE_WORKFLOW", "operations":outcomes,
       "reopen_finalize":"PASS_WITHOUT_REDISPATCH", "missing_evidence_decision":decision["status"],
       "event_count":len(bundle["events"]),"bundle_root":bundle["root"],"replay_root":checked["root"],
       "mode":"CONTROLLED_LOCAL_FIXTURE","authority_authentication":"NOT_BOUND", "ugk_binding":"NOT_BOUND",**BOUNDARY})
    (output/"DEMO-RESULT.json").write_bytes(canonical(report)+b"\n")
    return report
