"""One host-pinned trusted test process. No generic shell/process execution API."""
from __future__ import annotations
import os,subprocess,threading,time
from pathlib import Path
from ugel.canonical import canonical,byte_digest,load_bytes,require,Refusal
from .model import make,snapshot,runtime_manifest

class TrustedPythonChecker:
    def __init__(self,context:dict,task_dir:Path):
        self.context=context;self.folder=Path(task_dir)
    def perform(self,request:dict)->dict:
        c=self.context;p=c['plan'];run_dir=self.folder/'check'
        from .semantics import check_request
        require(request==check_request(c,request.get('at')),'CHECK_REQUEST_NOT_REDERIVED')
        require(runtime_manifest()==c['runtime'],'PYTHON_RUNTIME_CHANGED')
        driver=Path(__file__).with_name('checker_child.py')
        require(byte_digest(driver.read_bytes())==c['checker_sha256'],'CHECKER_CHANGED')
        require(snapshot(Path(c['source_path']))[0]==p['source_manifest'],'SOURCE_CHANGED')
        require(snapshot(Path(c['candidate_path']))[0]==p['candidate_manifest'],'CANDIDATE_CHANGED')
        run_dir.mkdir(mode=0o700) # existing run dir is never overwritten/reused
        request_path=run_dir/'REQUEST.json';result_path=run_dir/'RESULT.json'
        request_path.write_bytes(canonical(request)+b'\n')
        env={k:os.environ[k] for k in ('SYSTEMROOT','WINDIR','COMSPEC','LANG','LC_ALL') if k in os.environ}
        env.update({'PYTHONHASHSEED':'0','PYTHONDONTWRITEBYTECODE':'1'})
        args=[c['runtime']['executable'],'-I','-S','-B',str(driver),str(request_path),str(result_path)]
        output=bytearray();limit=request['max_output_bytes'];stop=threading.Event();reason=None;process=None
        started=time.monotonic()
        try:
            process=subprocess.Popen(args,cwd=c['candidate_path'],env=env,stdin=subprocess.DEVNULL,
                                     stdout=subprocess.PIPE,stderr=subprocess.STDOUT,shell=False)
            def drain():
                try:
                    while True:
                        block=process.stdout.read(4096)
                        if not block:break
                        remaining=limit-len(output)
                        output.extend(block[:max(0,remaining)])
                        if len(block)>remaining:stop.set();break
                except OSError:stop.set()
            thread=threading.Thread(target=drain,daemon=True);thread.start()
            while process.poll() is None:
                if stop.is_set():reason='OUTPUT_LIMIT';break
                if time.monotonic()-started>request['timeout_ms']/1000:reason='TIME_LIMIT';break
                time.sleep(.01)
            if reason is not None:
                process.kill();process.wait(timeout=5)
            thread.join(timeout=2)
            if thread.is_alive():reason='OUTPUT_STREAM_UNRESOLVED'
            if stop.is_set() and reason is None:reason='OUTPUT_LIMIT'
            returncode=process.returncode
        except OSError as exc:
            reason='PROCESS_OR_IO_UNCERTAIN:'+type(exc).__name__;returncode=None
        except subprocess.TimeoutExpired:
            reason='PROCESS_TERMINATION_UNRESOLVED';returncode=None
        finally:
            if process is not None and process.poll() is None:
                process.kill()
                try:process.wait(timeout=2)
                except subprocess.TimeoutExpired:pass
            if process is not None and process.stdout is not None:
                # Close only when the reader has ended; no join of an unbounded inherited pipe.
                if 'thread' not in locals() or not thread.is_alive():process.stdout.close()
        raw=bytes(output);(run_dir/'OUTPUT.log').write_bytes(raw)
        try:child=load_bytes(result_path.read_bytes()) if result_path.exists() else None
        except (OSError,Refusal):child=None;reason=reason or 'CHILD_RESULT_UNREADABLE'
        try:source_after=snapshot(Path(c['source_path']))[0]
        except (Refusal,OSError):source_after=None
        try:candidate_after=snapshot(Path(c['candidate_path']))[0]
        except (Refusal,OSError):candidate_after=None
        return make('check-observation',request_root=request['root'],returncode=returncode,
                    child_result=child,source_after=source_after,candidate_after=candidate_after,
                    output_sha256=byte_digest(raw),output_bytes=len(raw),stop_reason=reason,
                    scope='COOPERATIVE_HOST_OBSERVATION_NOT_INDEPENDENT_ATTESTATION',
                    effect_scope='LOCAL_PROCESS_AND_CUSTODY_POSSIBLE_FILESYSTEM_EFFECTS',
                    host_containment='NOT_ESTABLISHED',external_network_prevention='NOT_ESTABLISHED')
