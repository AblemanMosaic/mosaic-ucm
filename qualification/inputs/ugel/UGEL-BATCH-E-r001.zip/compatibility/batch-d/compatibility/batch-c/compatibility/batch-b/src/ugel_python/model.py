"""Exact flat-project snapshots and accepted candidate plans. No candidate imports."""
from __future__ import annotations
import ast
import os
import stat
from pathlib import Path
from ugel.canonical import (Refusal, require, exact, seal, rooted, canonical, digest,
                            byte_digest, identifier, integer, hash_value, copy)
from ugel.contracts import BOUNDARY, filename

PREFIX = "mosaic.ugel.batch-b."
MAX_FILE = 500_000
MAX_TOTAL = 2_000_000
MAX_FILES = 32

def make(record_kind: str, **values) -> dict:
    return seal({"schema": PREFIX + record_kind + ".v1", **values})

def checked(value: dict, kind: str, fields: set[str]) -> dict:
    return rooted(value, PREFIX + kind + ".v1", fields)

def file_name(name: str) -> str:
    filename(name)
    require(name.endswith('.py') and name[:-3].isidentifier(), 'FLAT_PYTHON_MODULE_REQUIRED')
    return name

def read_file(path: Path) -> bytes:
    try:
        before=path.lstat()
        require(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and not path.is_symlink(),
                'REGULAR_SINGLE_LINK_FILE_REQUIRED')
        flags=os.O_RDONLY | getattr(os,'O_NOFOLLOW',0) | getattr(os,'O_BINARY',0)
        fd=os.open(path,flags)
        with os.fdopen(fd,'rb') as f:
            opened=os.fstat(f.fileno()); data=f.read(MAX_FILE+1); after=os.fstat(f.fileno())
        attrs=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)
        require(attrs(before)==attrs(opened)==attrs(after),'SOURCE_CHANGED_DURING_READ')
        require(len(data)<=MAX_FILE,'SOURCE_FILE_LIMIT')
        return data
    except OSError as exc:
        raise Refusal('SOURCE_OBSERVATION_UNAVAILABLE',type(exc).__name__) from exc

def tree_from_texts(texts: dict[str,str]) -> dict:
    require(type(texts) is dict and 0<len(texts)<=MAX_FILES,'PROJECT_FILE_COUNT')
    rows=[]; total=0
    for name,text in sorted(texts.items()):
        file_name(name); require(type(text) is str,'UTF8_SOURCE_REQUIRED')
        data=text.encode('utf-8'); require(len(data)<=MAX_FILE,'SOURCE_FILE_LIMIT')
        total+=len(data); rows.append({'path':name,'bytes':len(data),'sha256':byte_digest(data)})
    require(total<=MAX_TOTAL,'SOURCE_TOTAL_LIMIT')
    return make('project-manifest',files=rows,file_count=len(rows),logical_bytes=total)

def snapshot(path: Path) -> tuple[dict,dict[str,str]]:
    """Closed flat tree. No ignore rules, generated files, links or imports."""
    path=Path(path)
    try:
        before=path.lstat()
        require(stat.S_ISDIR(before.st_mode) and not path.is_symlink(),'PROJECT_DIRECTORY_REQUIRED')
        names=sorted(p.name for p in path.iterdir()); texts={}
        require(0<len(names)<=MAX_FILES,'PROJECT_FILE_COUNT')
        for name in names:
            file_name(name)
            try: texts[name]=read_file(path/name).decode('utf-8')
            except UnicodeError as exc: raise Refusal('UTF8_SOURCE_REQUIRED') from exc
        after=path.lstat()
        require(names==sorted(p.name for p in path.iterdir()) and
                (before.st_dev,before.st_ino)==(after.st_dev,after.st_ino),'SOURCE_INVENTORY_CHANGED')
        return tree_from_texts(texts),texts
    except OSError as exc:
        raise Refusal('SOURCE_OBSERVATION_UNAVAILABLE',type(exc).__name__) from exc

def test_ids(texts: dict[str,str]) -> list[str]:
    """Supported subset: top-level unittest.TestCase classes and direct test methods."""
    out=[]
    for name,text in sorted(texts.items()):
        try: tree=ast.parse(text,filename=name)
        except SyntaxError as exc: raise Refusal('PYTHON_SYNTAX_INVALID',name) from exc
        if not name.startswith('test_'): continue
        require(not any(isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name=='load_tests'
                        for n in tree.body),'DYNAMIC_TEST_LOADER_UNSUPPORTED')
        for cls in tree.body:
            if not isinstance(cls,ast.ClassDef): continue
            bases=[ast.unparse(b) for b in cls.bases]
            if bases not in [['unittest.TestCase'],['TestCase']]:
                require(not any(isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name.startswith('test_')
                                for n in cls.body),'TEST_INHERITANCE_UNSUPPORTED')
                continue
            require(not cls.decorator_list,'DECORATED_TEST_CLASS_UNSUPPORTED')
            for n in cls.body:
                if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name.startswith('test_'):
                    require(isinstance(n,ast.FunctionDef) and not n.decorator_list,'ASYNC_OR_DECORATED_TEST_UNSUPPORTED')
                    out.append(name[:-3]+'.'+cls.name+'.'+n.name)
    require(out and len(out)==len(set(out)),'STATIC_NONEMPTY_TEST_SET_REQUIRED')
    return sorted(out)

PLAN_FIELDS={'task_id','objective','source_manifest','candidate_manifest','source_texts','candidate_texts',
             'changed_paths','protected_tests','test_ids','proposal_root','claim_scope'}

def plan_from_texts(task_id: str, objective: str, source: dict[str,str], replacements: dict[str,str]) -> dict:
    identifier(task_id); require(type(objective) is str and 0<len(objective)<=2000,'OBJECTIVE_REQUIRED')
    tree_from_texts(source)
    require(type(replacements) is dict and set(replacements)<=set(source),'EXISTING_FILES_ONLY')
    require(all(not n.startswith('test_') for n in replacements),'TRUSTED_TEST_CHANGE_REQUIRES_NEW_TASK')
    candidate={**source,**replacements}; candidate_manifest=tree_from_texts(candidate)
    expected=test_ids(source); require(test_ids(candidate)==expected,'TEST_SET_CHANGED')
    changes=sorted(n for n in source if candidate[n]!=source[n])
    protected=sorted(n for n in source if n.startswith('test_'))
    proposal=make('proposal',replacements=replacements)
    return make('task-plan',task_id=task_id,objective=objective,source_manifest=tree_from_texts(source),
                candidate_manifest=candidate_manifest,source_texts=source,candidate_texts=candidate,
                changed_paths=changes,protected_tests=protected,test_ids=expected,proposal_root=proposal['root'],
                claim_scope='DECLARED_UNITTEST_BEHAVIOR_ONLY_NOT_GENERAL_CORRECTNESS')

def validate_plan(value: dict, expected_root: str) -> dict:
    p=checked(value,'task-plan',PLAN_FIELDS); require(p['root']==hash_value(expected_root),'PLAN_PIN_MISMATCH')
    replacements={n:p['candidate_texts'][n] for n in p['changed_paths']}
    # The normalized proposal contains only changes. No-op keys are deliberately refused.
    expected=plan_from_texts(p['task_id'],p['objective'],p['source_texts'],replacements)
    require(p==expected,'PLAN_NOT_REDERIVED')
    return p

def propose(project: Path, task_id: str, objective: str, replacements: dict[str,str]) -> dict:
    _,source=snapshot(project)
    replacements={n:t for n,t in replacements.items() if n not in source or t!=source[n]}
    p=plan_from_texts(task_id,objective,source,replacements)
    return validate_plan(p,p['root'])

def engine_manifest() -> dict:
    source=Path(__file__).resolve().parents[1]
    rows=[]
    for package in ['ugel','ugel_python']:
        for p in sorted((source/package).glob('*.py')):
            data=p.read_bytes(); rows.append({'path':p.relative_to(source).as_posix(),'sha256':byte_digest(data),'bytes':len(data)})
    return make('engine-manifest',files=rows)

def runtime_manifest() -> dict:
    import platform,sys
    executable=Path(sys.executable).resolve()
    return make('runtime-manifest',executable=str(executable),executable_sha256=byte_digest(executable.read_bytes()),
                implementation=platform.python_implementation(),version=platform.python_version(),
                platform=platform.system(),stdlib_closure='NOT_HASHED',host_containment='NOT_ESTABLISHED')
