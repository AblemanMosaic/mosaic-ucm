import unittest
from invoice import total_cents

class InvoiceTests(unittest.TestCase):
    def test_empty(self):
        self.assertEqual(total_cents([]), 0)
    def test_single_quantity(self):
        self.assertEqual(total_cents([(125, 1)]), 125)
    def test_multiple_quantities(self):
        self.assertEqual(total_cents([(125, 3), (40, 2)]), 455)
    def test_zero_quantity(self):
        self.assertEqual(total_cents([(100, 0)]), 0)
    def test_discount(self):
        self.assertEqual(total_cents([(125, 1)], 25), 100)
    def test_invalid_line(self):
        with self.assertRaises(ValueError):
            total_cents([(-1, 2)])
