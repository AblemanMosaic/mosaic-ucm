"""Passive custody helpers; imports no candidate package."""
from __future__ import annotations
import hashlib,json
from pathlib import Path
DOMAIN=b'MOSAIC-UGEL-C1\x00'
def canonical(x):return json.dumps(x,ensure_ascii=True,sort_keys=True,separators=(',',':'),allow_nan=False).encode('ascii')
def digest(x):return hashlib.sha256(DOMAIN+canonical(x)).hexdigest()
def seal(x):return {**x,'root':digest(x)}
def inventory(root):
    rows=[]
    for p in sorted(Path(root).rglob('*')):
        rel=p.relative_to(root)
        if any(x in {'.git','__pycache__'} for x in rel.parts) or rel.parts[0] in {'evidence','release'} or rel.as_posix()=='PACKAGE-MANIFEST.json':continue
        if p.is_symlink():raise ValueError('SOURCE_SYMLINK')
        if not p.is_file():continue
        if p.suffix in {'.pyc','.pyo'}:raise ValueError('BYTECODE_IN_SOURCE')
        b=p.read_bytes();rows.append({'path':rel.as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
    return seal({'schema':'mosaic.ugel.batch-c.source-manifest.v1','files':rows,'file_count':len(rows),'logical_bytes':sum(r['bytes'] for r in rows)})
