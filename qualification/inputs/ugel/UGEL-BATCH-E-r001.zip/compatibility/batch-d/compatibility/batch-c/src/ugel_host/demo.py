"""Ordinary coding demonstration. No escape attempts, fault injection or network."""
from __future__ import annotations
import json,subprocess,sys,tempfile,time
from pathlib import Path
from .common import *
from .trust import Authority,LocalKey
from .service import HostSession
from .semantics import verify_bundle
from .policy import host_identity,policy
from ugel_python import propose,TaskSession

ROOT=Path(__file__).resolve().parents[2]
# __file__ -> ugel_host -> src -> package root

def demonstration(output:Path):
    output=Path(output);output.mkdir(mode=0o700)
    with tempfile.TemporaryDirectory(prefix='ugel-c-ordinary-') as tmp:
        work=Path(tmp);project=work/'project';project.mkdir()
        fixture=ROOT/'compatibility/batch-b/examples/project'
        for p in fixture.glob('*.py'):write_new(project/p.name,p.read_bytes())
        original={p.name:byte_hash(p.read_bytes()) for p in project.glob('*.py')}
        replacements=read_json(ROOT/'compatibility/batch-b/examples/REPAIR-PROPOSAL.json')['replacements']
        authority=Authority.create(work/'authority');observer=LocalKey.create(work/'observer','HOST_OBSERVER')
        runs={}
        for name,changes in [('baseline',{}),('repair',replacements)]:
            plan=propose(project,'invoice-'+name,'Check declared integer invoice behavior',changes)
            b=TaskSession.initialize(project=project,plan=plan,expected_plan_root=plan['root'],output=work/('b-'+name),acknowledge_trusted_code_execution=True)
            b.materialize()
            c=HostSession.prepare(b,'check-'+name,work/('host-'+name),authority=authority,observer=observer)
            c.execute(finalize=False)
            run=output/name;run.mkdir(mode=0o700)
            write_json(run/'OBSERVED-PINS.json',c.pins());write_json(run/'OBSERVED-CONTEXT.json',c.current_task())
            permit=authority.recovery_permit(c.context['request']['root'],'check-'+name,c.pins()['head'],now=int(time.time()))
            permit_path=work/('permit-'+name+'.json');write_json(permit_path,permit)
            # A new interpreter finalizes an already committed host observation.
            args=[sys.executable,'-B',str(ROOT/'run.py'),'reconcile',str(work/('host-'+name)),
                  '--pins',str(run/'OBSERVED-PINS.json'),'--authority',str(work/'authority'),
                  '--observer',str(work/'observer'),'--permit',str(permit_path)]
            proc=subprocess.run(args,capture_output=True,timeout=20)
            require(proc.returncode in {0,3},'FRESH_FINALIZATION_PROCESS_FAILED',proc.stderr.decode(errors='replace')[:500])
            result=load_bytes(proc.stdout);pins=result['pins']
            c=HostSession(work/('host-'+name),pins)
            bundle=c.export(acknowledge_plaintext=True);verified=c.verify();state=c.store.state()
            write_json(run/'BUNDLE.json',bundle);write_json(run/'PINS.json',pins);write_json(run/'REPLAY.json',verified)
            write_json(run/'RECEIPT.json',state['receipt']);write_json(run/'RECOVERY-PERMIT.json',permit)
            observation=state['observation']['body'];write_json(run/'OBSERVATION.json',state['observation'])
            write_new(run/'CHILD-OUTPUT.jsonl',bytes.fromhex(observation['stdout_hex']));write_new(run/'CHILD-STDERR.log',bytes.fromhex(observation['stderr_hex']))
            runs[name]={'receipt_root':state['receipt']['root'],'status':state['receipt']['status'],
                'tests_run':observation['child_result']['tests_run'] if observation['child_result'] and 'tests_run' in observation['child_result'] else 0,
                'failures':observation['child_result'].get('failures') if observation['child_result'] else None,
                'entry_observed':state['receipt']['entry_observed'],'parent_witness':observation['parent_witness'],
                'fresh_process_finalization':True,'event_count':state['event_count'],'request_root':c.context['request']['root']}
        require(runs['baseline']['status']=='CHECK_FAILED' and runs['repair']['status']=='CHECKED_NOT_RELEASED','DEMO_DOMAIN_RESULT')
        require(original=={p.name:byte_hash(p.read_bytes()) for p in project.glob('*.py')},'ORIGINAL_SOURCE_CHANGED')
        result=record('demo-result',status='PASS',runs=runs,host=host_identity(),policy_root=policy()['root'],
            original_unchanged=True,private_keys_exported=False,proposal_origin='PREWRITTEN_BATCH_B_FIXTURE',
            native_ugk_binding='NOT_BOUND',adversarial_testing='NOT_PERFORMED',fault_injection='NOT_PERFORMED',
            observed_containment_scope='POSITIVE_FILTER_ENTRY_AND_ALLOWED_MEMORY_CHECK',**BOUNDARY)
        write_json(output/'DEMO-RESULT.json',result)
    write_json(output/'CLEANUP.json',record('cleanup',temporary_demo_workspace_removed=True,secure_erasure_claim=False,private_keys_retained=False))
    return result
