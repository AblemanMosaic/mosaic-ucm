"""UGEL-A1 canonical records. This is a new dialect, not a UGK wire format."""
from __future__ import annotations
import hashlib
import json
import re
from typing import Any

MAX_INT = (1 << 53) - 1
DOMAIN = b"MOSAIC-UGEL-A1\x00"

class Refusal(ValueError):
    def __init__(self, code: str, detail: str = ""):
        self.code, self.detail = code, detail
        super().__init__(code + (": " + detail if detail else ""))

def require(condition: bool, code: str, detail: str = "") -> None:
    if not condition:
        raise Refusal(code, detail)

def _check(value: Any, depth: int = 0) -> None:
    require(depth <= 48, "JSON_DEPTH")
    if value is None or type(value) is bool:
        return
    if type(value) is int:
        require(abs(value) <= MAX_INT, "INTEGER_RANGE")
        return
    if type(value) is str:
        require(len(value) <= 2_000_000, "STRING_LIMIT")
        try:
            value.encode("utf-8")
        except UnicodeEncodeError as exc:
            raise Refusal("UNICODE_SCALAR_REQUIRED") from exc
        return
    if type(value) is list:
        require(len(value) <= 10000, "LIST_LIMIT")
        for v in value: _check(v, depth + 1)
        return
    if type(value) is dict:
        require(all(type(k) is str for k in value), "STRING_KEYS_REQUIRED")
        for k, v in value.items():
            _check(k, depth + 1); _check(v, depth + 1)
        return
    raise Refusal("JSON_TYPE_UNSUPPORTED", type(value).__name__)

def canonical(value: Any) -> bytes:
    _check(value)
    return json.dumps(value, ensure_ascii=True, sort_keys=True,
                      separators=(",", ":"), allow_nan=False).encode("ascii")

def digest(value: Any) -> str:
    return hashlib.sha256(DOMAIN + canonical(value)).hexdigest()

def byte_digest(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()

def copy(value: Any) -> Any:
    return json.loads(canonical(value))

def seal(body: dict) -> dict:
    require("root" not in body, "ROOT_ALREADY_PRESENT")
    return {**copy(body), "root": digest(body)}

def exact(value: Any, keys: set[str]) -> dict:
    require(type(value) is dict and set(value) == keys, "FIELDS_INVALID")
    return value

def rooted(value: Any, schema: str, fields: set[str]) -> dict:
    exact(value, fields | {"schema", "root"})
    require(value["schema"] == schema, "SCHEMA_INVALID")
    require(value["root"] == digest({k:v for k,v in value.items() if k != "root"}), "ROOT_INVALID")
    return copy(value)

def identifier(value: Any) -> str:
    require(type(value) is str and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}", value) is not None,
            "IDENTIFIER_INVALID")
    return value

def hash_value(value: Any) -> str:
    require(type(value) is str and re.fullmatch(r"[0-9a-f]{64}", value) is not None, "DIGEST_INVALID")
    return value

def integer(value: Any, minimum: int = 0, maximum: int = MAX_INT) -> int:
    require(type(value) is int and minimum <= value <= maximum, "INTEGER_INVALID")
    return value

def ordered(value: Any, *, nonempty: bool = False) -> list:
    require(type(value) is list and all(type(v) is str for v in value), "STRING_LIST_INVALID")
    require(value == sorted(set(value)) and (bool(value) or not nonempty), "ORDERED_SET_INVALID")
    return value

def load_bytes(data: bytes) -> Any:
    def pairs(items):
        out = {}
        for k,v in items:
            require(k not in out, "DUPLICATE_JSON_KEY")
            out[k] = v
        return out
    try:
        out = json.loads(data, object_pairs_hook=pairs,
                         parse_constant=lambda x: (_ for _ in ()).throw(Refusal("JSON_CONSTANT")))
    except (ValueError, UnicodeError) as exc:
        if isinstance(exc, Refusal): raise
        raise Refusal("JSON_INVALID") from exc
    _check(out)
    return out
