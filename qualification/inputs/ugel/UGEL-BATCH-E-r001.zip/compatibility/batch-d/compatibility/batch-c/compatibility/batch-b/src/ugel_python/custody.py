"""Batch B task custody, separate from the unchanged Batch A effect ledger."""
from __future__ import annotations
import os,sqlite3
from pathlib import Path
from contextlib import closing
from ugel.canonical import require,hash_value,canonical,load_bytes,Refusal
from .model import make,checked
ZERO='0'*64

class TaskJournal:
    def __init__(self,path:Path,context_root:str):
        self.path=Path(path).absolute(); self.context_root=hash_value(context_root)
        require(self.path.is_file() and not self.path.is_symlink(),'TASK_JOURNAL_ABSENT')
        with closing(self._connect(False)) as db:
            row=db.execute("SELECT value FROM metadata WHERE key='context_root'").fetchone()
            require(row is not None and row[0]==context_root,'TASK_CONTEXT_PIN_MISMATCH')
    def _connect(self,write):
        db=sqlite3.connect(self.path.as_uri()+('?mode=rw' if write else '?mode=ro'),uri=True,timeout=5)
        if write: db.execute('PRAGMA synchronous=FULL')
        return db
    @classmethod
    def initialize(cls,path:Path,context_root:str):
        path=Path(path).absolute(); hash_value(context_root)
        fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600);os.close(fd)
        try:
            with closing(sqlite3.connect(str(path))) as db:
                db.execute('PRAGMA synchronous=FULL')
                db.execute('CREATE TABLE metadata(key TEXT PRIMARY KEY,value TEXT NOT NULL)')
                db.execute('CREATE TABLE events(sequence INTEGER PRIMARY KEY,body TEXT NOT NULL)')
                db.execute("INSERT INTO metadata VALUES('context_root',?)",(context_root,));db.commit()
        except Exception as exc:
            raise Refusal('TASK_INITIALIZATION_INCOMPLETE',str(path)) from exc
        return cls(path,context_root)
    def events(self):
        try:
            with closing(self._connect(False)) as db:
                rows=db.execute('SELECT sequence,body FROM events ORDER BY sequence').fetchall()
            require([n for n,_ in rows]==list(range(1,len(rows)+1)),'TASK_EVENT_SEQUENCE')
            return [load_bytes(x.encode('ascii')) for _,x in rows]
        except sqlite3.Error as exc: raise Refusal('TASK_JOURNAL_UNAVAILABLE') from exc
    @property
    def head(self):
        events=self.events(); return events[-1]['root'] if events else ZERO
    def append(self,kind:str,body:dict,*,expected_head:str):
        hash_value(expected_head); db=self._connect(True)
        try:
            db.execute('BEGIN IMMEDIATE')
            row=db.execute('SELECT sequence,body FROM events ORDER BY sequence DESC LIMIT 1').fetchone()
            head=load_bytes(row[1].encode('ascii'))['root'] if row else ZERO
            require(head==expected_head,'STALE_TASK_HEAD')
            n=row[0]+1 if row else 1
            event=make('task-event',sequence=n,previous=head,context_root=self.context_root,kind=kind,body=body)
            db.execute('INSERT INTO events VALUES(?,?)',(n,canonical(event).decode('ascii'))); db.commit()
            return event
        except Refusal: db.rollback();raise
        except sqlite3.Error as exc:
            try:db.rollback()
            except sqlite3.Error:pass
            raise Refusal('TASK_COMMIT_UNCERTAIN') from exc
        finally:db.close()
