# Named host boundary

## Support

`LINUX_X86_64_SECCOMP_MEMORY_CHECK_V1` is deliberately narrower than arbitrary
Python execution. A pinned bootstrap starts under isolated CPython startup,
receives exact JSON source bytes, loads the declared standard-library support,
compiles modules without executing them, and changes to `/` before entry.
All nonstandard descriptors are closed. The root case drops to UID/GID 65534,
supplementary groups are removed, and all capability sets are cleared. The child
sets `PR_SET_NO_NEW_PRIVS`, disables dumpability, and bounds core files, regular-file
writes, address space, CPU and descriptor allocation.

A libseccomp filter defaults to EPERM. The explicit allowlist is in
`spec/HOST-POLICY.json`; memory/time/signal-return primitives are allowed, plus
argument-limited read on fd 0, write on fd 1/2, fstat on fd 1/2 and two read-only
prctl queries. There are no open, socket, exec, clone/fork, kill, ptrace, mount,
io_uring, or arbitrary ioctl operations in the allowed set. This is a syscall
policy, not proof about every possible information flow or kernel vulnerability.

The bootstrap computes its filter-program digest before installing the filter,
then sends READY. The parent independently reads that child's `/proc/<pid>/status`
and checks filter mode, `NoNewPrivs`, thread count, zero capabilities and nonroot
credentials. The issuer rechecks the grant and current epoch immediately before a
signed entry decision. Only then does the parent send GO. Candidate code cannot
execute in the intended bootstrap path before this point. No cooperative fallback
exists when prerequisites or entry observations are missing.

## Effects and data

The child operates on an exact immutable-in-memory source snapshot; it receives no
host path capability. Original and candidate paths are observed by the trusted
parent before/after. Batch B materialization still uses its unchanged cooperative
file adapter; this batch does not strengthen those prior file effects retroactively.

Output pipes are deliberately exposed effects. Their bytes may contain all source
provided to the child and must be treated as untrusted. The supervisor bounds total
output and elapsed time. The profile prohibits descendant creation after entry;
the watchdog manages the direct child, not an unrestricted hostile process tree.
The bootstrap, interpreter, loaded libraries, seccomp/kernel implementation, parent,
and local owner are trusted. Full runtime/OS closure is not hashed. Exact bootstrap,
host modules, interpreter and libseccomp bytes are bound, with host/kernel versions.

The child can modify its own Python interpreter state. The unittest report is NOT
an independent oracle against deliberately malicious candidate code. Signed host
transport authenticates what the host received; it does not prove an arbitrary
program's correctness. An isolated external oracle would be a separate profile.

## Authority timing

Admission consumes a single attempt. The later GO authorization is the authority
linearization point for candidate entry. Revocation and epoch changes before GO
refuse entry. There is no promise of synchronous revocation of an already-running
computation. A finite watchdog/CPU budget bounds that run; use a stronger live
termination service where immediate revocation is a requirement.

## Executed and unexecuted assurance

Ordinary positive invoice checks run under the installed filter. Parent observations
and signed receipt replay are captured. Forbidden-action probes, sandbox escapes,
stress/DoS, forced termination, power loss, hostile concurrent writes, kernel
attacks, other OSes and independent containment review are NOT_RUN.

The initial environment query found Landlock unavailable (ENOSYS). That observation
led to the named memory-only profile; it is not a claim of Landlock enforcement.
See official references in REFERENCES.md for the mechanisms' documented limits.
