"""Exact ordinary lane: contract-enumerated C tests plus unchanged Batch B checks.
No automatic dependency installation, adversarial tests or denial probes.
"""
from __future__ import annotations
import argparse,ast,hashlib,io,json,os,platform,sqlite3,subprocess,sys,unittest
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'compatibility/batch-b/src'),str(ROOT)]
from source_inventory import inventory,canonical,seal,digest
class RecordingResult(unittest.TextTestResult):
    def __init__(self,*a,**kw):super().__init__(*a,**kw);self.rows=[]
    def addSuccess(self,t):super().addSuccess(t);self.rows.append({'id':t.id(),'status':'PASS'})
    def addFailure(self,t,e):super().addFailure(t,e);self.rows.append({'id':t.id(),'status':'FAIL'})
    def addError(self,t,e):super().addError(t,e);self.rows.append({'id':t.id(),'status':'ERROR'})
    def addSkip(self,t,r):super().addSkip(t,r);self.rows.append({'id':t.id(),'status':'SKIP'})
def ids():
    result=[]
    for p in sorted((ROOT/'tests').glob('test_*.py')):
        for c in ast.parse(p.read_text()).body:
            if isinstance(c,ast.ClassDef):result.extend('tests.'+p.stem+'.'+c.name+'.'+f.name for f in c.body if isinstance(f,ast.FunctionDef) and f.name.startswith('test_'))
    return sorted(result)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();a.output.mkdir(parents=True,exist_ok=False)
    before=inventory(ROOT);contract=json.loads((ROOT/'spec/CHECK-CONTRACT.json').read_bytes());expected=ids()
    if contract['root']!=digest({k:v for k,v in contract.items() if k!='root'}) or contract['test_ids']!=expected:raise SystemExit('TEST_CONTRACT_INVALID')
    stream=io.StringIO();suite=unittest.defaultTestLoader.discover(str(ROOT/'tests'),top_level_dir=str(ROOT))
    result=unittest.TextTestRunner(stream=stream,verbosity=2,resultclass=RecordingResult).run(suite)
    b_out=a.output/'inherited-b'
    b_proc=subprocess.run([sys.executable,'-B',str(ROOT/'compatibility/batch-b/tools/check.py'),'--output',str(b_out)],capture_output=True,timeout=120)
    (a.output/'INHERITED-RUN.log').write_bytes(b_proc.stdout+b'\nSTDERR\n'+b_proc.stderr)
    b=json.loads((b_out/'REFERENCE-CHECKS.json').read_bytes()) if (b_out/'REFERENCE-CHECKS.json').exists() else None
    after=inventory(ROOT);rows=sorted(result.rows,key=lambda r:r['id'])
    passed=result.wasSuccessful() and not result.skipped and not result.expectedFailures and not result.unexpectedSuccesses and [r['id'] for r in rows]==expected and before==after and b_proc.returncode==0 and b is not None and b['status']=='PASS' and b['tests_run']==73
    rec=seal({'schema':'mosaic.ugel.batch-c.reference-checks.v1','status':'PASS' if passed else 'FAIL',
      'source_root':before['root'],'source_stable':before==after,'contract_root':contract['root'],
      'test_ids':expected,'test_set_root':hashlib.sha256(canonical(expected)).hexdigest(),'rows':rows,
      'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skips':len(result.skipped),
      'expected_failures':len(result.expectedFailures),'unexpected_successes':len(result.unexpectedSuccesses),
      'inherited_b_result_root':b['root'] if b else None,'inherited_b_source_root':b['source_root'] if b else None,
      'inherited_b_test_count':b['tests_run'] if b else None,'total_distinct_test_count':len(expected)+(b['tests_run'] if b else 0),
      'prior_result_cache_reads':0,'cache_policy':'DISABLED','execution_scope':'ORDINARY_REFERENCE_AND_POSITIVE_KERNEL_ENTRY',
      'adversarial_testing':'NOT_PERFORMED','fault_injection':'NOT_PERFORMED','denied_syscall_probes':'NOT_PERFORMED',
      'standing':'INFORMATION_ONLY','authority_effect':'NONE','real_a5':False,'g0':'CLOSED'})
    for name,value in [('REFERENCE-CHECKS.json',rec),('SOURCE-MANIFEST.json',before)]:
        (a.output/name).write_bytes(canonical(value)+b'\n')
    (a.output/'REFERENCE-CHECKS.log').write_text(stream.getvalue())
    import cryptography,ctypes
    lib=ctypes.CDLL('libseccomp.so.2')
    class Version(ctypes.Structure):_fields_=[('major',ctypes.c_uint),('minor',ctypes.c_uint),('micro',ctypes.c_uint)]
    lib.seccomp_version.restype=ctypes.POINTER(Version);v=lib.seccomp_version().contents
    host={'python':sys.version,'platform':platform.platform(),'machine':platform.machine(),'sqlite':sqlite3.sqlite_version,
      'cryptography':cryptography.__version__,'libseccomp':f'{v.major}.{v.minor}.{v.micro}','host_uid':os.getuid(),
      'other_hosts':'NOT_RUN','landlock':'NOT_USED_LOCAL_QUERY_RETURNED_ENOSYS','mode':'LOCAL_SINGLE_OWNER_POSITIVE_REFERENCE'}
    (a.output/'HOST.json').write_bytes(canonical(host)+b'\n')
    try:print(json.dumps({'status':rec['status'],'c_tests':result.testsRun,'inherited_b_tests':rec['inherited_b_test_count'],'total':rec['total_distinct_test_count'],'source_root':before['root'],'record_root':rec['root']},indent=2))
    except OSError:pass
    if not passed:
        try:print(stream.getvalue())
        except OSError:pass
    return 0 if passed else 1
if __name__=='__main__':raise SystemExit(main())
