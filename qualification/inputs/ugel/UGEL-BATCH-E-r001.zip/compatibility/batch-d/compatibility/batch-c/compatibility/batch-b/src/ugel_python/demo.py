"""Ordinary controlled repair demonstration; no model call or hostile execution."""
from __future__ import annotations
import subprocess,sys
from pathlib import Path
from ugel.canonical import canonical,load_bytes,require,byte_digest
from ugel.contracts import BOUNDARY
from .model import propose,make,snapshot
from .session import TaskSession
from .semantics import verify_task_bundle

ROOT=Path(__file__).resolve().parents[2]

def save(path,value):path.write_bytes(canonical(value)+b'\n')

def checkpoint(session,output):
    bundle=session.export(acknowledge_plaintext=True);pins=session.pins()
    save(output/'BUNDLE.json',bundle);save(output/'PINS.json',pins)
    verification=verify_task_bundle(bundle,expected_context_root=pins['context_root'],expected_task_head=pins['task_head'],
                                   expected_effects_head=pins['effects_head'])
    save(output/'REPLAY.json',verification);save(output/'CURRENT-TASK.json',session.current_task())
    return bundle,verification

def run_demo(output:Path):
    output=Path(output).absolute();require(not output.exists(),'DEMO_OUTPUT_MUST_BE_NEW');output.mkdir(mode=0o700)
    source=ROOT/'examples/project';before=snapshot(source)[0]
    base=propose(source,'baseline-check','Record the original integer-cent behavior',{})
    baseline=TaskSession.initialize(project=source,plan=base,expected_plan_root=base['root'],output=output/'baseline',
                                    acknowledge_trusted_code_execution=True)
    base_receipt=baseline.run();require(base_receipt['status']=='CHECK_FAILED','DEMO_BASELINE_EXPECTED_TEST_FAILURE')
    checkpoint(baseline,output/'baseline')
    replacements=load_bytes((ROOT/'examples/REPAIR-PROPOSAL.json').read_bytes())['replacements']
    plan=propose(source,'invoice-repair','Multiply unit cents by quantity; retain the accepted test suite',replacements)
    fixed=TaskSession.initialize(project=source,plan=plan,expected_plan_root=plan['root'],output=output/'repair',
                                acknowledge_trusted_code_execution=True)
    fixed.materialize();fixed.execute_check(finalize=False)
    require(fixed.state()['phase']=='CHECK_OBSERVED','DEMO_OBSERVATION_REQUIRED')
    save(output/'repair'/'RESUME-PINS.json',fixed.pins())
    # Ordinary process handoff after a supported persisted phase, not crash injection.
    result=subprocess.run([sys.executable,'-I','-S','-B',str(ROOT/'run.py'),'finalize',str(output/'repair'),
                           '--pins',str(output/'repair'/'RESUME-PINS.json')],capture_output=True,text=True,timeout=20)
    require(result.returncode==0,'DEMO_FRESH_PROCESS_FINALIZE',result.stderr+result.stdout)
    returned=load_bytes(result.stdout.encode());pins=returned['pins']
    fixed=TaskSession(output/'repair',expected_context_root=pins['context_root'],expected_task_head=pins['task_head'],
                      expected_effects_head=pins['effects_head'])
    bundle,replay=checkpoint(fixed,output/'repair');receipt=fixed.state()['receipt']
    require(receipt['status']=='CHECKED_NOT_RELEASED','DEMO_REPAIR_NOT_CHECKED')
    require(snapshot(source)[0]==before,'DEMO_SOURCE_CHANGED')
    report=make('demo-result',status='PASS_CONTROLLED_WORKFLOW',proposal_origin='PREWRITTEN_REFERENCE_PROPOSAL_NOT_LLM_GENERATED',
        source_root=before['root'],candidate_root=plan['candidate_manifest']['root'],plan_root=plan['root'],
        baseline_outcome=base_receipt['status'],repair_outcome=receipt['status'],trusted_test_count=len(plan['test_ids']),
        baseline_bundle_root=baseline.export(acknowledge_plaintext=True)['root'],repair_bundle_root=bundle['root'],
        replay_root=replay['root'],fresh_process_finalize='PASS_WITHOUT_REDISPATCH',
        source_unchanged=True,task_events=len(bundle['task_events']),file_events=len(bundle['effects_bundle']['events']),
        file_operations=len(bundle['effects_bundle']['events'])//4,
        child_invocations_per_task=1,independent_model_harness='NOT_BOUND',native_ugk_binding='NOT_BOUND',
        host_containment='NOT_ESTABLISHED',**BOUNDARY)
    save(output/'DEMO-RESULT.json',report);return report
