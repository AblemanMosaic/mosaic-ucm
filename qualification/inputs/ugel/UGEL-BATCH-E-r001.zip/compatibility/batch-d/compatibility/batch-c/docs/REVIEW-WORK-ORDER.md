# Batch C independent review work order

Standing INFORMATION_ONLY; authority effect NONE; real A5 false; G0 CLOSED.

Start with passive archive identity, source/manifest custody, exact inherited-byte
comparison, signing domains, context and request bindings, state transitions, shared
receipt derivation, supported host profile, output and recovery boundaries.

Ordinary execution requires an explicitly accepted local host and disclosure of
physical effects. The supplied default checks are positive/lifecycle reference
checks, not independent containment qualification. No adversarial work is authorized
by this handoff. Obtain separate permission before escape, denied-syscall, fault,
interruption, resource-exhaustion or hostile concurrent-writer testing.

Report separate dispositions for source custody, signatures/issuer custody, host
entry, child result meaning, task/effect histories, recovery, inherited compatibility,
artifact verification and joint composition. Do not turn the local signature into
an independent observation, or a passing workload into a complete sandbox proof.
