from __future__ import annotations
import argparse
from pathlib import Path
from .canonical import canonical, load_bytes, Refusal, require
from .contracts import REGISTRY, BOUNDARY
from .history import replay, verify_bundle
from .store import Ledger

def load(path): return load_bytes(Path(path).read_bytes())

def main(argv=None)->int:
    p=argparse.ArgumentParser(description="UGEL Batch A reference tools; no arbitrary-code runner")
    subs=p.add_subparsers(dest="command",required=True)
    subs.add_parser("orient",help="Pure capability and boundary report")
    d=subs.add_parser("demo",help="Create a NEW disposable local demonstration directory")
    d.add_argument("--output",required=True,type=Path)
    v=subs.add_parser("verify-bundle",help="Replay records only; never replay effects")
    v.add_argument("bundle",type=Path); v.add_argument("--binding-root",required=True)
    v.add_argument("--head",required=True); v.add_argument("--authority-root",action="append",required=True)
    i=subs.add_parser("inspect",help="Read an EXISTING ledger without initialization")
    i.add_argument("--ledger",required=True,type=Path); i.add_argument("--binding",required=True,type=Path)
    i.add_argument("--contract",required=True,type=Path); i.add_argument("--head",required=True)
    i.add_argument("--authority-root",action="append",required=True)
    a=p.parse_args(argv)
    try:
        if a.command=="orient":
            result={"schema":"mosaic.ugel.batch-a.orientation.v1","effect_registry":REGISTRY,
                "modes":["SIMULATION","CONTROLLED_LOCAL_REFERENCE"],"host_containment":False,
                "grant_authentication":"HOST_PINNED_REFERENCE_NO_SIGNATURE","native_ugk_binding":"NOT_BOUND",
                "effectful_cli":["demo"],"read_only_cli":["orient","inspect","verify-bundle"],**BOUNDARY}
        elif a.command=="demo":
            from .scenarios import run_demo
            result=run_demo(a.output)
        elif a.command=="verify-bundle":
            result=verify_bundle(load(a.bundle),expected_binding_root=a.binding_root,expected_head=a.head,
                                 trusted_authority_roots=set(a.authority_root))
        else:
            binding=load(a.binding); contract=load(a.contract)
            ledger=Ledger(a.ledger,binding["root"])
            result=replay(binding=binding,contract=contract,events=ledger.events(),trusted_authority_roots=set(a.authority_root))
            require(result["head"]==a.head,"HEAD_PIN_MISMATCH")
        print(canonical(result).decode("ascii")); return 0
    except (Refusal,OSError) as exc:
        # Do not claim NONE for an error after starting an explicitly effectful command.
        print(canonical({"status":"REFUSED_OR_PENDING","code":exc.code if isinstance(exc,Refusal) else type(exc).__name__,
                         "effect_scope":"LOCAL_EFFECTS_POSSIBLE" if a.command=="demo" else "READ_ONLY",**BOUNDARY}).decode("ascii"))
        return 2

if __name__=="__main__": raise SystemExit(main())
