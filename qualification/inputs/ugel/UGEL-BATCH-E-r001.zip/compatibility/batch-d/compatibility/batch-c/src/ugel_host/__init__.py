"""UGEL Batch C: explicit local signed authority and restricted memory-check host."""
__version__="0.1.0"
