"""Ordinary reference workflows. No fault injection, hostile programs, or network calls."""
from __future__ import annotations
import json,subprocess,sys,tempfile,unittest,time
from pathlib import Path
from ugel.canonical import canonical,load_bytes,Refusal
from ugel_python import TaskSession,propose,snapshot,verify_task_bundle,governed_task
from ugel_python.model import test_ids,validate_plan,engine_manifest
ROOT=Path(__file__).resolve().parents[1]

class PythonHarnessTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='ugel-b-check-');self.folder=Path(self.temp.name)
        self.source=self.folder/'source';self.source.mkdir()
        for p in (ROOT/'examples/project').glob('*.py'):(self.source/p.name).write_bytes(p.read_bytes())
        self.replacements=load_bytes((ROOT/'examples/REPAIR-PROPOSAL.json').read_bytes())['replacements']
    def tearDown(self):self.temp.cleanup()
    def prepare(self,*,repair=True,seconds=3600,clock=lambda:1000):
        p=propose(self.source,'reference-task','Quantity-aware invoice calculation',self.replacements if repair else {})
        return TaskSession.initialize(project=self.source,plan=p,expected_plan_root=p['root'],output=self.folder/'task',
            acknowledge_trusted_code_execution=True,clock=clock,valid_seconds=seconds)
    def reopen(self,s,clock=lambda:1000):
        p=s.pins();return TaskSession(s.folder,expected_context_root=p['context_root'],expected_task_head=p['task_head'],
                                     expected_effects_head=p['effects_head'],clock=clock)
    def test_source_manifest_uses_actual_file_bytes(self):
        manifest,texts=snapshot(self.source)
        self.assertEqual(manifest['file_count'],2)
        self.assertEqual(sorted(texts),['invoice.py','test_invoice.py'])
    def test_plan_rederives_candidate_and_exact_test_set(self):
        p=propose(self.source,'plan','Repair quantities',self.replacements)
        self.assertEqual(validate_plan(p,p['root']),p)
        self.assertEqual(p['changed_paths'],['invoice.py']);self.assertEqual(len(p['test_ids']),6)
    def test_plan_preserves_trusted_test_bytes(self):
        p=propose(self.source,'plan','Repair quantities',self.replacements)
        self.assertEqual(p['candidate_texts']['test_invoice.py'],p['source_texts']['test_invoice.py'])
        self.assertEqual(p['protected_tests'],['test_invoice.py'])
    def test_noop_plan_is_a_distinct_baseline_check(self):
        p=propose(self.source,'plan','Check baseline',{})
        self.assertEqual(p['source_manifest'],p['candidate_manifest']);self.assertEqual(p['changed_paths'],[])
    def test_initialization_requires_explicit_code_trust(self):
        p=propose(self.source,'plan','Check baseline',{})
        with self.assertRaisesRegex(Refusal,'TRUSTED_CODE_EXECUTION_ACK_REQUIRED'):
            TaskSession.initialize(project=self.source,plan=p,expected_plan_root=p['root'],output=self.folder/'task',
                                   acknowledge_trusted_code_execution=False)
        self.assertFalse((self.folder/'task').exists())
    def test_grants_bind_actual_project_and_candidate(self):
        s=self.prepare();c=s.context
        self.assertEqual(c['effect_binding']['subject_root'],c['plan']['root'])
        self.assertEqual(c['process_grant']['candidate_root'],c['plan']['candidate_manifest']['root'])
        self.assertEqual(c['engine'],engine_manifest());self.assertEqual(c['native_ugk_binding'],'NOT_BOUND')
    def test_source_and_candidate_have_distinct_grants(self):
        s=self.prepare();gs={g['resources'][0]:g for g in s.context['effect_authority']['grants']}
        self.assertEqual(gs['source']['effects'],['fs.read'])
        self.assertEqual(gs['candidate']['effects'],['fs.create','fs.read'])
    def test_capability_attenuation_preserves_host_scope(self):
        s=self.prepare();h=s.candidate.restrict(names=['invoice.py'],effects=['fs.create'])
        self.assertEqual(h.names,('invoice.py',));self.assertEqual(h.effects,('fs.create',))
        self.assertEqual(h.grant_root,s.candidate.grant_root)
    def test_decorator_exposes_and_checks_declared_sdk_needs(self):
        s=self.prepare()
        @governed_task(requires=('source.read',))
        def read_one(ctx):return ctx.source.read('invoice.py',operation_id='read-source-0')
        r=read_one(s);self.assertEqual(r.data,(self.source/'invoice.py').read_bytes())
        self.assertEqual(read_one.ugel_requires,('source.read',))
    def test_read_has_live_and_snapshot_resume_origins(self):
        s=self.prepare();one=s.source.read('invoice.py',operation_id='read-source-0');head=s.effect_head
        two=s.source.read('invoice.py',operation_id='read-source-0')
        self.assertEqual(one.data_origin,'LIVE_MEDIATED_READ');self.assertEqual(two.data_origin,'ACCEPTED_SNAPSHOT_NOT_FRESH_READ')
        self.assertEqual(one.data,two.data);self.assertEqual(s.effect_head,head)
    def test_materialization_has_exact_effect_receipts(self):
        s=self.prepare();out=s.materialize()
        self.assertEqual(out['phase'],'MATERIALIZED');self.assertEqual(len(s.ledger.events()),24)
        self.assertEqual(snapshot(Path(s.context['candidate_path']))[0],s.context['plan']['candidate_manifest'])
    def test_materialization_is_idempotent(self):
        s=self.prepare();s.materialize();pins=s.pins();s.materialize();self.assertEqual(pins,s.pins())
    def test_readonly_context_leaves_both_heads_unchanged(self):
        s=self.prepare();before=s.pins();s.current_task();self.assertEqual(before,s.pins())
    def test_inspection_of_missing_task_creates_nothing(self):
        missing=self.folder/'missing'
        with self.assertRaisesRegex(Refusal,'TASK_ABSENT'):
            TaskSession(missing,expected_context_root='0'*64,expected_task_head='0'*64,expected_effects_head='0'*64)
        self.assertFalse(missing.exists())
    def test_completed_candidate_passes_exact_tests(self):
        s=self.prepare();r=s.run()
        self.assertEqual(r['status'],'CHECKED_NOT_RELEASED');self.assertTrue(r['inventory_complete'])
        self.assertEqual(len(r['test_ids']),6);self.assertFalse(r['release_authorized'])
    def test_baseline_failure_is_recorded_without_false_completion(self):
        s=self.prepare(repair=False);r=s.run()
        self.assertEqual(r['status'],'CHECK_FAILED');self.assertEqual(r['completed_obligations'],[])
        self.assertEqual(s.current_task()['next_action'],'PROPOSE_SUCCESSOR_TASK')
    def test_observation_finalizes_after_reopen_without_redispatch(self):
        s=self.prepare();s.materialize();s.execute_check(finalize=False)
        output=(s.folder/'check/RESULT.json').read_bytes();q=self.reopen(s);r=q.finalize()
        self.assertEqual(r['status'],'CHECKED_NOT_RELEASED');self.assertEqual(output,(s.folder/'check/RESULT.json').read_bytes())
        self.assertEqual([e['kind'] for e in q.journal.events()].count('CHECK_STARTED'),1)
    def test_fresh_interpreter_finalizes_recorded_observation(self):
        s=self.prepare();s.materialize();s.execute_check(finalize=False)
        pins=s.folder/'resume.json';pins.write_bytes(canonical(s.pins()))
        proc=subprocess.run([sys.executable,'-I','-S','-B',str(ROOT/'run.py'),'finalize',str(s.folder),'--pins',str(pins)],
                            capture_output=True,text=True,timeout=20)
        self.assertEqual(proc.returncode,0,proc.stdout+proc.stderr)
        self.assertEqual(load_bytes(proc.stdout.encode())['result']['status'],'CHECKED_NOT_RELEASED')
    def test_finalize_is_idempotent(self):
        s=self.prepare();r=s.run();pins=s.pins();self.assertEqual(s.finalize(),r);self.assertEqual(s.pins(),pins)
    def test_completed_check_is_not_repeated(self):
        s=self.prepare();r=s.run();pins=s.pins();self.assertEqual(s.execute_check(),r);self.assertEqual(s.pins(),pins)
    def test_grant_expiry_blocks_new_check_without_renewal(self):
        s=self.prepare(seconds=1);s.materialize();expired=self.reopen(s,clock=lambda:1001);head=expired.task_head
        with self.assertRaisesRegex(Refusal,'PROCESS_GRANT_NOT_CURRENT'):expired.execute_check()
        self.assertEqual(expired.task_head,head)
    def test_record_finalization_does_not_need_new_execution_grant(self):
        s=self.prepare(seconds=1);s.materialize();s.execute_check(finalize=False)
        expired=self.reopen(s,clock=lambda:1002)
        self.assertEqual(expired.finalize()['status'],'CHECKED_NOT_RELEASED')
    def test_export_requires_disclosure_acknowledgment(self):
        s=self.prepare()
        with self.assertRaisesRegex(Refusal,'EXPLICIT_SOURCE_AND_GRANT_DISCLOSURE_REQUIRED'):s.export()
    def test_record_replay_rederives_receipt_and_both_chains(self):
        s=self.prepare();r=s.run();b=s.export(acknowledge_plaintext=True);pins=s.pins()
        v=verify_task_bundle(b,expected_context_root=pins['context_root'],expected_task_head=pins['task_head'],
                            expected_effects_head=pins['effects_head'])
        self.assertEqual(v['receipt_root'],r['root']);self.assertFalse(v['empirical_execution_independently_verified'])
    def test_final_context_keeps_boundaries_and_remaining_obligations(self):
        s=self.prepare();s.run();c=s.current_task()
        self.assertTrue(c['current_evidence_applicable']);self.assertEqual(c['next_action'],'EXPORT_FOR_REVIEW')
        self.assertIn('NATIVE_UGK_AUTHORITY',c['supported_receipt']['remaining_obligations'])
        self.assertEqual(c['authority_effect'],'NONE');self.assertEqual(c['g0'],'CLOSED')
    def test_original_project_unchanged_by_successful_workflow(self):
        before=snapshot(self.source);s=self.prepare();s.run();self.assertEqual(snapshot(self.source),before)
    def test_cli_domain_failure_is_nonzero(self):
        s=self.prepare(repair=False,clock=lambda:int(time.time()));pins=s.folder/'pins.json';pins.write_bytes(canonical(s.pins()))
        proc=subprocess.run([sys.executable,'-I','-S','-B',str(ROOT/'run.py'),'run',str(s.folder),'--pins',str(pins)],
                            capture_output=True,text=True,timeout=20)
        self.assertEqual(proc.returncode,3,proc.stdout+proc.stderr)
        self.assertEqual(load_bytes(proc.stdout.encode())['result']['status'],'CHECK_FAILED')
    def test_authored_started_state_requires_reconciliation(self):
        # A declared model-state fixture, not an interrupted subprocess.
        from ugel_python.semantics import check_request
        s=self.prepare();s.materialize()
        q=check_request(s.context,1000);s._append('CHECK_STARTED',{'request':q})
        self.assertEqual(s.current_task()['next_action'],'RECONCILE_CHECK_NO_AUTOMATIC_REDISPATCH')
        with self.assertRaisesRegex(Refusal,'CHECK_NOT_READY_OR_RECONCILIATION_REQUIRED'):s.execute_check()
        self.assertFalse((s.folder/'check').exists())
    def test_later_manual_candidate_edit_marks_historical_result_stale(self):
        s=self.prepare();s.run();receipt=s.state()['receipt']
        path=Path(s.context['candidate_path'])/'invoice.py'
        path.write_text(path.read_text()+'\n# Subsequent local editing session.\n')
        current=s.current_task()
        self.assertFalse(current['current_evidence_applicable'])
        self.assertEqual(current['supported_receipt'],receipt)
