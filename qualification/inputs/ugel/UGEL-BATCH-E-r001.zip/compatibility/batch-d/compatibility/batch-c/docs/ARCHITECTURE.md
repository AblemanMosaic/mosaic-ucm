# Additive execution boundary

1. **Unchanged Batch B** proposes and materializes an exact candidate through its
   original Batch A broker. Its own process-check path remains cooperative.
2. **Batch C request** binds the B context, file and task heads, plan, candidate
   text and tests, host policy, interpreter, libseccomp, bootstrap and host engine.
3. **Local issuer** supplies a signed, bounded, one-attempt grant to the exact host
   observer. The host records intent before consumption and launch.
4. **Fresh bootstrap** establishes the kernel boundary before executing candidate
   code. The supervisor observes `/proc` and obtains a current signed GO decision.
5. **Memory-only test** loads exact source from in-memory modules. It has no path,
   socket or process capability. Output is returned through bounded inherited pipes.
6. **Supervisor observation** binds the raw streams, child result, exit status,
   runtime entry witness, authority decisions and post-run source snapshots.
7. **Signed journal** records the observation. Shared derivation creates the final
   receipt. Offline verification uses those same rules without executing code.

No prior record is relabeled. In particular a Batch B task stays MATERIALIZED; its
cooperative `CHECKED_NOT_RELEASED` semantics are not substituted with Batch C's
host-profile semantics. The new receipt links back to the accepted materialization.

New record schemas use `mosaic.ugel.batch-c.*.v1` and canonical domain
`MOSAIC-UGEL-C1\\0`. Signatures use a separate `MOSAIC-UGEL-C1-SIGNATURE\\0` domain.
The authoritative runtime schema fields are shared by production and replay in
semantics.py. All exported records are plaintext and need explicit disclosure
acknowledgment. No canonical UGK IDs or native warrant semantics are invented.

The selected host profile is consciously small. General filesystem writes, shell
commands, networking, third-party imports, threads, subprocesses, and external
application orchestration are not available through this child. Broader adapters
need separate grants, enforcement and reconciliation contracts.
