"""Machine-readable host interface. It does not mint external/UGK authority."""
from __future__ import annotations
import argparse,json,sys
from pathlib import Path
from ugel.canonical import canonical,load_bytes,Refusal,require
from ugel.contracts import BOUNDARY
from .model import propose,make
from .session import TaskSession
from .semantics import verify_task_bundle

def read(path):return load_bytes(Path(path).read_bytes())
def session(a):
    pins=read(a.pins)
    return TaskSession(a.task,expected_context_root=pins['context_root'],expected_task_head=pins['task_head'],
                       expected_effects_head=pins['effects_head'])
def main():
    p=argparse.ArgumentParser(description='UGEL Batch B cooperative Python harness')
    sub=p.add_subparsers(dest='command',required=True)
    sub.add_parser('orient')
    x=sub.add_parser('plan');x.add_argument('--project',type=Path,required=True);x.add_argument('--proposal',type=Path,required=True)
    x.add_argument('--task-id',required=True);x.add_argument('--objective',required=True)
    x=sub.add_parser('prepare');x.add_argument('--project',type=Path,required=True);x.add_argument('--plan',type=Path,required=True)
    x.add_argument('--expected-plan-root',required=True);x.add_argument('--output',type=Path,required=True)
    x.add_argument('--acknowledge-trusted-code-execution',action='store_true')
    for verb in ['context','materialize','check','finalize','run','export']:
        x=sub.add_parser(verb);x.add_argument('task',type=Path);x.add_argument('--pins',type=Path,required=True)
        if verb=='check':x.add_argument('--leave-observed',action='store_true')
        if verb=='export':x.add_argument('--acknowledge-plaintext',action='store_true')
    x=sub.add_parser('verify-bundle');x.add_argument('bundle',type=Path);x.add_argument('--pins',type=Path,required=True)
    x=sub.add_parser('demo');x.add_argument('--output',type=Path,required=True)
    args=p.parse_args()
    try:
        if args.command=='orient':
            value=make('orientation',sdk='ugel_python.TaskSession',version='0.2.0b1',
                capabilities=['SOURCE_READ','CANDIDATE_CREATE','CANDIDATE_READ','EXACT_TRUSTED_UNITTEST','TASK_CONTEXT','RECORD_REPLAY'],
                support='FLAT_UTF8_PYTHON_PROJECTS_WITH_STATIC_UNITTEST_SETS',
                batch_a_engine='BYTE_IDENTICAL',native_ugk_binding='NOT_BOUND',os_sandbox=False,
                authority='EXPLICIT_UNSIGNED_LOCAL_HOST_PINS',**BOUNDARY)
        elif args.command=='plan':
            value=propose(args.project,args.task_id,args.objective,read(args.proposal)['replacements'])
        elif args.command=='prepare':
            s=TaskSession.initialize(project=args.project,plan=read(args.plan),expected_plan_root=args.expected_plan_root,
                output=args.output,acknowledge_trusted_code_execution=args.acknowledge_trusted_code_execution)
            value={'result':s.current_task(),'pins':s.pins()}
        elif args.command=='demo':
            from .demo import run_demo
            value=run_demo(args.output)
        elif args.command=='verify-bundle':
            pins=read(args.pins);value=verify_task_bundle(read(args.bundle),expected_context_root=pins['context_root'],
                expected_task_head=pins['task_head'],expected_effects_head=pins['effects_head'])
        else:
            s=session(args)
            if args.command=='context':result=s.current_task()
            elif args.command=='materialize':result=s.materialize()
            elif args.command=='check':result=s.execute_check(finalize=not args.leave_observed)
            elif args.command=='finalize':result=s.finalize()
            elif args.command=='run':result=s.run()
            else:result=s.export(acknowledge_plaintext=args.acknowledge_plaintext)
            value={'result':result,'pins':s.pins()}
        print(canonical(value).decode('ascii'))
        status=value.get('result',value).get('status')
        return 3 if status in {'CHECK_FAILED','SUBJECT_CHANGED_HOLD','RECONCILIATION_REQUIRED','OBSERVATION_PENDING'} else 0
    except Exception as exc:
        code=exc.code if isinstance(exc,Refusal) else type(exc).__name__
        # Never assert NONE for an exception after a method could have mutated custody.
        print(canonical({'status':'REQUEST_NOT_COMPLETED','code':code,'detail':str(exc),
            'effect_scope':'NOT_INFERRED_INSPECT_EXISTING_CUSTODY','standing':'INFORMATION_ONLY',
            'authority_effect':'NONE','real_a5':False,'g0':'CLOSED'}).decode('ascii'))
        return 2
if __name__=='__main__':raise SystemExit(main())
