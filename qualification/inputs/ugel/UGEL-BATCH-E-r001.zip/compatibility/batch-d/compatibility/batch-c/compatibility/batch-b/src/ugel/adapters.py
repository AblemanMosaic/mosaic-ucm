"""Built-in simulation and cooperative private-directory adapters.

The directory adapter is NOT a sandbox against hostile concurrent mutation.
It never executes programs, opens sockets, overwrites files, or deletes them.
"""
from __future__ import annotations
import os
import stat
from pathlib import Path
from .canonical import *
from .contracts import *

OBS_FIELDS={"request_root","adapter_identity_root","status","effect_scope","output_sha256","output_bytes","facts","causal_attribution"}

def observation(q: dict, identity: str, status: str, scope: str,
                output: bytes | None = None, facts: dict | None = None,
                attribution: str = "LOCAL_ADAPTER_REPORT") -> dict:
    return seal({"schema":SCHEMAS["observation"],"request_root":q["root"],
       "adapter_identity_root":identity,"status":status,"effect_scope":scope,
       "output_sha256":byte_digest(output) if output is not None else None,
       "output_bytes":len(output) if output is not None else 0,
       "facts":facts or {},"causal_attribution":attribution})

def validate_observation(value: dict, q: dict, resource: dict, *, reconciliation: bool = False) -> dict:
    o=rooted(value,SCHEMAS["observation"],OBS_FIELDS)
    require(o["request_root"] == q["root"] and o["adapter_identity_root"] == resource["identity_root"],"OBSERVATION_BINDING")
    integer(o["output_bytes"])
    if o["output_sha256"] is not None: hash_value(o["output_sha256"])
    require(o["causal_attribution"] in {"LOCAL_ADAPTER_REPORT","NOT_ESTABLISHED"},"ATTRIBUTION_INVALID")
    status=o["status"]; effect=q["effect"]
    if status == "SUCCEEDED":
        require(o["causal_attribution"] == "LOCAL_ADAPTER_REPORT","ATTRIBUTION_INVALID")
        if effect in {ECHO,ADD}:
            output=(q["parameters"]["text"].encode("utf-8") if effect == ECHO else
                    canonical(q["parameters"]["left"]+q["parameters"]["right"]))
            require(o == observation(q,resource["identity_root"],"SUCCEEDED","SIMULATED",output,
                    {"kind":"PURE_RECOMPUTATION"}),"SIMULATION_OBSERVATION_INVALID")
        elif effect == CREATE:
            data=q["parameters"]["text"].encode("utf-8")
            require(not reconciliation and o["effect_scope"] == "LOCAL_FILESYSTEM_CREATE"
                    and o["output_sha256"] == byte_digest(data) and o["output_bytes"] == len(data)
                    and o["facts"] == {"kind":"EXCLUSIVE_CREATE_AND_READBACK"},"CREATE_OBSERVATION_INVALID")
        else:
            require(not reconciliation and o["effect_scope"] == "LOCAL_FILESYSTEM_READ"
                    and o["output_sha256"] == q["parameters"]["expected_sha256"]
                    and o["output_bytes"] <= q["parameters"]["max_bytes"]
                    and o["facts"] == {"kind":"STABLE_SNAPSHOT"},"READ_OBSERVATION_INVALID")
    elif status == "PRECONDITION_FAILED":
        require(not reconciliation and effect in {READ,CREATE},"PRECONDITION_STATUS_INVALID")
        if effect == CREATE:
            require(o["effect_scope"] == "LOCAL_METADATA_OBSERVATION" and o["facts"] == {"code":"ALREADY_PRESENT"}
                    and o["output_sha256"] is None and o["output_bytes"] == 0,"CREATE_PRECONDITION_INVALID")
        else:
            require(o["effect_scope"] == "LOCAL_FILESYSTEM_READ" and o["facts"] == {"code":"CONTENT_MISMATCH"}
                    and o["output_sha256"] is not None and o["output_sha256"] != q["parameters"]["expected_sha256"]
                    and o["output_bytes"] <= q["parameters"]["max_bytes"],"READ_PRECONDITION_INVALID")
    elif status == "STATE_MATCH":
        data=q["parameters"].get("text","").encode("utf-8")
        require(reconciliation and effect == CREATE and o["effect_scope"] == "LOCAL_FILESYSTEM_READ"
                and o["causal_attribution"] == "NOT_ESTABLISHED" and o["output_sha256"] == byte_digest(data)
                and o["output_bytes"] == len(data) and o["facts"] == {"kind":"CURRENT_BYTES_ONLY"},"STATE_MATCH_INVALID")
    elif status in {"UNCERTAIN","UNRESOLVED"}:
        require(status == ("UNRESOLVED" if reconciliation else "UNCERTAIN"),"UNCERTAINTY_PHASE_INVALID")
        require(o["output_sha256"] is None and o["output_bytes"] == 0 and o["causal_attribution"] == "NOT_ESTABLISHED",
                "UNCERTAINTY_FACTS_INVALID")
        exact(o["facts"],{"code"}); identifier(o["facts"]["code"])
        allowed_scopes={"SIMULATED","LOCAL_EFFECT_POSSIBLE","LOCAL_FILESYSTEM_READ","NONE"}
        require(o["effect_scope"] in allowed_scopes,"UNCERTAINTY_SCOPE_INVALID")
    else:
        raise Refusal("OBSERVATION_STATUS_INVALID")
    return o

class SimulationAdapter:
    def __init__(self, resource_id: str):
        self.resource_id=identifier(resource_id)
        self.descriptor={"id":resource_id,"adapter":"simulation-v1", "identity_root":digest({"simulation_resource":resource_id,"version":1})}

    def perform(self, q: dict) -> tuple[dict, bytes]:
        validate("request",q)
        require(q["effect"] in {ECHO,ADD},"ADAPTER_EFFECT_MISMATCH")
        p=q["parameters"]
        data=p["text"].encode("utf-8") if q["effect"] == ECHO else canonical(p["left"]+p["right"])
        return observation(q,self.descriptor["identity_root"],"SUCCEEDED","SIMULATED",data,
                           {"kind":"PURE_RECOMPUTATION"}), data

    def reconcile(self, q: dict) -> dict:
        return self.perform(q)[0]

class PrivateDirectoryAdapter:
    def __init__(self, path: Path, resource_id: str):
        self.path=Path(path).absolute(); self.resource_id=identifier(resource_id)
        st=self.path.lstat()
        require(stat.S_ISDIR(st.st_mode) and not self.path.is_symlink(),"PRIVATE_DIRECTORY_REQUIRED")
        self._identity=(st.st_dev,st.st_ino)
        self.descriptor={"id":resource_id,"adapter":"private-directory-v1",
            "identity_root":digest({"path":str(self.path),"device":st.st_dev,"inode":st.st_ino,"version":1})}

    @classmethod
    def initialize(cls, path: Path, resource_id: str):
        """Explicit local effect. Parents must exist; existing roots are refused."""
        path=Path(path)
        require(not path.exists() and not path.is_symlink(),"DIRECTORY_ALREADY_EXISTS")
        path.mkdir(mode=0o700)
        return cls(path,resource_id)

    def _target(self, q: dict) -> Path:
        validate("request",q)
        st=self.path.lstat()
        require(stat.S_ISDIR(st.st_mode) and (st.st_dev,st.st_ino) == self._identity and not self.path.is_symlink(),
                "RESOURCE_INSTANCE_CHANGED")
        return self.path / filename(q["parameters"]["name"])

    def _read(self, path: Path, max_bytes: int) -> bytes:
        st=path.lstat()
        require(stat.S_ISREG(st.st_mode) and st.st_nlink == 1 and not path.is_symlink(),"REGULAR_SINGLE_LINK_FILE_REQUIRED")
        flags=os.O_RDONLY | getattr(os,"O_NOFOLLOW",0) | getattr(os,"O_BINARY",0)
        fd=os.open(path,flags)
        with os.fdopen(fd,"rb") as stream:
            before=os.fstat(stream.fileno())
            require((before.st_dev,before.st_ino)==(st.st_dev,st.st_ino),"RESOURCE_INSTANCE_CHANGED")
            data=stream.read(max_bytes+1)
            after=os.fstat(stream.fileno())
        require(len(data)<=max_bytes,"READ_BUDGET_EXCEEDED")
        require((before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)==
                (after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns),"RESOURCE_CHANGED_DURING_READ")
        return data

    def perform(self, q: dict) -> tuple[dict, bytes | None]:
        require(q["effect"] in {READ,CREATE},"ADAPTER_EFFECT_MISMATCH")
        identity=self.descriptor["identity_root"]
        try:
            target=self._target(q); p=q["parameters"]
            if q["effect"] == READ:
                data=self._read(target,p["max_bytes"])
                if byte_digest(data) != p["expected_sha256"]:
                    return observation(q,identity,"PRECONDITION_FAILED","LOCAL_FILESYSTEM_READ",data,
                                       {"code":"CONTENT_MISMATCH"}),None
                return observation(q,identity,"SUCCEEDED","LOCAL_FILESYSTEM_READ",data,{"kind":"STABLE_SNAPSHOT"}),data
            data=p["text"].encode("utf-8")
            try:
                fd=os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL|getattr(os,"O_NOFOLLOW",0)|getattr(os,"O_BINARY",0),0o600)
            except FileExistsError:
                return observation(q,identity,"PRECONDITION_FAILED","LOCAL_METADATA_OBSERVATION",None,
                                   {"code":"ALREADY_PRESENT"}),None
            with os.fdopen(fd,"wb") as stream:
                stream.write(data); stream.flush(); os.fsync(stream.fileno())
            check=self._read(target,len(data))
            require(check == data,"WRITE_READBACK_MISMATCH")
            return observation(q,identity,"SUCCEEDED","LOCAL_FILESYSTEM_CREATE",check,
                               {"kind":"EXCLUSIVE_CREATE_AND_READBACK"}),None
        except (OSError,Refusal) as exc:
            # Never infer NONE after an attempted external path. No automatic retry.
            code=exc.code if isinstance(exc,Refusal) else type(exc).__name__
            return observation(q,identity,"UNCERTAIN","LOCAL_EFFECT_POSSIBLE",None,
                               {"code":code},"NOT_ESTABLISHED"),None

    def reconcile(self, q: dict) -> dict:
        identity=self.descriptor["identity_root"]
        if q["effect"] == READ:
            return observation(q,identity,"UNRESOLVED","NONE",None,
                               {"code":"HISTORICAL_READ_NOT_RECONSTRUCTIBLE"},"NOT_ESTABLISHED")
        try:
            target=self._target(q); expected=q["parameters"]["text"].encode("utf-8")
            actual=self._read(target,len(expected))
            if actual == expected:
                return observation(q,identity,"STATE_MATCH","LOCAL_FILESYSTEM_READ",actual,
                                   {"kind":"CURRENT_BYTES_ONLY"},"NOT_ESTABLISHED")
            code="CURRENT_BYTES_DIFFER"
        except (OSError,Refusal) as exc:
            code=exc.code if isinstance(exc,Refusal) else type(exc).__name__
        return observation(q,identity,"UNRESOLVED","LOCAL_FILESYSTEM_READ",None,
                           {"code":code},"NOT_ESTABLISHED")
