"""Batch A's complete ordinary-workflow reference suite."""
