"""Ordinary reference workflows and expected lifecycle outcomes.

No attack corpus, altered evidence, fault injection, external applications,
network requests, hostile code, or runtime containment tests are included.
The STARTED-state fixtures below are authored model states, not observed crashes.
"""
from __future__ import annotations
import ast
import contextlib
import io
import tempfile
import subprocess
import sys
import unittest
from pathlib import Path
from ugel.canonical import canonical, digest, byte_digest, seal, load_bytes, Refusal
from ugel.contracts import *
from ugel.gate import evaluate
from ugel.scenarios import ReferenceHost, run_demo
from ugel.history import ZERO, replay, verify_bundle
from ugel.broker import Broker
from ugel.store import Ledger
from ugel.cli import main

class CanonicalAndContracts(unittest.TestCase):
    def test_canonical_key_order_is_stable(self):
        self.assertEqual(digest({"b":2,"a":1}),digest({"a":1,"b":2}))

    def test_unicode_round_trip(self):
        value={"text":"Mosaic — explicit meaning", "count":3}
        self.assertEqual(load_bytes(canonical(value)),value)

    def test_record_root_recomputes(self):
        value=seal({"schema":"example","value":42})
        self.assertEqual(value["root"],digest({"schema":"example","value":42}))

    def test_record_descriptor_matches_executable_validators(self):
        source=Path(__file__).resolve().parents[1]
        descriptor=load_bytes((source/"spec/RECORD-CONTRACTS.json").read_bytes())
        self.assertEqual(descriptor["required_fields"],{k:sorted(v|{"schema","root"}) for k,v in FIELDS.items()})
        self.assertEqual(descriptor["schemas"],SCHEMAS)

    def test_machine_registry_matches_effect_implementation(self):
        source=Path(__file__).resolve().parents[1]
        registry=load_bytes((source/"spec/EFFECT-REGISTRY.json").read_bytes())
        self.assertEqual(registry,REGISTRY)

    def test_effect_registry_has_four_exact_operations(self):
        self.assertEqual({x["id"] for x in REGISTRY["effects"]},EFFECTS)
        self.assertEqual(REGISTRY["ugk_native_binding"],"NOT_BOUND")

class Workflow(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix="ugel-positive-")
        self.folder=Path(self.temp.name)
        self.host=ReferenceHost(self.folder)
    def tearDown(self): self.temp.cleanup()
    def request(self,oid="op",effect=ADD,params=None,**kwargs):
        return self.host.request(oid,effect,params or {"left":2,"right":3},**kwargs)
    def admit(self,q): return self.host.broker.admit(q,expected_head=self.host.ledger.head)
    def verify(self):
        bundle=self.host.export()
        return verify_bundle(bundle,expected_binding_root=self.host.binding["root"],expected_head=self.host.ledger.head,
                             trusted_authority_roots=self.host.trusted)

    def test_pure_gate_repeats_byte_for_byte(self):
        q=self.request()
        a=self.host.broker.preview(q,expected_head=ZERO)
        b=self.host.broker.preview(q,expected_head=ZERO)
        self.assertEqual(canonical(a),canonical(b)); self.assertEqual(a["status"],"PERMITTED")
        self.assertEqual(self.host.ledger.head,ZERO)

    def test_missing_evidence_is_an_actionable_gate(self):
        q=self.request(effect=ECHO,params={"text":"hello"},with_evidence=False)
        result=self.admit(q)
        self.assertEqual(result["status"],"NEEDS_EVIDENCE"); self.assertEqual(self.host.ledger.head,ZERO)

    def test_text_evidence_is_rederived(self):
        q=self.request(effect=ECHO,params={"text":"hello"})
        ev=self.host.evidence[q["evidence_roots"][0]]
        self.assertEqual(ev,make_evidence(q,2000))
        self.assertEqual(ev["finding"]["sha256"],byte_digest(b"hello"))

    def test_pure_simulation_completes(self):
        q=self.request(); result=self.host.run(q)
        self.assertEqual(result["receipt"]["status"],"COMPLETED")
        self.assertEqual(result["receipt"]["effect_scope"],"SIMULATED")
        self.assertEqual(self.verify()["status"],"CONSISTENT_WITH_PINNED_RECORDS")

    def test_full_event_order_before_effect_receipt(self):
        self.host.run(self.request())
        self.assertEqual([e["kind"] for e in self.host.ledger.events()],
                         ["ADMITTED","STARTED","OBSERVED","FINALIZED"])

    def test_normal_local_create_and_read(self):
        q=self.request("write",CREATE,{"name":"candidate.txt","text":"bounded candidate"})
        w=self.host.run(q)
        self.assertEqual(w["receipt"]["effect_scope"],"LOCAL_FILESYSTEM_CREATE")
        data=(self.folder/"workspace"/"candidate.txt").read_bytes()
        q=self.request("read",READ,{"name":"candidate.txt","expected_sha256":byte_digest(data),"max_bytes":100})
        a=self.admit(q); d=self.host.broker.dispatch("read",expected_head=a["head"])
        self.assertEqual(d["data"],data)
        done=self.host.broker.finalize("read",expected_head=d["head"])
        self.assertEqual(done["receipt"]["effect_scope"],"LOCAL_FILESYSTEM_READ")
        self.verify()

    def test_existing_filename_is_not_overwritten(self):
        self.host.run(self.request("first",CREATE,{"name":"once.txt","text":"first"}))
        result=self.host.run(self.request("second",CREATE,{"name":"once.txt","text":"second"}))
        self.assertEqual(result["receipt"]["status"],"REFUSED_AFTER_OBSERVATION")
        self.assertEqual((self.folder/"workspace"/"once.txt").read_text(),"first")
        self.verify()

    def test_reopen_and_finalize_persisted_observation(self):
        q=self.request(); a=self.admit(q)
        d=self.host.broker.dispatch("op",expected_head=a["head"])
        self.host.reopen()
        self.host.broker.adapters={} # Finalization needs no effect adapter.
        r=self.host.broker.finalize("op",expected_head=d["head"])
        self.assertEqual(r["receipt"]["status"],"COMPLETED"); self.verify()

    def test_fresh_process_finishes_recorded_observation_without_adapter(self):
        q=self.request(); a=self.admit(q)
        observed=self.host.broker.dispatch("op",expected_head=a["head"])
        context={"binding":self.host.binding,"contract":self.host.contract,"authority":self.host.authority,
                 "trusted":sorted(self.host.trusted),"head":observed["head"]}
        context_path=self.folder/"context.json"; context_path.write_bytes(canonical(context))
        code = """import json,sys
from pathlib import Path
sys.path.insert(0,sys.argv[1])
from ugel import Broker,Ledger
from ugel.canonical import load_bytes,canonical
p=Path(sys.argv[2]); c=load_bytes(p.read_bytes())
b=Broker(ledger=Ledger(p.parent/'ledger.sqlite',c['binding']['root']),binding=c['binding'],
 expected_binding_root=c['binding']['root'],contract=c['contract'],authority=c['authority'],
 expected_authority_root=c['authority']['root'],trusted_authority_roots=set(c['trusted']),
 evidence={},adapters={},clock=lambda:2500)
print(canonical(b.finalize('op',expected_head=c['head'])).decode('ascii'))
"""
        source=Path(__file__).resolve().parents[1]/"src"
        result=subprocess.run([sys.executable,"-I","-B","-c",code,str(source),str(context_path)],
                              text=True,capture_output=True,timeout=15,check=False)
        self.assertEqual(result.returncode,0,result.stderr)
        out=load_bytes(result.stdout.encode())
        self.assertEqual(out["receipt"]["status"],"COMPLETED")
        self.assertEqual(sum(e["kind"]=="STARTED" for e in self.host.ledger.events()),1)
        self.verify()

    def test_finalization_does_not_renew_execution_authority(self):
        q=self.request(); a=self.admit(q); d=self.host.broker.dispatch("op",expected_head=a["head"])
        self.host.now=2500; self.host.reopen()
        done=self.host.broker.finalize("op",expected_head=d["head"])
        self.assertEqual(done["receipt"]["status"],"COMPLETED")
        next_q=self.request("next")
        self.assertEqual(self.host.broker.preview(next_q,expected_head=self.host.ledger.head)["status"],"NEEDS_AUTHORIZATION")

    def test_finalization_is_idempotent(self):
        done=self.host.run(self.request()); before=len(self.host.ledger.events())
        again=self.host.broker.finalize("op",expected_head=self.host.ledger.head)
        self.assertEqual(done["receipt"],again["receipt"])
        self.assertFalse(again["new_event"]); self.assertEqual(before,len(self.host.ledger.events()))

    def test_retry_of_same_request_does_not_duplicate_dispatch(self):
        q=self.request(); self.host.run(q)
        result=self.admit(q)
        self.assertEqual(result["status"],"ALREADY_RECORDED")
        d=self.host.broker.dispatch("op",expected_head=self.host.ledger.head)
        self.assertEqual(d["status"],"NO_REDISPATCH")
        self.assertEqual(sum(e["kind"]=="STARTED" for e in self.host.ledger.events()),1)

    def test_durable_cancellation_prevents_later_dispatch(self):
        a=self.admit(self.request())
        c=self.host.broker.cancel("op",expected_head=a["head"])
        self.host.reopen()
        result=self.host.broker.dispatch("op",expected_head=c["head"])
        self.assertEqual(result["status"],"NO_REDISPATCH")
        self.assertEqual(self.verify()["operation_states"]["op"],"CANCELLED")

    def test_expired_grant_does_not_start_work(self):
        q=self.request(); self.host.now=2100
        r=self.admit(q)
        self.assertEqual(r["status"],"NEEDS_AUTHORIZATION"); self.assertEqual(self.host.ledger.head,ZERO)

    def test_grant_is_rechecked_at_dispatch(self):
        a=self.admit(self.request()); self.host.now=2100
        d=self.host.broker.dispatch("op",expected_head=a["head"])
        self.assertEqual(d["status"],"DECLINED")
        r=self.host.broker.finalize("op",expected_head=d["head"])
        self.assertEqual(r["receipt"]["status"],"REFUSED")
        self.assertNotIn("STARTED",[e["kind"] for e in self.host.ledger.events()])
        self.verify()

    def test_host_revocation_prevents_dispatch(self):
        a=self.admit(self.request()); self.host.revoke()
        d=self.host.broker.dispatch("op",expected_head=a["head"])
        self.assertEqual(d["status"],"DECLINED")
        self.host.broker.finalize("op",expected_head=d["head"]); self.verify()

    def test_expired_evidence_needs_new_proposal(self):
        q=self.request(effect=ECHO,params={"text":"current"},evidence_until=1100)
        a=self.admit(q); self.host.now=1200
        d=self.host.broker.dispatch("op",expected_head=a["head"])
        self.assertEqual(d["decision"]["status"],"NEEDS_EVIDENCE")
        self.host.broker.finalize("op",expected_head=d["head"]); self.verify()

    def test_inspection_leaves_ledger_and_workspace_unchanged(self):
        self.host.run(self.request())
        before=self.host.ledger.path.read_bytes(); files=list((self.folder/"workspace").iterdir())
        self.host.broker.inspect(); self.host.reopen()
        self.assertEqual(before,self.host.ledger.path.read_bytes())
        self.assertEqual(files,list((self.folder/"workspace").iterdir()))

    def test_missing_ledger_inspection_does_not_initialize(self):
        absent=self.folder/"absent.sqlite"
        with self.assertRaises(Refusal) as caught: Ledger(absent,self.host.binding["root"])
        self.assertEqual(caught.exception.code,"LEDGER_ABSENT_OR_UNSUPPORTED")
        self.assertFalse(absent.exists())

    def test_export_and_replay_are_byte_deterministic(self):
        self.host.run(self.request())
        a=self.host.export(); b=self.host.export()
        self.assertEqual(canonical(a),canonical(b)); self.assertEqual(self.verify(),self.verify())

    def test_receipt_does_not_claim_release_or_project_completion(self):
        r=self.host.run(self.request())["receipt"]
        self.assertEqual(r["project_obligations_satisfied"],[])
        self.assertFalse(r["release_authorized"]); self.assertEqual(r["authority_effect"],"NONE")
        self.assertEqual(r["authenticity"],"UNSIGNED_LOCAL_REFERENCE")

    def pending_fixture(self,q):
        """Declare a paused model state, without inducing a process interruption."""
        self.admit(q); state=self.host.broker.inspect()
        count,used=state["usage"][q["grant_root"]]
        d=evaluate(binding=self.host.binding,contract=self.host.contract,authority=self.host.authority,
                   request=q,evidence=self.host.evidence,now=self.host.now,used_operations=count,used_bytes=used,reserved=True)
        event=self.host.ledger.append(q["operation_id"],"STARTED",{"authority":self.host.authority,"decision":d,
            "evidence":{r:self.host.evidence[r] for r in q["evidence_roots"]}},expected_head=self.host.ledger.head)
        return event

    def test_pending_simulation_reconciles_under_separate_permit(self):
        q=self.request(); self.pending_fixture(q)
        self.host.now=2500; permit=self.host.recovery("op")
        r=self.host.broker.reconcile("op",permit_root=permit["root"],expected_head=self.host.ledger.head)
        out=self.host.broker.finalize("op",expected_head=r["head"])
        self.assertEqual(out["receipt"]["status"],"COMPLETED")
        self.assertEqual(sum(e["kind"]=="STARTED" for e in self.host.ledger.events()),1)
        self.verify()

    def test_matching_current_file_does_not_prove_causal_execution(self):
        q=self.request("pending",CREATE,{"name":"already-there.txt","text":"fixture"})
        self.pending_fixture(q)
        # Fixture file intentionally supplied by the host, not by the effect adapter.
        (self.folder/"workspace"/"already-there.txt").write_text("fixture")
        self.host.now=2500; permit=self.host.recovery("pending")
        r=self.host.broker.reconcile("pending",permit_root=permit["root"],expected_head=self.host.ledger.head)
        out=self.host.broker.finalize("pending",expected_head=r["head"])["receipt"]
        self.assertEqual(out["status"],"RECONCILED_STATE_MATCH")
        self.assertEqual(out["causal_attribution"],"NOT_ESTABLISHED"); self.verify()

    def test_absent_current_file_remains_unresolved(self):
        q=self.request("pending",CREATE,{"name":"absent.txt","text":"fixture"}); self.pending_fixture(q)
        self.host.now=2500; permit=self.host.recovery("pending")
        r=self.host.broker.reconcile("pending",permit_root=permit["root"],expected_head=self.host.ledger.head)
        out=self.host.broker.finalize("pending",expected_head=r["head"])["receipt"]
        self.assertEqual(out["status"],"RECONCILIATION_REQUIRED")
        self.assertFalse(out["terminal"]); self.verify()

    def test_historical_read_remains_unresolved(self):
        q=self.request("pending",READ,{"name":"input.txt","expected_sha256":byte_digest(b"input"),"max_bytes":10})
        self.pending_fixture(q); self.host.now=2500; permit=self.host.recovery("pending")
        r=self.host.broker.reconcile("pending",permit_root=permit["root"],expected_head=self.host.ledger.head)
        out=self.host.broker.finalize("pending",expected_head=r["head"])["receipt"]
        self.assertEqual(out["status"],"RECONCILIATION_REQUIRED"); self.verify()

class ProfilesAndBudgets(unittest.TestCase):
    def test_verify_profile_refuses_mutation_at_dispatch_boundary(self):
        with tempfile.TemporaryDirectory() as d:
            h=ReferenceHost(Path(d),profile="VERIFY_ONLY")
            q=h.request("x",ADD,{"left":1,"right":2})
            self.assertEqual(h.broker.preview(q,expected_head=ZERO)["status"],"PROFILE_REFUSED")
            with self.assertRaises(Refusal): h.broker.admit(q,expected_head=ZERO)
            self.assertEqual(h.ledger.head,ZERO)

    def test_simulation_profile_cannot_dispatch_file_effect(self):
        with tempfile.TemporaryDirectory() as d:
            h=ReferenceHost(Path(d),profile="SIMULATION")
            q=h.request("x",CREATE,{"name":"x.txt","text":"x"})
            self.assertEqual(h.broker.admit(q,expected_head=ZERO)["status"],"PROFILE_REFUSED")
            self.assertEqual(list((Path(d)/"workspace").iterdir()),[])

    def test_operation_budget_is_conservative_across_cancellation(self):
        with tempfile.TemporaryDirectory() as d:
            h=ReferenceHost(Path(d),max_operations=1)
            q=h.request("one",ADD,{"left":1,"right":1}); a=h.broker.admit(q,expected_head=ZERO)
            h.broker.cancel("one",expected_head=a["head"])
            q2=h.request("two",ADD,{"left":1,"right":1})
            self.assertEqual(h.broker.admit(q2,expected_head=h.ledger.head)["status"],"BUDGET_REFUSED")

    def test_byte_budget_reserves_before_effect(self):
        with tempfile.TemporaryDirectory() as d:
            h=ReferenceHost(Path(d),max_total_bytes=3)
            q=h.request("one",ECHO,{"text":"abc"}); h.run(q)
            q2=h.request("two",ECHO,{"text":"a"})
            self.assertEqual(h.broker.admit(q2,expected_head=h.ledger.head)["status"],"BUDGET_REFUSED")

class Entrypoints(unittest.TestCase):
    def test_orientation_reports_real_boundaries(self):
        out=io.StringIO()
        with contextlib.redirect_stdout(out): code=main(["orient"])
        obj=load_bytes(out.getvalue().encode())
        self.assertEqual(code,0); self.assertFalse(obj["host_containment"])
        self.assertEqual(obj["native_ugk_binding"],"NOT_BOUND")

    def test_demonstration_exports_verifiable_bundle(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/"demo"; result=run_demo(p)
            self.assertEqual(result["status"],"PASS_REFERENCE_WORKFLOW")
            pins=load_bytes((p/"PINS.json").read_bytes())
            bundle=load_bytes((p/"BUNDLE.json").read_bytes())
            checked=verify_bundle(bundle,expected_binding_root=pins["binding_root"],expected_head=pins["head"],
                                  trusted_authority_roots=set(pins["authority_roots"]))
            self.assertEqual(checked["status"],"CONSISTENT_WITH_PINNED_RECORDS")
            self.assertEqual(result["event_count"],18)

    def test_live_and_replay_use_same_terminal_derivation(self):
        # Architectural positive check: live finalization calls the shared function.
        path=Path(__file__).resolve().parents[1]/"src/ugel/broker.py"
        module=ast.parse(path.read_text())
        calls=[n.func.id for n in ast.walk(module) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name)]
        self.assertIn("receipt",calls); self.assertIn("replay",calls)

if __name__=="__main__": unittest.main()
