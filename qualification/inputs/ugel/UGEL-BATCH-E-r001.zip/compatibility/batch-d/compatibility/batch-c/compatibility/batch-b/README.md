# UGEL Batch B — Python task harness, r001

**Experimental cooperative reference. INFORMATION_ONLY; constitutional authority
NONE; real A5 false; G0 CLOSED.** Local filesystem, custody, and trusted Python
subprocess effects are real and separately recorded. This is not a sandbox.

Batch B connects a controlled Python coding task to the frozen Batch A file
broker. It adds capability-bearing handles, task context, exact candidate/test
binding, explicit trusted-process authorization, persistent check observations,
and record-only verification. It does not grant native UGK authority or change
any existing UCM review disposition.

## Quick start — standard library, no installation

Use prepared CPython 3.12 or 3.13. Only the host recorded in `evidence/HOST.json`
was exercised; the version range is not a cross-host qualification.

```console
python -B run.py orient
python -B run.py demo --output ../ugel-python-demo
python -B tools/check.py --output ../ugel-python-checks
```

The demo destination must not exist. It creates two local tasks. First, the
original invoice helper fails its six-test regression suite. Then a supplied
repair multiplies unit cents by quantity, preserves the trusted test bytes, and
passes the same exact six tests in a fresh child process. A second fresh Python
process finalizes the already persisted observation without running tests again.
The original project remains unchanged.

The proposal is **prewritten reference material**, not LLM-generated. The same
host API accepts proposals produced by an external agent. No provider credentials,
network access, proprietary harness or installed application are required.

## Use a project

This first supported subset is a **flat directory of UTF-8 `.py` files**, with
1–32 files, at most 500,000 bytes per file and 2,000,000 total source bytes.
Tests must be ordinary top-level `unittest.TestCase` classes with direct,
undecorated test methods. Runtime discovery must equal the AST-derived accepted
inventory. Dynamic test loaders, asynchronous tests, test inheritance, packages,
third-party dependencies, renamed/deleted files, and arbitrary shell commands
are not supported here.

Create a proposal JSON with `{"replacements": {"module.py": "complete replacement text"}}`.
Only existing non-test modules can change. Existing trusted tests remain exact.
The host can use Python directly:

```python
from pathlib import Path
from ugel_python import propose, TaskSession

project = Path("my-flat-project")
replacements = {"module.py": Path("accepted-module.py").read_text(encoding="utf-8")}
plan = propose(project, "repair-001", "Correct the declared behavior", replacements)
# The host reviews this exact plan and retains its root outside the candidate.
accepted_root = plan["root"]
session = TaskSession.initialize(
    project=project,
    plan=plan,
    expected_plan_root=accepted_root,
    output=Path("new-task-workspace"),
    acknowledge_trusted_code_execution=True,
)
receipt = session.run()
print(receipt["status"])       # CHECKED_NOT_RELEASED, CHECK_FAILED, or explicit hold
print(session.current_task())  # Current identities, obligations, freshness, next action
```

For source checkout use `PYTHONPATH=src`, or add the package's `src` directory
using trusted host code. `run.py` does that for CLI use. An installable pyproject
is supplied, but a wheel/install lane has not been exercised in this batch.

`accepted_root = plan["root"]` in the example represents a local host decision,
not independent authenticity. In a real integration, obtain the root from your
accepted task workflow, not from an unreviewed agent proposal.

## CLI workflow

```console
python -B run.py plan --project my-project --proposal proposal.json --task-id repair-001 --objective "Correct the declared behavior"
python -B run.py prepare --project my-project --plan PLAN.json --expected-plan-root <accepted-root> --output new-task --acknowledge-trusted-code-execution
python -B run.py materialize new-task --pins new-task/INITIAL-PINS.json
python -B run.py check new-task --pins CURRENT-PINS.json --leave-observed
python -B run.py finalize new-task --pins CURRENT-PINS.json
python -B run.py export new-task --pins CURRENT-PINS.json --acknowledge-plaintext
python -B run.py verify-bundle BUNDLE.json --pins FINAL-PINS.json
```

Save the plan JSON emitted by `plan`. Each mutation emits its new `pins` object;
retain that object as `CURRENT-PINS.json` before the next command. Initial pins
will intentionally become stale after a mutation. These are local owner
checkpoints, not authenticated external trust. Opening or inspecting existing
custody never initializes a missing task.

CLI codes: `0` = operation/report completed (inspect its domain state); `3` =
failed check or unresolved/held effect; `2` = request not completed. Errors never
infer that no local effect occurred. Read-only context can report an unfinished
task with exit 0; that is not a completion verdict.

## What is and is not governed

* All source reads, candidate creates and candidate reads in materialization go
  through **unchanged Batch A** `Broker` methods and its `fs.read` / `fs.create` IR.
* Test execution uses the **new Batch B** `python.trusted-unittest` request and
  explicit one-run process grant. It is not relabelled as a Batch A effect.
* Its action is one fixed interpreter/checker over one exact candidate and test
  inventory. It has no shell-command or user-selected executable interface.
* Grants are unsigned, host-pinned reference records. Source and candidate
  identities are computed from actual bytes, not arbitrary fixture subjects.
* Child processes are trusted. `-I -S -B` controls Python startup and bytecode,
  but does not prevent filesystem, network, FFI, subprocess, or credential access.
* The deadline and output capture are host controls for cooperative tests,
  **not** a sandbox or a hard resource guarantee for hostile descendants.
* The execution identity includes interpreter bytes and version, not a complete
  standard-library, dynamic-library, or operating-system closure.
* Source snapshots detect the declared before/after changes; they are not atomic
  filesystem snapshots or proof against concurrent hostile writes.
* No model inference, live private agent-harness binding, native UGK admission,
  real identity issuer, secret store, C/Rust adapter, release, or application
  deployment is implemented in this batch.

## Evidence and recovery

`CHECKED_NOT_RELEASED` means the exact accepted candidate passed the exact declared
unittest set, with matching before/after source and candidate snapshots in this
cooperative host observation. It is not general correctness or independent proof.
The current-task view separately flags stale on-disk subjects; historical receipts
remain historical facts rather than silently gaining applicability to new bytes.

An observation persisted before finalization is resumable. A task left at
`CHECK_STARTED` is never automatically redispatched. It requires reconciliation;
this batch does not supply generic process-completion recovery or grant renewal.
Batch A file reconciliation retains its existing separate-permit semantics and
is not silently driven by the Python workflow.

Exports carry complete source, replacement text, file-effect history, and grants.
They are plaintext and unredacted. Export requires an explicit acknowledgement.
Do not put secrets or confidential source in a shared demonstration bundle.

## Verify the delivery

```console
python -B VERIFY.py ../UGEL-BATCH-B-r001.zip --expected-sha256 <external-archive-pin>
```

This standalone verifier imports no candidate modules. It checks source and
package custody, exact recorded test identities, clean reproduction records,
and byte-preservation of the inherited engine. It does not run the tests or
independently authenticate empirical observations.

See `docs/ARCHITECTURE.md`, `docs/CONTRACTS.md`, `docs/RECOVERY.md`,
`docs/UCM-UGK-INTEGRATION.md`, and `evidence/BUILD-REPORT.md` for scope and results.
