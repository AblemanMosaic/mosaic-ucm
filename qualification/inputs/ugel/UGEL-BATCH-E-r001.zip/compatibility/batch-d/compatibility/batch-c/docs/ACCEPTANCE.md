# Acceptance lanes

## Executed lane in this build

The exact 45 Batch C tests are enumerated in spec/CHECK-CONTRACT.json. They cover
ordinary signatures and grant lifecycle, real positive memory-only host execution,
the baseline's expected two test failures, the repaired six-test PASS, separate
process finalization, source preservation, record replay, and exact Batch B reuse.
The inherited Batch B 73-test ordinary suite runs separately against byte-identical
files, not renamed as native Batch C enforcement tests.

Typed expiry/revocation and authored unfinished-state checks are ordinary contract
and state-model tests. They do not create malformed network traffic, attack services,
try forbidden syscalls, induce crashes, or prove hostile-code resistance.

The final check record is bound to the complete current source inventory and exact
test identities. No previous result is used to satisfy a check. A clean extraction
runs both suites again. Host observations and signed demo keys/times are nondeterministic
observations; they are not represented as cross-run byte-identical evidence.

## Explicitly unperformed

Independent review; denied-effect/escape attempts; forced interruption; power loss;
concurrent hostile mutation; child report-integrity attacks; time-source compromise;
key compromise/recovery; native UGK/AOK integration; remote anchors; Windows/macOS;
other architectures; other Python versions than HOST.json; runtime-library closure.

Further operator/adversarial lanes need their own permission and scope. No command
in this package automatically runs an attack lane. A host lacking the named profile
must refuse, not skip required host checks and claim a full pass.
