# Native integration and later batches

Batch A and Batch B are exact predecessors, not a native UGK implementation.
Batch C adds actual local signatures and a kernel-enforced child profile while
preserving the same constitutional ceiling. It changes no previous UCM review
result and claims no UGK Receipt Core, GSOL or AOK ABI equivalence.

A real native bridge still requires the approved kernel/dictionary/version pins,
authority and attenuation mapping, obligation and outcome correspondence, native
receipt-before-effect behavior, qualified host semantics, and reviewed recovery.
The local issuer is not A5, and G0 remains CLOSED.

Batch C's achieved host boundary is the child's fixed memory-compute profile.
Source materialization and administrative custody continue to rely on the trusted
host and unchanged cooperative adapters. Remote identity/anchor services, secure
hardware-backed keys, general Windows containment and independent attack review
remain open. This is not full closure of every future production-security concern.

Batch D can add C ABI and Rust types that lower to the same accepted requests,
without granting new authority by the choice of language. Batch E can supply
restricted component hosts, independent verifiers and optional timestamp/witness
services. Neither requires claiming that this local signature is remote notarization.
