"""Passive standalone custody verifier. Standard library only; no candidate import."""
from __future__ import annotations
import argparse,ast,hashlib,io,json,sys,zipfile
from pathlib import Path,PurePosixPath
D=b'MOSAIC-UGEL-C1\0';B=b'MOSAIC-UGEL-A1\0'
def canon(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('ascii')
def h(b):return hashlib.sha256(b).hexdigest()
def root(x,domain=D):return h(domain+canon(x))
def need(x,msg):
    if not x:raise ValueError(msg)
def load(data):
    def pairs(items):
        d={}
        for k,v in items:need(k not in d,'DUPLICATE_KEY');d[k]=v
        return d
    return json.loads(data,object_pairs_hook=pairs)
def checked(r,domain=D):
    need(type(r) is dict and r.get('root')==root({k:v for k,v in r.items() if k!='root'},domain),'RECORD_ROOT');return r

def unpack(raw):
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        names=z.namelist();need(names==sorted(set(names)),'ZIP_ORDER_OR_DUPLICATE');need(sum(i.file_size for i in z.infolist())<100_000_000,'EXPANSION_BOUND')
        for i in z.infolist():
            p=PurePosixPath(i.filename);need(not p.is_absolute() and '..' not in p.parts and '\\' not in i.filename,'ZIP_PATH')
            need(i.date_time==(1980,1,1,0,0,0) and i.external_attr==(0o100644<<16) and i.compress_type==zipfile.ZIP_DEFLATED and not i.extra and not i.comment,'ZIP_METADATA')
        return {n:z.read(n) for n in names}
def static_ids(members,prefix):
    ids=[]
    for n,b in sorted(members.items()):
        path=PurePosixPath(n)
        if path.parent.as_posix()!=prefix or not path.name.startswith('test_') or path.suffix!='.py':continue
        for c in ast.parse(b,filename=n).body:
            if isinstance(c,ast.ClassDef):ids.extend('tests.'+path.stem+'.'+c.name+'.'+x.name for x in c.body if isinstance(x,ast.FunctionDef) and x.name.startswith('test_'))
    return sorted(ids)
def measurement(r,ids,domain=D):
    checked(r,domain);need(r['status']=='PASS' and r['source_stable'] is True,'RESULT_STATUS')
    need(r['test_ids']==ids and r['tests_run']==len(ids),'EXACT_TEST_INVENTORY')
    need(r['test_set_root']==h(canon(ids)),'TEST_SET_ROOT')
    need(r['rows']==[{'id':i,'status':'PASS'} for i in ids],'EXACT_PASS_ROWS')
    for k in ['failures','errors','skips','expected_failures','unexpected_successes','prior_result_cache_reads']:need(type(r[k]) is int and r[k]==0,'NONZERO_RESULT:'+k)

def verify(path,expected):
    raw=Path(path).read_bytes();need(h(raw)==expected,'EXTERNAL_ARCHIVE_PIN');m=unpack(raw)
    manifest=checked(load(m['PACKAGE-MANIFEST.json']));rows=manifest['files']
    need([r['path'] for r in rows]==sorted(set(m)-{'PACKAGE-MANIFEST.json'}),'PACKAGE_CLOSED_INVENTORY')
    for r in rows:need(len(m[r['path']])==r['bytes'] and h(m[r['path']])==r['sha256'],'PACKAGE_MEMBER:'+r['path'])
    src=checked(load(m['release/SOURCE-MANIFEST.json']))
    source_names=[n for n in m if n!='PACKAGE-MANIFEST.json' and PurePosixPath(n).parts[0] not in {'release','evidence'}]
    expected_rows=[{'path':n,'bytes':len(m[n]),'sha256':h(m[n])} for n in sorted(source_names)]
    need(src['files']==expected_rows and src['file_count']==len(expected_rows) and src['logical_bytes']==sum(r['bytes'] for r in expected_rows),'SOURCE_INVENTORY')
    need(manifest['source_root']==src['root'],'PACKAGE_SOURCE_BINDING')
    cids=static_ids(m,'tests');contract=checked(load(m['spec/CHECK-CONTRACT.json']));need(contract['test_ids']==cids and contract['test_count']==len(cids),'CHECK_CONTRACT')
    result=load(m['evidence/REFERENCE-CHECKS.json']);measurement(result,cids);need(result['source_root']==src['root'] and result['contract_root']==contract['root'] and manifest['reference_check_root']==result['root'],'QUALIFICATION_SOURCE')
    braw=m['predecessors/UGEL-BATCH-B-r001.zip'];need(h(braw)=='dd18f578332d7f45341a3f2e0801f0ea839c12369d78134addb50fe47cdb3edc','B_ARCHIVE_PIN')
    with zipfile.ZipFile(io.BytesIO(braw)) as z:
        for n in z.namelist():need(m['compatibility/batch-b/'+n]==z.read(n),'B_REUSE:'+n)
        need({n for n in m if n.startswith('compatibility/batch-b/')}=={'compatibility/batch-b/'+n for n in z.namelist()},'B_REUSE_INVENTORY')
    bids=static_ids(m,'compatibility/batch-b/tests');br=load(m['evidence/inherited-b/REFERENCE-CHECKS.json']);measurement(br,bids,B)
    need(br['source_root']=='a867250f7eb8289754babfb0b0b342809ca996d15ffd02705d4b864f2217cb52','B_SOURCE_PIN')
    need(result['inherited_b_result_root']==br['root'] and result['inherited_b_test_count']==len(bids) and result['total_distinct_test_count']==len(cids)+len(bids),'COMBINED_COUNTS')
    need(set(cids).isdisjoint(bids),'TEST_ID_OVERLAP')
    if 'evidence/CLEAN-REPRODUCTION.json' in m:
        clean=checked(load(m['evidence/CLEAN-REPRODUCTION.json']))
        again=load(m['evidence/clean-reproduction/REFERENCE-CHECKS.json']);measurement(again,cids)
        againb=load(m['evidence/clean-reproduction/inherited-b/REFERENCE-CHECKS.json']);measurement(againb,bids,B)
        need(again['source_root']==src['root'] and clean['source_root']==src['root'] and clean['status']=='PASS' and clean['clean_check_root']==again['root'],'CLEAN_SOURCE')
        need(again==result,'DETERMINISTIC_REFERENCE_RECORD')
    for n in m:need(PurePosixPath(n).name!='PRIVATE.key' and not n.endswith(('.pyc','.sqlite')),'PRIVATE_OR_RUNTIME_MEMBER')
    return {'schema':'mosaic.ugel.batch-c.passive-verification.v1','status':'PASS','archive_sha256':expected,
      'source_root':src['root'],'source_file_count':src['file_count'],'package_members':len(m),
      'c_test_identities':len(cids),'inherited_b_test_identities':len(bids),'reference_check_root':result['root'],
      'candidate_imports':0,'candidate_invocations':0,'signature_authentication':'NOT_PERFORMED_USE_SEPARATE_PINNED_BUNDLE_VERIFIER',
      'empirical_results_independently_reproduced':False,'standing':'INFORMATION_ONLY','authority_effect':'NONE','real_a5':False,'g0':'CLOSED'}
def main():
    p=argparse.ArgumentParser();p.add_argument('archive',type=Path);p.add_argument('--expected-sha256',required=True);a=p.parse_args()
    try:r=verify(a.archive,a.expected_sha256)
    except Exception as exc:print(json.dumps({'status':'REFUSED','error':str(exc)}));return 2
    print(json.dumps(r,indent=2,sort_keys=True));return 0
if __name__=='__main__':raise SystemExit(main())
