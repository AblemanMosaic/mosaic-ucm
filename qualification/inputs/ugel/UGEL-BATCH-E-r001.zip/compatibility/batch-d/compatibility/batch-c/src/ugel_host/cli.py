"""Human and agent entrypoints. Inspection is side-effect-free; no implicit key creation."""
from __future__ import annotations
import argparse,json,sys
from pathlib import Path
from .common import *
from .policy import policy,inspect_host

def main(argv=None):
    p=argparse.ArgumentParser(prog='ugel-host');s=p.add_subparsers(dest='command',required=True)
    s.add_parser('orient');s.add_parser('inspect-host')
    d=s.add_parser('demo');d.add_argument('--output',type=Path,required=True)
    k=s.add_parser('create-authority');k.add_argument('directory',type=Path)
    k=s.add_parser('create-observer');k.add_argument('directory',type=Path)
    prep=s.add_parser('prepare');prep.add_argument('batch_b_task',type=Path);prep.add_argument('--b-pins',type=Path,required=True)
    prep.add_argument('--operation-id',required=True);prep.add_argument('--output',type=Path,required=True)
    prep.add_argument('--authority',type=Path,required=True);prep.add_argument('--issuer-root',required=True)
    prep.add_argument('--observer',type=Path,required=True);prep.add_argument('--observer-root',required=True)
    for name in ['inspect','execute','permit','reconcile','export','cancel']:
        q=s.add_parser(name);q.add_argument('directory',type=Path);q.add_argument('--pins',type=Path,required=True)
        if name in {'execute','permit','reconcile'}:q.add_argument('--authority',type=Path,required=True)
        if name in {'execute','reconcile','cancel'}:q.add_argument('--observer',type=Path,required=True)
        if name=='execute':q.add_argument('--leave-observed',action='store_true')
        if name=='reconcile':q.add_argument('--permit',type=Path,required=True)
        if name=='export':q.add_argument('--acknowledge-plaintext',action='store_true')
    v=s.add_parser('verify-bundle');v.add_argument('bundle',type=Path);v.add_argument('--pins',type=Path,required=True)
    args=p.parse_args(argv)
    try:
        result=None;pins=None
        if args.command=='orient':
            result=record('orientation',policy=policy(),new_effect='python.memory-unittest',native_ugk_binding='NOT_BOUND',
                trust='LOCAL_ED25519_KEYS_WITH_EXTERNAL_PINS_NOT_REAL_WORLD_IDENTITY',
                host_support='LINUX_X86_64_CPYTHON_3_12_OR_3_13_LIBSECCOMP',
                independent_containment_review='NOT_PERFORMED',no_cooperative_fallback=True,**BOUNDARY)
        elif args.command=='inspect-host':result=inspect_host()
        elif args.command=='demo':
            from .demo import demonstration
            result=demonstration(args.output)
        elif args.command=='create-authority':
            from .trust import Authority
            a=Authority.create(args.directory);result={'public_key':a.public,'retention':'KEEP_PUBLIC_ROOT_SEPARATELY_FROM_CANDIDATES','private_key_location':str(args.directory/'issuer/PRIVATE.key')}
        elif args.command=='create-observer':
            from .trust import LocalKey
            result={'public_key':LocalKey.create(args.directory,'HOST_OBSERVER').public,'retention':'KEEP_PUBLIC_ROOT_SEPARATELY_FROM_CANDIDATES'}
        elif args.command=='prepare':
            from .trust import Authority,LocalKey
            from .service import HostSession
            from ugel_python import TaskSession
            bp=read_json(args.b_pins)
            b=TaskSession(args.batch_b_task,expected_context_root=bp['context_root'],expected_task_head=bp['task_head'],expected_effects_head=bp['effects_head'])
            c=HostSession.prepare(b,args.operation_id,args.output,authority=Authority(args.authority,args.issuer_root),observer=LocalKey(args.observer,args.observer_root))
            result=c.current_task();pins=c.pins()
        elif args.command=='verify-bundle':
            from .semantics import verify_bundle
            pins=read_json(args.pins);result=verify_bundle(read_json(args.bundle),expected_context_root=pins['context_root'],expected_head=pins['head'],issuer_root=pins['issuer_root'],observer_root=pins['observer_root'])
        else:
            from .service import HostSession
            from .trust import Authority,LocalKey
            pins=read_json(args.pins);authority=Authority(args.authority,pins['issuer_root']) if hasattr(args,'authority') else None
            observer=LocalKey(args.observer,pins['observer_root']) if hasattr(args,'observer') else None
            c=HostSession(args.directory,pins,authority=authority,observer=observer)
            if args.command=='inspect':result=c.current_task()
            elif args.command=='execute':result=c.execute(finalize=not args.leave_observed)
            elif args.command=='permit':result=authority.recovery_permit(c.context['request']['root'],c.context['request']['operation_id'],pins['head'],now=canonical_integer_clock())
            elif args.command=='reconcile':result=c.reconcile(read_json(args.permit))
            elif args.command=='export':result=c.export(acknowledge_plaintext=args.acknowledge_plaintext)
            elif args.command=='cancel':result=c.cancel()
            pins=None if args.command in {'permit','export'} else c.pins()
        # Output transport failure never changes the already committed domain result.
        output={'result':result,'pins':pins} if pins is not None else result
        sys.stdout.write(json.dumps(output,sort_keys=True,indent=2)+'\n');sys.stdout.flush()
        status=result.get('status') if isinstance(result,dict) else None
        return 3 if status in {'CHECK_FAILED','RECONCILIATION_REQUIRED','UNRESOLVED_NO_REDISPATCH','HOST_ENTRY_NOT_COMPLETED','SUBJECT_CHANGED_HOLD','REFUSED_HOST_UNAVAILABLE'} else 0
    except (Refusal,OSError,ValueError,KeyError) as exc:
        error={'status':'REQUEST_NOT_COMPLETED','reason':getattr(exc,'code',type(exc).__name__),
               'detail':str(exc)[:1000],'effect_scope':'INSPECT_EXISTING_CUSTODY_NO_NO_EFFECT_INFERENCE',**BOUNDARY}
        try:sys.stderr.write(json.dumps(error)+'\n')
        except OSError:pass
        return 2
