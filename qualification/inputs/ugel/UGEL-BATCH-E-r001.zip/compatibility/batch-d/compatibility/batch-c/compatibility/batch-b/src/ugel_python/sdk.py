"""Capability-bearing Python API. Attenuation is ergonomic; host grants govern effects."""
from __future__ import annotations
from dataclasses import dataclass
from functools import wraps
from ugel.canonical import require,Refusal,byte_digest
from ugel.contracts import record,validate,make_evidence

@dataclass(frozen=True)
class FileResult:
    receipt: dict
    data: bytes | None
    data_origin: str

@dataclass(frozen=True)
class FileCapability:
    _session: object
    resource_id: str
    grant_root: str
    effects: tuple[str,...]
    names: tuple[str,...]
    def restrict(self,*,names=None,effects=None):
        ns=tuple(sorted(set(self.names if names is None else names)))
        es=tuple(sorted(set(self.effects if effects is None else effects)))
        require(set(ns)<=set(self.names) and set(es)<=set(self.effects),'CAPABILITY_CANNOT_EXPAND')
        return FileCapability(self._session,self.resource_id,self.grant_root,es,ns)
    def _perform(self,operation_id,effect,parameters):
        require(effect in self.effects and parameters['name'] in self.names,'HANDLE_SCOPE_REFUSED')
        session=self._session;session._check_heads();session._check_engine();c=session.context
        q=record('request',operation_id=operation_id,subject_root=c['plan']['root'],
                 contract_root=c['effect_contract']['root'],grant_root=self.grant_root,epoch=1,
                 effect=effect,resource_id=self.resource_id,parameters=parameters,evidence_roots=[])
        evidence={}
        if effect=='fs.create':
            e=make_evidence(q,c['process_grant']['valid_until']);evidence[e['root']]=e
            q=record('request',**{k:v for k,v in q.items() if k not in {'schema','root','evidence_roots'}},
                     evidence_roots=[e['root']])
        q=validate('request',q);broker=session._broker(evidence);data=None
        state=broker.inspect(session.effect_head);existing=state['operations'].get(operation_id)
        if existing is not None:require(existing['request']==q,'OPERATION_ID_CONFLICT')
        if existing is None:
            decision=broker.admit(q,expected_head=session.effect_head)
            require(decision['status']=='ADMITTED',decision['status'])
            session.effect_head=decision['head'];existing=broker.inspect()['operations'][operation_id]
        if existing['state']=='ADMITTED':
            result=broker.dispatch(operation_id,expected_head=session.effect_head)
            session.effect_head=broker.inspect()['head']
            if result['status']=='OBSERVED':data=result['data']
            require(result['status'] in {'OBSERVED','DECLINED'},'RECONCILIATION_REQUIRED')
            existing=broker.inspect()['operations'][operation_id]
        if existing['state'] in {'OBSERVED','DECLINED'}:
            final=broker.finalize(operation_id,expected_head=session.effect_head);session.effect_head=final['head']
            existing=broker.inspect()['operations'][operation_id]
        require(existing['receipt'] is not None,'RECONCILIATION_REQUIRED')
        r=existing['receipt'];require(r['status']=='COMPLETED','FILE_OPERATION_NOT_COMPLETED',r['status'])
        origin='LIVE_MEDIATED_READ' if data is not None else 'NO_RETURNED_DATA'
        if effect=='fs.read' and data is None:
            texts=c['plan']['source_texts' if self.resource_id=='source' else 'candidate_texts']
            data=texts[parameters['name']].encode('utf-8')
            require(byte_digest(data)==r['output_sha256'],'SNAPSHOT_RECEIPT_MISMATCH')
            origin='ACCEPTED_SNAPSHOT_NOT_FRESH_READ'
        return FileResult(r,data,origin)
    def read(self,name:str,*,operation_id:str)->FileResult:
        texts=self._session.context['plan']['source_texts' if self.resource_id=='source' else 'candidate_texts']
        require(name in texts,'FILE_NOT_IN_PLAN');data=texts[name].encode('utf-8')
        return self._perform(operation_id,'fs.read',{'name':name,'expected_sha256':byte_digest(data),
                                                    'max_bytes':max(1,len(data))})
    def create(self,name:str,text:str,*,operation_id:str)->FileResult:
        require(self.resource_id=='candidate' and self._session.context['plan']['candidate_texts'].get(name)==text,
                'CANDIDATE_CONTENT_NOT_ACCEPTED')
        return self._perform(operation_id,'fs.create',{'name':name,'text':text})

def governed_task(*,requires:tuple[str,...]):
    """Checks declared SDK capabilities before entry; does not intercept arbitrary Python."""
    allowed={'source.read','candidate.create','candidate.read','python.check'}
    require(set(requires)<=allowed,'TASK_CAPABILITY_UNKNOWN')
    def decorate(fn):
        @wraps(fn)
        def wrapped(session,*args,**kwargs):
            session._check_heads()
            require(set(requires)<=set(session.available_capabilities()),'TASK_CAPABILITIES_MISSING')
            return fn(session,*args,**kwargs)
        wrapped.ugel_requires=requires
        return wrapped
    return decorate
