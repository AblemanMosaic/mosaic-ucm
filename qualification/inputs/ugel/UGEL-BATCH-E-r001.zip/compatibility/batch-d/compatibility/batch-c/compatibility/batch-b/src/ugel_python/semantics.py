"""Shared live/offline derivation. Does not infer empirical authenticity from hashes."""
from __future__ import annotations
from ugel.canonical import *
from ugel.contracts import BOUNDARY,validate
from ugel.history import replay as replay_effects,verify_bundle as verify_effect_bundle
from .model import make,checked,validate_plan
from .custody import ZERO

CONTEXT_FIELDS={'plan','source_path','candidate_path','engine','runtime','checker_sha256','effect_binding',
                'effect_contract','effect_authority','process_grant','created_at','host_profile',
                'native_ugk_binding','authority_authentication','disclosure'}
PROCESS_GRANT_FIELDS={'task_id','plan_root','source_root','candidate_root','engine_root','checker_sha256',
                      'runtime_root','test_ids','valid_from','valid_until','max_runs','timeout_ms',
                      'max_output_bytes','action','containment','issuer'}
CHILD_FIELDS={'request_root','status','discovered_ids','started_ids','rows','tests_run','failures','errors',
              'skips','expected_failures','unexpected_successes','subtest_failures','log_sha256','log_bytes'}
OBS_FIELDS={'request_root','returncode','child_result','source_after','candidate_after','output_sha256',
            'output_bytes','stop_reason','scope','effect_scope','host_containment','external_network_prevention'}

def validate_context(value:dict,expected_root:str)->dict:
    c=checked(value,'task-context',CONTEXT_FIELDS)
    require(c['root']==hash_value(expected_root),'CONTEXT_PIN_MISMATCH')
    p=validate_plan(c['plan'],c['plan']['root'])
    g=checked(c['process_grant'],'process-grant',PROCESS_GRANT_FIELDS)
    require(g['task_id']==p['task_id'] and g['plan_root']==p['root'] and
            g['source_root']==p['source_manifest']['root'] and g['candidate_root']==p['candidate_manifest']['root']
            and g['engine_root']==c['engine']['root'] and g['checker_sha256']==c['checker_sha256']
            and g['runtime_root']==c['runtime']['root'] and g['test_ids']==p['test_ids'],'PROCESS_GRANT_BINDING')
    require(g['action']=='RUN_EXACT_TRUSTED_UNITTEST_SET' and g['max_runs']==1 and
            g['containment']=='COOPERATIVE_NOT_SANDBOXED' and g['issuer']=='LOCAL_OWNER_REFERENCE_PIN',
            'PROCESS_GRANT_SCOPE')
    integer(g['valid_from']);integer(g['valid_until']);require(g['valid_until']>g['valid_from'],'GRANT_WINDOW')
    integer(g['timeout_ms'],100,120000);integer(g['max_output_bytes'],1024,1000000)
    require(c['host_profile']=='COOPERATIVE_TRUSTED_PYTHON' and c['native_ugk_binding']=='NOT_BOUND'
            and c['authority_authentication']=='UNSIGNED_LOCAL_OWNER_PIN','CONTEXT_SCOPE')
    require(c['disclosure']=='FULL_SOURCE_PARAMETERS_AND_GRANTS_NO_REDACTION','DISCLOSURE_INVALID')
    b=validate('binding',c['effect_binding']);contract=validate('contract',c['effect_contract'])
    a=validate('authority',c['effect_authority'])
    require(b['subject_root']==contract['subject_root']==p['root'] and b['contract_root']==contract['root']
            and b['profile']=='LOCAL_REFERENCE','EFFECT_CONTEXT_BINDING')
    require(a['jurisdiction_root']==b['jurisdiction_root'],'AUTHORITY_JURISDICTION')
    for rec in [c['engine'],c['runtime']]:
        require(type(rec) is dict and rec['root']==digest({k:v for k,v in rec.items() if k!='root'}),'IDENTITY_ROOT')
    hash_value(c['checker_sha256'])
    require(type(c['source_path']) is str and type(c['candidate_path']) is str
            and c['source_path']!=c['candidate_path'],'RESOURCE_PATHS_INVALID')
    integer(c['created_at']);return c

def check_request(c:dict,at:int)->dict:
    g=c['process_grant'];integer(at)
    require(g['valid_from']<=at<g['valid_until'],'PROCESS_GRANT_NOT_CURRENT')
    return make('check-request',operation_id='check-'+c['plan']['task_id'],context_root=c['root'],
        plan_root=c['plan']['root'],source_root=g['source_root'],candidate_root=g['candidate_root'],
        candidate_path=c['candidate_path'],grant_root=g['root'],checker_sha256=c['checker_sha256'],
        runtime_root=c['runtime']['root'],test_ids=c['plan']['test_ids'],at=at,
        timeout_ms=g['timeout_ms'],max_output_bytes=g['max_output_bytes'],
        effect='python.trusted-unittest',mode='COOPERATIVE_NOT_SANDBOXED')

def derive_check_receipt(c:dict,q:dict,observation:dict)->dict:
    require(q==check_request(c,q.get('at')),'CHECK_REQUEST_NOT_REDERIVED')
    o=checked(observation,'check-observation',OBS_FIELDS)
    require(o['request_root']==q['root'],'CHECK_OBSERVATION_SUBJECT')
    hash_value(o['output_sha256']);integer(o['output_bytes'],0,q['max_output_bytes'])
    require(o['returncode'] is None or type(o['returncode']) is int,'RETURN_CODE_INVALID')
    require(o['stop_reason'] is None or type(o['stop_reason']) is str,'STOP_REASON_INVALID')
    require(o['scope']=='COOPERATIVE_HOST_OBSERVATION_NOT_INDEPENDENT_ATTESTATION' and
            o['effect_scope']=='LOCAL_PROCESS_AND_CUSTODY_POSSIBLE_FILESYSTEM_EFFECTS' and
            o['host_containment']=='NOT_ESTABLISHED' and o['external_network_prevention']=='NOT_ESTABLISHED',
            'OBSERVATION_SCOPE_INVALID')
    source_ok=o['source_after']==c['plan']['source_manifest']
    candidate_ok=o['candidate_after']==c['plan']['candidate_manifest']
    child=o['child_result']; child_ok=False; inventory_ok=False; test_outcome='NOT_ESTABLISHED'
    if child is not None:
        child=checked(child,'child-result',CHILD_FIELDS)
        require(child['request_root']==q['root'],'CHILD_REQUEST_BINDING')
        for key in ['tests_run','failures','errors','skips','expected_failures','unexpected_successes','log_bytes']:
            integer(child[key])
        hash_value(child['log_sha256']);require(type(child['rows']) is list,'CHILD_ROWS_REQUIRED')
        for row in child['rows']:
            exact(row,{'id','status'});require(type(row['id']) is str and row['status'] in
                {'PASS','FAIL','ERROR','SKIP','EXPECTED_FAILURE','UNEXPECTED_SUCCESS'},'CHILD_ROW_INVALID')
        require(type(child['subtest_failures']) is list,'CHILD_SUBTESTS_INVALID')
        inventory_ok=(child['discovered_ids']==q['test_ids'] and child['started_ids']==q['test_ids'] and
                      sorted(r['id'] for r in child['rows'])==q['test_ids'] and child['tests_run']==len(q['test_ids']))
        zero=all(child[k]==0 for k in ['failures','errors','skips','expected_failures','unexpected_successes'])
        calculated=inventory_ok and zero and not child['subtest_failures'] and all(r['status']=='PASS' for r in child['rows'])
        require((child['status']=='PASS')==calculated,'CHILD_STATUS_NOT_REDERIVED')
        require(child['status'] in {'PASS','FAIL','INVENTORY_MISMATCH'},'CHILD_STATUS_INVALID')
        child_ok=calculated and o['returncode']==0
        test_outcome='PASS_EXACT_DECLARED_TESTS' if child_ok else 'NOT_ALL_DECLARED_TESTS_PASSED'
    uncertain=(o['stop_reason'] is not None or o['returncode'] is None or child is None)
    status=('RECONCILIATION_REQUIRED' if uncertain else 'SUBJECT_CHANGED_HOLD' if not(source_ok and candidate_ok)
            else 'CHECKED_NOT_RELEASED' if child_ok else 'CHECK_FAILED')
    return make('task-receipt',context_root=c['root'],plan_root=c['plan']['root'],request_root=q['root'],
                observation_root=o['root'],source_root=q['source_root'],candidate_root=q['candidate_root'],
                checker_sha256=c['checker_sha256'],runtime_root=c['runtime']['root'],test_ids=q['test_ids'],
                status=status,test_outcome=test_outcome,source_unchanged=source_ok,candidate_unchanged=candidate_ok,
                inventory_complete=inventory_ok,completed_obligations=(['CANDIDATE_BYTES_MATCH','EXACT_DECLARED_TESTS_PASS',
                'SOURCE_UNCHANGED'] if status=='CHECKED_NOT_RELEASED' else []),
                remaining_obligations=['INDEPENDENT_REVIEW','NATIVE_UGK_AUTHORITY','HOST_CONTAINMENT',
                                       'GENERAL_CORRECTNESS','RELEASE_AUTHORIZATION'],
                new_execution_permitted=False,automatic_retry=False,release_authorized=False,
                authenticity='UNSIGNED_COOPERATIVE_HOST_OBSERVATION',**BOUNDARY)

def effect_state(c:dict,bundle:dict):
    verify_effect_bundle(bundle,expected_binding_root=c['effect_binding']['root'],expected_head=bundle['head'],
                         trusted_authority_roots={c['effect_authority']['root']})
    require(bundle['binding']==c['effect_binding'] and bundle['contract']==c['effect_contract'],'FILE_BUNDLE_CONTEXT')
    return replay_effects(binding=bundle['binding'],contract=bundle['contract'],events=bundle['events'],
                          trusted_authority_roots={c['effect_authority']['root']})

def materialized_body(c:dict,bundle:dict)->dict:
    state=effect_state(c,bundle);p=c['plan'];receipts=[]
    for i,name in enumerate(sorted(p['source_texts'])):
        for prefix,effect,rid,text in [('read-source','fs.read','source',p['source_texts'][name]),
                                     ('create-candidate','fs.create','candidate',p['candidate_texts'][name]),
                                     ('read-candidate','fs.read','candidate',p['candidate_texts'][name])]:
            oid=f'{prefix}-{i}';op=state['operations'].get(oid)
            require(op is not None and op['state']=='COMPLETED','MATERIALIZATION_INCOMPLETE',oid)
            q=op['request'];require(q['effect']==effect and q['resource_id']==rid and q['parameters']['name']==name,
                                   'FILE_OPERATION_BINDING')
            if effect=='fs.create':require(q['parameters']['text']==text,'CANDIDATE_TEXT_MISMATCH')
            else:require(q['parameters']['expected_sha256']==byte_digest(text.encode('utf-8')),'SOURCE_DIGEST_MISMATCH')
            receipts.append(op['receipt']['root'])
    require(len(state['operations'])==3*len(p['source_texts']),'UNPLANNED_FILE_OPERATION')
    return {'effects_head':state['head'],'source_root':p['source_manifest']['root'],
            'candidate_root':p['candidate_manifest']['root'],'receipt_roots':receipts}

def replay_task(c:dict,events:list[dict],effects_bundle:dict)->dict:
    validate_context(c,c['root']);effect_state(c,effects_bundle)
    require(type(events) is list and len(events)<=16,'TASK_EVENT_LIMIT')
    phase='INITIALIZED';head=ZERO;request=None;obs=None;receipt=None
    for index,event in enumerate(events,1):
        e=checked(event,'task-event',{'sequence','previous','context_root','kind','body'})
        require(e['sequence']==index and e['previous']==head and e['context_root']==c['root'],'TASK_CHAIN_INVALID')
        body=e['body'];kind=e['kind']
        if kind=='MATERIALIZED':
            require(phase=='INITIALIZED','TASK_TRANSITION')
            target=body.get('effects_head');prefix=[]
            for item in effects_bundle['events']:
                prefix.append(item)
                if item['root']==target:break
            truncated=seal({**{k:v for k,v in effects_bundle.items() if k!='root'},'events':prefix,'head':target})
            require(body==materialized_body(c,truncated),'MATERIALIZATION_NOT_REDERIVED');phase='MATERIALIZED'
        elif kind=='CHECK_STARTED':
            require(phase=='MATERIALIZED','CHECK_ALREADY_STARTED');exact(body,{'request'})
            request=check_request(c,body['request'].get('at'));require(request==body['request'],'CHECK_REQUEST_NOT_REDERIVED')
            phase='CHECK_STARTED'
        elif kind=='CHECK_OBSERVED':
            require(phase=='CHECK_STARTED','CHECK_OBSERVATION_STATE');exact(body,{'observation'})
            obs=body['observation'];derive_check_receipt(c,request,obs);phase='CHECK_OBSERVED'
        elif kind=='CHECK_FINALIZED':
            require(phase=='CHECK_OBSERVED','CHECK_FINALIZE_STATE');exact(body,{'receipt'})
            receipt=derive_check_receipt(c,request,obs);require(receipt==body['receipt'],'CHECK_RECEIPT_NOT_REDERIVED')
            phase=receipt['status']
        else:raise Refusal('TASK_EVENT_KIND_INVALID')
        head=e['root']
    return {'phase':phase,'head':head,'request':request,'observation':obs,'receipt':receipt,'event_count':len(events)}

def verify_task_bundle(bundle:dict,*,expected_context_root:str,expected_task_head:str,expected_effects_head:str)->dict:
    b=checked(bundle,'task-bundle',{'context','task_events','effects_bundle','task_head','effects_head','disclosure'})
    c=validate_context(b['context'],expected_context_root)
    require(b['disclosure']==c['disclosure'],'BUNDLE_DISCLOSURE')
    require(b['effects_head']==b['effects_bundle']['head']==hash_value(expected_effects_head),'EFFECTS_HEAD_PIN')
    state=replay_task(c,b['task_events'],b['effects_bundle'])
    require(state['head']==b['task_head']==hash_value(expected_task_head),'TASK_HEAD_PIN')
    return make('verification',status='CONSISTENT_WITH_PINNED_RECORDS',context_root=c['root'],
        plan_root=c['plan']['root'],bundle_root=b['root'],task_head=state['head'],effects_head=b['effects_head'],
        task_state=state['phase'],receipt_root=state['receipt']['root'] if state['receipt'] else None,
        test_outcome=state['receipt']['test_outcome'] if state['receipt'] else 'NOT_ESTABLISHED',
        empirical_execution_independently_verified=False,signature_authentication=False,
        native_ugk_binding='NOT_BOUND',scope='RECORD_DERIVATION_NOT_PROOF_OF_CODE_CORRECTNESS',**BOUNDARY)
