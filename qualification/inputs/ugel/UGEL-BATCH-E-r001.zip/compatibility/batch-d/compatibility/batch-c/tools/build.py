"""Deterministic package construction, bound to completed ordinary-check evidence."""
import argparse,hashlib,json,zipfile
from pathlib import Path
from source_inventory import canonical,seal,inventory
ROOT=Path(__file__).resolve().parents[1]
def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    src=inventory(ROOT);qualified=json.loads((ROOT/'evidence/REFERENCE-CHECKS.json').read_bytes())
    if qualified['status']!='PASS' or qualified['source_root']!=src['root']:raise SystemExit('QUALIFIED_SOURCE_MISMATCH')
    (ROOT/'release').mkdir(exist_ok=True);(ROOT/'release/SOURCE-MANIFEST.json').write_bytes(canonical(src)+b'\n')
    members={}
    for path in sorted(ROOT.rglob('*')):
        rel=path.relative_to(ROOT)
        if path.is_symlink():raise SystemExit('PACKAGE_SYMLINK')
        if any(x in {'__pycache__','.git'} for x in rel.parts) or not path.is_file() or rel.as_posix()=='PACKAGE-MANIFEST.json':continue
        if path.suffix in {'.pyc','.pyo'} or path.name=='PRIVATE.key' or path.suffix=='.sqlite':raise SystemExit('PRIVATE_OR_RUNTIME_FILE_IN_PACKAGE')
        members[rel.as_posix()]=path.read_bytes()
    rows=[{'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in sorted(members.items())]
    manifest=seal({'schema':'mosaic.ugel.batch-c.package-manifest.v1','files':rows,'file_count':len(rows),
        'source_root':src['root'],'reference_check_root':qualified['root'],'standing':'INFORMATION_ONLY','authority_effect':'NONE','real_a5':False,'g0':'CLOSED'})
    members['PACKAGE-MANIFEST.json']=canonical(manifest)+b'\n'
    (ROOT/'PACKAGE-MANIFEST.json').write_bytes(members['PACKAGE-MANIFEST.json'])
    a.output.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(a.output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,data in sorted(members.items()):
            zi=zipfile.ZipInfo(name,(1980,1,1,0,0,0));zi.compress_type=zipfile.ZIP_DEFLATED;zi.create_system=3;zi.external_attr=0o100644<<16
            z.writestr(zi,data,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    print(json.dumps({'archive':str(a.output),'sha256':hashlib.sha256(a.output.read_bytes()).hexdigest(),'bytes':a.output.stat().st_size,'members':len(members),'source_root':src['root'],'package_root':manifest['root']},indent=2))
if __name__=='__main__':main()
