"""Cooperative reference broker; new execution never follows a lost acknowledgment."""
from __future__ import annotations
import threading
from typing import Callable
from .canonical import *
from .contracts import *
from .gate import evaluate, recovery_authorized
from .history import replay, receipt, cancellation_receipt, check_cancel, TERMINAL
from .adapters import observation
from .store import Ledger

class Broker:
    def __init__(self, *, ledger: Ledger, binding: dict, expected_binding_root: str,
                 contract: dict, authority: dict, expected_authority_root: str,
                 trusted_authority_roots: set[str], evidence: dict[str,dict],
                 adapters: dict, clock: Callable[[],int]):
        self.binding=validate("binding",binding); self.contract=validate("contract",contract)
        self.authority=validate("authority",authority)
        require(self.binding["root"]==expected_binding_root==ledger.binding_root,"BINDING_PIN_MISMATCH")
        require(self.authority["root"]==expected_authority_root and expected_authority_root in trusted_authority_roots,
                "AUTHORITY_PIN_REQUIRED")
        self.trusted=set(trusted_authority_roots); self.ledger=ledger; self.clock=clock
        self.evidence=copy(evidence); self.adapters=dict(adapters); self._lock=threading.RLock()
        for rid,a in self.adapters.items():
            require(a.descriptor in self.binding["resources"] and rid==a.descriptor["id"],"ADAPTER_BINDING_MISMATCH")
        self.inspect() # Read-only construction, including an empty existing ledger.

    def _mutable(self):
        require(self.binding["profile"] != "VERIFY_ONLY","PROFILE_REFUSED")

    def inspect(self, expected_head: str | None = None)->dict:
        state=replay(binding=self.binding,contract=self.contract,events=self.ledger.events(),
                     trusted_authority_roots=self.trusted)
        if expected_head is not None: require(state["head"]==expected_head,"STALE_LEDGER_HEAD")
        return state

    def _decision(self,q:dict,state:dict,reserved:bool)->dict:
        now=integer(self.clock())
        require(now>=state["last_host_time"],"HOST_CLOCK_REGRESSION")
        count,used=state["usage"].get(q["grant_root"],(0,0))
        return evaluate(binding=self.binding,contract=self.contract,authority=self.authority,request=q,
                        evidence=self.evidence,now=now,used_operations=count,used_bytes=used,reserved=reserved)

    def preview(self,request:dict,*,expected_head:str)->dict:
        q=validate("request",request); state=self.inspect(expected_head)
        existing=state["operations"].get(q["operation_id"])
        require(existing is None or existing["request"]==q,"OPERATION_ID_CONFLICT")
        return self._decision(q,state,existing is not None)

    def admit(self,request:dict,*,expected_head:str)->dict:
        self._mutable()
        with self._lock:
            q=validate("request",request); state=self.inspect(expected_head)
            existing=state["operations"].get(q["operation_id"])
            if existing:
                require(existing["request"]==q,"OPERATION_ID_CONFLICT")
                return {"status":"ALREADY_RECORDED","head":state["head"],"state":existing["state"]}
            d=self._decision(q,state,False)
            if d["status"]!="PERMITTED":
                return {"status":d["status"],"decision":d,"head":state["head"],"custody_effect":"NONE"}
            ev={r:self.evidence[r] for r in q["evidence_roots"] if r in self.evidence}
            event=self.ledger.append(q["operation_id"],"ADMITTED",{"request":q,"decision":d,
                "authority":self.authority,"evidence":ev},expected_head=state["head"])
            return {"status":"ADMITTED","decision":d,"head":event["root"],"custody_effect":"LOCAL_SQLITE_APPEND"}

    def dispatch(self,operation_id:str,*,expected_head:str)->dict:
        self._mutable()
        with self._lock:
            state=self.inspect(expected_head); op=state["operations"].get(operation_id)
            require(op is not None,"OPERATION_UNKNOWN")
            if op["state"] in TERMINAL or op["state"] in {"OBSERVED","DECLINED"}:
                return {"status":"NO_REDISPATCH","head":state["head"],"state":op["state"]}
            require(op["state"]=="ADMITTED","RECONCILIATION_REQUIRED")
            q=op["request"]; d=self._decision(q,state,True)
            payload={"authority":self.authority,"decision":d,"evidence":{r:self.evidence[r] for r in q["evidence_roots"] if r in self.evidence}}
            if d["status"]!="PERMITTED":
                event=self.ledger.append(operation_id,"DECLINED",payload,expected_head=state["head"])
                return {"status":"DECLINED","head":event["root"],"decision":d}
            require(q["resource_id"] in self.adapters,"ADAPTER_UNAVAILABLE")
            adapter=self.adapters[q["resource_id"]]
            started=self.ledger.append(operation_id,"STARTED",payload,expected_head=state["head"])
            # Admission + STARTED are committed before invoking the adapter.
            try:
                observed,data=adapter.perform(q)
            except Exception as exc:
                resource=next(r for r in self.binding["resources"] if r["id"]==q["resource_id"])
                observed=observation(q,resource["identity_root"],"UNCERTAIN",
                    "SIMULATED" if q["effect"] in {ECHO,ADD} else "LOCAL_EFFECT_POSSIBLE",
                    None,{"code":type(exc).__name__},"NOT_ESTABLISHED")
                data=None
            # Use the shared replay validator before accepting a report.
            try:
                trial=seal({"schema":SCHEMAS["event"],"sequence":started["sequence"]+1,
                    "previous":started["root"],"operation_id":operation_id,"kind":"OBSERVED", "body":{"observation":observed}})
                replay(binding=self.binding,contract=self.contract,events=self.ledger.events()+[trial],trusted_authority_roots=self.trusted)
                event=self.ledger.append(operation_id,"OBSERVED",{"observation":observed},expected_head=started["root"])
            except (Refusal,OSError):
                return {"status":"OBSERVATION_PENDING","effect_may_have_occurred":True,
                        "last_committed_head":started["root"],"pending_observation":observed,
                        "next_action":"INSPECT_THEN_RECONCILE_NO_REDISPATCH"}
            # Deliberately leaves a persisted OBSERVED state; finalize is resumable.
            return {"status":"OBSERVED","head":event["root"],"observation":observed,"data":data}

    def finalize(self,operation_id:str,*,expected_head:str)->dict:
        self._mutable()
        with self._lock:
            state=self.inspect(expected_head); op=state["operations"].get(operation_id)
            require(op is not None,"OPERATION_UNKNOWN")
            if op["receipt"] is not None:
                return {"receipt":op["receipt"],"head":state["head"],"new_event":False}
            require(op["state"] in {"OBSERVED","DECLINED"},"OBSERVATION_REQUIRED")
            result=receipt(self.binding,op)
            event=self.ledger.append(operation_id,"FINALIZED",{"receipt":result},expected_head=state["head"])
            return {"receipt":result,"head":event["root"],"new_event":True}

    def cancel(self,operation_id:str,*,expected_head:str,reason:str="OWNER_CANCELLED")->dict:
        self._mutable(); identifier(reason)
        with self._lock:
            state=self.inspect(expected_head); op=state["operations"].get(operation_id)
            require(op is not None and op["state"]=="ADMITTED","CANCEL_STATE_INVALID")
            now=integer(self.clock()); require(now>=state["last_host_time"],"HOST_CLOCK_REGRESSION")
            check_cancel(self.binding,op,self.authority,now)
            r=cancellation_receipt(self.binding,op,self.authority,now,reason)
            event=self.ledger.append(operation_id,"CANCELLED",{"authority":self.authority,"at":now,
                "reason":reason,"receipt":r},expected_head=state["head"])
            return {"receipt":r,"head":event["root"]}

    def reconcile(self,operation_id:str,*,permit_root:str,expected_head:str)->dict:
        self._mutable()
        with self._lock:
            state=self.inspect(expected_head); op=state["operations"].get(operation_id)
            require(op is not None and op["state"] in {"STARTED","UNCERTAIN"},"RECONCILIATION_STATE_INVALID")
            q=op["request"]; now=integer(self.clock()); require(now>=state["last_host_time"],"HOST_CLOCK_REGRESSION")
            recovery_authorized(binding=self.binding,authority=self.authority,request=q,
                operation_head=op["operation_head"],permit_root=permit_root,now=now)
            require(q["resource_id"] in self.adapters,"ADAPTER_UNAVAILABLE")
            adapter=self.adapters[q["resource_id"]]
            try: obs=adapter.reconcile(q)
            except Exception as exc:
                obs=observation(q,adapter.descriptor["identity_root"],"UNRESOLVED","LOCAL_FILESYSTEM_READ",None,
                                {"code":type(exc).__name__},"NOT_ESTABLISHED")
            payload={"authority":self.authority,"permit_root":permit_root,"at":now,"observation":obs}
            trial=seal({"schema":SCHEMAS["event"],"sequence":state["event_count"]+1,"previous":state["head"],
                        "operation_id":operation_id,"kind":"RECOVERY_OBSERVED","body":payload})
            replay(binding=self.binding,contract=self.contract,events=self.ledger.events()+[trial],trusted_authority_roots=self.trusted)
            event=self.ledger.append(operation_id,"RECOVERY_OBSERVED",payload,expected_head=state["head"])
            return {"status":"OBSERVED","head":event["root"],"observation":obs}

    def export(self,*,expected_head:str,acknowledge_plaintext:bool=False)->dict:
        require(acknowledge_plaintext is True,"EXPLICIT_EXPORT_DISCLOSURE_REQUIRED")
        events=self.ledger.events()
        state=replay(binding=self.binding,contract=self.contract,events=events,trusted_authority_roots=self.trusted)
        require(state["head"] == expected_head,"STALE_LEDGER_HEAD")
        return seal({"schema":SCHEMAS["bundle"],"binding":self.binding,"contract":self.contract,
                     "events":events,"head":state["head"],
                     "disclosure":"FULL_LOCAL_INPUTS_AND_GRANTS_NO_SECRET_REDACTION"})
