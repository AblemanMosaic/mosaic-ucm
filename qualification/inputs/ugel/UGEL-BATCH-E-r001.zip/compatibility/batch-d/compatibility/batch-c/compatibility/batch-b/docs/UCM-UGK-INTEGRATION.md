# UCM / UGK and harness integration boundary

The canonical Batch A archive is preserved with SHA-256
`4fc49f0a9cf46a0b83d2de593768981991413434c6726ae7351ae611a076df27`.
Every inherited `src/ugel` module, test file, and required contract record remains
byte-identical. `provenance/BATCH-A-REUSE.json` enumerates that exact reuse.

## Batch B delivered

* Capability-bearing Python file handles and an optional task decorator.
* A plan/acceptance boundary for actual project and candidate bytes.
* Controlled materialization through the unmodified Batch A broker.
* A separately declared exact trusted-Python test operation and host grant.
* Persistent current-task context, check observation, finalization and replay.
* A CLI and Python API through which an external coding agent can supply proposals.

Native UCM/UGK semantics and the private real AI harness are **NOT_BOUND**. Naming
something a grant does not make it a native warrant. A host checkpoint is not an
issuer credential. No code or result here closes findings in earlier UCM packages.

## Host integration contract

An eventual real harness should supply and retain: accepted project/task roots,
trusted test/checker policy, current authority/epoch/revocation information,
resource-directory identities, external continuity heads, and review decisions.
It can call `propose`, show/review the plan, then initialize `TaskSession` under a
bounded grant. It must keep proposal generation separate from plan acceptance.
The supplied model-independent API is usable now; no provider is called by this
package. Task output is never silently admitted into the project's main source.

A native bridge still needs the exact UGK/AOK version and semantic dictionary,
approved authority mapping, intent/warrant/admission correspondence, receipt
translation, and a qualified effect boundary. `spec/NATIVE-BINDING.json` retains
those open obligations. Batch A's `ugk_binding: NOT_BOUND` remains unchanged.

## Next batches

**C:** one named host isolation configuration and real trust services; actual
containment and separately authorized interruption/recovery validation. Replace
cooperative ambient access with supported enforcement. Add the exact recovery
paths for uncertain process effects and secure custody of external heads.

**D:** C/Rust adapters to accepted common contracts; no new authority through a
language wrapper. **E:** WASI/components, independent verifiers and optional
attestation/witness providers. Cloud storage and legal notarization are outside
this batch.
