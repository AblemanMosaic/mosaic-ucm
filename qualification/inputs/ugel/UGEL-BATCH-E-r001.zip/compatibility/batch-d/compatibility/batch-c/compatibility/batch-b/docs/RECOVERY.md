# Recovery, continuity and epistemic boundaries

## Supported ordinary continuations

| Recorded state | Permitted reference continuation |
|---|---|
| Task INITIALIZED with no A operations | Materialize the accepted plan |
| A operation ADMITTED | Recheck current A authority before dispatch |
| A operation OBSERVED / DECLINED | Derive and append the existing A receipt |
| A operation COMPLETED | Return the existing receipt, never repeat its effect |
| Task MATERIALIZED | Run the one exact check if current authority still permits it |
| Task CHECK_OBSERVED | Reopen and finalize the persisted observation, without a process adapter |
| Terminal task receipt | Return it unchanged; new work needs a successor task |

The fresh-process finalization checks close and reopen normal supported phases.
They do not simulate an abrupt process kill, lost fsync or power failure.

## Deliberate unresolved boundaries

`CHECK_STARTED` without a recorded observation can mean the child did not start,
ran, is running, or completed without acknowledgment. It always returns a
reconciliation requirement. The workflow never repeats the child to find out.
No general process reconciliation/absence proof is implemented in Batch B.

A `CHECK_OBSERVED` write failure returns pending observation material and the last
known committed head. This does not automatically authorize its later import.
Inspect existing custody, verify the observation through an approved recovery
path, and use an independently reviewed successor before operational deployment.

Batch A file reconciliation remains available under its separate exact-operation
permit. This Python runner does not mint that recovery authority or turn a current
matching file into proof of the earlier operation's causal success.

A read SDK call whose receipt was already finalized returns source bytes retained
in the accepted plan and labels them `ACCEPTED_SNAPSHOT_NOT_FRESH_READ`. It does
not pretend that returning old data performed a new read. The workflow's ordinary
before/after source observations are separate.

## Host and persistence limits

One cooperating owner controls directories, SQLite files, host time and pins.
Expected-head comparison prevents cooperating stale callers from knowingly
appending against the wrong state. It does not authenticate custody against an
arbitrary filesystem writer. There is no global atomicity between A and B ledgers,
files, subprocesses and the caller's checkpoint storage.

Initialization is explicitly effectful and must use a fresh destination. An error
preserves partial state and reports local effects as possible/present, never a
clean no-effect refusal. Inspection opens existing databases read-only. No failed
initialization is automatically deleted or reinterpreted as a valid task.

Timeout/output controls target a cooperative child. No host-wide process-tree,
resource or network sandbox is established. Abrupt interruption, concurrent hostile
mutation, sudden power loss and cross-platform containment are Batch C work.
