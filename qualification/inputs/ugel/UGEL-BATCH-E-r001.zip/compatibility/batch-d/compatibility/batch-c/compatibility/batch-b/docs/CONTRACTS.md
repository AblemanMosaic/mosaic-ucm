# Batch B record contracts

Batch B uses `mosaic.ugel.batch-b.*.v1` schemas and the unchanged Batch A canonical
JSON/hash dialect (integer-only canonical JSON, `MOSAIC-UGEL-A1` hash domain).
The versioned schema in each body distinguishes new records. Raw file hashes are
ordinary SHA-256 over bytes. These are provisional UGEL records, not UGK wire IDs.

## Plans and capabilities

A task plan binds two complete flat project manifests, exact text for both, the
normalized changed-path set, unchanged test filenames, exact static test IDs,
objective, task ID, proposal root, and an explicit bounded claim scope. Validation
reconstructs the complete plan. It cannot silently accept an extra changed module
or replacement of a trusted test. A newly chosen test policy is a new task plan.

The host context binds the plan, source/candidate directory instances, engine and
checker identities, interpreter observation, A file authority and a separate
B process grant. It pins `COOPERATIVE_TRUSTED_PYTHON` rather than implying an OS
security profile. Grants are host choices, not credentials; permit issuance and
revocation through a real authority service remain unbound.

The process grant has one action, `RUN_EXACT_TRUSTED_UNITTEST_SET`, for one exact
plan/candidate/checker/interpreter/test inventory, a validity window, a maximum of
one dispatch, a timeout and a bounded parent output capture. No arbitrary command,
shell, binary path, environment expansion or network grant is accepted by this API.
The host profile is nevertheless cooperative: absence of a network API is not
prevention of a trusted child calling the OS itself.

## Strongest supported final statement

`CHECKED_NOT_RELEASED` requires all of:

* Exact source/candidate materialization through the A receipt chain.
* A currently valid bound one-run process grant at the recorded dispatch time.
* A matching checker request and complete dynamically discovered/started/test-row set.
* Every declared test passes; zero failures, errors, skips, expected failures,
  unexpected successes, and failed subtests; child return code zero.
* Unchanged original source and exact candidate bytes after the child returns.
* No timeout/output/observation uncertainty.

Only `CANDIDATE_BYTES_MATCH`, `EXACT_DECLARED_TESTS_PASS`, and `SOURCE_UNCHANGED`
are marked complete by that result. General correctness, native authority, host
containment, independent review and release remain explicitly unestablished.

Other statuses: `CHECK_FAILED`, `SUBJECT_CHANGED_HOLD`, and
`RECONCILIATION_REQUIRED`. A process exception is not a successful test result.
A test failure remains a completed observation of failing tests, rather than a
request to rerun the same one-shot operation. A revised proposal uses a successor
task, with a new accepted plan and grant.

## Replay and pins

The full task bundle contains the accepted context, A file bundle, and B task
history. `verify_task_bundle()` requires external context and both final-head
pins. It replays A's semantic gate/budget/receipt logic, checks materialization
against the correct effect-history prefix, and uses exactly the live B terminal
derivation for the task receipt. It never imports or executes the candidate.

The verifier establishes consistency relative to those host pins and local
observations. It does not authenticate the host, prove physical execution, or
refresh the receipt's applicability to today's on-disk files.

## Source scope

Flat UTF-8 `.py` sources and conventional static unittest classes are a deliberately
small first integration. A body supplied by a coding model is merely a proposal
until accepted by the host. The built demo's repair is prewritten; the package does
not include an LLM provider, automatic planner, or private-harness binding.
