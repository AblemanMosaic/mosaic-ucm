"""Standalone, passive package verifier. Standard library; NO candidate imports.

Verifies exact artifact bytes, closed member/source sets and recorded check
identities. Does not execute tests or attest the honesty of recorded observations.
"""
from __future__ import annotations
import argparse,ast,hashlib,io,json,zipfile
from pathlib import PurePosixPath

DOMAIN=b"MOSAIC-UGEL-A1\x00"
def canonical(x): return json.dumps(x,ensure_ascii=True,sort_keys=True,separators=(",",":"),allow_nan=False).encode("ascii")
def digest(x): return hashlib.sha256(DOMAIN+canonical(x)).hexdigest()
def require(x,message):
    if not x: raise ValueError(message)
def load(data):
    def pairs(items):
        out={}
        for k,v in items:
            require(k not in out,"DUPLICATE_KEY"); out[k]=v
        return out
    return json.loads(data,object_pairs_hook=pairs)
def rooted(x):
    require(type(x) is dict and x.get("root")==digest({k:v for k,v in x.items() if k!="root"}),"RECORD_ROOT_INVALID")
    return x

def verify(path,expected):
    raw=path.read_bytes(); observed=hashlib.sha256(raw).hexdigest()
    require(observed==expected,"ARCHIVE_PIN_MISMATCH")
    with zipfile.ZipFile(path) as z:
        names=z.namelist()
        require(names==sorted(set(names)),"MEMBER_INVENTORY_INVALID")
        require(len(names)<=1000 and sum(i.file_size for i in z.infolist())<=20_000_000,"ARCHIVE_BUDGET_EXCEEDED")
        for n in names:
            p=PurePosixPath(n)
            require(not p.is_absolute() and ".." not in p.parts and "\\" not in n and not n.endswith("/"),"MEMBER_PATH_INVALID")
        data={n:z.read(n) for n in names}
    manifest=rooted(load(data["PACKAGE-MANIFEST.json"]))
    require(manifest["schema"]=="mosaic.ugel.batch-b.package-manifest.v1","PACKAGE_SCHEMA_INVALID")
    rows=manifest["files"]
    require([r["path"] for r in rows]==sorted(set(data)-{"PACKAGE-MANIFEST.json"}),"PACKAGE_CLOSURE_INVALID")
    for r in rows:
        require(set(r)=={"path","bytes","sha256"},"FILE_ROW_INVALID")
        require(r["bytes"]==len(data[r["path"]]) and r["sha256"]==hashlib.sha256(data[r["path"]]).hexdigest(),"FILE_BYTES_INVALID")
    source=rooted(load(data["release/SOURCE-MANIFEST.json"]))
    require(source["schema"]=="mosaic.ugel.batch-b.source-manifest.v1","SOURCE_SCHEMA_INVALID")
    source_names=sorted(n for n in data if n!="PACKAGE-MANIFEST.json" and n.split('/')[0] not in {"evidence","release"})
    actual=[{"path":n,"bytes":len(data[n]),"sha256":hashlib.sha256(data[n]).hexdigest()} for n in source_names]
    require(source["files"]==actual and source["file_count"]==len(actual)
            and source["logical_bytes"]==sum(r["bytes"] for r in actual),"SOURCE_CLOSURE_INVALID")
    require(manifest["source_root"]==source["root"],"SOURCE_BINDING_INVALID")
    checks=rooted(load(data["evidence/REFERENCE-CHECKS.json"]))
    contract=rooted(load(data["spec/REFERENCE-CHECK-CONTRACT.json"]))
    ids=[]
    for n in source_names:
        if n.startswith("tests/test_") and n.endswith(".py"):
            module=n[:-3].replace("/",".")
            for cls in ast.parse(data[n]).body:
                if isinstance(cls,ast.ClassDef):
                    ids += [module+"."+cls.name+"."+m.name for m in cls.body if isinstance(m,ast.FunctionDef) and m.name.startswith("test_")]
    ids.sort()
    require(ids==contract["test_ids"]==checks["test_ids"],"TEST_IDENTITY_MISMATCH")
    require(checks["rows"]==[{"id":i,"status":"PASS"} for i in ids],"TEST_ROWS_INVALID")
    require(checks["status"]=="PASS" and checks["tests_run"]==len(ids) and checks["source_root"]==source["root"]
            and checks["source_stable"] is True,"CHECK_BINDING_INVALID")
    for k in ["failures","errors","skips","expected_failures","unexpected_successes","prior_result_cache_reads"]:
        require(type(checks[k]) is int and checks[k]==0,"CHECK_COUNTER_INVALID")
    require(checks["adversarial_testing"]=="NOT_PERFORMED" and checks["fault_injection"]=="NOT_PERFORMED","SCOPE_INVALID")
    require(checks["test_set_root"]==hashlib.sha256(canonical(ids)).hexdigest(),"TEST_SET_ROOT_INVALID")
    require(manifest["reference_checks_root"]==checks["root"],"CHECK_ROOT_BINDING_INVALID")
    predecessor=data["predecessors/UGEL-BATCH-A-r001.zip"]
    require(hashlib.sha256(predecessor).hexdigest()=="4fc49f0a9cf46a0b83d2de593768981991413434c6726ae7351ae611a076df27","PREDECESSOR_PIN")
    with zipfile.ZipFile(io.BytesIO(predecessor)) as old:
        inherited=[n for n in old.namelist() if n.startswith("src/ugel/") or n in
                   {"tests/test_reference.py","tests/__init__.py","spec/RECORD-CONTRACTS.json","spec/EFFECT-REGISTRY.json"}]
        for n in inherited: require(data[n]==old.read(n),"INHERITED_BYTES_CHANGED")
    reuse=rooted(load(data["provenance/BATCH-A-REUSE.json"]))
    require(reuse["paths"]==sorted(inherited),"REUSE_DECLARATION_INVALID")
    if "evidence/CLEAN-REPRODUCTION.json" in data:
        clean=rooted(load(data["evidence/CLEAN-REPRODUCTION.json"]))
        repeated=rooted(load(data["evidence/clean-reproduction/REFERENCE-CHECKS.json"]))
        require(clean["source_root"]==source["root"] and clean["primary_check_root"]==checks["root"]
                and clean["reproduced_check_root"]==repeated["root"] and repeated==checks,"CLEAN_REPRODUCTION_INVALID")
    return {"schema":"mosaic.ugel.batch-b.passive-verification.v1","status":"PASS_CUSTODY_AND_RECORD_CONSISTENCY",
            "archive_sha256":observed,"source_root":source["root"],"source_files":len(actual),"package_files":len(data),
            "reference_check_identities":len(ids),"reference_checks_root":checks["root"],"candidate_imports":0,
            "candidate_invocations":0,"tests_executed_by_verifier":0,"effect_replay":"NOT_PERFORMED","inherited_files_unchanged":len(inherited),
            "execution_claims":"BUILDER_REPORTED_NOT_INDEPENDENTLY_REPRODUCED_BY_THIS_VERIFIER",
            "authority_effect":"NONE","real_a5":False,"g0":"CLOSED"}

def main():
    from pathlib import Path
    p=argparse.ArgumentParser(); p.add_argument("archive",type=Path); p.add_argument("--expected-sha256",required=True)
    a=p.parse_args()
    try: print(json.dumps(verify(a.archive,a.expected_sha256),sort_keys=True,indent=2)); return 0
    except (ValueError,KeyError,OSError,zipfile.BadZipFile) as e:
        print(json.dumps({"status":"REFUSED","error":str(e)})); return 2
if __name__=="__main__": raise SystemExit(main())
