# Experimental reference notice

New Batch C implementation and records are additive. The complete Batch B payload
and its archive are preserved; all inherited notices and boundaries continue to
apply to those bytes. Nothing here supplies release, installation or application
execution authority beyond a user's explicitly selected local reference operation.

No private signing keys are distributed. Generated demonstrations contain plaintext
source and public signed evidence. Runtime libraries are host-prepared dependencies,
not bundled executables. All final review, independent containment, production,
real-world issuer identity, and native UGK authority obligations remain explicit.
