"""Ordinary lifecycle, supported positive execution, and structural checks only.
No denied-syscall probes, malformed-source attacks, forced process kills, or
fault injection are run. Explicit unfinished states are authored model fixtures.
"""
import ast,json,os,subprocess,sys,tempfile,unittest,zipfile
from pathlib import Path
from ugel_host.common import *
from ugel_host.policy import policy,host_identity,inspect_host,engine_identity
from ugel_host.trust import Authority,LocalKey,verify_signed,validate_grant
from ugel_host.service import HostSession
from ugel_host.store import HostStore
from ugel_host.semantics import verify_bundle
from tests.support import Fixture,ROOT

class RecordAndPolicyTests(unittest.TestCase):
    def test_domain_separated_canonical_record(self):
        r=record('example',value=42);self.assertEqual(check(r,'example')['value'],42)
    def test_policy_has_no_ambient_effect_syscalls(self):
        p=policy();self.assertTrue({'open','openat','execve','clone','socket','connect','ptrace'}.isdisjoint(p['allowed_unconditional_syscalls']))
    def test_argument_limited_pipe_access(self):
        p=policy();self.assertEqual(p['argument_limited_syscalls']['read'],[0]);self.assertEqual(p['argument_limited_syscalls']['write'],[1,2])
    def test_policy_expresses_independent_review_limit(self):
        self.assertEqual(policy()['forbidden_effect_tests'],'NOT_RUN_WITHOUT_SEPARATE_AUTHORIZATION')
    def test_local_profile_has_bounded_cpu_memory_output(self):
        p=policy();self.assertEqual(p['cpu_seconds'],5);self.assertEqual(p['address_space_bytes'],536870912);self.assertEqual(p['max_output_bytes'],1048576)
    def test_host_preflight_is_not_containment_result(self):
        p=inspect_host();self.assertEqual(p['status'],'SETUP_CANDIDATE_NOT_YET_ENTERED');self.assertFalse(p['enforcement_installed'])
    def test_host_identity_binds_actual_interpreter(self):
        h=host_identity();self.assertEqual(byte_hash(Path(h['executable']).read_bytes()),h['executable_sha256'])
    def test_engine_identity_lists_all_host_modules(self):
        self.assertEqual([r['path'] for r in engine_identity()['files']],sorted(p.name for p in (ROOT/'src/ugel_host').glob('*.py')))
    def test_basic_orientation_requires_only_stdlib(self):
        p=subprocess.run([sys.executable,'-I','-S','-B',str(ROOT/'run.py'),'orient'],capture_output=True,timeout=10)
        self.assertEqual(p.returncode,0,p.stderr);self.assertTrue(json.loads(p.stdout)['no_cooperative_fallback'])
    def test_record_root_does_not_claim_authentication(self):
        r=record('plain',claim='not signed');self.assertNotIn('signature_hex',r)

class SignedAuthorityTests(unittest.TestCase):
    def setUp(self):
        self.t=tempfile.TemporaryDirectory(prefix='ugel-c-issuer-');self.r=Path(self.t.name)
        self.a=Authority.create(self.r/'a');self.k=LocalKey.create(self.r/'observer','HOST_OBSERVER')
    def tearDown(self):self.t.cleanup()
    def grant(self):return self.a.issue('ordinary-task','1'*64,self.k.public['root'],now=1000,valid_seconds=120)
    def test_ed25519_signature_roundtrip(self):
        s=self.k.sign('observation',{'fact':'bounded'});self.assertEqual(verify_signed(s,self.k.public,self.k.public['root'],'observation'),{'fact':'bounded'})
    def test_private_key_storage_permissions(self):
        self.assertEqual((self.r/'observer/PRIVATE.key').stat().st_mode&0o777,0o600)
    def test_public_key_identity_is_local_not_legal(self):
        self.assertEqual(self.a.public['identity_assurance'],'LOCAL_OWNER_PIN_ONLY')
    def test_grant_binds_exact_request_and_peer(self):
        g=self.grant();b=validate_grant(g,self.a.public,self.a.public['root'],'1'*64,self.k.public['root'],1001)
        self.assertEqual(b['max_attempts'],1);self.assertEqual(b['action'],'RUN_EXACT_MEMORY_CHECK')
    def test_admission_is_signed_and_durable(self):
        g=self.grant();ad=self.a.consume(g,'1'*64,self.k.public['root'],now=1001)
        self.assertEqual(verify_signed(ad,self.a.public,self.a.public['root'],'admission')['decision'],'AUTHORIZED_ONE_LAUNCH_ATTEMPT')
        reopened=Authority(self.r/'a',self.a.public['root']);self.assertEqual(reopened.status(),self.a.status())
    def test_entry_has_distinct_later_authority_sequence(self):
        g=self.grant();a=self.a.consume(g,'1'*64,self.k.public['root'],now=1001);e=self.a.release_entry(g,'1'*64,self.k.public['root'],now=1002)
        self.assertGreater(e['body']['authority_sequence'],a['body']['authority_sequence'])
    def test_owner_revocation_prevents_new_admission(self):
        g=self.grant();self.a.revoke(g['root'],now=1001)
        with self.assertRaisesRegex(Refusal,'GRANT_ALREADY_SPENT_OR_REVOKED'):self.a.consume(g,'1'*64,self.k.public['root'],now=1002)
    def test_epoch_change_requires_a_new_grant(self):
        g=self.grant();self.a.advance_epoch(now=1001)
        with self.assertRaisesRegex(Refusal,'GRANT_EPOCH_CHANGED'):self.a.consume(g,'1'*64,self.k.public['root'],now=1002)
    def test_expired_grant_remains_a_verifiable_historical_signature(self):
        g=self.grant();self.assertEqual(verify_signed(g,self.a.public,self.a.public['root'],'execution-grant')['not_after'],1120)
        with self.assertRaisesRegex(Refusal,'GRANT_NOT_CURRENT'):validate_grant(g,self.a.public,self.a.public['root'],'1'*64,self.k.public['root'],1120)
    def test_recovery_permit_has_no_execution_scope(self):
        p=self.a.recovery_permit('1'*64,'ordinary-task','2'*64,now=1200)
        self.assertFalse(p['body']['new_execution_permitted']);self.assertEqual(p['body']['action'],'FINALIZE_OR_OBSERVE_ONLY')

class HostWorkflowTests(unittest.TestCase):
    def setUp(self):self.f=Fixture()
    def tearDown(self):self.f.close()
    def test_bridge_requires_materialized_exact_batch_b_state(self):
        q=self.f.c.context['request'];self.assertEqual(q['candidate_root'],self.f.plan['candidate_manifest']['root'])
        self.assertEqual(self.f.b.state()['phase'],'MATERIALIZED')
    def test_readonly_inspection_does_not_append(self):
        before=self.f.c.pins();self.f.c.current_task();self.assertEqual(before,self.f.c.pins())
    def test_cancel_is_durable_before_dispatch(self):
        self.f.c.cancel();c=HostSession(self.f.c.store.folder,self.f.c.pins());self.assertEqual(c.current_task()['phase'],'CANCELLED')
    def test_expired_execution_grant_finishes_as_admission_refusal(self):
        self.f.now[0]+=121;self.f.c.execute();self.assertEqual(self.f.c.store.state()['phase'],'ADMISSION_REFUSED')
        self.assertIsNone(self.f.c.store.state()['observation'])
    def test_repaired_candidate_passes_under_installed_filter(self):
        r=self.f.c.execute();self.assertEqual(r['status'],'CHECKED_NOT_RELEASED');self.assertTrue(r['entry_observed'])
    def test_parent_observes_unprivileged_seccomp_child(self):
        self.f.c.execute();w=self.f.c.store.state()['observation']['body']['parent_witness']
        self.assertEqual(w['Seccomp'],'2');self.assertEqual(w['NoNewPrivs'],'1');self.assertEqual(int(w['CapEff'],16),0);self.assertNotEqual(w['Uid'].split()[1],'0')
    def test_exact_six_tests_and_no_skips(self):
        self.f.c.execute();r=self.f.c.store.state()['observation']['body']['child_result']
        self.assertEqual(r['test_ids'],self.f.plan['test_ids']);self.assertEqual(r['tests_run'],6);self.assertEqual(r['skips'],0)
    def test_source_and_candidate_are_unchanged_after_check(self):
        r=self.f.c.execute();self.assertTrue(r['source_unchanged']);self.assertTrue(r['candidate_unchanged'])
    def test_observed_state_can_finalize_after_execution_grant_expiry(self):
        self.f.c.execute(finalize=False);self.f.now[0]+=121
        r=self.f.c.reconcile(self.f.permit());self.assertEqual(r['status'],'CHECKED_NOT_RELEASED')
    def test_finalized_operation_returns_receipt_without_new_event(self):
        r=self.f.c.execute();pins=self.f.c.pins();seq=self.f.authority.status()['sequence']
        self.assertEqual(r,self.f.c.execute());self.assertEqual(pins,self.f.c.pins());self.assertEqual(seq,self.f.authority.status()['sequence'])
    def test_signed_export_replays_without_private_keys(self):
        self.f.c.execute();b=self.f.c.export(acknowledge_plaintext=True);p=self.f.c.pins()
        v=verify_bundle(b,expected_context_root=p['context_root'],expected_head=p['head'],issuer_root=p['issuer_root'],observer_root=p['observer_root'])
        self.assertEqual(v['result'],'CHECKED_NOT_RELEASED');self.assertFalse(v['independent_execution_verified'])
        self.assertNotIn('PRIVATE.key',canonical(b).decode())
    def test_export_requires_explicit_disclosure_acknowledgment(self):
        with self.assertRaisesRegex(Refusal,'EXPLICIT_SOURCE_DISCLOSURE_REQUIRED'):self.f.c.export()
    def test_authored_dispatch_intent_state_stays_unresolved(self):
        # Model state fixture; no child was launched and no crash was injected.
        self.f.c.store.append(self.f.observer,'DISPATCH_INTENT',{'request_root':self.f.c.context['request']['root']})
        r=self.f.c.reconcile(self.f.permit());self.assertEqual(r['status'],'UNRESOLVED_NO_REDISPATCH');self.assertFalse(r['new_execution_permitted'])
    def test_authored_admitted_state_stays_unresolved(self):
        # Model state fixture; it is incorrect to infer nonexecution from absent observation.
        c=self.f.c;c.store.append(self.f.observer,'DISPATCH_INTENT',{'request_root':c.context['request']['root']})
        a=self.f.authority.consume(c.context['grant'],c.context['request']['root'],self.f.observer.public['root'],now=self.f.now[0])
        c.store.append(self.f.observer,'ADMITTED',{'admission':a});r=c.reconcile(self.f.permit())
        self.assertTrue(r['observed_absence_is_not_nonexecution']);self.assertEqual(c.store.state()['phase'],'ADMITTED')
    def test_fresh_interpreter_finalizes_observation(self):
        c=self.f.c;c.execute(finalize=False);pins=self.f.root/'pins.json';permit=self.f.root/'permit.json'
        write_json(pins,c.pins());write_json(permit,self.f.permit())
        p=subprocess.run([sys.executable,'-B',str(ROOT/'run.py'),'reconcile',str(c.store.folder),'--pins',str(pins),
            '--authority',str(self.f.root/'authority'),'--observer',str(self.f.root/'observer'),'--permit',str(permit)],capture_output=True,timeout=15)
        self.assertEqual(p.returncode,0,p.stderr);r=json.loads(p.stdout);self.assertEqual(r['result']['status'],'CHECKED_NOT_RELEASED')
    def test_observe_head_is_explicit_not_implicit_resume(self):
        self.f.c.execute(finalize=False);p=self.f.c.pins()
        got=HostStore.recover_head(self.f.c.store.folder,expected_context_root=p['context_root'],issuer_root=p['issuer_root'],observer_root=p['observer_root'])
        self.assertEqual(p,got)
    def test_original_fixture_failure_is_reported(self):
        f=Fixture(repair=False)
        try:
            self.assertEqual(f.c.execute()['status'],'CHECK_FAILED')
            self.assertEqual(f.c.store.state()['observation']['body']['child_result']['failures'],2)
        finally:f.close()
    def test_cli_export_and_permit_are_directly_consumable(self):
        c=self.f.c;c.execute(finalize=False);pins=self.f.root/'cli-pins.json';write_json(pins,c.pins())
        p=subprocess.run([sys.executable,'-B',str(ROOT/'run.py'),'permit',str(c.store.folder),'--pins',str(pins),'--authority',str(self.f.root/'authority')],capture_output=True,timeout=10)
        self.assertEqual(p.returncode,0,p.stderr);permit=json.loads(p.stdout)
        self.assertEqual(permit['schema'],'mosaic.ugel.batch-c.signed-record.v1')
        self.f.now[0]=permit['body']['not_before']  # align the fixture clock with the real CLI issuer
        self.assertEqual(c.reconcile(permit)['status'],'CHECKED_NOT_RELEASED')
        finalpins=self.f.root/'final-pins.json';write_json(finalpins,c.pins())
        e=subprocess.run([sys.executable,'-B',str(ROOT/'run.py'),'export',str(c.store.folder),'--pins',str(finalpins),'--acknowledge-plaintext'],capture_output=True,timeout=10)
        self.assertEqual(e.returncode,0,e.stderr);bundle=json.loads(e.stdout);p=c.pins()
        self.assertEqual(verify_bundle(bundle,expected_context_root=p['context_root'],expected_head=p['head'],issuer_root=p['issuer_root'],observer_root=p['observer_root'])['result'],'CHECKED_NOT_RELEASED')
    def test_constitutional_boundary_does_not_hide_local_effects(self):
        r=self.f.c.execute();self.assertEqual(r['authority_effect'],'NONE');self.assertEqual(r['physical_effects'],'LOCAL_PROCESS_PIPES_HOST_CUSTODY');self.assertFalse(r['release_authorized'])

class DistributionTests(unittest.TestCase):
    def test_exact_batch_b_archive_preserved(self):
        self.assertEqual(byte_hash((ROOT/'predecessors/UGEL-BATCH-B-r001.zip').read_bytes()),'dd18f578332d7f45341a3f2e0801f0ea839c12369d78134addb50fe47cdb3edc')
    def test_every_carried_batch_b_file_is_identical(self):
        with zipfile.ZipFile(ROOT/'predecessors/UGEL-BATCH-B-r001.zip') as z:
            for n in z.namelist():self.assertEqual((ROOT/'compatibility/batch-b'/n).read_bytes(),z.read(n),n)
    def test_machine_policy_matches_implementation(self):
        self.assertEqual(read_json(ROOT/'spec/HOST-POLICY.json'),policy())
    def test_native_binding_is_not_promoted(self):
        r=read_json(ROOT/'spec/NATIVE-BINDING.json');self.assertEqual(r['native_ugk_binding'],'NOT_BOUND');self.assertFalse(r['real_a5'])
    def test_no_private_key_file_is_packaged(self):
        self.assertFalse(any(p.name=='PRIVATE.key' for p in ROOT.rglob('*')))
    def test_host_and_compatibility_entrypoints_are_distinct(self):
        self.assertTrue((ROOT/'compatibility/batch-b/run.py').is_file());self.assertIn('ugel_host.cli',(ROOT/'run.py').read_text())
