"""Local single-owner Ed25519 issuer. No external identity, HSM, or native UGK claim.

Every privileged caller supplies a separately retained public-key root. SQLite
transactions serialize epoch, revocation and one-attempt consumption. This store
is outside candidate access; an administrator able to replace the store remains
trusted. Historical signatures do not establish current revocation status.
"""
from __future__ import annotations
from contextlib import closing
import os,sqlite3
from pathlib import Path
from .common import *
SIGN_DOMAIN=b'MOSAIC-UGEL-C1-SIGNATURE\x00'

def _crypto():
    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey,Ed25519PublicKey
        return Ed25519PrivateKey,Ed25519PublicKey
    except ImportError as e:raise Refusal('PREPARED_CRYPTOGRAPHY_REQUIRED') from e

def public_record(raw:bytes,role:str)->dict:
    require(role in {'LOCAL_ISSUER','HOST_OBSERVER'},'KEY_ROLE')
    require(len(raw)==32,'ED25519_PUBLIC_KEY_LENGTH')
    return record('public-key',algorithm='Ed25519',role=role,raw_hex=raw.hex(),identity_assurance='LOCAL_OWNER_PIN_ONLY')

def verify_signed(envelope:dict,public:dict,expected_public_root:str,kind:str)->dict:
    p=check(public,'public-key',{'algorithm','role','raw_hex','identity_assurance'})
    require(p==public_record(bytes.fromhex(p['raw_hex']),p['role']),'PUBLIC_KEY_NOT_REDERIVED')
    require(p['root']==hash_value(expected_public_root),'PUBLIC_KEY_PIN')
    e=check(envelope,'signed-record',{'kind','signer_root','body','signature_hex'})
    require(e['kind']==kind and e['signer_root']==p['root'],'SIGNATURE_CONTEXT')
    _,Public=_crypto()
    try:
        Public.from_public_bytes(bytes.fromhex(p['raw_hex'])).verify(bytes.fromhex(e['signature_hex']),
            SIGN_DOMAIN+canonical({'kind':kind,'signer_root':p['root'],'body':e['body']}))
    except Exception as exc:raise Refusal('SIGNATURE_INVALID') from exc
    return e['body']

class LocalKey:
    def __init__(self,folder:Path,expected_root:str):
        self.folder=private_dir(folder)
        self.public=read_json(private_file(self.folder/'PUBLIC.json'))
        require(self.public['root']==hash_value(expected_root),'LOCAL_KEY_PIN')
        Private,_=_crypto();self._key=Private.from_private_bytes(private_file(self.folder/'PRIVATE.key').read_bytes())
        require(public_record(self._key.public_key().public_bytes_raw(),self.public['role'])==self.public,'KEY_PAIR_MISMATCH')
    @classmethod
    def create(cls,folder:Path,role:str):
        folder=Path(folder);folder.mkdir(mode=0o700)
        Private,_=_crypto();key=Private.generate();pub=public_record(key.public_key().public_bytes_raw(),role)
        write_new(folder/'PRIVATE.key',key.private_bytes_raw());write_json(folder/'PUBLIC.json',pub)
        return cls(folder,pub['root'])
    def sign(self,kind:str,body:dict)->dict:
        message={'kind':kind,'signer_root':self.public['root'],'body':body}
        return record('signed-record',**message,signature_hex=self._key.sign(SIGN_DOMAIN+canonical(message)).hex())

GRANT_FIELDS={'operation_id','request_root','observer_root','epoch','not_before','not_after','max_attempts','action'}

def grant_body(operation_id,request_root,observer_root,epoch,not_before,not_after):
    identifier(operation_id);hash_value(request_root);hash_value(observer_root);integer(epoch,1)
    integer(not_before);integer(not_after);require(0<not_after-not_before<=3600,'BOUNDED_GRANT_WINDOW')
    return dict(operation_id=operation_id,request_root=request_root,observer_root=observer_root,
                epoch=epoch,not_before=not_before,not_after=not_after,max_attempts=1,action='RUN_EXACT_MEMORY_CHECK')

def validate_grant(envelope,public,pin,request_root,observer_root,at):
    b=verify_signed(envelope,public,pin,'execution-grant');exact(b,GRANT_FIELDS)
    require(b==grant_body(b['operation_id'],b['request_root'],b['observer_root'],b['epoch'],b['not_before'],b['not_after']),'GRANT_NOT_REDERIVED')
    require(b['request_root']==request_root and b['observer_root']==observer_root,'GRANT_SUBJECT')
    require(b['not_before']<=integer(at)<b['not_after'],'GRANT_NOT_CURRENT')
    return b

class Authority:
    def __init__(self,folder:Path,expected_root:str):
        self.folder=private_dir(folder);self.key=LocalKey(self.folder/'issuer',expected_root)
        self.public=self.key.public;self.path=private_file(self.folder/'authority.sqlite')
    @classmethod
    def create(cls,folder:Path):
        folder=Path(folder);folder.mkdir(mode=0o700);key=LocalKey.create(folder/'issuer','LOCAL_ISSUER')
        p=folder/'authority.sqlite';write_new(p,b'')
        with closing(sqlite3.connect(p)) as db:
            db.executescript('PRAGMA journal_mode=DELETE; PRAGMA synchronous=FULL; CREATE TABLE meta(epoch INTEGER,seq INTEGER); INSERT INTO meta VALUES(1,0); CREATE TABLE grants(root TEXT PRIMARY KEY,body TEXT NOT NULL,state TEXT NOT NULL,admission TEXT); CREATE TABLE audit(seq INTEGER PRIMARY KEY,record TEXT NOT NULL);')
        return cls(folder,key.public['root'])
    def _db(self,ro=False):
        private_file(self.path)
        db=sqlite3.connect(('file:'+str(self.path)+'?mode=ro') if ro else self.path,uri=ro,isolation_level=None,timeout=5)
        if not ro:db.execute('PRAGMA synchronous=FULL')
        return db
    def status(self):
        with closing(self._db(True)) as db:
            epoch,seq=db.execute('SELECT epoch,seq FROM meta').fetchone()
        return {'epoch':epoch,'sequence':seq,'issuer_root':self.public['root']}
    def _audit(self,db,kind,body):
        epoch,seq=db.execute('SELECT epoch,seq FROM meta').fetchone();seq+=1
        r=self.key.sign(kind,{**body,'authority_epoch':epoch,'authority_sequence':seq})
        db.execute('UPDATE meta SET seq=?',(seq,));db.execute('INSERT INTO audit VALUES(?,?)',(seq,canonical(r).decode()))
        return r
    def issue(self,operation_id,request_root,observer_root,*,now,valid_seconds=120):
        db=self._db()
        try:
            db.execute('BEGIN IMMEDIATE');epoch=db.execute('SELECT epoch FROM meta').fetchone()[0]
            body=grant_body(operation_id,request_root,observer_root,epoch,now,now+valid_seconds)
            g=self.key.sign('execution-grant',body)
            db.execute('INSERT INTO grants VALUES(?,?,?,NULL)',(g['root'],canonical(g).decode(),'UNSPENT'))
            self._audit(db,'grant-issued',{'grant_root':g['root'],'at':now});db.execute('COMMIT');return g
        except Exception:
            if db.in_transaction:db.execute('ROLLBACK')
            raise
        finally:db.close()
    def consume(self,grant,request_root,observer_root,*,now):
        b=validate_grant(grant,self.public,self.public['root'],request_root,observer_root,now);db=self._db()
        try:
            db.execute('BEGIN IMMEDIATE');epoch=db.execute('SELECT epoch FROM meta').fetchone()[0]
            row=db.execute('SELECT body,state FROM grants WHERE root=?',(grant['root'],)).fetchone()
            require(row is not None and load_bytes(row[0].encode())==grant,'GRANT_NOT_IN_ISSUER_CUSTODY')
            require(epoch==b['epoch'],'GRANT_EPOCH_CHANGED');require(row[1]=='UNSPENT','GRANT_ALREADY_SPENT_OR_REVOKED')
            admission=self._audit(db,'admission',{'grant_root':grant['root'],'request_root':request_root,
                'observer_root':observer_root,'at':now,'decision':'AUTHORIZED_ONE_LAUNCH_ATTEMPT'})
            db.execute('UPDATE grants SET state=?,admission=? WHERE root=?',('SPENT',canonical(admission).decode(),grant['root']))
            db.execute('COMMIT');return admission
        except Exception:
            if db.in_transaction:db.execute('ROLLBACK')
            raise
        finally:db.close()
    def release_entry(self,grant,request_root,observer_root,*,now):
        b=validate_grant(grant,self.public,self.public['root'],request_root,observer_root,now);db=self._db()
        try:
            db.execute('BEGIN IMMEDIATE');epoch=db.execute('SELECT epoch FROM meta').fetchone()[0]
            row=db.execute('SELECT state FROM grants WHERE root=?',(grant['root'],)).fetchone()
            require(row and row[0]=='SPENT' and epoch==b['epoch'],'ENTRY_AUTHORITY_NO_LONGER_CURRENT')
            e=self._audit(db,'entry-authorized',{'grant_root':grant['root'],'request_root':request_root,
              'observer_root':observer_root,'at':now,'decision':'ALLOW_ENTER_FIXED_CANDIDATE'})
            db.execute('UPDATE grants SET state=? WHERE root=?',('ENTERED',grant['root']))
            db.execute('COMMIT');return e
        except Exception:
            if db.in_transaction:db.execute('ROLLBACK')
            raise
        finally:db.close()
    def revoke(self,grant_root,*,now):
        hash_value(grant_root);db=self._db()
        try:
            db.execute('BEGIN IMMEDIATE')
            require(db.execute('SELECT 1 FROM grants WHERE root=?',(grant_root,)).fetchone() is not None,'GRANT_UNKNOWN')
            db.execute('UPDATE grants SET state=? WHERE root=?',('REVOKED',grant_root))
            r=self._audit(db,'grant-revoked',{'grant_root':grant_root,'at':now,'stops_running_child':False})
            db.execute('COMMIT');return r
        finally:
            if db.in_transaction:db.execute('ROLLBACK')
            db.close()
    def advance_epoch(self,*,now):
        db=self._db()
        try:
            db.execute('BEGIN IMMEDIATE');db.execute('UPDATE meta SET epoch=epoch+1')
            r=self._audit(db,'epoch-advanced',{'at':now,'stops_running_child':False});db.execute('COMMIT');return r
        finally:
            if db.in_transaction:db.execute('ROLLBACK')
            db.close()
    def recovery_permit(self,request_root,operation_id,expected_head,*,now,valid_seconds=120):
        hash_value(request_root);identifier(operation_id);hash_value(expected_head);integer(valid_seconds,1,600)
        return self.key.sign('recovery-permit',{'action':'FINALIZE_OR_OBSERVE_ONLY','request_root':request_root,
            'operation_id':operation_id,'expected_head':expected_head,'epoch':self.status()['epoch'],
            'not_before':now,'not_after':now+valid_seconds,'new_execution_permitted':False})
    def validate_recovery(self,permit,request,expected_head,*,now):
        b=verify_signed(permit,self.public,self.public['root'],'recovery-permit')
        exact(b,{'action','request_root','operation_id','expected_head','epoch','not_before','not_after','new_execution_permitted'})
        require(b['action']=='FINALIZE_OR_OBSERVE_ONLY' and b['new_execution_permitted'] is False,'RECOVERY_SCOPE')
        require(b['request_root']==request['root'] and b['operation_id']==request['operation_id'] and b['expected_head']==expected_head,'RECOVERY_SUBJECT')
        require(b['epoch']==self.status()['epoch'] and b['not_before']<=now<b['not_after'] and 0<b['not_after']-b['not_before']<=600,'RECOVERY_NOT_CURRENT')
        return b
