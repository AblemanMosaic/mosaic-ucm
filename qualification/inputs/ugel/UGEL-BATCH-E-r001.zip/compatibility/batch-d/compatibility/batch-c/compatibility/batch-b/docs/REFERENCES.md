# Design references

The local sources are authoritative for this package's implemented behavior.
Batch A's frozen `docs/UCM-UGK-INTEGRATION.md` specifies the Batch B interface and
explicitly reserves host containment and real authority for later integrations.

Primary Python references consulted while designing the trusted child runner:

* https://docs.python.org/3.13/using/cmdline.html — `-I`, `-S`, and `-B` startup
  behavior. The package deliberately makes no sandbox claim from these flags.
* https://docs.python.org/3.13/library/subprocess.html — explicit argument arrays,
  shell behavior, and child timeout/termination semantics. The package's deadline
  logic kills/reaps the direct process where possible; it does not establish
  containment of hostile descendants or kernel-level resource limits.

Consulting these references is not validation of the implementation. Actual host
and execution evidence are recorded separately under `evidence/`.
