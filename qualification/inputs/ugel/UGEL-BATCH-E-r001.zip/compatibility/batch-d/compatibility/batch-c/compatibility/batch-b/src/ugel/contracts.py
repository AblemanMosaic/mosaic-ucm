"""Strict, versioned reference contracts; host trust is explicit, not self-issued."""
from __future__ import annotations
import re
from .canonical import *

PREFIX = "mosaic.ugel.batch-a."
SCHEMAS = {name: PREFIX + name + ".v1" for name in
           ("contract", "grant", "request", "binding", "authority", "recovery", "evidence", "decision", "observation", "receipt", "event", "bundle")}
ECHO, ADD, READ, CREATE = "sim.echo", "sim.add", "fs.read", "fs.create"
EFFECTS = {ECHO, ADD, READ, CREATE}
PROFILES = {"VERIFY_ONLY", "SIMULATION", "LOCAL_REFERENCE"}
CHECKER = "ugel.check.utf8-size.v1"
BOUNDARY = {"standing":"INFORMATION_ONLY", "authority_effect":"NONE", "real_a5":False, "g0":"CLOSED"}
REGISTRY = seal({"schema":PREFIX+"effect-registry.v1", "effects":[
    {"id":ADD,"parameters":["left","right"],"plane":"SIMULATED", "reconciliation":"PURE_RECOMPUTE"},
    {"id":ECHO,"parameters":["text"],"plane":"SIMULATED", "reconciliation":"PURE_RECOMPUTE"},
    {"id":CREATE,"parameters":["name","text"],"plane":"CONTROLLED_LOCAL", "reconciliation":"OBSERVE_ONLY_NO_CAUSAL_ATTRIBUTION"},
    {"id":READ,"parameters":["expected_sha256","max_bytes","name"],"plane":"CONTROLLED_LOCAL", "reconciliation":"HISTORICAL_READ_NOT_RECONSTRUCTIBLE"}],
    "ugk_native_binding":"NOT_BOUND", "dynamic_effect_registration":False})

FIELDS = {
 "contract":{"subject_root","jurisdiction_root","epoch","effects","resources","max_operation_bytes","obligations"},
 "grant":{"grant_id","ledger_id","subject_root","contract_root","epoch","effects","resources","actions","valid_from","valid_until","max_operations","max_total_bytes"},
 "request":{"operation_id","subject_root","contract_root","grant_root","epoch","effect","resource_id","parameters","evidence_roots"},
 "binding":{"ledger_id","subject_root","jurisdiction_root","contract_root","profile","registry_root","resources","ugk_binding"},
 "authority":{"issuer_id","jurisdiction_root","epoch","valid_from","valid_until","grants","revoked_grants","recoveries"},
 "recovery":{"permit_id","ledger_id","operation_id","request_root","operation_head","contract_root","subject_root","valid_from","valid_until","action"},
 "evidence":{"checker_id","subject_root","contract_root","effect","parameters_root","valid_until","finding"},
}

def record(kind: str, **fields) -> dict:
    return seal({"schema":SCHEMAS[kind], **fields})

def window(v: dict) -> None:
    integer(v["valid_from"]); integer(v["valid_until"])
    require(v["valid_from"] < v["valid_until"], "TIME_WINDOW_INVALID")

def filename(v: str) -> str:
    require(type(v) is str and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,63}", v) is not None,
            "LEAF_NAME_REQUIRED")
    require(not v.endswith(".") and v.split(".")[0].upper() not in
            {"CON","PRN","AUX","NUL", *[f"COM{i}" for i in range(1,10)], *[f"LPT{i}" for i in range(1,10)]},
            "PORTABLE_NAME_REQUIRED")
    return v

def validate_parameters(effect: str, p: dict) -> int:
    require(effect in EFFECTS, "EFFECT_NOT_SUPPORTED")
    if effect == ECHO:
        exact(p,{"text"}); require(type(p["text"]) is str, "TEXT_REQUIRED")
        canonical(p); return len(p["text"].encode("utf-8"))
    if effect == ADD:
        exact(p,{"left","right"}); integer(p["left"],-1_000_000,1_000_000); integer(p["right"],-1_000_000,1_000_000)
        return 0
    if effect == READ:
        exact(p,{"name","expected_sha256","max_bytes"}); filename(p["name"]); hash_value(p["expected_sha256"])
        return integer(p["max_bytes"],1,1_000_000)
    exact(p,{"name","text"}); filename(p["name"])
    require(type(p["text"]) is str, "TEXT_REQUIRED"); canonical(p)
    return len(p["text"].encode("utf-8"))

def validate(kind: str, value: dict) -> dict:
    v = rooted(value, SCHEMAS[kind], FIELDS[kind])
    if kind == "contract":
        hash_value(v["subject_root"]); hash_value(v["jurisdiction_root"]); integer(v["epoch"],1)
        require(set(ordered(v["effects"],nonempty=True)) <= EFFECTS,"EFFECT_NOT_SUPPORTED")
        for r in ordered(v["resources"], nonempty=True): identifier(r)
        integer(v["max_operation_bytes"],1,1_000_000)
        exact(v["obligations"],set(v["effects"]))
        for effect, checks in v["obligations"].items():
            ordered(checks)
            require(set(checks) <= ({CHECKER} if effect in {ECHO,CREATE} else set()), "CHECKER_NOT_SUPPORTED")
    elif kind == "grant":
        identifier(v["grant_id"]); identifier(v["ledger_id"])
        hash_value(v["subject_root"]); hash_value(v["contract_root"]); integer(v["epoch"],1)
        require(set(ordered(v["effects"],nonempty=True)) <= EFFECTS,"EFFECT_NOT_SUPPORTED")
        for r in ordered(v["resources"],nonempty=True): identifier(r)
        require(set(ordered(v["actions"],nonempty=True)) <= {"EXECUTE","CANCEL"},"ACTION_INVALID")
        window(v); integer(v["max_operations"],1); integer(v["max_total_bytes"])
    elif kind == "request":
        identifier(v["operation_id"]); identifier(v["resource_id"])
        for k in ["subject_root","contract_root","grant_root"]: hash_value(v[k])
        integer(v["epoch"],1); validate_parameters(v["effect"],v["parameters"])
        for r in ordered(v["evidence_roots"]): hash_value(r)
    elif kind == "binding":
        identifier(v["ledger_id"])
        for k in ["subject_root","jurisdiction_root","contract_root"]: hash_value(v[k])
        require(v["profile"] in PROFILES,"PROFILE_INVALID")
        require(v["registry_root"] == REGISTRY["root"] and v["ugk_binding"] == "NOT_BOUND","BINDING_UNSUPPORTED")
        require(type(v["resources"]) is list and bool(v["resources"]),"RESOURCES_REQUIRED")
        ids=[]
        for r in v["resources"]:
            exact(r,{"id","adapter","identity_root"}); ids.append(identifier(r["id"])); hash_value(r["identity_root"])
            require(r["adapter"] in {"simulation-v1","private-directory-v1"},"ADAPTER_INVALID")
        require(ids == sorted(set(ids)),"RESOURCE_IDS_INVALID")
    elif kind == "authority":
        identifier(v["issuer_id"]); hash_value(v["jurisdiction_root"]); integer(v["epoch"],1); window(v)
        require(type(v["grants"]) is list and type(v["recoveries"]) is list,"AUTHORITY_RECORDS_INVALID")
        for field, subtype in [("grants","grant"),("recoveries","recovery")]:
            roots=[validate(subtype,x)["root"] for x in v[field]]
            require(roots == sorted(set(roots)),"AUTHORITY_RECORD_ORDER")
        for r in ordered(v["revoked_grants"]): hash_value(r)
    elif kind == "recovery":
        for k in ["permit_id","ledger_id","operation_id"]: identifier(v[k])
        for k in ["request_root","operation_head","contract_root","subject_root"]: hash_value(v[k])
        window(v); require(v["valid_until"]-v["valid_from"] <= 3600,"RECOVERY_WINDOW_TOO_WIDE")
        require(v["action"] == "OBSERVE_ONLY", "RECOVERY_ACTION_INVALID")
    elif kind == "evidence":
        require(v["checker_id"] == CHECKER and v["effect"] in {ECHO,CREATE},"CHECKER_NOT_SUPPORTED")
        for k in ["subject_root","contract_root","parameters_root"]: hash_value(v[k])
        integer(v["valid_until"])
        exact(v["finding"],{"utf8_bytes","sha256","scope"})
        integer(v["finding"]["utf8_bytes"]); hash_value(v["finding"]["sha256"])
        require(v["finding"]["scope"] == "EXACT_TEXT_PARAMETER_ONLY","EVIDENCE_SCOPE")
    return v

def make_evidence(request: dict, valid_until: int) -> dict:
    q=validate("request",request)
    require(q["effect"] in {ECHO,CREATE},"CHECKER_NOT_SUPPORTED")
    data=q["parameters"]["text"].encode("utf-8")
    return validate("evidence",record("evidence", checker_id=CHECKER,
        subject_root=q["subject_root"],contract_root=q["contract_root"],effect=q["effect"],
        parameters_root=digest(q["parameters"]),valid_until=valid_until,
        finding={"utf8_bytes":len(data),"sha256":byte_digest(data),"scope":"EXACT_TEXT_PARAMETER_ONLY"}))
