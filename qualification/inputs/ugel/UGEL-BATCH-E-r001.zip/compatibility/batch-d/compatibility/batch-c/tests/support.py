from pathlib import Path
import tempfile,time
from ugel_host.common import read_json
from ugel_host.trust import Authority,LocalKey
from ugel_host.service import HostSession
from ugel_python import propose,TaskSession
ROOT=Path(__file__).resolve().parents[1]
class Fixture:
    def __init__(self,repair=True,seconds=120):
        self.temp=tempfile.TemporaryDirectory(prefix='ugel-c-test-');self.root=Path(self.temp.name)
        self.project=self.root/'project';self.project.mkdir()
        for p in (ROOT/'compatibility/batch-b/examples/project').glob('*.py'):(self.project/p.name).write_bytes(p.read_bytes())
        proposal=read_json(ROOT/'compatibility/batch-b/examples/REPAIR-PROPOSAL.json')['replacements'] if repair else {}
        self.plan=propose(self.project,'test-task','Check declared fixture',proposal)
        self.b=TaskSession.initialize(project=self.project,plan=self.plan,expected_plan_root=self.plan['root'],output=self.root/'b',acknowledge_trusted_code_execution=True)
        self.b.materialize();self.now=[int(time.time())]
        self.authority=Authority.create(self.root/'authority');self.observer=LocalKey.create(self.root/'observer','HOST_OBSERVER')
        self.c=HostSession.prepare(self.b,'test-operation',self.root/'host',authority=self.authority,observer=self.observer,valid_seconds=seconds,clock=lambda:self.now[0])
    def permit(self):
        return self.authority.recovery_permit(self.c.context['request']['root'],'test-operation',self.c.pins()['head'],now=self.now[0])
    def close(self):self.temp.cleanup()
