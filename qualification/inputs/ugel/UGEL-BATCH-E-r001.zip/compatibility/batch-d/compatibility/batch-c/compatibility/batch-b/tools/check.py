"""Ordinary reference checks, with exact source/test binding. No adversarial lane."""
from __future__ import annotations
import argparse,ast,io,json,platform,sqlite3,sys,unittest
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"src")); sys.path.insert(0,str(ROOT))
from source_inventory import inventory,canonical,seal

class RecordingResult(unittest.TextTestResult):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs); self.rows=[]
    def addSuccess(self,test):
        super().addSuccess(test); self.rows.append({"id":test.id(),"status":"PASS"})
    def addFailure(self,test,err):
        super().addFailure(test,err); self.rows.append({"id":test.id(),"status":"FAIL"})
    def addError(self,test,err):
        super().addError(test,err); self.rows.append({"id":test.id(),"status":"ERROR"})
    def addSkip(self,test,reason):
        super().addSkip(test,reason); self.rows.append({"id":test.id(),"status":"SKIP"})

def static_ids():
    result=[]
    for path in sorted((ROOT/"tests").glob("test_*.py")):
        module="tests."+path.stem
        for cls in ast.parse(path.read_text()).body:
            if isinstance(cls,ast.ClassDef):
                result.extend(module+"."+cls.name+"."+n.name for n in cls.body
                    if isinstance(n,ast.FunctionDef) and n.name.startswith("test_"))
    return sorted(result)

def main():
    p=argparse.ArgumentParser(); p.add_argument("--output",type=Path,required=True); args=p.parse_args()
    before=inventory(ROOT)
    contract=json.loads((ROOT/"spec/REFERENCE-CHECK-CONTRACT.json").read_bytes())
    from source_inventory import root
    if contract["root"] != root({k:v for k,v in contract.items() if k!="root"}):
        raise SystemExit("CHECK_CONTRACT_ROOT_INVALID")
    expected=static_ids()
    if expected!=contract["test_ids"]: raise SystemExit("TEST_INVENTORY_MISMATCH")
    log=io.StringIO()
    suite=unittest.defaultTestLoader.discover(str(ROOT/"tests"),top_level_dir=str(ROOT))
    run=unittest.TextTestRunner(stream=log,verbosity=2,resultclass=RecordingResult).run(suite)
    after=inventory(ROOT)
    rows=sorted(run.rows,key=lambda x:x["id"])
    passed=(run.wasSuccessful() and not run.skipped and not run.expectedFailures and not run.unexpectedSuccesses
            and [r["id"] for r in rows]==expected and before==after)
    modules=[]
    for name,m in sorted(sys.modules.items()):
        if name.startswith(("ugel.","ugel_python.","tests.test_")) and getattr(m,"__file__",None):
            path=Path(m.__file__).resolve()
            if not path.is_relative_to(ROOT): raise SystemExit("SUBJECT_IMPORT_OUTSIDE_SOURCE")
            modules.append(path.relative_to(ROOT).as_posix())
    result=seal({"schema":"mosaic.ugel.batch-b.reference-checks.v1","status":"PASS" if passed else "FAIL",
        "source_root":before["root"],"source_stable":before==after,"test_ids":expected,"test_set_root":__import__('hashlib').sha256(canonical(expected)).hexdigest(),
        "rows":rows,"tests_run":run.testsRun,"failures":len(run.failures),"errors":len(run.errors),"skips":len(run.skipped),
        "expected_failures":len(run.expectedFailures),"unexpected_successes":len(run.unexpectedSuccesses),
        "subject_imports":sorted(set(modules)),"prior_result_cache_reads":0,"cache_policy":"DISABLED_NO_RESULT_CACHE",
        "scope":"BUILDER_ORDINARY_REFERENCE_WORKFLOWS","adversarial_testing":"NOT_PERFORMED",
        "fault_injection":"NOT_PERFORMED","native_ugk_binding":"NOT_BOUND","host_containment":"NOT_ESTABLISHED",
        "standing":"INFORMATION_ONLY","authority_effect":"NONE","real_a5":False,"g0":"CLOSED"})
    args.output.mkdir(parents=True,exist_ok=True)
    (args.output/"REFERENCE-CHECKS.json").write_bytes(canonical(result)+b"\n")
    (args.output/"REFERENCE-CHECKS.log").write_text(log.getvalue())
    (args.output/"SOURCE-MANIFEST.json").write_bytes(canonical(before)+b"\n")
    host={"python":sys.version,"platform":platform.platform(),"sqlite":sqlite3.sqlite_version,
          "implementation":platform.python_implementation(),"other_hosts":"NOT_RUN"}
    (args.output/"HOST.json").write_bytes(canonical(host)+b"\n")
    print(json.dumps({"status":result["status"],"tests_run":run.testsRun,"source_root":before["root"],"result_root":result["root"]},indent=2))
    if not passed: print(log.getvalue())
    return 0 if passed else 1
if __name__=="__main__": raise SystemExit(main())
