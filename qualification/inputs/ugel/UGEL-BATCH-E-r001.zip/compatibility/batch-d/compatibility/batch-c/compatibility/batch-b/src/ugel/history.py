"""One deterministic reducer for live state, final receipts, and offline replay.

Replay checks recorded inputs and derivations, not the honesty of the host or
physical execution. Trusted authority roots and the latest head arrive externally.
"""
from __future__ import annotations
from .canonical import *
from .contracts import *
from .gate import evaluate, recovery_authorized
from .adapters import validate_observation

ZERO = "0" * 64
EVENT_KINDS={"ADMITTED","STARTED","DECLINED","OBSERVED","FINALIZED","CANCELLED","RECOVERY_OBSERVED"}
TERMINAL={"COMPLETED","REFUSED","REFUSED_AFTER_OBSERVATION","RECONCILED_STATE_MATCH","CANCELLED"}


def receipt(binding: dict, op: dict) -> dict:
    q=op["request"]; obs=op.get("observation")
    if op["state"] == "DECLINED":
        status="REFUSED"; scope="NONE"; attribution="NO_DISPATCH"
    else:
        require(obs is not None,"OBSERVATION_REQUIRED")
        status={"SUCCEEDED":"COMPLETED","PRECONDITION_FAILED":"REFUSED_AFTER_OBSERVATION",
                "STATE_MATCH":"RECONCILED_STATE_MATCH","UNCERTAIN":"RECONCILIATION_REQUIRED",
                "UNRESOLVED":"RECONCILIATION_REQUIRED"}[obs["status"]]
        scope=obs["effect_scope"]; attribution=obs["causal_attribution"]
    return seal({"schema":SCHEMAS["receipt"],"operation_id":q["operation_id"],"request_root":q["root"],
       "binding_root":binding["root"],"subject_root":q["subject_root"],"contract_root":q["contract_root"],
       "admission_root":op["admission_root"],"dispatch_root":op.get("dispatch_root"),
       "decision_root":op["decision"]["root"],"observation_root":obs["root"] if obs else None,
       "status":status,"terminal":status in TERMINAL,"effect_scope":scope,
       "custody_effect":"LOCAL_SQLITE_APPEND","causal_attribution":attribution,
       "output_sha256":obs["output_sha256"] if obs else None,
       "output_bytes":obs["output_bytes"] if obs else 0,
       "project_obligations_satisfied":[],"release_authorized":False,
       "authenticity":"UNSIGNED_LOCAL_REFERENCE",**BOUNDARY})


def cancellation_receipt(binding: dict, op: dict, authority: dict, at: int, reason: str) -> dict:
    q=op["request"]
    return seal({"schema":SCHEMAS["receipt"],"operation_id":q["operation_id"],"request_root":q["root"],
        "binding_root":binding["root"],"subject_root":q["subject_root"],"contract_root":q["contract_root"],
        "admission_root":op["admission_root"],"dispatch_root":None,"decision_root":op["decision"]["root"],
        "observation_root":None,"status":"CANCELLED","terminal":True,"effect_scope":"NONE",
        "custody_effect":"LOCAL_SQLITE_APPEND","causal_attribution":"NO_DISPATCH",
        "output_sha256":None,"output_bytes":0,"project_obligations_satisfied":[],"release_authorized":False,
        "authenticity":"UNSIGNED_LOCAL_REFERENCE","cancellation_authority_root":authority["root"],
        "at":at,"reason":reason,**BOUNDARY})


def check_cancel(binding: dict, op: dict, authority: dict, at: int) -> None:
    a=validate("authority",authority); integer(at)
    require(binding["profile"] != "VERIFY_ONLY","PROFILE_REFUSED")
    require(a["jurisdiction_root"] == binding["jurisdiction_root"] and a["valid_from"] <= at < a["valid_until"],
            "CANCEL_AUTHORITY_NOT_CURRENT")
    q=op["request"]
    g=next((x for x in a["grants"] if x["root"]==q["grant_root"]),None)
    require(g is not None and "CANCEL" in g["actions"] and g["valid_from"] <= at < g["valid_until"]
            and g["root"] not in a["revoked_grants"] and g["ledger_id"] == binding["ledger_id"]
            and g["subject_root"] == binding["subject_root"] and g["contract_root"] == binding["contract_root"]
            and g["epoch"] == a["epoch"] == q["epoch"],"CANCEL_NOT_AUTHORIZED")


def replay(*, binding: dict, contract: dict, events: list[dict],
           trusted_authority_roots: set[str]) -> dict:
    b=validate("binding",binding); c=validate("contract",contract)
    require(b["contract_root"]==c["root"] and b["subject_root"]==c["subject_root"]
            and b["jurisdiction_root"]==c["jurisdiction_root"],"CONTEXT_MISMATCH")
    require(set(c["resources"]) <= {r["id"] for r in b["resources"]},"RESOURCE_BINDING_INCOMPLETE")
    for r in trusted_authority_roots: hash_value(r)
    require(type(events) is list and len(events) <= 10000,"EVENT_LIMIT")
    head=ZERO; ops={}; usage={}; resources={r["id"]:r for r in b["resources"]}
    last_time=-1
    def trusted(a):
        a=validate("authority",a)
        require(a["root"] in trusted_authority_roots,"AUTHORITY_PIN_REQUIRED")
        return a
    for index,event in enumerate(events,1):
        e=rooted(event,SCHEMAS["event"],{"sequence","previous","operation_id","kind","body"})
        integer(e["sequence"],1)
        require(e["sequence"]==index and e["previous"]==head,"EVENT_CHAIN_INVALID")
        oid=identifier(e["operation_id"]); kind=e["kind"]; p=e["body"]
        require(kind in EVENT_KINDS and type(p) is dict,"EVENT_KIND_INVALID")
        if kind in {"ADMITTED","STARTED","DECLINED"}:
            keys={"authority","decision","evidence"} | ({"request"} if kind=="ADMITTED" else set())
            exact(p,keys); a=trusted(p["authority"])
            if kind=="ADMITTED":
                require(oid not in ops,"OPERATION_ID_ALREADY_USED")
                q=validate("request",p["request"])
                require(q["operation_id"]==oid,"OPERATION_ID_MISMATCH")
            else:
                require(oid in ops and ops[oid]["state"]=="ADMITTED","TRANSITION_INVALID")
                q=ops[oid]["request"]
            require(type(p["evidence"]) is dict and set(p["evidence"]) <= set(q["evidence_roots"]),"EVIDENCE_SET_INVALID")
            require(type(p["decision"]) is dict,"DECISION_FORMAT_INVALID")
            at=p["decision"].get("at"); integer(at)
            require(at >= last_time,"HOST_CLOCK_REGRESSION"); last_time=at
            count,used=usage.get(q["grant_root"],(0,0))
            d=evaluate(binding=b,contract=c,authority=a,request=q,evidence=p["evidence"],now=at,
                       used_operations=count,used_bytes=used,reserved=(kind!="ADMITTED"))
            require(p["decision"]==d,"DECISION_NOT_REDERIVED")
            require((d["status"]=="PERMITTED") == (kind!="DECLINED"),"DECISION_STATE_MISMATCH")
            if kind=="ADMITTED":
                usage[q["grant_root"]]=(count+1,used+d["reservation_bytes"])
                ops[oid]={"request":q,"state":"ADMITTED","admission_root":e["root"],"decision":d,
                          "dispatch_root":None,"observation":None,"receipt":None}
            else:
                ops[oid]["state"]="STARTED" if kind=="STARTED" else "DECLINED"
                ops[oid]["decision"]=d
                if kind=="STARTED": ops[oid]["dispatch_root"]=e["root"]
        elif kind in {"OBSERVED","RECOVERY_OBSERVED"}:
            require(oid in ops,"OPERATION_UNKNOWN"); op=ops[oid]; q=op["request"]
            reconciliation=kind=="RECOVERY_OBSERVED"
            if reconciliation:
                exact(p,{"authority","permit_root","at","observation"})
                require(op["state"] in {"STARTED","UNCERTAIN"},"RECONCILIATION_STATE_INVALID")
                a=trusted(p["authority"])
                integer(p["at"]); require(p["at"]>=last_time,"HOST_CLOCK_REGRESSION"); last_time=p["at"]
                recovery_authorized(binding=b,authority=a,request=q,operation_head=op["operation_head"],
                                    permit_root=p["permit_root"],now=p["at"])
            else:
                exact(p,{"observation"}); require(op["state"]=="STARTED","OBSERVATION_STATE_INVALID")
            obs=validate_observation(p["observation"],q,resources[q["resource_id"]],reconciliation=reconciliation)
            op["observation"]=obs; op["state"]="OBSERVED"; op["receipt"]=None
        elif kind=="FINALIZED":
            exact(p,{"receipt"}); require(oid in ops and ops[oid]["state"] in {"OBSERVED","DECLINED"},"FINALIZE_STATE_INVALID")
            op=ops[oid]; expected=receipt(b,op)
            require(p["receipt"]==expected,"RECEIPT_NOT_REDERIVED")
            op["receipt"]=expected; op["state"]=expected["status"] if expected["terminal"] else "UNCERTAIN"
        elif kind=="CANCELLED":
            exact(p,{"authority","at","reason","receipt"}); require(oid in ops and ops[oid]["state"]=="ADMITTED","CANCEL_STATE_INVALID")
            op=ops[oid]; a=trusted(p["authority"]); identifier(p["reason"]); integer(p["at"])
            require(p["at"]>=last_time,"HOST_CLOCK_REGRESSION"); last_time=p["at"]
            check_cancel(b,op,a,p["at"])
            expected=cancellation_receipt(b,op,a,p["at"],p["reason"])
            require(p["receipt"]==expected,"CANCELLATION_NOT_REDERIVED")
            op["receipt"]=expected; op["state"]="CANCELLED"
        ops[oid]["operation_head"]=e["root"]; head=e["root"]
    return {"head":head,"event_count":len(events),"operations":ops,"usage":usage,"last_host_time":last_time}


def verify_bundle(bundle: dict, *, expected_binding_root: str, expected_head: str,
                  trusted_authority_roots: set[str]) -> dict:
    v=rooted(bundle,SCHEMAS["bundle"],{"binding","contract","events","head","disclosure"})
    require(v["binding"]["root"]==hash_value(expected_binding_root),"BINDING_PIN_MISMATCH")
    require(v["disclosure"]=="FULL_LOCAL_INPUTS_AND_GRANTS_NO_SECRET_REDACTION","DISCLOSURE_INVALID")
    result=replay(binding=v["binding"],contract=v["contract"],events=v["events"],trusted_authority_roots=trusted_authority_roots)
    require(result["head"]==v["head"]==hash_value(expected_head),"HEAD_PIN_MISMATCH")
    return seal({"schema":PREFIX+"replay-result.v1","status":"CONSISTENT_WITH_PINNED_RECORDS",
        "bundle_root":v["root"],"head":result["head"],"event_count":result["event_count"],
        "operation_states":{k:o["state"] for k,o in sorted(result["operations"].items())},
        "physical_execution_independently_verified":False,"signature_authentication":False,
        "ugk_binding":"NOT_BOUND","scope":"RECORD_DERIVATION_NOT_EMPIRICAL_PROOF",**BOUNDARY})
