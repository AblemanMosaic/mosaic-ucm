"""One canonical envelope around unchanged A requests and C host actions."""
from __future__ import annotations
import hashlib
from ugel.canonical import canonical, load_bytes, require, exact, integer, identifier, hash_value, seal, copy
from ugel.contracts import validate, SCHEMAS, FIELDS
DOMAIN=b'MOSAIC-UGEL-D1'+bytes([0])
SCHEMA='mosaic.ugel.batch-d.command.v1'
MAX_TEXT=65536
MAX_FRAME=1048576
EFFECT_ACTIONS={'PREVIEW','ADMIT','OBSERVE','RUN'}
CONTROL_ACTIONS={'INSPECT','FINALIZE','CANCEL','HOST_INSPECT','HOST_EXECUTE','HOST_FINALIZE'}
BOUNDARY={'standing':'INFORMATION_ONLY','authority_effect':'NONE','real_a5':False,'g0':'CLOSED'}
def digest(x):return hashlib.sha256(DOMAIN+canonical(x)).hexdigest()
def record(kind,**fields):
    body={'schema':'mosaic.ugel.batch-d.'+kind+'.v1',**fields}
    return {**body,'root':digest(body)}
def check(x,kind):
    require(type(x) is dict and x.get('schema')=='mosaic.ugel.batch-d.'+kind+'.v1','D_SCHEMA_INVALID')
    require(x.get('root')==digest({k:v for k,v in x.items() if k!='root'}),'D_ROOT_INVALID')
    return copy(x)
def body(q):
    q=validate('request',q);return {k:v for k,v in q.items() if k!='root'}
def command(context_root,head,action,request):
    require(action in EFFECT_ACTIONS,'ACTION_INVALID')
    return validate_command({'schema':SCHEMA,'context_root':context_root,'expected_head':head,'action':action,'payload':{'request':body(request)}})
def control(context_root,head,action,value=None):
    require(action in CONTROL_ACTIONS,'ACTION_INVALID')
    payload=({'operation_id':identifier(value)} if action in {'FINALIZE','CANCEL'} else
             {'permit_root':hash_value(value)} if action=='HOST_FINALIZE' else {})
    return validate_command({'schema':SCHEMA,'context_root':context_root,'expected_head':head,'action':action,'payload':payload})
def validate_command(x):
    exact(x,{'schema','context_root','expected_head','action','payload'})
    require(x['schema']==SCHEMA,'COMMAND_SCHEMA');hash_value(x['context_root']);hash_value(x['expected_head'])
    a=x['action'];require(a in EFFECT_ACTIONS|CONTROL_ACTIONS,'ACTION_UNSUPPORTED')
    p=x['payload']
    if a in EFFECT_ACTIONS:
        exact(p,{'request'});exact(p['request'],FIELDS['request']|{'schema'})
        q=validate('request',seal(p['request']));pars=q['parameters']
        require(len(q['evidence_roots'])<=1,'D_EVIDENCE_SUBSET_LIMIT')
        if 'text' in pars:require(len(pars['text'].encode('utf-8'))<=MAX_TEXT,'D_TEXT_LIMIT')
        if 'max_bytes' in pars:require(pars['max_bytes']<=MAX_TEXT,'D_READ_LIMIT')
    elif a in {'FINALIZE','CANCEL'}:exact(p,{'operation_id'});identifier(p['operation_id'])
    elif a=='HOST_FINALIZE':exact(p,{'permit_root'});hash_value(p['permit_root'])
    else:exact(p,set())
    require(len(canonical(x))<=MAX_FRAME,'FRAME_LIMIT')
    return copy(x)
def decode(data):
    require(type(data) is bytes and len(data)<=MAX_FRAME and b'\n' not in data,'FRAME_INVALID')
    value=validate_command(load_bytes(data));require(canonical(value)==data,'CANONICAL_COMMAND_REQUIRED');return value
