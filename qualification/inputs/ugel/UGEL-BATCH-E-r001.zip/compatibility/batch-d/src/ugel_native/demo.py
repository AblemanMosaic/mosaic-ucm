"""Ordinary native interoperability and signed-host demonstrations."""
from __future__ import annotations
import hashlib,shutil,subprocess,sys,tempfile,time
from pathlib import Path
from ugel.canonical import canonical,require,byte_digest
from .protocol import command,control,record,digest,BOUNDARY
from .effects import EffectSession,write_new,verify_export
from .transport import emit,exchange
ROOT=Path(__file__).resolve().parents[2]

def comparison(build,output):
    output=Path(output);output.mkdir(parents=True,exist_ok=False)
    task={'name':'native-canonical-conformance','revision':1,'operations':['sum','echo'],'examples':'exact-same-logical-task-no-executable-equivalence-claim'}
    subject=digest(task);clients={'c':build['c']['client']}
    if build['alternate_c']['status']=='BUILT':clients['clang']=build['alternate_c']['client']
    if build['rust']['status']=='BUILT_AND_TESTED':clients['rust']=build['rust']['client']
    results={};wires={};receipts={};transports={}
    with tempfile.TemporaryDirectory(prefix='ugel-d-compare-') as tmp:
        for language in ['python',*clients]:
            host=EffectSession.initialize(Path(tmp)/language,subject_root=subject,expected_subject_root=subject,now=1000,clock=lambda:1000)
            language_wires=[];language_receipts=[];language_traces=[]
            for oid,effect,pars in [('sum','sim.add',{'left':19,'right':23}),('echo','sim.echo',{'text':'Same meaning: café 🌞\n\t"quote" \\ path'})]:
                q=host.prepare_request(oid,effect,pars);cmd=command(host.context['root'],host.pins()['head'],'RUN',q)
                raw=canonical(cmd) if language=='python' else emit(clients[language],cmd)
                require(raw==canonical(cmd),'REQUEST_BYTES_DIFFER')
                if language=='python':response=host.handle(cmd)
                else:response,trace=exchange(clients[language],cmd,host.handle);language_traces.append(trace)
                require(response['status']=='COMPLETED','DEMO_OPERATION_NOT_COMPLETED')
                language_wires.append(raw.decode());language_receipts.append(response['receipt']);
            pending=host.prepare_request('await-evidence','sim.echo',{'text':'ordinary work awaiting its checker'},with_evidence=False)
            pending_command=command(host.context['root'],host.pins()['head'],'PREVIEW',pending)
            if language=='python':pending_result=host.handle(pending_command)
            else:pending_result,pending_trace=exchange(clients[language],pending_command,host.handle);language_traces.append(pending_trace)
            require(pending_result['status']=='NEEDS_EVIDENCE','PENDING_EVIDENCE_STATUS')
            language_wires.append(canonical(pending_command).decode());language_receipts.append(pending_result)
            exported=host.export(expected_head=host.pins()['head'],acknowledge_plaintext=True)
            verified=verify_export(exported,export_root=exported['root'],**host.pins())
            write_new(output/(language+'-BUNDLE.json'),exported);write_new(output/(language+'-PINS.json'),{**host.pins(),'export_root':exported['root']})
            write_new(output/(language+'-REPLAY.json'),verified);write_new(output/(language+'-TRANSPORT.json'),language_traces)
            results[language]={'status':'PASS','head':host.pins()['head'],'export_root':exported['root'],'verification_root':verified['root']}
            wires[language]=language_wires;receipts[language]=language_receipts;transports[language]=language_traces
        for language in clients:
            require(wires[language]==wires['python'] and receipts[language]==receipts['python'],'SEMANTIC_RECORD_PARITY_FAILED')
        comparison_record=record('comparison',status='MATCH_FOR_EXECUTED_LANGUAGES',languages=list(results),runs=results,
            request_bytes_equal=True,decision_receipt_and_history_roots_equal=True,logical_clock=1000,
            scope='FINITE_TWO_OPERATIONS_PLUS_ONE_PENDING_PREVIEW_SHARED_LOGICAL_TASK',
            pending_evidence_decision='NEEDS_EVIDENCE',
            rust_runtime_status='PASS' if 'rust' in results else 'NOT_RUN_TOOLCHAIN_UNAVAILABLE',
            executable_equivalence_proved=False,**BOUNDARY)
        write_new(output/'COMPARISON.json',comparison_record)
    return comparison_record

def filesystem_demo(build,output):
    output=Path(output);output.mkdir(parents=True,exist_ok=False)
    with tempfile.TemporaryDirectory(prefix='ugel-d-local-') as tmp:
        folder=Path(tmp)/'task';task={'name':'native-report-workflow','report':'Governed C request → unchanged broker.\n'};subject=digest(task)
        host=EffectSession.initialize(folder,subject_root=subject,expected_subject_root=subject,local=True)
        traces=[];results=[];exe=build['c']['client']
        q=host.prepare_request('create-report','fs.create',{'name':'report.txt','text':task['report']})
        cmd=command(host.context['root'],host.pins()['head'],'OBSERVE',q)
        observed,trace=exchange(exe,cmd,host.handle);traces.append(trace);require(observed['status']=='OBSERVED','OBSERVATION_PHASE')
        # New Python process, same native C client: derive the persisted receipt only.
        pins=host.pins();write_new(output/'OBSERVED-PINS.json',pins)
        proc=subprocess.run([sys.executable,'-B',str(ROOT/'run.py'),'finalize-native','--task',str(folder),'--pins',str(output/'OBSERVED-PINS.json'),
            '--operation','create-report','--client',exe],capture_output=True,timeout=20)
        require(proc.returncode==0,'FRESH_PROCESS_FINALIZATION',proc.stderr.decode(errors='replace')[:300])
        from ugel.canonical import load_bytes
        final=load_bytes(proc.stdout);results.append(final['response']);traces.append(final['transport'])
        host=EffectSession(folder,pins['context_root'])
        q=host.prepare_request('read-report','fs.read',{'name':'report.txt','expected_sha256':byte_digest(task['report'].encode()),'max_bytes':4096})
        r,t=exchange(exe,command(host.context['root'],host.pins()['head'],'RUN',q),host.handle);traces.append(t);results.append(r)
        require(bytes.fromhex(r['content_hex']).decode()==task['report'],'READ_DATA')
        q=host.prepare_request('cancel-sum','sim.add',{'left':1,'right':2})
        r,t=exchange(exe,command(host.context['root'],host.pins()['head'],'ADMIT',q),host.handle);traces.append(t)
        r,t=exchange(exe,control(host.context['root'],host.pins()['head'],'CANCEL','cancel-sum'),host.handle);traces.append(t);results.append(r)
        exported=host.export(expected_head=host.pins()['head'],acknowledge_plaintext=True)
        verified=verify_export(exported,export_root=exported['root'],**host.pins())
        write_new(output/'BUNDLE.json',exported);write_new(output/'PINS.json',{**host.pins(),'export_root':exported['root']});write_new(output/'REPLAY.json',verified);write_new(output/'TRANSPORT.json',traces)
        report=record('filesystem-demo',status='PASS',operations=[{'operation_id':r['operation_id'],'status':r['status'],'receipt_root':r['receipt']['root']} for r in results],
            event_count=len(exported['bundle']['events']),fresh_process_finalization=True,no_effect_redispatch=True,
            file_content_sha256=byte_digest((folder/'workspace/report.txt').read_bytes()),native_client_containment='NOT_ESTABLISHED',**BOUNDARY)
        write_new(output/'DEMO-RESULT.json',report)
    return report

def signed_host_demo(build,output):
    """A C call reaches unchanged C HostSession. It does not run a native sandbox."""
    from ugel_host.trust import Authority,LocalKey
    from ugel_host.service import HostSession
    from ugel_python import propose,TaskSession
    from .host_bridge import HostBridge
    output=Path(output);output.mkdir(parents=True,exist_ok=False)
    with tempfile.TemporaryDirectory(prefix='ugel-d-host-') as tmp:
        t=Path(tmp);p=t/'project';p.mkdir();broot=ROOT/'compatibility/batch-c/compatibility/batch-b'
        for f in (broot/'examples/project').glob('*.py'):(p/f.name).write_bytes(f.read_bytes())
        from .effects import read_json
        changes=read_json(broot/'examples/REPAIR-PROPOSAL.json')['replacements']
        plan=propose(p,'native-host-demo','Use existing accepted Python check through native dispatch',changes)
        b=TaskSession.initialize(project=p,plan=plan,expected_plan_root=plan['root'],output=t/'b',acknowledge_trusted_code_execution=True);b.materialize()
        authority=Authority.create(t/'authority');observer=LocalKey.create(t/'observer','HOST_OBSERVER')
        h=HostSession.prepare(b,'native-python-check',t/'host',authority=authority,observer=observer)
        bridge=HostBridge(h,expected_context_root=h.context['root'])
        r,t1=exchange(build['c']['client'],control(bridge.context['root'],h.pins()['head'],'HOST_EXECUTE'),bridge.handle,timeout=40)
        require(h.store.state()['phase']=='OBSERVED','HOST_OBSERVATION_NOT_PERSISTED')
        permit=authority.recovery_permit(h.context['request']['root'],'native-python-check',h.pins()['head'],now=int(time.time()))
        bridge.permits[permit['root']]=permit
        r,t2=exchange(build['c']['client'],control(bridge.context['root'],h.pins()['head'],'HOST_FINALIZE',permit['root']),bridge.handle)
        receipt=h.store.state()['receipt'];require(receipt['status']=='CHECKED_NOT_RELEASED','HOST_CHECK_FAILED')
        bundle=h.export(acknowledge_plaintext=True);verification=h.verify();observation=h.store.state()['observation']['body']
        for name,x in [('BUNDLE.json',bundle),('PINS.json',h.pins()),('REPLAY.json',verification),('TRANSPORT.json',[t1,t2]),('RECEIPT.json',receipt),('CHANNEL.json',bridge.context)]:write_new(output/name,x)
        report=record('signed-host-demo',status='PASS',native_language='C',tests_run=observation['child_result']['tests_run'],
            failures=observation['child_result']['failures'],receipt_root=receipt['root'],verification_root=verification['root'],
            parent_witness=observation['parent_witness'],child_execution_profile=h.context['request']['policy']['profile'],
            private_keys_exported=False,native_client_containment='NOT_ESTABLISHED',
            enforced_profile_applies_to='UNCHANGED_BATCH_C_PYTHON_CHILD',**BOUNDARY)
        write_new(output/'DEMO-RESULT.json',report)
    write_new(output/'CLEANUP.json',record('cleanup',temporary_workspace_removed=True,private_keys_retained=False,secure_erasure_claim=False))
    return report

def demonstration(build,output,*,with_host=True):
    output=Path(output);output.mkdir(parents=True,exist_ok=False)
    comparison_result=comparison(build,output/'comparison');local_result=filesystem_demo(build,output/'filesystem')
    host=signed_host_demo(build,output/'signed-host') if with_host else {'status':'NOT_RUN','reason':'NOT_REQUESTED'}
    result=record('demo-result',status='PASS_EXECUTED_LANES_RUST_NOT_RUN' if build['rust']['status']=='NOT_RUN' else 'PASS',
        comparison=comparison_result,filesystem=local_result,signed_host=host,
        rust_runtime_status=build['rust']['status'],native_ugk_binding='NOT_BOUND',
        adversarial_testing='NOT_PERFORMED',fault_injection='NOT_PERFORMED',**BOUNDARY)
    write_new(output/'DEMO-RESULT.json',result);return result
