"""Trusted one-command native subprocess over inherited pipes. Not a sandbox."""
from __future__ import annotations
import os,select,subprocess,time
from pathlib import Path
from ugel.canonical import canonical,load_bytes,require,byte_digest
from .protocol import decode,digest,record,MAX_FRAME,BOUNDARY

def arguments(cmd):
    a=cmd['action'];common=[a,cmd['context_root'],cmd['expected_head']]
    if 'request' not in cmd['payload']:
        value=list(cmd['payload'].values());return ['control',*common,*value]
    q=cmd['payload']['request'];p=q['parameters'];ev=q['evidence_roots'][0] if q['evidence_roots'] else '-'
    args=['effect',*common,q['subject_root'],q['contract_root'],q['grant_root'],str(q['epoch']),q['operation_id'],q['effect'],q['resource_id']]
    if q['effect']=='sim.add':args += [str(p['left']),str(p['right'])]
    elif q['effect']=='sim.echo':args += [p['text'],ev]
    elif q['effect']=='fs.create':args += [p['name'],p['text'],ev]
    else:args += [p['name'],p['expected_sha256'],str(p['max_bytes'])]
    return args

def emit(executable,cmd):
    proc=subprocess.run([str(Path(executable).absolute()),'emit',*arguments(cmd)],capture_output=True,timeout=15,env={'LANG':'C.UTF-8','LC_ALL':'C.UTF-8'})
    require(proc.returncode==0,'NATIVE_ENCODING_FAILED',proc.stderr.decode(errors='replace')[:300])
    require(proc.stdout.endswith(b'\n') and proc.stdout.count(b'\n')==1,'NATIVE_FRAME_COUNT')
    data=proc.stdout[:-1];decode(data);return data

def frame(fd,deadline):
    out=bytearray()
    while len(out)<=MAX_FRAME:
        remaining=deadline-time.monotonic();require(remaining>0,'PIPE_DEADLINE_UNCERTAIN')
        ready,_,_=select.select([fd],[],[],remaining);require(bool(ready),'PIPE_DEADLINE_UNCERTAIN')
        c=os.read(fd,1);require(bool(c),'PIPE_EOF_UNCERTAIN')
        if c==b'\n':return bytes(out)
        out+=c
    raise ValueError('PIPE_FRAME_BOUND_UNCERTAIN')

def exchange(executable,expected_command,handler,*,timeout=30):
    """The host independently compares the proposed command before invoking the broker.
    This harness binds an exact accepted command; it is not a general network service.
    A response/read error after handling is uncertain and causes NO automatic retry.
    """
    exe=Path(executable).absolute();exe_hash=byte_digest(exe.read_bytes())
    proc=subprocess.Popen([str(exe),'exchange',*arguments(expected_command)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
        env={'LANG':'C.UTF-8','LC_ALL':'C.UTF-8'},close_fds=True,shell=False)
    sent=False
    try:
        wire=frame(proc.stdout.fileno(),time.monotonic()+timeout);cmd=decode(wire)
        require(canonical(expected_command)==wire,'NATIVE_REQUEST_NOT_EXPECTED')
        response=handler(cmd);reply=canonical(response);require(len(reply)<=MAX_FRAME,'RESPONSE_BOUND_UNCERTAIN')
        proc.stdin.write(reply+b'\n');proc.stdin.flush();proc.stdin.close();sent=True
        ack=frame(proc.stdout.fileno(),time.monotonic()+timeout);require(ack==reply,'NATIVE_RESPONSE_DELIVERY_UNCERTAIN')
        proc.wait(timeout=timeout);tail=proc.stdout.read();stderr=proc.stderr.read()
        require(proc.returncode==0 and not tail,'NATIVE_EXCHANGE_INCOMPLETE')
        trace=record('transport-observation',executable_sha256=exe_hash,command_root=digest(cmd),command_sha256=byte_digest(wire),
            response_root=response['root'],response_sha256=byte_digest(reply),ack_sha256=byte_digest(ack),
            returncode=proc.returncode,stderr=stderr.decode('utf-8',errors='replace'),
            transport='LOCAL_INHERITED_PIPE_SINGLE_EXCHANGE',native_code='TRUSTED_COOPERATIVE_NO_HOST_ISOLATION',**BOUNDARY)
        return response,trace
    finally:
        if proc.poll() is None:
            # Cooperative child cleanup, not recovery of broker effects or an attack.
            proc.terminate()
            try:proc.wait(timeout=3)
            except subprocess.TimeoutExpired:proc.kill();proc.wait(timeout=3)
        for f in [proc.stdin,proc.stdout,proc.stderr]:
            if f and not f.closed:f.close()
