"""Operator CLI. All host effects are explicit commands; orientation is stdlib only."""
from __future__ import annotations
import argparse,json,sys
from pathlib import Path
from ugel.canonical import canonical,load_bytes
from .protocol import record,control,BOUNDARY

def main(argv=None):
    p=argparse.ArgumentParser();sp=p.add_subparsers(dest='cmd',required=True)
    sp.add_parser('orient')
    d=sp.add_parser('demo');d.add_argument('--build',type=Path,required=True);d.add_argument('--output',type=Path,required=True);d.add_argument('--without-host',action='store_true')
    f=sp.add_parser('finalize-native');f.add_argument('--task',type=Path,required=True);f.add_argument('--pins',type=Path,required=True);f.add_argument('--operation',required=True);f.add_argument('--client',type=Path,required=True)
    v=sp.add_parser('verify-bundle');v.add_argument('bundle',type=Path);v.add_argument('--pins',type=Path,required=True)
    a=p.parse_args(argv)
    try:
        if a.cmd=='orient':
            result=record('orientation',status='INFORMATION_ONLY',abi_version=1,
                effects=['fs.create','fs.read','sim.add','sim.echo'],inherited_effect_semantics='UNCHANGED_BATCH_A',
                signed_host_operation='UNCHANGED_BATCH_C_PYTHON_MEMORY_UNITTEST',native_profiles='TRUSTED_COOPERATIVE',
                rust_source='DELIVERED_RUNTIME_STATUS_IN_BUILD_EVIDENCE',native_ugk_binding='NOT_BOUND',**{k:v for k,v in BOUNDARY.items() if k!='standing'})
        elif a.cmd=='demo':
            from .demo import demonstration
            result=demonstration(load_bytes(a.build.read_bytes()),a.output,with_host=not a.without_host)
        elif a.cmd=='finalize-native':
            from .effects import EffectSession
            from .transport import exchange
            pins=load_bytes(a.pins.read_bytes());s=EffectSession(a.task,pins['context_root'])
            response,trace=exchange(a.client,control(pins['context_root'],pins['head'],'FINALIZE',a.operation),s.handle)
            result={'response':response,'transport':trace,'pins':s.pins()}
        else:
            from .effects import verify_export
            result=verify_export(load_bytes(a.bundle.read_bytes()),**load_bytes(a.pins.read_bytes()))
        sys.stdout.buffer.write(canonical(result)+b'\n');return 0
    except Exception as e:
        result={'status':'REQUEST_NOT_COMPLETED','error':getattr(e,'code',type(e).__name__),'detail':str(e),
            'local_effects':'MAY_BE_PRESENT_AFTER_MUTATING_COMMAND','automatic_retry':False,**BOUNDARY}
        try:sys.stdout.buffer.write(canonical(result)+b'\n')
        except OSError:pass
        return 2
if __name__=='__main__':raise SystemExit(main())
