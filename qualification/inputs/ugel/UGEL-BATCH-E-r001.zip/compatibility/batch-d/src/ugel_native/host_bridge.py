"""Typed native access to an already accepted Batch C host session. No signing keys on wire."""
from __future__ import annotations
from ugel.canonical import require,exact,hash_value
from .protocol import record,check,digest,validate_command,BOUNDARY
class HostBridge:
    def __init__(self,host_session,*,expected_context_root,permits=None):
        self.host=host_session;require(self.host.context['root']==hash_value(expected_context_root),'HOST_CONTEXT_PIN')
        self.permits=dict(permits or {})
        for r,p in self.permits.items():require(p['root']==r,'PERMIT_MAP_BINDING')
        self.context=record('host-channel',host_context_root=expected_context_root,
            issuer_root=self.host.pins()['issuer_root'],observer_root=self.host.pins()['observer_root'],
            allowed_actions=['HOST_EXECUTE','HOST_FINALIZE','HOST_INSPECT'],native_client_containment='NOT_ESTABLISHED',
            child_profile_scope='UNCHANGED_BATCH_C_PYTHON_CHILD_ONLY',**BOUNDARY)
    def handle(self,cmd):
        cmd=validate_command(cmd);require(cmd['context_root']==self.context['root'],'CHANNEL_PIN')
        before=self.host.pins();require(cmd['expected_head']==before['head'],'STALE_HOST_HEAD')
        a=cmd['action'];require(a in self.context['allowed_actions'],'CHANNEL_ACTION')
        if a=='HOST_EXECUTE':result=self.host.execute(finalize=False)
        elif a=='HOST_FINALIZE':
            root=cmd['payload']['permit_root'];require(root in self.permits,'RECOVERY_PERMIT_NOT_HOST_BOUND')
            result=self.host.reconcile(self.permits[root])
        else:result=self.host.current_task()
        after=self.host.pins()
        return record('host-response',command_root=digest(cmd),channel_root=self.context['root'],host_context_root=before['context_root'],
            before_head=before['head'],after_head=after['head'],action=a,result=result,pins=after,
            response_scope='TRANSPORT_ENVELOPE_USE_BATCH_C_SIGNED_BUNDLE_FOR_ACCEPTANCE',**BOUNDARY)
