"""Host-pinned forwarding into unchanged Batch A. Never takes grants from a client."""
from __future__ import annotations
import os,time
from pathlib import Path
from ugel.canonical import canonical,load_bytes,require,exact,seal,copy,byte_digest,hash_value,integer
from ugel.contracts import validate,record as a_record,make_evidence,EFFECTS,REGISTRY,CHECKER,ECHO,ADD,READ,CREATE
from ugel.adapters import SimulationAdapter,PrivateDirectoryAdapter
from ugel.broker import Broker
from ugel.store import Ledger
from ugel.history import replay,verify_bundle,ZERO
from ugel.gate import evaluate
from .protocol import record,check,digest,validate_command,command,EFFECT_ACTIONS,BOUNDARY

def write_new(path,value):
    path=Path(path)
    with path.open('xb') as f:f.write(canonical(value)+b'\n');f.flush();os.fsync(f.fileno())
def read_json(path):return load_bytes(Path(path).read_bytes())

def context_valid(c,pin):
    c=check(c,'effect-context');require(c['root']==hash_value(pin),'CONTEXT_PIN')
    exact(c,{'schema','root','binding','contract','grant','authority','workspace_path','subject_meaning','authority_authentication',*BOUNDARY})
    for k in BOUNDARY:require(c[k]==BOUNDARY[k],'AUTHORITY_CEILING')
    b=validate('binding',c['binding']);con=validate('contract',c['contract']);g=validate('grant',c['grant']);a=validate('authority',c['authority'])
    require(b['contract_root']==con['root']==g['contract_root'] and b['subject_root']==con['subject_root']==g['subject_root'],'CONTEXT_SUBJECT')
    require(g in a['grants'] and g['ledger_id']==b['ledger_id'],'GRANT_CONTEXT')
    require(c['authority_authentication']=='BATCH_A_UNSIGNED_HOST_PIN_NOT_BATCH_C_SIGNATURE','AUTHORITY_SCOPE')
    require(c['workspace_path'] is None or type(c['workspace_path']) is str,'WORKSPACE_BINDING')
    return c

def query(c,q):
    q=validate('request',q)
    for k,v in [('subject_root',c['binding']['subject_root']),('contract_root',c['contract']['root']),('grant_root',c['grant']['root']),('epoch',c['grant']['epoch'])]:
        require(q[k]==v,'REQUEST_CONTEXT_MISMATCH')
    return q

def rederive(c,cmd,before_events,after_events,at,evidence,content_hex=None):
    """Shared live/offline interpretation. A replay checks all decision/receipt semantics."""
    c=context_valid(c,c['root']);cmd=validate_command(cmd)
    require(cmd['context_root']==c['root'],'CONTEXT_PIN');integer(at)
    kw={'binding':c['binding'],'contract':c['contract'],'trusted_authority_roots':{c['authority']['root']}}
    before=replay(events=before_events,**kw);after=replay(events=after_events,**kw)
    require(at>=before['last_host_time'],'HOST_CLOCK_REGRESSION')
    require(before['head']==cmd['expected_head'] and after_events[:len(before_events)]==before_events,'TRANSCRIPT_HEAD')
    action=cmd['action'];require(not action.startswith('HOST_'),'WRONG_CHANNEL')
    q=query(c,seal(cmd['payload']['request'])) if action in EFFECT_ACTIONS else None
    oid=q['operation_id'] if q else cmd['payload'].get('operation_id')
    old=before['operations'].get(oid);new=after['operations'].get(oid)
    if old is not None and q is not None:require(old['request']==q,'OPERATION_ID_CONFLICT')
    delta=after_events[len(before_events):]
    require(all(e['operation_id']==oid for e in delta),'UNRELATED_EFFECT_IN_EXCHANGE')
    allowed={'PREVIEW':set(),'INSPECT':set(),'ADMIT':{'ADMITTED'},'OBSERVE':{'ADMITTED','STARTED','DECLINED','OBSERVED'},
             'RUN':{'ADMITTED','STARTED','DECLINED','OBSERVED','FINALIZED'},'FINALIZE':{'FINALIZED'},'CANCEL':{'CANCELLED'}}[action]
    require(all(e['kind'] in allowed for e in delta),'ACTION_TRANSITION_SCOPE')
    decision=None
    if q is not None:
        count,used=before['usage'].get(q['grant_root'],(0,0))
        decision=evaluate(binding=c['binding'],contract=c['contract'],authority=c['authority'],request=q,evidence=evidence,
                          now=at,used_operations=count,used_bytes=used,reserved=old is not None)
    if action=='PREVIEW':status=decision['status']
    elif action=='INSPECT':status='INSPECTED'
    elif new is None:
        require(q is not None and decision['status']!='PERMITTED' and not delta,'MISSING_ADMISSION');status=decision['status']
    elif new['receipt'] is not None:status=new['receipt']['status']
    elif new['state']=='STARTED':status='RECONCILIATION_REQUIRED'
    else:status=new['state']
    if action=='CANCEL':require(new is not None and new['state']=='CANCELLED','CANCEL_RESULT')
    if action=='FINALIZE':require(new is not None and new['receipt'] is not None,'FINALIZATION_RESULT')
    if content_hex is not None:
        data=bytes.fromhex(content_hex)
        require(q is not None and q['effect']==READ and new is not None and new['observation'] is not None,'READ_CONTENT_SCOPE')
        obs=new['observation'];require(obs['status']=='SUCCEEDED' and byte_digest(data)==obs['output_sha256'] and len(data)==obs['output_bytes'],'CONTENT_BINDING')
    return record('response',context_root=c['root'],command_root=digest(cmd),action=action,at=at,before_head=before['head'],after_head=after['head'],
        status=status,operation_id=oid,request_root=q['root'] if q else new['request']['root'] if new else None,
        decision=decision,receipt=new['receipt'] if new else None,observation=new['observation'] if new else None,
        content_hex=content_hex,operation_states={k:o['state'] for k,o in sorted(after['operations'].items())},
        transport_authentication='TRUSTED_LOCAL_PIPE_NO_REMOTE_AUTHENTICATION',native_client_containment='NOT_ESTABLISHED',**BOUNDARY)

class EffectSession:
    @classmethod
    def initialize(cls,folder,*,subject_root,expected_subject_root,local=False,now=None,clock=None):
        require(hash_value(subject_root)==hash_value(expected_subject_root),'SUBJECT_ACCEPTANCE_PIN')
        folder=Path(folder).absolute();require(not folder.exists(),'FRESH_DESTINATION_REQUIRED');folder.mkdir(mode=0o700)
        sim=SimulationAdapter('simulation');adapters={'simulation':sim};workspace=None
        if local:
            workspace=folder/'workspace';adapters['workspace']=PrivateDirectoryAdapter.initialize(workspace,'workspace')
        effects=sorted(EFFECTS if local else {ADD,ECHO});resources=sorted(adapters)
        at=int(time.time()) if now is None else integer(now)
        from ugel.canonical import digest as adigest
        jurisdiction=adigest({'local_reference_owner':'UGEL Batch D','native_ugk_binding':'NOT_BOUND'})
        con=validate('contract',a_record('contract',subject_root=subject_root,jurisdiction_root=jurisdiction,epoch=1,
            effects=effects,resources=resources,max_operation_bytes=65536,obligations={e:[CHECKER] if e in {ECHO,CREATE} else [] for e in effects}))
        binding=validate('binding',a_record('binding',ledger_id='native-adapter-task',subject_root=subject_root,jurisdiction_root=jurisdiction,
            contract_root=con['root'],profile='LOCAL_REFERENCE' if local else 'SIMULATION',registry_root=REGISTRY['root'],
            resources=[adapters[r].descriptor for r in resources],ugk_binding='NOT_BOUND'))
        grant=validate('grant',a_record('grant',grant_id='native-adapter-local-grant',ledger_id=binding['ledger_id'],subject_root=subject_root,
            contract_root=con['root'],epoch=1,effects=effects,resources=resources,actions=['CANCEL','EXECUTE'],valid_from=at,valid_until=at+3600,max_operations=32,max_total_bytes=2_000_000))
        authority=validate('authority',a_record('authority',issuer_id='local-reference-owner',jurisdiction_root=jurisdiction,epoch=1,
            valid_from=at,valid_until=at+3600,grants=[grant],revoked_grants=[],recoveries=[]))
        c=record('effect-context',binding=binding,contract=con,grant=grant,authority=authority,workspace_path=str(workspace) if workspace else None,
            subject_meaning='HOST_ACCEPTED_LOGICAL_TASK_NOT_NATIVE_EXECUTABLE_EQUIVALENCE',authority_authentication='BATCH_A_UNSIGNED_HOST_PIN_NOT_BATCH_C_SIGNATURE',**BOUNDARY)
        write_new(folder/'CONTEXT.json',c);(folder/'evidence').mkdir();(folder/'exchanges').mkdir()
        Ledger.initialize(folder/'ledger.sqlite',binding['root'])
        return cls(folder,c['root'],clock=clock)
    def __init__(self,folder,expected_context_root,*,clock=None):
        self.folder=Path(folder).absolute();self.context=context_valid(read_json(self.folder/'CONTEXT.json'),expected_context_root)
        self.clock=clock or (lambda:int(time.time()))
        self.ledger=Ledger(self.folder/'ledger.sqlite',self.context['binding']['root'])
        self._broker(adapters=False).inspect() # opens existing custody only
    def pins(self):return {'context_root':self.context['root'],'binding_root':self.context['binding']['root'],'authority_root':self.context['authority']['root'],'head':self.ledger.head}
    def _evidence(self):
        out={}
        for p in sorted((self.folder/'evidence').glob('*.json')):
            ev=validate('evidence',read_json(p));require(p.stem==ev['root'],'EVIDENCE_PATH_BINDING');out[ev['root']]=ev
        return out
    def _broker(self,*,adapters=True,at=None):
        c=self.context;resolved={}
        if adapters:
            resolved['simulation']=SimulationAdapter('simulation')
            if c['workspace_path']:resolved['workspace']=PrivateDirectoryAdapter(Path(c['workspace_path']),'workspace')
        return Broker(ledger=self.ledger,binding=c['binding'],expected_binding_root=c['binding']['root'],contract=c['contract'],
            authority=c['authority'],expected_authority_root=c['authority']['root'],trusted_authority_roots={c['authority']['root']},
            evidence=self._evidence(),adapters=resolved,clock=(lambda:at) if at is not None else self.clock)
    def prepare_request(self,operation_id,effect,parameters,*,with_evidence=True):
        """Trusted host helper: executes the existing bounded text checker, never issues authority."""
        c=self.context;q=a_record('request',operation_id=operation_id,subject_root=c['binding']['subject_root'],contract_root=c['contract']['root'],grant_root=c['grant']['root'],
            epoch=c['grant']['epoch'],effect=effect,resource_id='simulation' if effect in {ADD,ECHO} else 'workspace',parameters=parameters,evidence_roots=[])
        q=validate('request',q)
        if with_evidence and c['contract']['obligations'][effect]:
            ev=make_evidence(q,c['grant']['valid_until']);p=self.folder/'evidence'/(ev['root']+'.json')
            if p.exists():require(read_json(p)==ev,'EVIDENCE_CONFLICT')
            else:write_new(p,ev)
            q=seal({**{k:v for k,v in q.items() if k!='root'},'evidence_roots':[ev['root']]})
        return validate('request',q)
    def handle(self,cmd):
        cmd=validate_command(cmd);require(cmd['context_root']==self.context['root'],'CONTEXT_PIN')
        action=cmd['action'];require(not action.startswith('HOST_'),'WRONG_CHANNEL')
        at=integer(self.clock());broker=self._broker(adapters=action in {'RUN','OBSERVE'},at=at)
        before=self.ledger.events();state=broker.inspect(cmd['expected_head']);content=None
        if action in EFFECT_ACTIONS:
            q=query(self.context,seal(cmd['payload']['request']))
            if action=='PREVIEW':broker.preview(q,expected_head=cmd['expected_head'])
            else:
                admitted=broker.admit(q,expected_head=cmd['expected_head'])
                if admitted['status'] in {'ADMITTED','ALREADY_RECORDED'} and action!='ADMIT':
                    op=broker.inspect()['operations'][q['operation_id']]
                    if op['state']=='ADMITTED':
                        dispatched=broker.dispatch(q['operation_id'],expected_head=self.ledger.head)
                        if dispatched.get('data') is not None and q['effect']==READ:content=dispatched['data'].hex()
                    op=broker.inspect()['operations'][q['operation_id']]
                    if action=='RUN' and op['state'] in {'OBSERVED','DECLINED'}:broker.finalize(q['operation_id'],expected_head=self.ledger.head)
        elif action=='FINALIZE':broker.finalize(cmd['payload']['operation_id'],expected_head=cmd['expected_head'])
        elif action=='CANCEL':broker.cancel(cmd['payload']['operation_id'],expected_head=cmd['expected_head'],reason='NATIVE_CLIENT_CANCELLED')
        else:require(action=='INSPECT','ACTION_INVALID')
        response=rederive(self.context,cmd,before,self.ledger.events(),at,self._evidence(),content)
        # Transcript storage is separate from authoritative A custody. Failure here
        # must be reported as uncertain, and the effect must never be blindly retried.
        if action not in {'PREVIEW','INSPECT'}:
            seq=len(list((self.folder/'exchanges').glob('*.json')))+1
            write_new(self.folder/'exchanges'/f'{seq:06d}.json',{'command':cmd,'response':response})
        return response
    def export(self,*,expected_head,acknowledge_plaintext=False):
        require(acknowledge_plaintext is True,'PLAINTEXT_ACK_REQUIRED')
        broker=self._broker(adapters=False);bundle=broker.export(expected_head=expected_head,acknowledge_plaintext=True)
        exchanges=[read_json(p) for p in sorted((self.folder/'exchanges').glob('*.json'))]
        return record('effect-export',context=self.context,bundle=bundle,exchanges=exchanges,evidence=self._evidence(),
            disclosure='SOURCE_PARAMETERS_GRANTS_AND_RESULTS_PLAINTEXT',**BOUNDARY)

def verify_export(value,*,context_root,binding_root,authority_root,head,export_root):
    v=check(value,'effect-export');require(v['root']==hash_value(export_root),'EXPORT_PIN')
    c=context_valid(v['context'],context_root);require(c['binding']['root']==binding_root and c['authority']['root']==authority_root,'EXTERNAL_PINS')
    av=verify_bundle(v['bundle'],expected_binding_root=binding_root,expected_head=head,trusted_authority_roots={authority_root})
    events=v['bundle']['events'];indices={ZERO:0,**{e['root']:i for i,e in enumerate(events,1)}};last=ZERO
    for row in v['exchanges']:
        exact(row,{'command','response'});cmd=validate_command(row['command']);r=check(row['response'],'response')
        require(cmd['expected_head']==last and r['before_head']==last,'EXCHANGE_CONTINUITY')
        require(r['after_head'] in indices,'EXCHANGE_HEAD_UNKNOWN');n=indices[last];m=indices[r['after_head']];require(m>=n,'EXCHANGE_REWIND')
        expected=rederive(c,cmd,events[:n],events[:m],r['at'],v['evidence'],r['content_hex']);require(r==expected,'RESPONSE_NOT_REDERIVED')
        last=r['after_head']
    require(last==head,'EXCHANGE_COVERAGE')
    return record('effect-verification',status='CONSISTENT_WITH_PINNED_A_RECORDS',export_root=v['root'],context_root=context_root,head=head,
        exchanges=len(v['exchanges']),a_replay_root=av['root'],native_execution_independently_verified=False,
        signature_authentication=False,native_ugk_binding='NOT_BOUND',**BOUNDARY)
