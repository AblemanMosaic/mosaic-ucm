"""UGEL Batch D: cooperative native adapters, no new grant mechanism."""
from .protocol import command, control, record
__all__ = ["command", "control", "record"]
