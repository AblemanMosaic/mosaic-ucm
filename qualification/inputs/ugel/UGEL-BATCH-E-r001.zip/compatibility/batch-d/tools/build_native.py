"""Build only with prepared toolchains. No downloads or dependency installation."""
from __future__ import annotations
import argparse,hashlib,json,os,platform,shutil,subprocess,sys
from pathlib import Path
from source_inventory import canonical,seal
ROOT=Path(__file__).resolve().parents[1]
def run(args,cwd=None,timeout=90):
    p=subprocess.run([str(a) for a in args],capture_output=True,cwd=cwd,timeout=timeout,
        env={**os.environ,'CARGO_NET_OFFLINE':'true','CARGO_INCREMENTAL':'0'})
    return {'argv':[str(a) for a in args],'returncode':p.returncode,'stdout':p.stdout.decode(errors='replace'),'stderr':p.stderr.decode(errors='replace')}
def compile_c(out,compiler):
    out.mkdir(parents=True);cc=shutil.which(compiler);ar=shutil.which('ar')
    if not cc or not ar:raise RuntimeError('PREPARED_C_COMPILER_AND_AR_REQUIRED')
    src=ROOT/'native/c';flags=['-std=c99','-O2','-Wall','-Wextra','-Wpedantic','-Werror','-fPIC','-I',src/'include']
    commands=[[cc,*flags,'-c',src/'src/ugel.c','-o',out/'ugel.o'],[ar,'rcs',out/'libugel.a',out/'ugel.o'],
        [cc,'-shared','-o',out/'libugel.so',out/'ugel.o'],[cc,*flags,src/'examples/client.c',out/'ugel.o','-o',out/'ugel-client']]
    logs=[]
    for args in commands:
        result=run(args);logs.append(result)
        if result['returncode']:
            (out/'FAILED-BUILD.json').write_bytes(canonical(result)+b'\n');raise RuntimeError('C_BUILD_FAILED: '+result['stderr'])
    files={p.name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in out.iterdir() if p.is_file()}
    return {'status':'BUILT','compiler_path':cc,'compiler_version':run([cc,'--version'])['stdout'].splitlines()[0],
        'client':str(out/'ugel-client'),'library':str(out/'libugel.so'),'artifacts':files,'commands':logs}
def build(output,*,rust='auto',second_c=True):
    output=Path(output).absolute();output.mkdir(parents=True,exist_ok=False)
    if platform.system()!='Linux':raise RuntimeError('BUILD_PROFILE_LINUX_ONLY')
    c=compile_c(output/'c','gcc' if shutil.which('gcc') else 'cc')
    alternate=compile_c(output/'clang','clang') if second_c and shutil.which('clang') else {'status':'NOT_RUN','reason':'ALTERNATE_C_COMPILER_UNAVAILABLE_OR_DISABLED'}
    cargo=shutil.which('cargo');rustc=shutil.which('rustc')
    r={'status':'NOT_RUN','reason':'RUST_TOOLCHAIN_UNAVAILABLE','required_for_full_batch_d':True,'source_delivered':True,'client':None,'tests_run':0}
    if cargo and rustc:
        manifest=ROOT/'native/rust/Cargo.toml';target=output/'rust-target'
        commands=[run([cargo,'build','--offline','--locked','--manifest-path',manifest,'--target-dir',target]),
                  run([cargo,'test','--offline','--locked','--manifest-path',manifest,'--target-dir',target])]
        if any(x['returncode'] for x in commands):
            (output/'RUST-BUILD-FAILURE.json').write_bytes(canonical(commands)+b'\n');raise RuntimeError('RUST_BUILD_OR_TEST_FAILED')
        binary=target/'debug/ugel-rust-client'
        import re
        ids=sorted(re.findall(r'^test (tests::[A-Za-z0-9_]+) \.\.\. ok$',commands[-1]['stdout'],re.M))
        expected=sorted('tests::'+name for name in re.findall(r'#\[test\]\s*fn\s+(\w+)',(ROOT/'native/rust/src/lib.rs').read_text()))
        if ids!=expected:raise RuntimeError('RUST_TEST_INVENTORY_MISMATCH')
        r={'status':'BUILT_AND_TESTED','compiler_version':run([rustc,'--version'])['stdout'].strip(),
            'cargo_version':run([cargo,'--version'])['stdout'].strip(),'client':str(binary),'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),
            'tests_run':len(ids),'test_ids':ids,'commands':commands,'required_for_full_batch_d':True}
    result=seal({'schema':'mosaic.ugel.batch-d.native-build.v1','c':c,'alternate_c':alternate,'rust':r,
        'network_access':'NONE_BY_BUILD_TOOL','dependency_installation':'NONE','host':platform.platform(),
        'status':'BUILD_COMPLETE' if r['status']=='BUILT_AND_TESTED' else 'C_BUILT_RUST_NOT_RUN'})
    (output/'BUILD.json').write_bytes(canonical(result)+b'\n')
    if rust=='required' and r['status']=='NOT_RUN':raise RuntimeError('REQUIRED_RUST_LANE_NOT_RUN: '+str(output/'BUILD.json'))
    return result
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--rust',choices=['auto','required'],default='required');a=p.parse_args()
    try:r=build(a.output,rust=a.rust);print(json.dumps({'status':r['status'],'root':r['root'],'c':r['c']['client'],'rust':r['rust']['status']},indent=2))
    except Exception as e:print(str(e),file=sys.stderr);raise SystemExit(2)
