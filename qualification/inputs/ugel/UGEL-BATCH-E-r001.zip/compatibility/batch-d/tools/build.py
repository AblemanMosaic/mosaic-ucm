"""Deterministic frozen-input ZIP builder. No execution or dependency installation."""
from pathlib import Path
import argparse,hashlib,json,zipfile
from source_inventory import inventory,canonical,seal
ROOT=Path(__file__).resolve().parents[1]
def build(destination):
    source=inventory(ROOT)
    expected=json.loads((ROOT/'release/SOURCE-MANIFEST.json').read_bytes())
    if source!=expected:raise ValueError('FROZEN_SOURCE_CHANGED')
    checks=json.loads((ROOT/'evidence/REFERENCE-CHECKS.json').read_bytes())
    if checks['source_root']!=source['root'] or checks['status']!='PASS_EXECUTED_LANES':raise ValueError('CHECK_EVIDENCE_SUBJECT')
    files={}
    for p in sorted(ROOT.rglob('*')):
        rel=p.relative_to(ROOT)
        if any(x in {'.git','__pycache__'} for x in rel.parts) or rel.as_posix()=='PACKAGE-MANIFEST.json':continue
        if p.is_symlink():raise ValueError('PACKAGE_SYMLINK')
        if p.is_file():
            if p.suffix in {'.pyc','.pyo','.key'}:raise ValueError('UNACCEPTED_PAYLOAD_FILE')
            files[rel.as_posix()]=p.read_bytes()
    rows=[{'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in sorted(files.items())]
    manifest=seal({'schema':'mosaic.ugel.batch-d.package-manifest.v1','source_root':source['root'],
        'reference_check_root':checks['root'],'batch_disposition':checks['batch_disposition'],
        'files':rows,'payload_count':len(rows),'logical_bytes':sum(r['bytes'] for r in rows),
        'standing':'INFORMATION_ONLY','authority_effect':'NONE','real_a5':False,'g0':'CLOSED'})
    files['PACKAGE-MANIFEST.json']=canonical(manifest)+b'\n'
    destination=Path(destination);destination.parent.mkdir(parents=True,exist_ok=True)
    if destination.exists():raise ValueError('NEW_ARCHIVE_PATH_REQUIRED')
    with zipfile.ZipFile(destination,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for n,b in sorted(files.items()):
            info=zipfile.ZipInfo(n,date_time=(1980,1,1,0,0,0));info.create_system=3;info.external_attr=0o100644<<16;info.compress_type=zipfile.ZIP_DEFLATED
            z.writestr(info,b,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    return {'archive':destination.name,'sha256':hashlib.sha256(destination.read_bytes()).hexdigest(),'bytes':destination.stat().st_size,
        'file_count':len(files),'source_root':source['root'],'manifest_root':manifest['root'],'reference_check_root':checks['root'],'batch_disposition':checks['batch_disposition']}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();print(json.dumps(build(a.output),indent=2))
