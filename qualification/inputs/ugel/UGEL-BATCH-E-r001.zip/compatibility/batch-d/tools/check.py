"""Ordinary checks, explicit missing-Rust lane, inherited regression. No attacks."""
from __future__ import annotations
import argparse,ast,hashlib,io,json,os,platform,shutil,subprocess,sys,unittest
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'compatibility/batch-c/src'),str(ROOT/'compatibility/batch-c/compatibility/batch-b/src'),str(ROOT)]
from source_inventory import inventory,canonical,digest,seal
from build_native import build
class Recording(unittest.TextTestResult):
    def __init__(self,*a,**kw):super().__init__(*a,**kw);self.rows=[]
    def addSuccess(self,t):super().addSuccess(t);self.rows.append({'id':t.id(),'status':'PASS'})
    def addFailure(self,t,e):super().addFailure(t,e);self.rows.append({'id':t.id(),'status':'FAIL'})
    def addError(self,t,e):super().addError(t,e);self.rows.append({'id':t.id(),'status':'ERROR'})
    def addSkip(self,t,r):super().addSkip(t,r);self.rows.append({'id':t.id(),'status':'SKIP'})
def test_ids():
    ids=[]
    for p in sorted((ROOT/'tests').glob('test_*.py')):
        for c in ast.parse(p.read_text()).body:
            if isinstance(c,ast.ClassDef):
                ids.extend('tests.'+p.stem+'.'+c.name+'.'+f.name for f in c.body if isinstance(f,ast.FunctionDef) and f.name.startswith('test_'))
    return sorted(ids)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);ap.add_argument('--rust',choices=['auto','required'],default='required');a=ap.parse_args();a.output.mkdir(parents=True,exist_ok=False)
    before=inventory(ROOT);ids=test_ids();contract=json.loads((ROOT/'spec/CHECK-CONTRACT.json').read_bytes())
    if contract['root']!=digest({k:v for k,v in contract.items() if k!='root'}) or contract['test_ids']!=ids:raise SystemExit('CHECK_CONTRACT_MISMATCH')
    native=build(a.output/'native',rust='auto');os.environ['UGEL_D_NATIVE_BUILD']=str(a.output/'native/BUILD.json')
    stream=io.StringIO();suite=unittest.defaultTestLoader.discover(str(ROOT/'tests'),top_level_dir=str(ROOT))
    result=unittest.TextTestRunner(stream=stream,verbosity=2,resultclass=Recording).run(suite)
    inherited=a.output/'inherited-c'
    p=subprocess.run([sys.executable,'-B',str(ROOT/'compatibility/batch-c/tools/check.py'),'--output',str(inherited)],capture_output=True,timeout=180)
    (a.output/'INHERITED-RUN.log').write_bytes(p.stdout+b'\nSTDERR\n'+p.stderr)
    c=json.loads((inherited/'REFERENCE-CHECKS.json').read_bytes()) if (inherited/'REFERENCE-CHECKS.json').exists() else None
    after=inventory(ROOT);rows=sorted(result.rows,key=lambda r:r['id'])
    passed=result.wasSuccessful() and not result.skipped and not result.expectedFailures and not result.unexpectedSuccesses and [r['id'] for r in rows]==ids and before==after and p.returncode==0 and c and c['status']=='PASS' and c['total_distinct_test_count']==118
    rust_ran=native['rust']['status']=='BUILT_AND_TESTED'
    disposition='VALIDATED_EXECUTED_LANES_RUST_NOT_RUN' if passed and not rust_ran else 'REFERENCE_VALIDATION_PASS' if passed else 'REPAIR_REQUIRED'
    rec=seal({'schema':'mosaic.ugel.batch-d.reference-checks.v1','status':'PASS_EXECUTED_LANES' if passed else 'FAIL','batch_disposition':disposition,
        'source_root':before['root'],'source_stable':before==after,'contract_root':contract['root'],'test_ids':ids,
        'test_set_root':hashlib.sha256(canonical(ids)).hexdigest(),'rows':rows,'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
        'skips':len(result.skipped),'expected_failures':len(result.expectedFailures),'unexpected_successes':len(result.unexpectedSuccesses),
        'inherited_c_result_root':c['root'] if c else None,'inherited_c_source_root':c['source_root'] if c else None,'inherited_test_count':118 if c and c['status']=='PASS' else None,
        'total_distinct_python_test_count':len(ids)+118,'native_rust_test_count':native['rust']['tests_run'],'rust_lane':'PASS' if rust_ran else 'NOT_RUN_TOOLCHAIN_UNAVAILABLE',
        'c_native_lane':'PASS' if passed else 'NOT_ESTABLISHED','independent_verification':'NOT_PERFORMED','prior_result_cache_reads':0,'cache_policy':'DISABLED',
        'adversarial_testing':'NOT_PERFORMED','fault_injection':'NOT_PERFORMED','native_containment':'NOT_ESTABLISHED',
        'standing':'INFORMATION_ONLY','authority_effect':'NONE','real_a5':False,'g0':'CLOSED'})
    for n,x in [('REFERENCE-CHECKS.json',rec),('SOURCE-MANIFEST.json',before)]: (a.output/n).write_bytes(canonical(x)+b'\n')
    (a.output/'REFERENCE-CHECKS.log').write_text(stream.getvalue());(a.output/'HOST.json').write_bytes(canonical({'python':sys.version,'platform':platform.platform(),
        'machine':platform.machine(),'gcc':native['c']['compiler_version'],'clang':native['alternate_c'].get('compiler_version'),
        'rust':native['rust']['status'],'other_hosts':'NOT_RUN','network_dependency_fetch':'NOT_PERFORMED_BY_BUILD_OR_TEST_TOOLS'})+b'\n')
    print(json.dumps({'status':rec['status'],'disposition':disposition,'new_tests':result.testsRun,'inherited':rec['inherited_test_count'],'root':rec['root']},indent=2))
    if not passed:print(stream.getvalue());return 1
    return 0 if rust_ran or a.rust=='auto' else 3
if __name__=='__main__':raise SystemExit(main())
