# UGEL Batch D r001 — C ABI and Rust request adapters

**INFORMATION_ONLY; constitutional authority effect NONE; real A5 false; G0 CLOSED.**

This additive batch connects conventional native code to the unchanged Batch A
broker and, separately, the signed Batch C Python memory-check service.

**C/Python validation is executed. Rust implementation is delivered but Rust
compilation, Rust tests, and Rust runtime conformance are NOT_RUN on the build
host: neither rustc nor Cargo was available, and toolchain retrieval failed.
Do not describe this delivery as a fully qualified three-language system.**

## What is delivered

- C99 ABI: checked context construction, capability-handle narrowing, four typed
  effect constructors, explicit control commands, owned output buffers, and a
  single-exchange pipe interface. Static/shared library and example client build.
- Independent Rust 2021 source: private-field typed contexts and capabilities,
  four typed effect functions, explicit control enum, canonical JSON encoding,
  and an `UnverifiedResponse` type. No registry crates, unsafe Rust, or FFI needed.
- A Python host adapter that seals the exact unchanged Batch A Effect IR, checks
  current local grant/evidence/budget/head, and invokes the existing broker.
- A separate adapter to an already accepted Batch C HostSession. Issuer and
  observer private keys never travel through the native command channel.
- Finite conformance workflows comparing full request bytes, decisions, receipts
  and event roots across Python and compiled C. GCC and Clang are distinct builds,
  not distinct programming languages or independent implementations of the C SDK.
- A filesystem demonstration and fresh-process finalization without redispatch.
- A signed six-test Batch C check requested from a C process.
- Source-bound checks, retained predecessors, and a passive distribution verifier.

## Trust and containment

Native clients are **trusted cooperative processes**. They retain their host
user's ambient access. Their local SDK handles are programming constraints,
not authenticated grants or a sandbox. The host enforces the supported broker
path; this delivery does not prevent a native process bypassing that path.

Batch C's unchanged seccomp profile applies only to its Python child. It is NOT
applied to the C client, Rust client, compiler, parent broker, or file preparation.
No new filesystem/process/network adapter or UGK primitive is introduced.

Batch A file/simulation receipts remain unsigned host-pinned reference records.
They do not acquire Batch C signatures by passing through this adapter. The
separate Python check retains the actual Batch C signed admission, observation,
recovery permit, and receipt verification.

## Prepared host and quick start

The exercised build host is Linux x86_64 with CPython 3.13.5, GCC and Clang.
C/Python development uses only the Python standard library, a prepared C99
compiler and `ar`. The inherited signed-host lane additionally needs prepared
cryptography and libseccomp as specified by Batch C. Nothing is auto-installed.
Windows, macOS, other CPU architectures and Python 3.12 were NOT_RUN here.

```console
python -B run.py orient
python -B tools/build_native.py --output ../ugel-native-build --rust auto
python -B run.py demo --build ../ugel-native-build/BUILD.json --output ../ugel-native-demo
python -B tools/check.py --output ../ugel-native-checks --rust auto
```

All output directories must be new. The `auto` option explicitly allows an
unperformed Rust lane to be recorded; it does not turn that lane into PASS.
Both build/check tools default to `--rust required`. On a host with Rust prepared:

```console
python -B tools/build_native.py --output ../ugel-all-native --rust required
python -B tools/check.py --output ../ugel-all-checks --rust required
cargo test --offline --locked --manifest-path native/rust/Cargo.toml --target-dir ../ugel-rust-target
```

The Rust crate declares `rust-version = "1.70"` as a source intention, not an
exercised minimum-version guarantee. Build/check tools never fetch toolchains or
crate dependencies. Required missing Rust produces a nonzero exit and a clear
record rather than a skipped test silently counted as a successful batch.

## Existing effects, exact meanings

| Effect | Meaning |
|---|---|
| `sim.add` | Add two integers in [-1,000,000, 1,000,000]. |
| `sim.echo` | Deterministic UTF-8 text echo. |
| `fs.create` | Exclusive creation/readback of a portable leaf file. No overwrite. |
| `fs.read` | Bounded read of a leaf file against the expected content digest. |

The native adapter deliberately supports at most one text-check evidence root
per request and 65,536 UTF-8 parameter/read bytes. The underlying A contracts
remain unchanged and support their own broader documented bounds.

Actions are PREVIEW, ADMIT, OBSERVE, RUN, FINALIZE, CANCEL, and INSPECT on the A
channel; HOST_EXECUTE, HOST_FINALIZE, and HOST_INSPECT on the C channel. Host
finalization accepts only a reference to a recovery permit already held by the
trusted host; the client cannot issue one.

## C usage

`native/c/include/ugel.h` is the versioned ABI. Initialize context from an accepted
host binding and current external head; create/narrow a local handle; construct a
request; call `ugel_exchange` exactly once. Free each allocated buffer with
`ugel_buffer_free`. An exchange returns unverified response bytes. Inspect the
actual domain result and independently verify the exported evidence.

`native/c/examples/client.c` is a complete driver. The Python demonstration runs
it as a separate process, compares its proposed command with the host-accepted
command before effects, and checks byte-exact response delivery. Its exit 0 means
transport completion, not successful execution or authority to release.

## Rust usage

The independent `ugel-native` crate provides `Context`, `Capability`, `Action`,
`Control`, typed constructors, and `exchange`. `Capability::narrow` cannot widen
its parent hint. The authoritative scope still comes from the host grant.
`native/rust/src/main.rs` is the matching native driver. Its source and eight
ordinary unit tests are present; no Rust runtime result is claimed in this freeze.

## Evidence and verification

The demonstrations use an actual bounded logical task, but their repair proposal
is still the prewritten invoice example inherited from Batch B. No model provider
is contacted. Simulation parity uses a fixed logical clock and the same explicit
logical subject and grant in independent ledgers. It does not prove compiler,
binary, or arbitrary program equivalence.

```console
python -B VERIFY.py ../UGEL-BATCH-D-r001.zip --expected-sha256 EXTERNAL_ARCHIVE_PIN
python -B run.py verify-bundle ../ugel-native-demo/filesystem/BUNDLE.json --pins ../ugel-native-demo/filesystem/PINS.json
```

Pins retained by the same untrusted bundle are not an independent trust basis.
Exports include complete plaintext parameters, local grants, read results,
source/code in the signed-host example, and host paths. Export requires explicit
acknowledgment. Private signing keys and compiler binaries are not distributed.

See `docs/ARCHITECTURE.md`, `docs/C-ABI.md`, `docs/RECOVERY.md`,
`docs/ASSURANCE.md`, and `docs/UCM-UGK-INTEGRATION.md` for exact boundaries.
