# UGEL Batch D r001 — build and validation report

## Disposition

**VALIDATED_EXECUTED_LANES_RUST_NOT_RUN.** The C ABI, host bridge, C/Python conformance
workflows and inherited suites ran successfully. The independent safe Rust source,
Cargo lockfile and eight native unit tests are delivered, but Rust compilation,
unit tests and runtime conformance are **NOT_RUN**: this host has no Rust toolchain.
Attempts to obtain a prepared toolchain were unsuccessful. No dependency was installed.
Missing Rust is a required unperformed Batch D lane, not a passing test or waiver.

Standing: INFORMATION_ONLY; constitutional authority effect NONE; real A5 false;
G0 CLOSED. Actual local compilation, file, custody, and subprocess effects are distinct.
Native UGK/AOK and the private agent harness remain NOT_BOUND.

## Frozen source

- Source files: **221**; logical bytes: **2829210**.
- Source root: `de39672ef6d9bfb0205418bbc81bec140392e77cf0cd5138de28c9d3537794bd`.
- Final reference-check root: `8977c0c5c41d21d3010c8e36679e2941d076406b2e77a94eda45271e4d8cde6d`.
- All 180 Batch C payload files and the original Batch C archive remain byte-identical.
- The original Batch A, B, and C uploaded archive hashes remain unchanged.
- Native build products are not shipped; their measured hashes and build commands are retained.

## Delivered implementation

A C99 library exposes ABI version 1, typed requests and explicit buffer ownership,
capability-handle attenuation, canonical UTF-8 to JSON lowering, and single-exchange
stdio transport. It builds as a static library, shared library, and example client.
An independent Rust 2021 std-only crate mirrors the typed API and command protocol;
its claimed minimum Rust version is not qualified on this host.

The host bridge seals exact Batch A request records and invokes the unchanged broker.
It verifies the context, current head, host-accepted request, grants, budgets and
required evidence. Native handles are not signed credentials. Native output bytes
remain unverified until the host/verifier checks them. No shell command, network
listener, or key custody is exposed through the client protocol.

A separate bridge calls an already accepted Batch C HostSession. A C request triggers
only the existing `python.memory-unittest` operation and names an independently
host-held recovery permit for finalization. The local issuer/observer key pins and
Batch C observation semantics remain unchanged.

## Executed checks

| Lane | Final source | Clean source extraction |
|---|---:|---:|
| New Batch D ordinary unittest identities | 33 PASS | 33 PASS |
| Unchanged inherited C/B/A identities | 118 PASS | 118 PASS |
| Total distinct Python unittest identities | 151 PASS | 151 PASS |
| Failures/errors/skips/expected failures/unexpected successes | 0 | 0 |
| Source changed during lane | No | No |
| Rust native compilation/tests/conformance | NOT_RUN | NOT_RUN |

The two reference-check JSON files are byte-identical. Repeated execution is not
independent review and is not 302 distinct tests. Additional explicit demonstration
observations are not added to this distinct-test count.

GCC 14.2.0 and Clang 17.0.0 compiled the C source with C99, optimization and
`-Wall -Wextra -Wpedantic -Werror`. Compilation produced no diagnostics in the final
runs. Native artifact maps reproduced within each compiler across clean extraction:
GCC `True`, Clang `True`. This does not claim
cross-compiler executable equality.

Actual host: Linux x86_64, CPython 3.13.5. Detailed versions are in HOST.json and
NATIVE-BUILD.json. Windows, Python 3.12, other architectures, and Rust are not qualified.

## Ordinary demonstrations

1. Python, GCC-built C and Clang-built C emit identical requests for the finite shared
   simulation workload. Decision, receipt, journal-head and export roots agree.
   An ordinary missing-evidence preview is `NEEDS_EVIDENCE` in each client path.
2. The C client creates and reads a file through the unchanged file broker, finalizes
   its persisted observation in a fresh Python process without redispatch, and durably
   cancels another operation before dispatch. The recorded history has ten A events.
3. A C command enters the existing Batch C signed host service. The accepted repaired
   invoice candidate passes six exact tests in the restricted Python child. The parent
   observes Seccomp=2, NoNewPrivs=1, zero effective/permitted/inheritable capabilities,
   uid/gid 65534 and one thread. A separately signed recovery permit finalizes it.
4. A fresh process verifies the exported signed bundle and derives the receipt from
   records. It does not replay its effects or independently prove empirical truth.

These are finite conformance observations, not a proof of compiler correctness or
universal cross-language equivalence. The normal task proposal is prewritten material,
not a claim of autonomous model-generated coding.

## Enforcement and trust boundaries

The C/Rust client process is **cooperative and unconfined**. It can use ambient host
APIs outside this SDK. Batch C's restriction profile applies only to its Python child,
not to native client binaries. No native sandbox or native test runner is introduced.
All broker effects still use the same host authority and resource boundaries.

Batch A records remain unsigned local reference records; using a C adapter does not
upgrade them into signed Batch C receipts. Batch C signatures remain locally pinned
Ed25519 evidence, not a legal identity, independent timestamp, hardware attestation,
external witness, native UGK warrant, or operational authority promotion.

Record finalization is resumable. Unobserved dispatch and auxiliary transcript-write
uncertainty do not justify retrying an effect. The auxiliary D transcript and A/C
custody are not one atomic transaction. Transport interruption never proves absence
of effects. Exports are plaintext; no private signing key is included.

## Review and unperformed work

No adversarial testing, malicious payloads, denied-syscall probes, deliberate process
kills, power-loss tests, external application contact, or network probing occurred.
Ordinary bounded tests and separately recorded historical evidence are not relabeled
as independent assurance. Earlier-source development results remain under development/
and have no claim on the final source.

Required next legs: compile and run the Rust lane with prepared Rust/Cargo, compare
its actual emitted requests and receipts with the same reference, independently review
C memory/ABI and transport semantics, and qualify any desired host/ABI beyond this one.
No instruction in this package authorizes attacks, deployment, publication or G0 opening.

## Reproduce

Partial C/Python lane on a prepared host:

```console
python -B tools/check.py --output ../ugel-d-checks --rust auto
```

Full intended adapter lane when Rust is prepared:

```console
python -B tools/check.py --output ../ugel-d-full-checks --rust required
```

The latter refuses to call Batch D complete if the Rust toolchain is absent. Cargo
build/test uses `--offline --locked`; this crate has no external registry dependencies.
Use fresh output directories. Build and package scripts never install dependencies.
