# Notice

Experimental additive UGEL reference, delivered for local development and review.
The 180 Batch C payload members and original Batch C archive are retained exactly.
No original UCM/UGK finding or independent-review disposition is closed by this
build. New native source is a reference adapter, not a native UGK ABI.
