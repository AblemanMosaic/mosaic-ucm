# Primary technical references

Consulted for implementation vocabulary, not evidence of this implementation.

- Rustonomicon, Foreign Function Interface: https://doc.rust-lang.org/nomicon/ffi.html
  C ABI pointer/layout obligations and safe wrapper boundaries. The Rust adapter
  here is independent safe source, not FFI over the C library.
- Cargo Book, cargo build: https://doc.rust-lang.org/cargo/commands/cargo-build.html
  `--offline` and `--locked` behavior. Build tooling always uses both.
- Rust Reference, ABI: https://doc.rust-lang.org/reference/abi.html
  Platform ABI boundaries. No universal native ABI equivalence is inferred.

Toolchain availability is measured locally. Documentation availability does not
establish that rustc was installed or that Rust source was compiled.
