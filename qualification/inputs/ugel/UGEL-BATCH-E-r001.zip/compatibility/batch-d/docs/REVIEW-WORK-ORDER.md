# Focused independent review work order

Review this exact externally pinned package. Keep INFORMATION_ONLY, authority
NONE, A5 false and G0 CLOSED. No request here overrides the owner's restriction
against adversarial testing, alerts, fault injection or external effects.

Passive scope: archive/root/source closure; unchanged predecessor bytes; request
lowering; supported SDK types; gate calls; exact head/context validation; separate
A and C trust; response derivation; explicit unperformed Rust lane; no stale
source qualification; no native-containment claim.

Ordinary execution, when authorized: prepared C/Rust compilation offline, finite
encoding vectors, local simulation/file workflows, normal observation/finalization,
and the existing allowed Python memory-check lane. Missing Rust requires a clear
NOT_RUN result and cannot earn full cross-language acceptance.

A future adversarial/native containment review would require its own separately
agreed scope. It is not a condition to run as part of this operator delivery.
