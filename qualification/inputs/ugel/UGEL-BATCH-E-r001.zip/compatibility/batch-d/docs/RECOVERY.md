# Recovery and transport uncertainty

| State | Supported continuation |
|---|---|
| No A admission | Submit an accepted request under the current host policy. |
| A ADMITTED | Dispatch under a new current-authority/evidence check, or cancel. |
| A OBSERVED / DECLINED | Finalize the existing record without adapters. |
| A terminal receipt | Return historical receipt; no redispatch. |
| A STARTED / UNCERTAIN without settled observation | Hold; explicit A reconciliation remains a separate host procedure. |
| C OBSERVED | Finalize using a host-held, separately signed exact recovery permit. |
| C ADMITTED / DISPATCH_INTENT without observation | Retain uncertainty; no automatic native retry. |
| Native response lost | Inspect authoritative host custody; delivery loss is not nonexecution. |

The demonstrated fresh-process finalization closes and reopens a normal supported
phase. No process was forcibly killed to claim a crash guarantee.

The D transcript is auxiliary, separately persisted after A custody. If transcript
storage fails after an effect, preserve the A ledger and report uncertainty. This
batch does not claim atomicity between A SQLite, D transcript files, C issuer state,
C signed history, child execution, pipe delivery or caller-held pins. A missing D
transcript cannot be silently invented to produce a complete D export. A's own
record-only export/replay remains available under its original contract.

An open/inspect command never initializes absent custody. Effect-channel PREVIEW
and INSPECT do not append transcript files. Host context inspection uses the
existing C read path. Initialization, evidence preparation, execution, cancellation,
finalization, transcript capture and export-file writing are explicit local effects.

There is no native generic process recovery, concurrency ownership guarantee,
malicious filesystem-writer protection, or power-loss durability claim in Batch D.
