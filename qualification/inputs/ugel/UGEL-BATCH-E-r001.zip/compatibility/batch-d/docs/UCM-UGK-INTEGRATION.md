# Integration boundary

Batch D owns only provisional `mosaic.ugel.batch-d.*.v1` envelope records and a
cooperative native ABI. Batch A's four effect IDs and meanings remain unchanged.
Batch C's signed host operation and Linux Python-child profile remain unchanged.
All 180 inherited Batch C payload files and its original archive are retained.

Real native UGK operation contracts, CSIL dictionary bindings, GSOL semantics,
Receipt Core equivalence, institutional grants, A5 and G0 are not introduced by
calling the library from C or Rust. Existing UCM findings remain their own review
subjects. A new adapter's hash is not a new source of authority.

A real AI harness should retain task acceptance and external continuity pins,
select the effect contract and resource bindings, and keep signing/authority
services outside generated code. It can use the C ABI, Rust SDK or Python API
without widening the selected contract. Accepted response evidence is then
reconstructed against the same task and actual current head.

Batch E may add a restricted WASI/component host, independent verifiers, or
optional witness interfaces. It should preserve the declared native-containment
and Rust-validation gaps rather than inheriting a broader PASS from this delivery.
