# C ABI v1 and Rust types

The public header is `native/c/include/ugel.h`. `ugel_abi_version()` returns 1;
`ugel_context_size()` lets a foreign host check its struct layout. The tested ABI
is Linux x86_64 with the recorded compilers. Cross-platform ABI equivalence is not
established. `ugel_context` uses fixed-width integers and fixed root strings;
lengths are `size_t` on the consuming ABI.

Constructors copy context/handle data. All call arguments otherwise remain borrowed
for the duration of the call. Text is UTF-8 plus an explicit byte length; embedded
NUL and non-BMP Unicode are supported by the library. The argv example cannot
carry NUL because it uses process arguments; the direct C ABI test covers it.

Every output `ugel_buffer` must initially be zeroed. A successful construction
allocates one buffer. `ugel_buffer_free` releases and clears it. Request memory
is never reused as caller-owned input. Partial construction failure frees the
builder allocation. Callers remain responsible for valid pointer lifetimes; this
is ordinary C, not a memory-safe or hostile-pointer API.

`ugel_exchange` writes one command and reads one bounded response. It does not
parse, accept, authenticate or automatically retry that response. An I/O failure
can occur after an effect; its code is `UGEL_IO_UNCERTAIN`. Do not infer absence
or start a replacement operation from that error.

The independent Rust implementation uses private-field types, `&str`, owned
byte vectors, and an explicit `UnverifiedResponse`. It forbids unsafe code. It is
not a wrapper around the C serializer. Both adapters use the same operation and
resource meanings, but only compiled/executed lanes earn conformance evidence.

Text encoding preserves scalar values without normalization. C and Rust lower
Unicode to Batch A's ensure_ascii JSON: control escapes, lowercase hexadecimal
BMP escapes, and surrogate-pair escapes for non-BMP values. Object key order and
integer formatting are fixed. The host rejects noncanonical wire bytes before
admission rather than silently rewriting a different request.

Local capability attenuation can remove effect bits and reduce the byte limit.
It cannot change the resource. These are SDK usage restrictions. Forging an SDK
struct cannot widen the authoritative host contract or grant, but no native
sandbox is claimed.
