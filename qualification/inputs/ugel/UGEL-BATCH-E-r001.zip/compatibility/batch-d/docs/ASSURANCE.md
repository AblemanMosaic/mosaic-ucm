# Acceptance and unperformed legs

## Delivered implementation

C request ABI, local client transport, independent Rust request source, unchanged
A mediation, shared A response interpretation, explicit C host action binding,
portable A-history verification and build/package custody.

## Executed scope

Ordinary successful and documented pending workflows only. C compiled with GCC
and Clang; local generated programs ran without hostile payloads. The Python child
was the existing trusted invoice fixture under Batch C's existing policy. Ordinary
inherited tests are rerun without modification. No attacks, fuzzing, denied-syscall
probes, forced crashes, power-loss experiments or network effects are performed.

## Missing Rust toolchain

No Rust compiler or Cargo was prepared. Direct retrieval of an official toolchain
failed with DNS/retrieval errors. No system dependency was installed. The crate,
matching driver, lockfile and eight ordinary tests are delivered, but compilation,
unit-test execution, cross-language runtime equivalence and release performance
are NOT_RUN. Source inspection is not a substitute for those legs.

The reference-check record can say PASS_EXECUTED_LANES while the whole-batch
disposition remains VALIDATED_EXECUTED_LANES_RUST_NOT_RUN. Default tooling requires
Rust; `--rust auto` explicitly permits a partial report. The passive verifier must
retain that distinction. No skip count hides the unperformed required lane.

## Additional limits

- SDK and native-process containment: NOT_ESTABLISHED.
- Native UGK/AOK ABI/dictionary/authority binding: NOT_BOUND.
- Effect/decision/receipt meanings: only the unchanged supported A and C contracts.
- The task subject is a logical accepted task; compiler/program equivalence is not proved.
- C/Python share the same gate/reducer; this is adapter conformance, not independent checker diversity.
- A signatures remain absent; C keys are local owner-pinned, not legal or hardware identity.
- Native wire responses are unverified until the separate replay checks succeed.
- No implicit authorization for deployment, publication, external applications or networking.
- No Windows/macOS/other-architecture or Python 3.12 result is established here.
- No independent review or production assurance is claimed.
