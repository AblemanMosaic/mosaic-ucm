# Architecture and authority boundaries

## Canonical ownership

Batch A remains the sole interpreter of its four effect contracts. Native C and
Rust constructors encode the same rootless request body. The trusted host applies
Batch A's existing canonical seal and exact validator; the result is the same
request root as the Python producer. D owns only its command/channel/transport
and verification-envelope schemas. No native client chooses a new effect meaning.

`EffectSession` receives a host-accepted logical subject, constructs a host-pinned
A context, and persists it before use. Context roots and current heads are checked
at every command. Requests cannot supply replacement grants, bindings, directories,
checker code, or signing keys. Local C/Rust handle masks are additional cooperative
constraints, never the authority source. The broker remains authoritative even if
an SDK is not used.

The local A authority record is frozen for the reference session and checked
against local time at admission/dispatch. This is not an online revocation source,
an authenticated identity service, or permission to keep an old snapshot current.
A production host must bind approved live authority services separately.

## Transport

One canonical ASCII JSON command line travels from a trusted native process to
its trusted parent. The parent compares it to the exact command selected by that
host before handling it. It returns a canonical response; the example client
acknowledges the exact response bytes. This is delivery evidence, not a new
signature or independent observation. There is no listener, network port, service
installation, or request-controlled executable path.

Only the parent holds actual broker and host-service objects. The native process
is NOT isolated from ambient host access; same-user access is not prevented by
withholding a path or key from argv. Host secrets are not deliberately transmitted,
which is a data-flow fact, not a malicious-native containment claim.

## Semantic comparison

The simulation control creates independent ledgers with identical logical task,
contract, grant, resource identity, clock, and operation sequence. Python, GCC C,
and Clang C produce byte-identical requests, receipts, and event roots for those
ordinary controls. A Rust lane participates when a compiler is prepared. A missing
Rust toolchain remains a required unperformed leg.

Physical file contexts bind actual directory instances. Their receipts are
verified against their own contexts; distinct directories are not normalized
away to manufacture identical receipt hashes.

## Existing signed host service

`HostBridge` accepts only an already configured Batch C HostSession and its
expected context root. The native HOST_EXECUTE action invokes its existing
one-attempt execution path. HOST_FINALIZE names a permit in a host-held map;
Batch C validates its signature, scope, time and head before continuation.

The C process is an unconfined client. The Python candidate is the separate child
under the unchanged Linux seccomp memory-only profile. Native code is never
relabeled as having run under that Python profile. Signed host verification uses
the unchanged C replay implementation, with separately retained public key pins.

## Dependency tiers

Orientation, protocol encoding, the A bridge and passive package verification use
stdlib Python. The signed host demonstration imports optional crypto/host modules
only on that path. Rust has no registry dependencies. Its build is always offline.
Compilers, standard libraries and OS facilities remain prepared host dependencies,
not bundled authority or a reproducible compiler closure.
