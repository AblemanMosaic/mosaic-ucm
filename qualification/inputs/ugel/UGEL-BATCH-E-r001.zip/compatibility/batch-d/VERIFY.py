#!/usr/bin/env python3
"""Passive distribution verifier. Standard library only; no candidate imports."""
from __future__ import annotations
import argparse,ast,hashlib,io,json,re,sys,zipfile
from pathlib import Path,PurePosixPath
DOMAIN=b'MOSAIC-UGEL-D1'+bytes([0])
C_DOMAIN=b'MOSAIC-UGEL-C1'+bytes([0])
C_PIN='204012120178a871a32dcf2939e2338fb8946a618c4f9f248bd7a5afc8b04ef8'
def need(ok,code):
    if not ok:raise ValueError(code)
def canonical(x):return json.dumps(x,ensure_ascii=True,sort_keys=True,separators=(',',':'),allow_nan=False).encode('ascii')
def sha(b):return hashlib.sha256(b).hexdigest()
def digest(x,domain=DOMAIN):return sha(domain+canonical(x))
def pairs(items):
    d={}
    for k,v in items:need(k not in d,'DUPLICATE_JSON_KEY');d[k]=v
    return d
def obj(b):return json.loads(b,object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError('JSON_CONSTANT')))
def record(x,schema,domain=DOMAIN):
    need(type(x) is dict and x.get('schema')==schema,'SCHEMA');need(x.get('root')==digest({k:v for k,v in x.items() if k!='root'},domain),'ROOT');return x
def read_zip(data):
    need(len(data)<=100_000_000,'ARCHIVE_SIZE_BOUND')
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        names=z.namelist();need(names==sorted(set(names)),'ARCHIVE_ORDER_OR_DUPLICATE')
        need(sum(i.file_size for i in z.infolist())<=150_000_000,'EXPANDED_BOUND')
        for i in z.infolist():
            p=PurePosixPath(i.filename);need(not p.is_absolute() and '..' not in p.parts and '\\' not in i.filename,'MEMBER_PATH')
            need(not i.is_dir() and i.date_time==(1980,1,1,0,0,0) and i.compress_type==zipfile.ZIP_DEFLATED and i.create_system==3 and i.external_attr==0o100644<<16,'ZIP_METADATA')
        return {n:z.read(n) for n in names}
def source_rows(payload):
    rows=[]
    for n,b in sorted(payload.items()):
        p=PurePosixPath(n)
        if p.parts[0] in {'evidence','release'} or n=='PACKAGE-MANIFEST.json':continue
        need('__pycache__' not in p.parts and p.suffix not in {'.pyc','.pyo','.key'},'SOURCE_EXTRA')
        rows.append({'path':n,'bytes':len(b),'sha256':sha(b)})
    return rows
def tests(payload):
    names=[]
    for path,b in sorted(payload.items()):
        p=PurePosixPath(path)
        if p.parent.as_posix()!='tests' or not p.name.startswith('test_') or p.suffix!='.py':continue
        for c in ast.parse(b.decode('utf-8')).body:
            if isinstance(c,ast.ClassDef):names += ['tests.'+p.stem+'.'+c.name+'.'+f.name for f in c.body if isinstance(f,ast.FunctionDef) and f.name.startswith('test_')]
    return sorted(names)
def verify(path,pin):
    raw=Path(path).read_bytes();need(re.fullmatch('[0-9a-f]{64}',pin) is not None and sha(raw)==pin,'EXTERNAL_ARCHIVE_PIN')
    payload=read_zip(raw);manifest=record(obj(payload['PACKAGE-MANIFEST.json']),'mosaic.ugel.batch-d.package-manifest.v1')
    rows=manifest['files'];need([r['path'] for r in rows]==sorted(set(payload)-{'PACKAGE-MANIFEST.json'}),'PAYLOAD_CLOSURE')
    for r in rows:need(set(r)=={'path','bytes','sha256'} and r['bytes']==len(payload[r['path']]) and r['sha256']==sha(payload[r['path']]),'PAYLOAD_HASH')
    need(manifest['payload_count']==len(rows) and manifest['logical_bytes']==sum(r['bytes'] for r in rows),'PAYLOAD_COUNTS')
    src=record(obj(payload['release/SOURCE-MANIFEST.json']),'mosaic.ugel.batch-d.source-manifest.v1');actual=source_rows(payload)
    need(src['files']==actual and src['file_count']==len(actual) and src['logical_bytes']==sum(r['bytes'] for r in actual),'SOURCE_CLOSURE')
    need(src['root']==manifest['source_root'],'SOURCE_BINDING')
    cc=record(obj(payload['spec/CHECK-CONTRACT.json']),'mosaic.ugel.batch-d.check-contract.v1');ids=tests(payload);need(ids==cc['test_ids'],'STATIC_TEST_IDS')
    checks=record(obj(payload['evidence/REFERENCE-CHECKS.json']),'mosaic.ugel.batch-d.reference-checks.v1')
    need(checks['source_root']==src['root'] and checks['contract_root']==cc['root'] and checks['root']==manifest['reference_check_root'],'CHECK_SUBJECT')
    need(checks['status']=='PASS_EXECUTED_LANES' and checks['source_stable'] is True and checks['cache_policy']=='DISABLED' and checks['prior_result_cache_reads']==0,'CHECK_SCOPE')
    need(checks['test_ids']==ids and checks['tests_run']==len(ids) and checks['test_set_root']==sha(canonical(ids)),'CHECK_INVENTORY')
    need(checks['rows']==[{'id':i,'status':'PASS'} for i in ids],'TEST_ROWS')
    need(all(type(checks[k]) is int and checks[k]==0 for k in ['failures','errors','skips','expected_failures','unexpected_successes']),'CHECK_COUNTERS')
    inherited=record(obj(payload['evidence/inherited-c/REFERENCE-CHECKS.json']),'mosaic.ugel.batch-c.reference-checks.v1',C_DOMAIN)
    need(inherited['root']==checks['inherited_c_result_root'] and inherited['status']=='PASS' and inherited['total_distinct_test_count']==118,'INHERITED_CHECKS')
    need(checks['inherited_test_count']==118 and checks['total_distinct_python_test_count']==len(ids)+118,'TOTAL_TEST_COUNT')
    need(checks['batch_disposition']==manifest['batch_disposition'],'DISPOSITION_BINDING')
    native=record(obj(payload['evidence/NATIVE-BUILD.json']),'mosaic.ugel.batch-d.native-build.v1')
    if checks['rust_lane']=='NOT_RUN_TOOLCHAIN_UNAVAILABLE':
        need(checks['native_rust_test_count']==0 and checks['batch_disposition']=='VALIDATED_EXECUTED_LANES_RUST_NOT_RUN' and native['rust']['status']=='NOT_RUN','RUST_NONCLAIM')
    else:
        rust_ids=sorted('tests::'+s for s in re.findall(r'#\[test\]\s*fn\s+(\w+)',payload['native/rust/src/lib.rs'].decode()))
        need(checks['rust_lane']=='PASS' and checks['native_rust_test_count']==len(rust_ids) and native['rust']['test_ids']==rust_ids and native['rust']['status']=='BUILT_AND_TESTED','RUST_EXECUTED_CONTRACT')
    predecessor=payload['predecessors/UGEL-BATCH-C-r001.zip'];need(sha(predecessor)==C_PIN,'PREDECESSOR_PIN')
    with zipfile.ZipFile(io.BytesIO(predecessor)) as z:
        names=z.namelist();prefix='compatibility/batch-c/'
        need({n[len(prefix):] for n in payload if n.startswith(prefix)}==set(names),'PREDECESSOR_CLOSURE')
        for n in names:need(payload[prefix+n]==z.read(n),'PREDECESSOR_BYTES')
    reuse=record(obj(payload['provenance/BATCH-C-REUSE.json']),'mosaic.ugel.batch-d.reuse.v1')
    need(reuse['predecessor_sha256']==C_PIN and reuse['file_count']==len(names),'REUSE_IDENTITY')
    need(reuse['files']==[{'path':n,'bytes':len(payload[prefix+n]),'sha256':sha(payload[prefix+n])} for n in sorted(names)],'REUSE_ROWS')
    clean=record(obj(payload['evidence/clean-reproduction/REFERENCE-CHECKS.json']),'mosaic.ugel.batch-d.reference-checks.v1')
    need(clean==checks,'CLEAN_REFERENCE_RECORD_DIFFERENT')
    reproduction=record(obj(payload['evidence/CLEAN-REPRODUCTION.json']),'mosaic.ugel.batch-d.clean-reproduction.v1')
    need(reproduction['source_root']==src['root'] and reproduction['first_check_root']==checks['root']==reproduction['clean_check_root'] and reproduction['check_records_byte_identical'] is True,'CLEAN_REPRODUCTION_BINDING')
    need(manifest['standing']=='INFORMATION_ONLY' and manifest['authority_effect']=='NONE' and manifest['real_a5'] is False and manifest['g0']=='CLOSED','AUTHORITY_CEILING')
    return {'schema':'mosaic.ugel.batch-d.passive-verification.v1','status':'PASS_PACKAGE_CUSTODY_AND_RECORDED_LANE_BINDINGS',
        'batch_disposition':checks['batch_disposition'],'archive_sha256':pin,'source_root':src['root'],'source_file_count':len(actual),
        'package_members':len(payload),'reference_check_root':checks['root'],'recorded_python_tests':checks['total_distinct_python_test_count'],
        'rust_runtime':checks['rust_lane'],'candidate_imports':0,'candidate_invocations':0,'recorded_execution_independently_reproduced':False,
        'native_containment_established':False,'native_ugk_binding':'NOT_BOUND','authority_effect':'NONE'}
def main():
    p=argparse.ArgumentParser();p.add_argument('archive',type=Path);p.add_argument('--expected-sha256',required=True);a=p.parse_args()
    try:r=verify(a.archive,a.expected_sha256);print(json.dumps(r,indent=2));return 0
    except Exception as e:print(json.dumps({'status':'REFUSED','error':type(e).__name__,'detail':str(e),'candidate_imports':0,'candidate_invocations':0}));return 2
if __name__=='__main__':raise SystemExit(main())
