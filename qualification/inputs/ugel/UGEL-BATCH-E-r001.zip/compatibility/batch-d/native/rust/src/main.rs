#![forbid(unsafe_code)]
use std::io::{self,Write};
use ugel_native::*;
fn run()->Result<()> {
    let a:Vec<String>=std::env::args().collect();
    if a.len()<6 {return Err("usage: client emit|exchange control ACTION CONTEXT HEAD [VALUE], or effect ACTION CONTEXT HEAD SUBJECT CONTRACT GRANT EPOCH OPID EFFECT RESOURCE PARAMS".into());}
    let at=|i:usize|->Result<&str>{a.get(i).map(String::as_str).ok_or_else(||"ARGUMENT_MISSING".into())};
    let is_exchange=at(1)?=="exchange";require_mode(at(1)?)?;
    let wire=if at(2)?=="control" {
        let op=match at(3)? {"INSPECT"=>Control::Inspect,"FINALIZE"=>Control::Finalize(at(6)?),"CANCEL"=>Control::Cancel(at(6)?),
            "HOST_INSPECT"=>Control::HostInspect,"HOST_EXECUTE"=>Control::HostExecute,"HOST_FINALIZE"=>Control::HostFinalize(at(6)?),_=>return Err("ACTION_INVALID".into())};
        control(at(4)?,at(5)?,op)?
    } else if at(2)?=="effect" {
        let ctx=Context::new(at(4)?,at(5)?,at(6)?,at(7)?,at(8)?,at(9)?.parse().map_err(|_|"EPOCH_INVALID")?)?;
        let cap=Capability::new(at(12)?,15,MAX_TEXT)?;
        let action=match at(3)? {"PREVIEW"=>Action::Preview,"ADMIT"=>Action::Admit,"OBSERVE"=>Action::Observe,"RUN"=>Action::Run,_=>return Err("ACTION_INVALID".into())};
        match at(11)? {
            "sim.add"=>add(&ctx,&cap,action,at(10)?,at(13)?.parse().map_err(|_|"INTEGER_INVALID")?,at(14)?.parse().map_err(|_|"INTEGER_INVALID")?)?,
            "sim.echo"=>echo(&ctx,&cap,action,at(10)?,at(13)?,ev(at(14)?))?,
            "fs.create"=>create(&ctx,&cap,action,at(10)?,at(13)?,at(14)?,ev(at(15)?))?,
            "fs.read"=>read(&ctx,&cap,action,at(10)?,at(13)?,at(14)?,at(15)?.parse().map_err(|_|"INTEGER_INVALID")?)?,
            _=>return Err("EFFECT_INVALID".into()),
        }
    } else {return Err("MODE_INVALID".into());};
    let mut out=io::stdout().lock();
    if is_exchange {let mut input=io::stdin().lock();let response=exchange(&mut out,&mut input,&wire)?;out.write_all(response.as_bytes()).map_err(|e|e.to_string())?;}
    else {out.write_all(&wire).map_err(|e|e.to_string())?;}
    out.write_all(b"\n").map_err(|e|e.to_string())?;out.flush().map_err(|e|e.to_string())?;Ok(())
}
fn ev(s:&str)->Option<&str> {if s=="-" {None} else {Some(s)}}
fn require_mode(s:&str)->Result<()> {if s=="emit"||s=="exchange"{Ok(())}else{Err("MODE_INVALID".into())}}
fn main(){if let Err(e)=run(){eprintln!("{}",e);std::process::exit(2);}}
