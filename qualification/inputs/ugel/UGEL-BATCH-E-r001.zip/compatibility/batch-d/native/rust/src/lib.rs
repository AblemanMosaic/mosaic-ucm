//! Typed cooperative request adapter. Local handles do not create authority.
//! Wire responses remain unverified until checked against retained host pins.
#![forbid(unsafe_code)]
use std::fmt::Write as FmtWrite;
use std::io::{Read, Write};

pub const MAX_TEXT: usize = 65_536;
pub const MAX_FRAME: usize = 1_048_576;
pub const ADD: u32 = 1;
pub const ECHO: u32 = 2;
pub const READ: u32 = 4;
pub const CREATE: u32 = 8;
pub type Result<T> = std::result::Result<T, String>;

fn require(ok: bool, code: &'static str) -> Result<()> {
    if ok { Ok(()) } else { Err(code.to_owned()) }
}
fn root(s: &str) -> bool {
    s.len() == 64 && s.bytes().all(|c| c.is_ascii_digit() || (b'a'..=b'f').contains(&c))
}
fn id(s: &str) -> bool {
    !s.is_empty() && s.len() <= 128 && s.bytes().enumerate().all(|(i, c)|
        c.is_ascii_alphanumeric() || (i > 0 && b"_.:-".contains(&c)))
}
fn leaf(s: &str) -> bool {
    if s.is_empty() || s.len() > 64 || s.ends_with('.') || !s.bytes().enumerate().all(|(i,c)|
        c.is_ascii_alphanumeric() || (i > 0 && b"_.-".contains(&c))) { return false; }
    let stem = s.split('.').next().unwrap_or("").to_ascii_uppercase();
    if ["CON", "PRN", "AUX", "NUL"].contains(&stem.as_str()) { return false; }
    !(stem.len()==4 && (stem.starts_with("COM") || stem.starts_with("LPT")) &&
        (b'1'..=b'9').contains(&stem.as_bytes()[3]))
}
/// Matches the frozen Batch A ensure_ascii canonical string representation.
pub fn json_string(text: &str) -> String {
    let mut out=String::from("\"");
    for ch in text.chars() {
        match ch {
            '"' => out.push_str("\\\""), '\\' => out.push_str("\\\\"),
            '\u{8}' => out.push_str("\\b"), '\t' => out.push_str("\\t"),
            '\n' => out.push_str("\\n"), '\u{c}' => out.push_str("\\f"),
            '\r' => out.push_str("\\r"),
            c if (32..127).contains(&(c as u32)) => out.push(c),
            c if (c as u32) <= 0xffff => { let _=write!(out,"\\u{:04x}",c as u32); },
            c => { let n=c as u32-0x10000; let _=write!(out,"\\u{:04x}\\u{:04x}",0xd800+(n>>10),0xdc00+(n&1023)); }
        }
    }
    out.push('"');out
}
#[derive(Clone, Debug)]
pub struct Context {
    context_root: String, expected_head: String, subject_root: String,
    contract_root: String, grant_root: String, epoch: u64,
}
impl Context {
    pub fn new(context_root: &str, expected_head: &str, subject_root: &str,
               contract_root: &str, grant_root: &str, epoch: u64) -> Result<Self> {
        require([context_root,expected_head,subject_root,contract_root,grant_root].iter().all(|s|root(s)),"DIGEST_INVALID")?;
        require((1..=9_007_199_254_740_991).contains(&epoch),"EPOCH_INVALID")?;
        Ok(Self{context_root:context_root.into(),expected_head:expected_head.into(),subject_root:subject_root.into(),
            contract_root:contract_root.into(),grant_root:grant_root.into(),epoch})
    }
    pub fn with_observed_head(&self, head: &str) -> Result<Self> {
        require(root(head),"HEAD_INVALID")?;let mut c=self.clone();c.expected_head=head.into();Ok(c)
    }
}
#[derive(Clone, Debug)]
pub struct Capability { resource: String, effects: u32, max_text: usize }
impl Capability {
    /// A local SDK constraint, not a credential. The host checks its own grant.
    pub fn new(resource: &str, effects: u32, max_text: usize) -> Result<Self> {
        require(id(resource)&&effects!=0&&effects&!15==0&&max_text<=MAX_TEXT,"HANDLE_INVALID")?;
        Ok(Self{resource:resource.into(),effects,max_text})
    }
    pub fn narrow(&self, effects: u32, max_text: usize) -> Result<Self> {
        require(effects!=0&&effects&!self.effects==0&&max_text<=self.max_text,"HANDLE_NOT_ATTENUATED")?;
        Self::new(&self.resource,effects,max_text)
    }
}
#[derive(Clone, Copy, Debug)]
pub enum Action { Preview, Admit, Observe, Run }
impl Action { pub fn name(self)-> &'static str { match self {Self::Preview=>"PREVIEW",Self::Admit=>"ADMIT",Self::Observe=>"OBSERVE",Self::Run=>"RUN"} } }

fn effect(c:&Context,h:&Capability,action:Action,op:&str,kind:&str,mask:u32,parameters:&str,evidence:Option<&str>)->Result<Vec<u8>> {
    require(h.effects&mask!=0,"LOCAL_HANDLE_REFUSED")?;require(id(op),"OPERATION_ID_INVALID")?;
    if let Some(e)=evidence {require(root(e),"EVIDENCE_ROOT_INVALID")?;}
    let evidence_list=evidence.map(json_string).unwrap_or_default();
    let request=format!("{{\"contract_root\":{},\"effect\":{},\"epoch\":{},\"evidence_roots\":[{}],\"grant_root\":{},\"operation_id\":{},\"parameters\":{},\"resource_id\":{},\"schema\":\"mosaic.ugel.batch-a.request.v1\",\"subject_root\":{}}}",
        json_string(&c.contract_root),json_string(kind),c.epoch,evidence_list,json_string(&c.grant_root),json_string(op),parameters,json_string(&h.resource),json_string(&c.subject_root));
    let wire=format!("{{\"action\":{},\"context_root\":{},\"expected_head\":{},\"payload\":{{\"request\":{}}},\"schema\":\"mosaic.ugel.batch-d.command.v1\"}}",
        json_string(action.name()),json_string(&c.context_root),json_string(&c.expected_head),request).into_bytes();
    require(wire.len()<=MAX_FRAME,"FRAME_BOUND")?;Ok(wire)
}
pub fn add(c:&Context,h:&Capability,a:Action,op:&str,left:i64,right:i64)->Result<Vec<u8>> {
    require((-1_000_000..=1_000_000).contains(&left)&&(-1_000_000..=1_000_000).contains(&right),"INTEGER_BOUND")?;
    effect(c,h,a,op,"sim.add",ADD,&format!("{{\"left\":{},\"right\":{}}}",left,right),None)
}
pub fn echo(c:&Context,h:&Capability,a:Action,op:&str,text:&str,evidence:Option<&str>)->Result<Vec<u8>> {
    require(text.len()<=h.max_text,"TEXT_BOUND")?;
    effect(c,h,a,op,"sim.echo",ECHO,&format!("{{\"text\":{}}}",json_string(text)),evidence)
}
pub fn create(c:&Context,h:&Capability,a:Action,op:&str,name:&str,text:&str,evidence:Option<&str>)->Result<Vec<u8>> {
    require(leaf(name),"LEAF_NAME_REQUIRED")?;require(text.len()<=h.max_text,"TEXT_BOUND")?;
    effect(c,h,a,op,"fs.create",CREATE,&format!("{{\"name\":{},\"text\":{}}}",json_string(name),json_string(text)),evidence)
}
pub fn read(c:&Context,h:&Capability,a:Action,op:&str,name:&str,sha:&str,max_bytes:usize)->Result<Vec<u8>> {
    require(leaf(name)&&root(sha)&&max_bytes>0&&max_bytes<=h.max_text,"READ_ARGUMENT")?;
    effect(c,h,a,op,"fs.read",READ,&format!("{{\"expected_sha256\":{},\"max_bytes\":{},\"name\":{}}}",json_string(sha),max_bytes,json_string(name)),None)
}
#[derive(Clone, Debug)]
pub enum Control<'a> { Inspect, Finalize(&'a str), Cancel(&'a str), HostInspect, HostExecute, HostFinalize(&'a str) }
pub fn control(context_root:&str,head:&str,op:Control<'_>)->Result<Vec<u8>> {
    require(root(context_root)&&root(head),"CONTEXT_PIN")?;
    let (action,payload)=match op {
        Control::Inspect=>("INSPECT","{}".into()),
        Control::HostInspect=>("HOST_INSPECT","{}".into()),
        Control::HostExecute=>("HOST_EXECUTE","{}".into()),
        Control::Finalize(s)=>{require(id(s),"OPERATION_ID")?;("FINALIZE",format!("{{\"operation_id\":{}}}",json_string(s)))},
        Control::Cancel(s)=>{require(id(s),"OPERATION_ID")?;("CANCEL",format!("{{\"operation_id\":{}}}",json_string(s)))},
        Control::HostFinalize(s)=>{require(root(s),"PERMIT_ROOT")?;("HOST_FINALIZE",format!("{{\"permit_root\":{}}}",json_string(s)))},
    };
    Ok(format!("{{\"action\":{},\"context_root\":{},\"expected_head\":{},\"payload\":{},\"schema\":\"mosaic.ugel.batch-d.command.v1\"}}",json_string(action),json_string(context_root),json_string(head),payload).into_bytes())
}
/// This type deliberately does not imply signature, semantic or authority verification.
#[derive(Debug)]
pub struct UnverifiedResponse(Vec<u8>);
impl UnverifiedResponse { pub fn as_bytes(&self)->&[u8] { &self.0 } }
/// Exactly one exchange. An I/O error after transmission is uncertain, never retried.
pub fn exchange<W:Write,R:Read>(writer:&mut W,reader:&mut R,command:&[u8])->Result<UnverifiedResponse> {
    require(!command.is_empty()&&command.len()<=MAX_FRAME&&!command.contains(&b'\n'),"FRAME_INVALID")?;
    let uncertain=|e:std::io::Error|format!("TRANSPORT_UNCERTAIN_NO_RETRY: {}",e);
    writer.write_all(command).map_err(uncertain)?;writer.write_all(b"\n").map_err(uncertain)?;writer.flush().map_err(uncertain)?;
    let mut out=Vec::new();let mut one=[0u8;1];
    for _ in 0..=MAX_FRAME {
        reader.read_exact(&mut one).map_err(uncertain)?;
        if one[0]==b'\n' {require(!out.is_empty(),"EMPTY_RESPONSE_UNCERTAIN")?;return Ok(UnverifiedResponse(out));}
        out.push(one[0]);
    }
    Err("RESPONSE_BOUND_UNCERTAIN_NO_RETRY".into())
}
#[cfg(test)]
mod tests {
    use super::*;
    fn context()->Context { Context::new(&"1".repeat(64),&"0".repeat(64),&"2".repeat(64),&"3".repeat(64),&"4".repeat(64),1).unwrap() }
    #[test] fn ascii_and_escapes(){assert_eq!(json_string("a\n\"\\\t"),"\"a\\n\\\"\\\\\\t\"");}
    #[test] fn unicode_scalars(){assert_eq!(json_string("é🌞"),"\"\\u00e9\\ud83c\\udf1e\"");}
    #[test] fn embedded_nul(){assert_eq!(json_string("a\0b"),"\"a\\u0000b\"");}
    #[test] fn add_has_bound_context(){let h=Capability::new("simulation",ADD,0).unwrap();let q=String::from_utf8(add(&context(),&h,Action::Run,"sum",19,23).unwrap()).unwrap();assert!(q.contains("\"left\":19,\"right\":23"));assert!(q.contains("mosaic.ugel.batch-a.request.v1"));}
    #[test] fn narrowed_handle_preserves_resource(){let h=Capability::new("workspace",READ|CREATE,100).unwrap();let r=h.narrow(READ,50).unwrap();assert_eq!(r.resource,"workspace");assert_eq!(r.effects,READ);assert_eq!(r.max_text,50);}
    #[test] fn controls_preserve_operation(){let q=String::from_utf8(control(&"1".repeat(64),&"0".repeat(64),Control::Finalize("sum")).unwrap()).unwrap();assert!(q.contains("\"payload\":{\"operation_id\":\"sum\"}"));}
    #[test] fn one_exchange_returns_unverified_bytes(){let mut write=Vec::new();let mut read=std::io::Cursor::new(b"{\"status\":\"REPORTED\"}\n");let r=exchange(&mut write,&mut read,b"{}").unwrap();assert_eq!(write,b"{}\n");assert_eq!(r.as_bytes(),b"{\"status\":\"REPORTED\"}");}
    #[test] fn empty_text_is_a_valid_parameter(){let h=Capability::new("simulation",ECHO,0).unwrap();let q=String::from_utf8(echo(&context(),&h,Action::Preview,"empty","",None).unwrap()).unwrap();assert!(q.contains("\"parameters\":{\"text\":\"\"}"));}
}
