#include "ugel.h"
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <inttypes.h>
static int number(const char *s,int64_t *out){char *end;intmax_t n;errno=0;n=strtoimax(s,&end,10);if(errno||!*s||*end||n<INT64_MIN||n>INT64_MAX)return 0;*out=(int64_t)n;return 1;}
int main(int argc,char **argv){ugel_buffer command={0},response={0};ugel_context ctx;ugel_capability cap;int e=UGEL_INVALID;int exchange;int64_t a,b,epoch;
    if(argc<6){fprintf(stderr,"usage: client emit|exchange control ACTION CONTEXT HEAD [VALUE]\n  or: client emit|exchange effect ACTION CONTEXT HEAD SUBJECT CONTRACT GRANT EPOCH OPID EFFECT RESOURCE PARAMS...\n");return 2;}
    exchange=!strcmp(argv[1],"exchange");if(!exchange&&strcmp(argv[1],"emit"))return 2;
    if(!strcmp(argv[2],"control")){e=ugel_control(argv[4],argv[5],argv[3],argc>6?argv[6]:NULL,&command);}
    else if(!strcmp(argv[2],"effect")&&argc>=14&&number(argv[9],&epoch)&&epoch>0){
        e=ugel_context_init(&ctx,argv[4],argv[5],argv[6],argv[7],argv[8],(uint64_t)epoch);if(e)goto done;
        e=ugel_capability_init(&cap,argv[12],15,UGEL_MAX_TEXT);if(e)goto done;
        if(!strcmp(argv[11],"sim.add")&&argc==15&&number(argv[13],&a)&&number(argv[14],&b))e=ugel_add(&ctx,&cap,argv[3],argv[10],a,b,&command);
        else if(!strcmp(argv[11],"sim.echo")&&argc==15)e=ugel_echo(&ctx,&cap,argv[3],argv[10],(const unsigned char*)argv[13],strlen(argv[13]),strcmp(argv[14],"-")?argv[14]:NULL,&command);
        else if(!strcmp(argv[11],"fs.create")&&argc==16)e=ugel_create(&ctx,&cap,argv[3],argv[10],argv[13],(const unsigned char*)argv[14],strlen(argv[14]),strcmp(argv[15],"-")?argv[15]:NULL,&command);
        else if(!strcmp(argv[11],"fs.read")&&argc==16&&number(argv[15],&a)&&a>0)e=ugel_read(&ctx,&cap,argv[3],argv[10],argv[13],argv[14],(size_t)a,&command);
        else e=UGEL_INVALID;
    }
    if(!e){if(exchange){e=ugel_exchange(stdout,stdin,&command,&response);if(!e&&(fwrite(response.data,1,response.length,stdout)!=response.length||fputc('\n',stdout)==EOF||fflush(stdout)!=0))e=UGEL_IO_UNCERTAIN;}
        else if(fwrite(command.data,1,command.length,stdout)!=command.length||fputc('\n',stdout)==EOF)e=UGEL_IO_UNCERTAIN;}
 done:if(e)fprintf(stderr,"%s\n",ugel_error_name(e));ugel_buffer_free(&command);ugel_buffer_free(&response);return e?2:0;}
