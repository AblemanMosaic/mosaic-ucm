#include "ugel.h"
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include <inttypes.h>
#include <ctype.h>
#define A_SCHEMA "mosaic.ugel.batch-a.request.v1"
#define D_SCHEMA "mosaic.ugel.batch-d.command.v1"
typedef struct { char *p; size_t n,cap; int err; } builder;
static int root_ok(const char *s) { size_t i; if (!s || strlen(s)!=64) return 0;
    for(i=0;i<64;i++) { if(!((s[i]>='0'&&s[i]<='9')||(s[i]>='a'&&s[i]<='f'))) return 0; } return 1; }
static int id_ok(const char *s) { size_t i,n; if(!s) return 0; n=strlen(s);if(n<1||n>128) return 0;
    for(i=0;i<n;i++) { unsigned char c=(unsigned char)s[i]; int al=(c>='A'&&c<='Z')||(c>='a'&&c<='z')||(c>='0'&&c<='9');
        if(!al && !(i>0&&(c=='_'||c=='.'||c==':'||c=='-'))) return 0; }return 1; }
static int leaf_ok(const char *s) { size_t i,n;char stem[65];size_t k=0;if(!s)return 0;n=strlen(s);if(n<1||n>64||s[n-1]=='.')return 0;
    for(i=0;i<n;i++){unsigned char c=(unsigned char)s[i];int al=(c>='A'&&c<='Z')||(c>='a'&&c<='z')||(c>='0'&&c<='9');
        if(!al && !(i>0&&(c=='_'||c=='.'||c=='-')))return 0;}
    while(k<n&&s[k]!='.') {stem[k]=(char)toupper((unsigned char)s[k]);k++;}stem[k]=0;
    if(!strcmp(stem,"CON")||!strcmp(stem,"PRN")||!strcmp(stem,"AUX")||!strcmp(stem,"NUL"))return 0;
    if(k==4&&(!strncmp(stem,"COM",3)||!strncmp(stem,"LPT",3))&&stem[3]>='1'&&stem[3]<='9')return 0;
    return 1; }
static void add(builder *b,const char *s,size_t n){if(b->err)return;if(n>UGEL_MAX_FRAME-b->n){b->err=UGEL_BOUNDS;return;}
    if(b->n+n+1>b->cap){size_t c=b->cap?b->cap:256;char *p;while(c<b->n+n+1)c*=2;p=(char*)realloc(b->p,c);if(!p){b->err=UGEL_MEMORY;return;}b->p=p;b->cap=c;}
    memcpy(b->p+b->n,s,n);b->n+=n;b->p[b->n]=0;}
static void lit(builder *b,const char *s){add(b,s,strlen(s));}
static void fmt(builder *b,const char *f,...){char s[128];va_list a;int n;va_start(a,f);n=vsnprintf(s,sizeof(s),f,a);va_end(a);
    if(n<0||(size_t)n>=sizeof(s)){b->err=UGEL_BOUNDS;return;}add(b,s,(size_t)n);}
static int scalar(const unsigned char *s,size_t n,size_t *i,uint32_t *cp){size_t j=*i;unsigned char c;uint32_t x;unsigned k,count;
    if(j>=n){return 0;} c=s[j++];if(c<0x80){*cp=c;*i=j;return 1;}
    if(c>=0xc2&&c<=0xdf){x=c&31;count=1;}else if(c>=0xe0&&c<=0xef){x=c&15;count=2;}else if(c>=0xf0&&c<=0xf4){x=c&7;count=3;}else return 0;
    if(j+count>n){return 0;} for(k=0;k<count;k++){c=s[j++];if((c&0xc0)!=0x80)return 0;x=(x<<6)|(c&63);}
    if((count==1&&x<0x80)||(count==2&&x<0x800)||(count==3&&x<0x10000)||x>0x10ffff||(x>=0xd800&&x<=0xdfff))return 0;
    *cp=x;*i=j;return 1;}
static void string(builder *b,const unsigned char *s,size_t n){size_t i=0;uint32_t cp;if(!s&&n){b->err=UGEL_INVALID;return;}lit(b,"\"");
    while(i<n&&!b->err){if(!scalar(s,n,&i,&cp)){b->err=UGEL_INVALID;break;}
        switch(cp){case '"':lit(b,"\\\"");break;case '\\':lit(b,"\\\\");break;case 8:lit(b,"\\b");break;case 9:lit(b,"\\t");break;
        case 10:lit(b,"\\n");break;case 12:lit(b,"\\f");break;case 13:lit(b,"\\r");break;
        default:if(cp<32||cp>=127){if(cp<=0xffff)fmt(b,"\\u%04x",(unsigned)cp);else{cp-=0x10000;fmt(b,"\\u%04x\\u%04x",(unsigned)(0xd800+(cp>>10)),(unsigned)(0xdc00+(cp&1023)));}}
        else{char c=(char)cp;add(b,&c,1);}}
    }lit(b,"\"");}
static void str(builder *b,const char *s){string(b,(const unsigned char*)s,strlen(s));}
static int finish(builder *b,ugel_buffer *out){if(!out||out->data){free(b->p);return UGEL_INVALID;}if(b->err){int e=b->err;free(b->p);return e;}out->data=b->p;out->length=b->n;return UGEL_OK;}
uint32_t ugel_abi_version(void){return UGEL_ABI_VERSION;}
size_t ugel_context_size(void){return sizeof(ugel_context);}
const char *ugel_error_name(int e){switch(e){case 0:return "OK";case 1:return "INVALID_ARGUMENT";case 2:return "ALLOCATION_FAILED";case 3:return "BOUND_EXCEEDED";case 4:return "LOCAL_HANDLE_REFUSED";case 5:return "TRANSPORT_UNCERTAIN_NO_RETRY";default:return "UNKNOWN_ERROR";}}
void ugel_buffer_free(ugel_buffer *b){if(b){free(b->data);b->data=NULL;b->length=0;}}
int ugel_context_init(ugel_context *c,const char *ctx,const char *head,const char *sub,const char *con,const char *grant,uint64_t epoch){
    if(!c||!root_ok(ctx)||!root_ok(head)||!root_ok(sub)||!root_ok(con)||!root_ok(grant)||epoch<1||epoch>9007199254740991ULL)return UGEL_INVALID;
    memset(c,0,sizeof(*c));c->abi_version=1;c->epoch=epoch;memcpy(c->context_root,ctx,65);memcpy(c->expected_head,head,65);memcpy(c->subject_root,sub,65);memcpy(c->contract_root,con,65);memcpy(c->grant_root,grant,65);return 0;}
int ugel_capability_init(ugel_capability *h,const char *rid,uint32_t effects,size_t max_text){if(!h||!id_ok(rid)||!effects||(effects&~15u)||max_text>UGEL_MAX_TEXT)return UGEL_INVALID;
    memset(h,0,sizeof(*h));memcpy(h->resource_id,rid,strlen(rid)+1);h->effects=effects;h->max_text=max_text;return 0;}
int ugel_capability_narrow(const ugel_capability *h,uint32_t effects,size_t n,ugel_capability *out){if(!h||!out||!effects||(effects&~h->effects)||n>h->max_text)return UGEL_CAPABILITY;return ugel_capability_init(out,h->resource_id,effects,n);}
static int begin(builder *b,const ugel_context *c,const ugel_capability *h,const char *action,const char *oid,const char *effect,uint32_t mask,const char *evidence){
    if(!c||c->abi_version!=1||!h||!(h->effects&mask)||!id_ok(h->resource_id)||h->max_text>UGEL_MAX_TEXT)return UGEL_CAPABILITY;
    if(!action||(!strcmp(action,"PREVIEW")?0:!strcmp(action,"RUN")?0:!strcmp(action,"OBSERVE")?0:!strcmp(action,"ADMIT")?0:1)||!id_ok(oid))return UGEL_INVALID;
    if(!root_ok(c->context_root)||!root_ok(c->expected_head)||!root_ok(c->subject_root)||!root_ok(c->contract_root)||!root_ok(c->grant_root)||c->epoch<1||c->epoch>9007199254740991ULL)return UGEL_INVALID;
    if(evidence&&!root_ok(evidence))return UGEL_INVALID;
    lit(b,"{\"action\":");str(b,action);lit(b,",\"context_root\":");str(b,c->context_root);lit(b,",\"expected_head\":");str(b,c->expected_head);
    lit(b,",\"payload\":{\"request\":{\"contract_root\":");str(b,c->contract_root);lit(b,",\"effect\":");str(b,effect);fmt(b,",\"epoch\":%" PRIu64,c->epoch);
    lit(b,",\"evidence_roots\":[");if(evidence)str(b,evidence);lit(b,"],\"grant_root\":");str(b,c->grant_root);lit(b,",\"operation_id\":");str(b,oid);lit(b,",\"parameters\":");return 0;}
static int end(builder *b,const ugel_context *c,const ugel_capability *h,ugel_buffer *out){lit(b,",\"resource_id\":");str(b,h->resource_id);lit(b,",\"schema\":\"" A_SCHEMA "\",\"subject_root\":");str(b,c->subject_root);lit(b,"}},\"schema\":\"" D_SCHEMA "\"}");return finish(b,out);}
int ugel_add(const ugel_context *c,const ugel_capability *h,const char *a,const char *oid,int64_t left,int64_t right,ugel_buffer *out){builder b={0};int e;if(left< -1000000||left>1000000||right< -1000000||right>1000000)return UGEL_BOUNDS;
    e=begin(&b,c,h,a,oid,"sim.add",UGEL_SIM_ADD,NULL);if(e)return e;fmt(&b,"{\"left\":%" PRId64 ",\"right\":%" PRId64 "}",left,right);return end(&b,c,h,out);}
int ugel_echo(const ugel_context *c,const ugel_capability *h,const char *a,const char *oid,const unsigned char *s,size_t n,const char *ev,ugel_buffer *out){builder b={0};int e;if(!h||n>h->max_text)return UGEL_BOUNDS;
    e=begin(&b,c,h,a,oid,"sim.echo",UGEL_SIM_ECHO,ev);if(e)return e;lit(&b,"{\"text\":");string(&b,s,n);lit(&b,"}");return end(&b,c,h,out);}
int ugel_create(const ugel_context *c,const ugel_capability *h,const char *a,const char *oid,const char *name,const unsigned char *s,size_t n,const char *ev,ugel_buffer *out){builder b={0};int e;if(!h||n>h->max_text||!leaf_ok(name))return UGEL_BOUNDS;
    e=begin(&b,c,h,a,oid,"fs.create",UGEL_FS_CREATE,ev);if(e)return e;lit(&b,"{\"name\":");str(&b,name);lit(&b,",\"text\":");string(&b,s,n);lit(&b,"}");return end(&b,c,h,out);}
int ugel_read(const ugel_context *c,const ugel_capability *h,const char *a,const char *oid,const char *name,const char *sha,size_t n,ugel_buffer *out){builder b={0};int e;if(!h||n<1||n>h->max_text||!leaf_ok(name)||!root_ok(sha))return UGEL_BOUNDS;
    e=begin(&b,c,h,a,oid,"fs.read",UGEL_FS_READ,NULL);if(e)return e;lit(&b,"{\"expected_sha256\":");str(&b,sha);fmt(&b,",\"max_bytes\":%zu,\"name\":",n);str(&b,name);lit(&b,"}");return end(&b,c,h,out);}
int ugel_control(const char *ctx,const char *head,const char *action,const char *value,ugel_buffer *out){builder b={0};const char *key=NULL;
    if(!root_ok(ctx)||!root_ok(head)||!action)return UGEL_INVALID;
    if(!strcmp(action,"FINALIZE")||!strcmp(action,"CANCEL")){if(!id_ok(value))return UGEL_INVALID;key="operation_id";}
    else if(!strcmp(action,"HOST_FINALIZE")){if(!root_ok(value))return UGEL_INVALID;key="permit_root";}
    else if(strcmp(action,"INSPECT")&&strcmp(action,"HOST_EXECUTE")&&strcmp(action,"HOST_INSPECT"))return UGEL_INVALID;
    lit(&b,"{\"action\":");str(&b,action);lit(&b,",\"context_root\":");str(&b,ctx);lit(&b,",\"expected_head\":");str(&b,head);lit(&b,",\"payload\":{");
    if(key){str(&b,key);lit(&b,":");str(&b,value);}lit(&b,"},\"schema\":\"" D_SCHEMA "\"}");return finish(&b,out);}
int ugel_exchange(FILE *to,FILE *from,const ugel_buffer *command,ugel_buffer *response){builder b={0};int c;
    if(!to||!from||!command||!command->data||command->length>UGEL_MAX_FRAME||!response||response->data)return UGEL_INVALID;
    if(fwrite(command->data,1,command->length,to)!=command->length||fputc('\n',to)==EOF||fflush(to)!=0)return UGEL_IO_UNCERTAIN;
    while((c=fgetc(from))!=EOF&&c!='\n'){char ch=(char)c;add(&b,&ch,1);if(b.err){free(b.p);return UGEL_IO_UNCERTAIN;}}
    if(c==EOF||b.n==0){free(b.p);return UGEL_IO_UNCERTAIN;}return finish(&b,response);}
