#ifndef MOSAIC_UGEL_D_H
#define MOSAIC_UGEL_D_H
/* Cooperative C ABI. These structs are local programming constraints, not grants.
 * All effects are decided by the separately pinned Python broker. */
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#ifdef __cplusplus
extern "C" {
#endif
#define UGEL_ABI_VERSION 1u
#define UGEL_MAX_TEXT 65536u
#define UGEL_MAX_FRAME 1048576u
#define UGEL_SIM_ADD 1u
#define UGEL_SIM_ECHO 2u
#define UGEL_FS_READ 4u
#define UGEL_FS_CREATE 8u
typedef enum { UGEL_OK=0, UGEL_INVALID=1, UGEL_MEMORY=2,
    UGEL_BOUNDS=3, UGEL_CAPABILITY=4, UGEL_IO_UNCERTAIN=5 } ugel_error;
typedef struct {
    uint32_t abi_version;
    uint64_t epoch;
    char context_root[65], expected_head[65], subject_root[65], contract_root[65], grant_root[65];
} ugel_context;
typedef struct { char resource_id[129]; uint32_t effects; size_t max_text; } ugel_capability;
typedef struct { char *data; size_t length; } ugel_buffer;
uint32_t ugel_abi_version(void);
size_t ugel_context_size(void);
const char *ugel_error_name(int error);
int ugel_context_init(ugel_context *, const char *context_root, const char *expected_head,
    const char *subject_root, const char *contract_root, const char *grant_root, uint64_t epoch);
int ugel_capability_init(ugel_capability *, const char *resource_id, uint32_t effects, size_t max_text);
int ugel_capability_narrow(const ugel_capability *, uint32_t effects, size_t max_text, ugel_capability *);
/* out must be zero-initialized. A successful call allocates out; free it exactly once.
 * All input buffers are borrowed for the duration of the call only. */
int ugel_add(const ugel_context *, const ugel_capability *, const char *action, const char *operation_id,
    int64_t left, int64_t right, ugel_buffer *out);
int ugel_echo(const ugel_context *, const ugel_capability *, const char *action, const char *operation_id,
    const unsigned char *utf8, size_t bytes, const char *evidence_root, ugel_buffer *out);
int ugel_create(const ugel_context *, const ugel_capability *, const char *action, const char *operation_id,
    const char *leaf_name, const unsigned char *utf8, size_t bytes, const char *evidence_root, ugel_buffer *out);
int ugel_read(const ugel_context *, const ugel_capability *, const char *action, const char *operation_id,
    const char *leaf_name, const char *expected_sha256, size_t max_bytes, ugel_buffer *out);
int ugel_control(const char *context_root, const char *expected_head, const char *action,
    const char *operation_or_permit, ugel_buffer *out);
/* Single exchange; never retries. A failed exchange may follow a committed effect.
 * response is unverified wire data, not an accepted receipt or permission. */
int ugel_exchange(FILE *to_host, FILE *from_host, const ugel_buffer *command, ugel_buffer *response);
void ugel_buffer_free(ugel_buffer *);
#ifdef __cplusplus
}
#endif
#endif
