"""Ordinary positive controls, documented state boundaries and package checks.
No malformed-input campaign, denied-effect probe, attack or forced interruption.
"""
from __future__ import annotations
import ast,ctypes,hashlib,json,os,subprocess,sys,tempfile,unittest,zipfile
from pathlib import Path
from ugel.canonical import canonical,byte_digest,seal
from ugel.contracts import validate
from ugel_native.protocol import command,control,record,digest,decode,BOUNDARY
from ugel_native.effects import EffectSession,verify_export
from ugel_native.transport import emit,exchange
from ugel_native.demo import comparison,filesystem_demo,signed_host_demo
ROOT=Path(__file__).resolve().parents[1]
BUILD=json.loads(Path(os.environ['UGEL_D_NATIVE_BUILD']).read_bytes())
CLIENTS={'gcc':BUILD['c']['client']}
if BUILD['alternate_c']['status']=='BUILT':CLIENTS['clang']=BUILD['alternate_c']['client']
if BUILD['rust']['status']=='BUILT_AND_TESTED':CLIENTS['rust']=BUILD['rust']['client']

class Base(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='ugel-d-test-');self.t=Path(self.tmp.name);self.subject=digest({'task':'positive-native-tests'})
    def tearDown(self):self.tmp.cleanup()
    def host(self,local=False,name='task'):
        return EffectSession.initialize(self.t/name,subject_root=self.subject,expected_subject_root=self.subject,local=local,now=1000,clock=lambda:1000)
    def eq(self,h,oid,effect,p,action='PREVIEW',with_evidence=True):
        q=h.prepare_request(oid,effect,p,with_evidence=with_evidence);c=command(h.context['root'],h.pins()['head'],action,q)
        for label,exe in CLIENTS.items():
            with self.subTest(language=label):self.assertEqual(emit(exe,c),canonical(c))
        return c

class EncodingTests(Base):
    def test_signed_integer_addition(self):self.eq(self.host(),'sum','sim.add',{'left':-23,'right':19})
    def test_integer_endpoint_values(self):self.eq(self.host(),'sum','sim.add',{'left':-1000000,'right':1000000})
    def test_ascii_text_and_pinned_evidence(self):self.eq(self.host(),'echo','sim.echo',{'text':'same contract and grant'})
    def test_multilingual_unicode_scalars(self):self.eq(self.host(),'echo','sim.echo',{'text':'café Ελληνικά 日本語 🌞'})
    def test_json_special_characters(self):self.eq(self.host(),'echo','sim.echo',{'text':'quote=" slash=\\ newline=\n tab=\t backspace=\b'})
    def test_empty_text(self):self.eq(self.host(),'echo','sim.echo',{'text':''})
    def test_text_without_evidence_is_a_valid_pending_request(self):
        h=self.host();c=self.eq(h,'echo','sim.echo',{'text':'await checker'},with_evidence=False)
        self.assertEqual(h.handle(c)['status'],'NEEDS_EVIDENCE')
    def test_file_create_request(self):self.eq(self.host(True),'create','fs.create',{'name':'report.txt','text':'local report\n'})
    def test_file_read_request(self):self.eq(self.host(True),'read','fs.read',{'name':'report.txt','expected_sha256':byte_digest(b'data'),'max_bytes':4000})
    def test_control_request_bytes(self):
        h=self.host()
        for a,v in [('INSPECT',None),('FINALIZE','op'),('CANCEL','op'),('HOST_EXECUTE',None),('HOST_INSPECT',None),('HOST_FINALIZE','f'*64)]:
            c=control(h.context['root'],h.pins()['head'],a,v)
            for exe in CLIENTS.values():self.assertEqual(emit(exe,c),canonical(c))

class CAbiTests(Base):
    def setUp(self):
        super().setUp();self.lib=ctypes.CDLL(BUILD['c']['library'])
        class Context(ctypes.Structure):_fields_=[('abi_version',ctypes.c_uint32),('epoch',ctypes.c_uint64),*[(n,ctypes.c_char*65) for n in ['context_root','expected_head','subject_root','contract_root','grant_root']]]
        class Cap(ctypes.Structure):_fields_=[('resource_id',ctypes.c_char*129),('effects',ctypes.c_uint32),('max_text',ctypes.c_size_t)]
        class Buffer(ctypes.Structure):_fields_=[('data',ctypes.c_void_p),('length',ctypes.c_size_t)]
        self.Context,self.Cap,self.Buffer=Context,Cap,Buffer
        self.lib.ugel_context_size.restype=ctypes.c_size_t
        self.lib.ugel_context_init.argtypes=[ctypes.POINTER(Context),*([ctypes.c_char_p]*5),ctypes.c_uint64]
        self.lib.ugel_capability_init.argtypes=[ctypes.POINTER(Cap),ctypes.c_char_p,ctypes.c_uint32,ctypes.c_size_t]
        self.lib.ugel_capability_narrow.argtypes=[ctypes.POINTER(Cap),ctypes.c_uint32,ctypes.c_size_t,ctypes.POINTER(Cap)]
        self.lib.ugel_buffer_free.argtypes=[ctypes.POINTER(Buffer)]
        self.lib.ugel_echo.argtypes=[ctypes.POINTER(Context),ctypes.POINTER(Cap),ctypes.c_char_p,ctypes.c_char_p,ctypes.c_void_p,ctypes.c_size_t,ctypes.c_char_p,ctypes.POINTER(Buffer)]
    def test_c_abi_layout_and_version(self):
        self.assertEqual(self.lib.ugel_abi_version(),1);self.assertEqual(self.lib.ugel_context_size(),ctypes.sizeof(self.Context))
    def test_local_handle_attenuation_preserves_resource(self):
        parent,child=self.Cap(),self.Cap();self.assertEqual(self.lib.ugel_capability_init(ctypes.byref(parent),b'workspace',12,4096),0)
        self.assertEqual(self.lib.ugel_capability_narrow(ctypes.byref(parent),4,1024,ctypes.byref(child)),0)
        self.assertEqual(bytes(child.resource_id),b'workspace');self.assertEqual(child.effects,4);self.assertEqual(child.max_text,1024)
    def test_length_delimited_text_including_nul(self):
        h=self.host();q=h.prepare_request('nul','sim.echo',{'text':'a\0b🌞'});expected=command(h.context['root'],h.pins()['head'],'PREVIEW',q)
        c=self.Context();values=[h.context['root'],h.pins()['head'],q['subject_root'],q['contract_root'],q['grant_root']]
        self.assertEqual(self.lib.ugel_context_init(ctypes.byref(c),*[s.encode() for s in values],1),0)
        cap=self.Cap();self.assertEqual(self.lib.ugel_capability_init(ctypes.byref(cap),b'simulation',2,100),0)
        raw='a\0b🌞'.encode();input_buffer=ctypes.create_string_buffer(raw);out=self.Buffer()
        try:
            self.assertEqual(self.lib.ugel_echo(ctypes.byref(c),ctypes.byref(cap),b'PREVIEW',b'nul',input_buffer,len(raw),q['evidence_roots'][0].encode(),ctypes.byref(out)),0)
            self.assertEqual(ctypes.string_at(out.data,out.length),canonical(expected))
        finally:self.lib.ugel_buffer_free(ctypes.byref(out))
        self.assertFalse(out.data);self.assertEqual(out.length,0)

class BrokerBridgeTests(Base):
    def test_preview_is_readonly(self):
        h=self.host();c=self.eq(h,'sum','sim.add',{'left':19,'right':23})
        before={str(p.relative_to(h.folder)):p.read_bytes() for p in h.folder.rglob('*') if p.is_file()}
        r,t=exchange(BUILD['c']['client'],c,h.handle)
        after={str(p.relative_to(h.folder)):p.read_bytes() for p in h.folder.rglob('*') if p.is_file()}
        self.assertEqual(r['status'],'PERMITTED');self.assertEqual(before,after);self.assertEqual(r['before_head'],r['after_head'])
    def test_inspect_is_readonly(self):
        h=self.host();before=h.pins();files=sorted(str(p) for p in h.folder.rglob('*'))
        r,t=exchange(BUILD['c']['client'],control(h.context['root'],before['head'],'INSPECT'),h.handle)
        self.assertEqual(r['status'],'INSPECTED');self.assertEqual(h.pins(),before);self.assertEqual(files,sorted(str(p) for p in h.folder.rglob('*')))
    def test_native_execution_receipt_is_unchanged_batch_a_schema(self):
        h=self.host();c=self.eq(h,'sum','sim.add',{'left':19,'right':23},'RUN');r,t=exchange(BUILD['c']['client'],c,h.handle)
        self.assertEqual(r['status'],'COMPLETED');self.assertEqual(r['receipt']['schema'],'mosaic.ugel.batch-a.receipt.v1');self.assertEqual(r['receipt']['authenticity'],'UNSIGNED_LOCAL_REFERENCE')
    def test_observation_can_finalize_without_adapters(self):
        h=self.host();q=h.prepare_request('sum','sim.add',{'left':19,'right':23})
        r,_=exchange(BUILD['c']['client'],command(h.context['root'],h.pins()['head'],'OBSERVE',q),h.handle);self.assertEqual(r['status'],'OBSERVED')
        new=EffectSession(h.folder,h.context['root'],clock=lambda:1000)
        r,_=exchange(BUILD['c']['client'],control(h.context['root'],new.pins()['head'],'FINALIZE','sum'),new.handle)
        self.assertEqual(r['status'],'COMPLETED');self.assertEqual(len(new.ledger.events()),4)
    def test_duplicate_completed_request_returns_receipt_without_dispatch(self):
        h=self.host();q=h.prepare_request('sum','sim.add',{'left':19,'right':23});r=h.handle(command(h.context['root'],h.pins()['head'],'RUN',q));head=h.pins()['head']
        r2,_=exchange(BUILD['c']['client'],command(h.context['root'],head,'RUN',q),h.handle)
        self.assertEqual(r2['receipt'],r['receipt']);self.assertEqual(h.pins()['head'],head)
    def test_native_cancellation_is_durable(self):
        h=self.host();q=h.prepare_request('sum','sim.add',{'left':1,'right':2});h.handle(command(h.context['root'],h.pins()['head'],'ADMIT',q))
        r,_=exchange(BUILD['c']['client'],control(h.context['root'],h.pins()['head'],'CANCEL','sum'),h.handle)
        reopened=EffectSession(h.folder,h.context['root'],clock=lambda:1000)
        self.assertEqual(r['status'],'CANCELLED');self.assertEqual(reopened._broker(adapters=False).inspect()['operations']['sum']['state'],'CANCELLED')
    def test_effect_export_rederives_receipts_and_delivery(self):
        h=self.host();q=h.prepare_request('sum','sim.add',{'left':19,'right':23});exchange(BUILD['c']['client'],command(h.context['root'],h.pins()['head'],'RUN',q),h.handle)
        bundle=h.export(expected_head=h.pins()['head'],acknowledge_plaintext=True);r=verify_export(bundle,export_root=bundle['root'],**h.pins())
        self.assertEqual(r['status'],'CONSISTENT_WITH_PINNED_A_RECORDS');self.assertFalse(r['signature_authentication'])
    def test_controlled_files_are_created_and_read_through_broker(self):
        h=self.host(True);text='bound native output\n';q=h.prepare_request('create','fs.create',{'name':'out.txt','text':text})
        r,_=exchange(BUILD['c']['client'],command(h.context['root'],h.pins()['head'],'RUN',q),h.handle);self.assertEqual(r['receipt']['effect_scope'],'LOCAL_FILESYSTEM_CREATE')
        q=h.prepare_request('read','fs.read',{'name':'out.txt','expected_sha256':byte_digest(text.encode()),'max_bytes':200})
        r,_=exchange(BUILD['c']['client'],command(h.context['root'],h.pins()['head'],'RUN',q),h.handle);self.assertEqual(bytes.fromhex(r['content_hex']),text.encode())
    def test_python_and_native_simulation_histories_match(self):
        r=comparison(BUILD,self.t/'comparison');self.assertTrue(r['request_bytes_equal']);self.assertTrue(r['decision_receipt_and_history_roots_equal'])
    def test_fresh_process_finalization_workflow(self):
        r=filesystem_demo(BUILD,self.t/'filesystem');self.assertTrue(r['fresh_process_finalization']);self.assertEqual(r['event_count'],10)

class SignedHostBridgeTests(Base):
    def test_native_command_reaches_existing_signed_python_check(self):
        r=signed_host_demo(BUILD,self.t/'signed-host');self.assertEqual(r['status'],'PASS');self.assertEqual(r['tests_run'],6)
        self.assertEqual(r['failures'],0);self.assertFalse(r['private_keys_exported']);self.assertEqual(r['native_client_containment'],'NOT_ESTABLISHED')
        self.assertEqual(r['parent_witness']['Seccomp'],'2');self.assertEqual(r['parent_witness']['NoNewPrivs'],'1')

class DistributionTests(Base):
    def test_exact_batch_c_archive(self):self.assertEqual(hashlib.sha256((ROOT/'predecessors/UGEL-BATCH-C-r001.zip').read_bytes()).hexdigest(),'204012120178a871a32dcf2939e2338fb8946a618c4f9f248bd7a5afc8b04ef8')
    def test_all_inherited_c_payload_bytes(self):
        with zipfile.ZipFile(ROOT/'predecessors/UGEL-BATCH-C-r001.zip') as z:
            expected=set(z.namelist());actual={p.relative_to(ROOT/'compatibility/batch-c').as_posix() for p in (ROOT/'compatibility/batch-c').rglob('*') if p.is_file()}
            self.assertEqual(actual,expected)
            for name in expected:self.assertEqual((ROOT/'compatibility/batch-c'/name).read_bytes(),z.read(name))
    def test_basic_orientation_is_standard_library_only(self):
        p=subprocess.run([sys.executable,'-S','-B',str(ROOT/'run.py'),'orient'],capture_output=True,timeout=10)
        self.assertEqual(p.returncode,0);r=json.loads(p.stdout);self.assertEqual(r['native_ugk_binding'],'NOT_BOUND')
    def test_rust_crate_has_no_external_dependencies(self):
        import tomllib
        c=tomllib.loads((ROOT/'native/rust/Cargo.toml').read_text());self.assertEqual(c['dependencies'],{});self.assertIn('#![forbid(unsafe_code)]',(ROOT/'native/rust/src/lib.rs').read_text())
    def test_rust_execution_status_is_explicit(self):
        self.assertIn(BUILD['rust']['status'],{'NOT_RUN','BUILT_AND_TESTED'})
        if BUILD['rust']['status']=='NOT_RUN':self.assertEqual(BUILD['rust']['tests_run'],0);self.assertTrue(BUILD['rust']['required_for_full_batch_d'])
    def test_native_outputs_are_bound_to_build_record(self):
        for lane in [BUILD['c'],BUILD['alternate_c']]:
            if lane['status']=='BUILT':
                p=Path(lane['client']);self.assertEqual(byte_digest(p.read_bytes()),lane['artifacts']['ugel-client']['sha256'])
    def test_native_wire_contract_matches_supported_actions(self):
        spec=json.loads((ROOT/'spec/NATIVE-WIRE.json').read_bytes())
        from ugel_native.protocol import EFFECT_ACTIONS,CONTROL_ACTIONS
        self.assertEqual(spec['actions'],sorted(EFFECT_ACTIONS|CONTROL_ACTIONS));self.assertEqual(spec['max_text_utf8_bytes'],65536)
    def test_same_ceiling_without_native_sandbox_claim(self):
        spec=json.loads((ROOT/'spec/NATIVE-BINDING.json').read_bytes());self.assertEqual(spec['native_ugk_binding'],'NOT_BOUND');self.assertEqual(spec['native_client_containment'],'NOT_ESTABLISHED')
    def test_no_private_keys_or_build_outputs_in_source(self):
        names=[p.name for p in ROOT.rglob('*') if p.is_file()]
        self.assertFalse(any(n.endswith(('.key','.o','.so','.rlib')) for n in names))
