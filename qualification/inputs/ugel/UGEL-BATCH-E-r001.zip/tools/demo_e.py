"""Ordinary positive local witness + governed D effect demonstration.
Temporary keys are never exported. The output is fixture evidence only.
"""
import json,hashlib,tempfile
from pathlib import Path
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization
from ugel_component.boundary import make_policy
from ugel_component.host import ComponentHost
from ugel_component.independent import verify_export_structure
from ugel_component.witness import make_statement,sign_witness,verify_witness
from ugel_native.effects import EffectSession,verify_export
from ugel_native.protocol import digest

def demo():
    with tempfile.TemporaryDirectory(prefix='ugel-e-demo-') as t:
        subject=digest({'purpose':'batch-e-positive-demo','revision':1})
        session=EffectSession.initialize(Path(t)/'task',subject_root=subject,expected_subject_root=subject,now=1000,clock=lambda:1000)
        policy=make_policy(b'non-executable-WASI-placeholder',session.context['contract']['root'],['sim.add'],['simulation'])
        host=ComponentHost(session,policy,policy['root'])
        q=session.prepare_request('sum','sim.add',{'left':40,'right':2})
        call={'schema':'mosaic.ugel.batch-e.guest-call.v1','policy_root':policy['root'],'action':'RUN','request':{k:v for k,v in q.items() if k!='root'}}
        result=host.submit_call(call,session.pins()['head'])
        exported=session.export(expected_head=session.pins()['head'],acknowledge_plaintext=True)
        pins={**session.pins(),'export_root':exported['root']}
        structural=verify_export_structure(exported,{k:pins[k] for k in ('export_root','context_root','head')})
        semantic=verify_export(exported,**pins)
        key=Ed25519PrivateKey.generate()
        pub=key.public_key().public_bytes(encoding=serialization.Encoding.Raw,format=serialization.PublicFormat.Raw)
        statement=make_statement(exported['root'],policy['root'],witness_id='demo-ephemeral',clock=lambda:1000)
        signed=sign_witness(statement,key)
        witness=verify_witness(signed,pub,exported['root'],hashlib.sha256(pub).hexdigest())
        assert result['d_response']['status']=='COMPLETED'
        return {'schema':'mosaic.ugel.batch-e.demo.v1','status':'PASS_POSITIVE_LOCAL_REFERENCE',
             'd_receipt_root':result['d_response']['receipt']['root'],
             'effect_export_root':exported['root'],'policy_root':policy['root'],
             'structural_assessment':structural,'d_semantic_replay_status':semantic['status'],
             'signed_local_witness':signed,'public_key_hex':pub.hex(),'witness_verification':witness,
             'wasi_guest_executed':False,'rust_executed':False,'private_key_exported':False,
             'independent_timestamp':False,'external_notary':False}
if __name__=='__main__':print(json.dumps(demo(),sort_keys=True,indent=2))
