"""Deterministic additive Batch E package builder. No candidate execution."""
import sys,json,hashlib,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
PRED=hashlib.sha256((ROOT/'compatibility/UGEL-BATCH-D-r001.zip').read_bytes()).hexdigest()
def canon(x):return json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False).encode('ascii')
def build(out):
    files={}
    for p in ROOT.rglob('*'):
        if not p.is_file():continue
        name=p.relative_to(ROOT).as_posix()
        if name=='PACKAGE-MANIFEST.json' or '__pycache__' in p.parts or p.suffix in {'.pyc','.pyo'}:continue
        if p.is_symlink():raise ValueError('SYMLINK')
        files[name]=p.read_bytes()
    rows=[dict(path=n,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()) for n,b in sorted(files.items())]
    m={'schema':'mosaic.ugel.batch-e.package-manifest.v1','predecessor_sha256':PRED,'files':rows,
       'member_count':len(rows)+1,'standing':'INFORMATION_ONLY','authority_effect':'NONE','real_a5':False,'g0':'CLOSED'}
    files['PACKAGE-MANIFEST.json']=canon(m)+b'\n'
    with zipfile.ZipFile(out,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for n,b in sorted(files.items()):
            info=zipfile.ZipInfo(n,(1980,1,1,0,0,0));info.create_system=3;info.external_attr=0o100644<<16
            z.writestr(info,b,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    x=Path(out).read_bytes()
    return {'sha256':hashlib.sha256(x).hexdigest(),'bytes':len(x),'file_count':len(files),'predecessor_sha256':PRED}
if __name__=='__main__':print(build(sys.argv[1]))
