"""Generate bounded evidence for Batch E; run by operator after checks."""
from pathlib import Path
import json,hashlib,platform,sys,subprocess,os,tempfile,shutil
ROOT=Path(__file__).resolve().parents[1]
def canon(x):return json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False).encode('ascii')
rows=[]
for p in ROOT.rglob('*'):
    if not p.is_file():continue
    n=p.relative_to(ROOT).as_posix()
    if n.startswith(('evidence/','release/')) or '__pycache__' in p.parts or p.suffix in {'.pyc','.pyo'} or n=='PACKAGE-MANIFEST.json':continue
    b=p.read_bytes();rows.append({'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
rows.sort(key=lambda x:x['path'])
source={'schema':'mosaic.ugel.batch-e.source.v1','files':rows,'file_count':len(rows)}
source['root']=hashlib.sha256(b'MOSAIC-UGEL-E1\x00'+canon(source)).hexdigest()
(ROOT/'evidence/SOURCE-MANIFEST.json').write_bytes(canon(source)+b'\n')
env=os.environ.copy();env['PYTHONPATH']=':'.join(str(ROOT/p) for p in ['src','compatibility/batch-d/src','compatibility/batch-d/compatibility/batch-c/src','compatibility/batch-d/compatibility/batch-c/compatibility/batch-b/src'])
# Re-run positive suite against exact source with bytecode disabled.
cmd=[sys.executable,'-B','-m','unittest','discover','-s',str(ROOT/'tests'),'-v']
a=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=40)
(ROOT/'evidence/REFERENCE-CHECKS.log').write_text(a.stdout+a.stderr)
if a.returncode!=0:raise RuntimeError(a.stderr)
with tempfile.TemporaryDirectory(prefix='ugel-e-clean-') as t:
    fresh=Path(t)/'source';fresh.mkdir()
    for row in rows:
        dest=fresh/row['path'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((ROOT/row['path']).read_bytes())
    env2=os.environ.copy();env2['PYTHONPATH']=':'.join(str(fresh/p) for p in ['src','compatibility/batch-d/src','compatibility/batch-d/compatibility/batch-c/src','compatibility/batch-d/compatibility/batch-c/compatibility/batch-b/src'])
    b=subprocess.run([sys.executable,'-B','-m','unittest','discover','-s',str(fresh/'tests'),'-v'],env=env2,capture_output=True,text=True,timeout=40)
    if b.returncode!=0:raise RuntimeError(b.stderr)
    (ROOT/'evidence/CLEAN-REPRODUCTION.log').write_text(b.stdout+b.stderr)
    for row in rows:
        if hashlib.sha256((ROOT/row['path']).read_bytes()).hexdigest()!=row['sha256']:raise RuntimeError('SOURCE_CHANGED')
        if hashlib.sha256((fresh/row['path']).read_bytes()).hexdigest()!=row['sha256']:raise RuntimeError('CLEAN_SOURCE_CHANGED')
record={'schema':'mosaic.ugel.batch-e.reference-checks.v1','status':'PASS_20_REFERENCE_TESTS',
   'distinct_tests':20,'first_run_pass':20,'clean_run_pass':20,'first_run_failures':0,'clean_run_failures':0,
   'source_root':source['root'],'source_files':len(rows),'rust_runtime':'NOT_RUN_TOOLCHAIN_UNAVAILABLE',
   'wasi_component_runtime':'NOT_RUN_RUNTIME_UNAVAILABLE','adversarial_tests':'NOT_RUN',
   'independent_witness_time':'NOT_ESTABLISHED','host':{'python':platform.python_version(),'platform':platform.platform()},
   'predecessor_sha256':hashlib.sha256((ROOT/'compatibility/UGEL-BATCH-D-r001.zip').read_bytes()).hexdigest(),
   'constitutional_authority':'NONE','native_ugk':'NOT_BOUND'}
record['root']=hashlib.sha256(b'MOSAIC-UGEL-E1\x00'+canon(record)).hexdigest()
(ROOT/'evidence/REFERENCE-CHECKS.json').write_bytes(canon(record)+b'\n')
print(json.dumps(record,indent=2))
