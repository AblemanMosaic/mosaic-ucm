"""Standalone passive verification of an E package archive. No source execution."""
import sys,hashlib,json,zipfile,argparse
from pathlib import Path

def verify(path,expected_sha):
    b=Path(path).read_bytes()
    if hashlib.sha256(b).hexdigest()!=expected_sha:raise ValueError('EXTERNAL_ARCHIVE_PIN')
    with zipfile.ZipFile(path) as z:
        names=z.namelist()
        if len(names)!=len(set(names)) or any(n.startswith('/') or '..' in Path(n).parts for n in names):raise ValueError('ARCHIVE_MEMBERS')
        if 'PACKAGE-MANIFEST.json' not in names:raise ValueError('MANIFEST_MISSING')
        m=json.loads(z.read('PACKAGE-MANIFEST.json'))
        rows=m['files'];expect={r['path']:r for r in rows}
        if len(expect)!=len(rows) or set(names)!=(set(expect)|{'PACKAGE-MANIFEST.json'}):raise ValueError('INVENTORY')
        for n,r in expect.items():
            b=z.read(n)
            if len(b)!=r['bytes'] or hashlib.sha256(b).hexdigest()!=r['sha256']:raise ValueError('MEMBER_IDENTITY:'+n)
        if m['standing']!='INFORMATION_ONLY' or m['authority_effect']!='NONE' or m['real_a5'] is not False or m['g0']!='CLOSED':raise ValueError('AUTHORITY')
        if hashlib.sha256(z.read('compatibility/UGEL-BATCH-D-r001.zip')).hexdigest()!=m['predecessor_sha256']:raise ValueError('D_PRESERVATION')
    return {'status':'PASS_PASSIVE_INVENTORY','member_count':len(names),'candidate_imports':0,'candidate_invocations':0,
            'source_execution':False,'effect_semantics_verified':False,'wasi_runtime_verified':False}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('archive');p.add_argument('--expected-sha256',required=True);args=p.parse_args()
    print(json.dumps(verify(args.archive,args.expected_sha256),sort_keys=True,indent=2))
