# UGEL Batch E r001 — portable boundary, custody verifier, witness interface

**Experimental, INFORMATION_ONLY; constitutional authority effect NONE; real A5 false; G0 CLOSED.**

Batch E extends, without modifying, the frozen UGEL Batch D r001 package. It adds:

1. A versioned WIT Component Model interface declaring mediated effect requests.
2. A Python host-side adapter binding guest-shaped operations to an existing, unchanged Batch D EffectSession and its original Batch A broker.
3. A separate standard-library-only structural evidence verifier and package verifier.
4. Optional Ed25519 local witness records binding subject, policy and semantic-regime roots with a **local, untrusted clock claim**.
5. Ordinary positive/reference tests and exact packaged provenance.

## What is not implemented

**No WebAssembly component was instantiated or executed.** No Wasmtime or other WASI runtime is installed on this host. `ComponentHost.run_wasm()` refuses as `WASI_COMPONENT_RUNTIME_NOT_BOUND`. The WIT declaration does not establish that untrusted guest calls cannot bypass a host boundary. There is no guest binary, guest sandbox assurance, or independent component-model conformance result.

The independent verifier checks structural custody. It does **not** rederive all Batch A/D effect semantics. Those remain verified by the inherited D replay implementation. Ed25519 signatures verify local key possession, **not independent time, legal identity, external notarization, ZKP, or tamper resistance against the host owner**. No remote services contacted.

The inherited Rust adapter remains **NOT_RUN**. The previous Batch C seccomp profile applies only to the exact Python child, not to C/Rust or proposed WASI components.

## Test and usage

With prepared Python 3.12/3.13 and the optional prepared `cryptography` dependency for signing tests:

```console
PYTHONPATH=src:compatibility/batch-d/src:compatibility/batch-d/compatibility/batch-c/src:compatibility/batch-d/compatibility/batch-c/compatibility/batch-b/src python -m unittest discover -s tests -v
```

The E module imports its independent verifier without requiring cryptography; signing imports it only at the point of use. Test records under `evidence/` report what was actually run.

`python tools/independent_verify.py UGEL-BATCH-E-r001.zip --expected-sha256 <external-pin>` passively verifies the package.

A host may create `ComponentHost(session,policy,expected_policy_root)` for a trusted and already opened D session; `submit_call()` checks policy and lowers through D's own broker. Guest execution is deliberately unavailable until a separately qualified WASI executor is supplied.

## Continuation

Close Rust compile/conformance; bind a real component runtime and import enforcement; perform separate bounded host and security review; add independent semantic verifier and optional external timestamp/witness providers. Do not promote the existing local witness into an external timestamp authority.
