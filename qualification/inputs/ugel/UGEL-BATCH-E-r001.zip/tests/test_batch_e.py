import unittest,tempfile,hashlib,os
from pathlib import Path
from ugel_component.boundary import make_policy,validate_policy,validate_guest_call,canon,root
from ugel_component.host import check_wit,ComponentHost
from ugel_component.witness import make_statement,verify_statement,sign_witness,verify_witness
from ugel_component.independent import verify_export_structure

class ContractTests(unittest.TestCase):
    def setUp(self):
        self.policy=make_policy(b'guest-example', 'a'*64,['sim.add'],['simulation'])
        self.call={'schema':'mosaic.ugel.batch-e.guest-call.v1','policy_root':self.policy['root'],'action':'RUN',
            'request':{'effect':'sim.add','resource_id':'simulation','parameters':{'left':1,'right':2}}}
    def test_contract_pinned(self):self.assertEqual(validate_policy(self.policy,self.policy['root']),self.policy)
    def test_guest_call(self):self.assertEqual(validate_guest_call(self.call,self.policy,self.policy['root'])['effect'],'sim.add')
    def test_no_extra_policy_fields(self):
        x={**self.policy,'untrusted':True}
        with self.assertRaises(ValueError):validate_policy(x,self.policy['root'])
    def test_no_unbound_effect(self):
        self.call['request']['effect']='fs.create'
        with self.assertRaises(ValueError):validate_guest_call(self.call,self.policy,self.policy['root'])
    def test_no_unbound_resource(self):
        self.call['request']['resource_id']='workspace'
        with self.assertRaises(ValueError):validate_guest_call(self.call,self.policy,self.policy['root'])
    def test_no_unbound_action(self):
        self.call['action']='HOST_EXECUTE'
        with self.assertRaises(ValueError):validate_guest_call(self.call,self.policy,self.policy['root'])
    def test_pin_required(self):
        with self.assertRaises(ValueError):validate_guest_call(self.call,self.policy,'0'*64)
    def test_no_root_relabel(self):
        x={**self.policy,'max_text_bytes':5}
        with self.assertRaises(ValueError):validate_policy(x,self.policy['root'])
    def test_policy_finite_effects(self):
        with self.assertRaises(ValueError):make_policy(b'guest','a'*64,['fs.delete'],['simulation'])
    def test_wit_contract(self):
        f=Path(__file__).resolve().parents[1]/'spec/ugel-effects.wit'
        self.assertEqual(check_wit(f)['runtime_execution'],'NOT_RUN')
    def test_wasm_fail_closed(self):
        class S:pass
        s=S();s.context={'contract':{'root':'a'*64}}
        host=ComponentHost(s,self.policy,self.policy['root'])
        with self.assertRaisesRegex(RuntimeError,'NOT_BOUND'):host.run_wasm(b'guest')

class WitnessTests(unittest.TestCase):
    def test_statement(self):
        s=make_statement('a'*64,'b'*64,witness_id='local-01',clock=lambda:123)
        self.assertEqual(verify_statement(s)['claimed_unix_seconds'],123)
        self.assertEqual(s['time_source'],'LOCAL_HOST_CLOCK_UNTRUSTED')
    def test_statement_pin_change(self):
        s=make_statement('a'*64,'b'*64,witness_id='local-01',clock=lambda:123);s['subject_root']='c'*64
        with self.assertRaises(ValueError):verify_statement(s)
    def test_signed_witness(self):
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
        from cryptography.hazmat.primitives import serialization
        private=Ed25519PrivateKey.generate()
        pub=private.public_key().public_bytes(encoding=serialization.Encoding.Raw,format=serialization.PublicFormat.Raw)
        s=make_statement('a'*64,'b'*64,witness_id='local',clock=lambda:123)
        signed=sign_witness(s,private)
        result=verify_witness(signed,pub,'a'*64,hashlib.sha256(pub).hexdigest())
        self.assertFalse(result['timestamp_independently_verified'])
        self.assertFalse(result['legal_notarization'])
    def test_witness_wrong_pin(self):
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
        from cryptography.hazmat.primitives import serialization
        priv=Ed25519PrivateKey.generate();pub=priv.public_key().public_bytes(encoding=serialization.Encoding.Raw,format=serialization.PublicFormat.Raw)
        s=sign_witness(make_statement('a'*64,'b'*64,witness_id='local',clock=lambda:2),priv)
        with self.assertRaises(ValueError):verify_witness(s,pub,'c'*64,hashlib.sha256(pub).hexdigest())

class BrokerIntegrationTests(unittest.TestCase):
    def test_mediated_d_effect_and_independent_structural_check(self):
        from ugel_native.effects import EffectSession,verify_export
        from ugel_native.protocol import digest
        with tempfile.TemporaryDirectory(prefix='ugel-e-positive-') as t:
            subject=digest({'purpose':'ugel-e-ordinary-positive'})
            session=EffectSession.initialize(Path(t)/'session',subject_root=subject,expected_subject_root=subject,now=1000,clock=lambda:1000)
            policy=make_policy(b'known-guest-placeholder',session.context['contract']['root'],['sim.add'],['simulation'])
            host=ComponentHost(session,policy,policy['root'])
            q=session.prepare_request('sum','sim.add',{'left':19,'right':23})
            call={'schema':'mosaic.ugel.batch-e.guest-call.v1','policy_root':policy['root'],'action':'RUN',
                'request':{k:v for k,v in q.items() if k!='root'}}
            response=host.submit_call(call,session.pins()['head'])
            self.assertEqual(response['d_response']['status'],'COMPLETED')
            exported=session.export(expected_head=session.pins()['head'],acknowledge_plaintext=True)
            pins={**session.pins(),'export_root':exported['root']}
            independent=verify_export_structure(exported,{k:pins[k] for k in ('export_root','context_root','head')})
            original=verify_export(exported,**pins)
            self.assertEqual(independent['status'],'PASS_STRUCTURAL_CUSTODY_ONLY')
            self.assertEqual(original['status'],'CONSISTENT_WITH_PINNED_A_RECORDS')
            self.assertEqual(independent['exchange_count'],1)
            self.assertFalse(independent['effect_semantics_verified'])
    def test_inspect_missing_storage_does_not_initialize(self):
        # A policy model's inspect operation does not create any filesystem state.
        with tempfile.TemporaryDirectory(prefix='ugel-e-inspect-') as t:
            before=list(Path(t).iterdir())
            check_wit(Path(__file__).resolve().parents[1]/'spec/ugel-effects.wit')
            self.assertEqual(before,list(Path(t).iterdir()))

class PreservationTests(unittest.TestCase):
    def test_canonical_batch_d_archive_exact(self):
        d=Path(__file__).resolve().parents[1]/'compatibility/UGEL-BATCH-D-r001.zip'
        self.assertEqual(hashlib.sha256(d.read_bytes()).hexdigest(),'d7c3278e994d4bb0f29ff79640066787886b3fa50e336ffad7838704a98f3a71')
    def test_d_source_tree_matches_original_zip(self):
        import zipfile
        root=Path(__file__).resolve().parents[1]/'compatibility'
        with zipfile.ZipFile(root/'UGEL-BATCH-D-r001.zip') as z:
            for n in z.namelist():
                self.assertEqual((root/'batch-d'/n).read_bytes(),z.read(n))
    def test_independent_verifier_is_stdlib_only(self):
        import ast
        p=Path(__file__).resolve().parents[1]/'tools/independent_verify.py'
        imports=[n for n in ast.walk(ast.parse(p.read_text())) if isinstance(n,(ast.Import,ast.ImportFrom))]
        modules=[]
        for i in imports:
            if isinstance(i,ast.Import):modules.extend(j.name.split('.')[0] for j in i.names)
            else:modules.append((i.module or '').split('.')[0])
        self.assertTrue(set(modules)<=set(['sys','hashlib','json','zipfile','argparse','pathlib']))
