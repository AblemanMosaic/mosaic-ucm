"""A local host adapter for accepted component-call JSON.
An actual WASI Component Model executor is unbound, and is never simulated as one.
"""
import json
from pathlib import Path
from .boundary import GuestBoundary,canon,demand

class ComponentHost:
    def __init__(self,session,policy,pin):
        self.boundary=GuestBoundary(session,policy,pin)
        self.pin=pin
    def submit_call(self,call,expected_head):
        """Host-side mediation for guest-shaped records; no guest binary executes."""
        return self.boundary.invoke(call,expected_head)
    def run_wasm(self,*args,**kwargs):
        raise RuntimeError('WASI_COMPONENT_RUNTIME_NOT_BOUND')

def check_wit(path):
    b=Path(path).read_bytes()
    demand(len(b)<=100000 and b'world governed-guest' in b and b'import governed-effects' in b,'WIT_CONTRACT')
    import hashlib
    return {'sha256':hashlib.sha256(b).hexdigest(),'runtime_execution':'NOT_RUN','component_host':'NOT_BOUND'}
