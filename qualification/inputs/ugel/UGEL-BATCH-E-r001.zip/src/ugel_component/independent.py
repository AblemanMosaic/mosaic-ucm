"""Independent, standard-library-only structural/custody verifier.
It does NOT claim to reproduce Batch A/D operational semantics or cryptographic signatures.
"""
import hashlib,json
from .boundary import canon,sha,root,demand,CEILING
D_DOMAIN=b'MOSAIC-UGEL-D1\x00'

def droot(obj):return hashlib.sha256(D_DOMAIN+canon(obj)).hexdigest()
def dr(x):
    demand(type(x) is dict and 'root' in x and sha(x['root']),'ROOT_FIELD')
    demand(droot({k:v for k,v in x.items() if k!='root'})==x['root'],'D_ROOT_MISMATCH')

def verify_export_structure(export,external):
    demand(type(external) is dict and set(external)=={'export_root','context_root','head'},'PINS_FIELDS')
    for k in external:demand(sha(external[k]),'PIN_FORMAT')
    dr(export);demand(export.get('schema')=='mosaic.ugel.batch-d.effect-export.v1','EXPORT_SCHEMA')
    demand(export['root']==external['export_root'],'EXTERNAL_EXPORT_PIN')
    for k,v in CEILING.items():demand(export.get(k)==v,'AUTHORITY_CEILING')
    ctx=export['context'];dr(ctx);demand(ctx['root']==external['context_root'],'CONTEXT_PIN')
    bundle=export['bundle'];demand(type(bundle) is dict,'BUNDLE_TYPE')
    exchanges=export['exchanges'];demand(type(exchanges) is list,'EXCHANGES_TYPE')
    head=None
    for i,item in enumerate(exchanges):
        demand(type(item) is dict and set(item)=={'command','response'},'EXCHANGE_FIELDS')
        cmd=item['command'];resp=item['response'];dr(resp)
        demand(resp.get('schema')=='mosaic.ugel.batch-d.response.v1','RESPONSE_SCHEMA')
        demand(droot(cmd)==resp['command_root'],'COMMAND_BIND')
        demand(resp['context_root']==ctx['root'],'EXCHANGE_CONTEXT')
        if head is not None:demand(cmd['expected_head']==head and resp['before_head']==head,'EXCHANGE_CHAIN')
        else:demand(cmd['expected_head']==resp['before_head'],'FIRST_EXCHANGE')
        head=resp['after_head'];demand(sha(head),'HEAD_FORMAT')
    if head is not None:demand(head==external['head'],'FINAL_HEAD')
    # No external effects, native checkers or signature verification are run.
    body={'schema':'mosaic.ugel.batch-e.custody-assessment.v1','status':'PASS_STRUCTURAL_CUSTODY_ONLY',
          'export_root':export['root'],'context_root':ctx['root'],'exchange_count':len(exchanges),
          'effect_semantics_verified':False,'external_effects_verified':False,'signatures_verified':False,**CEILING}
    return {**body,'root':root(body)}
