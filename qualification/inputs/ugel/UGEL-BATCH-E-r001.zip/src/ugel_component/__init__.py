"""UGEL E: a constrained guest-command interface, not a WASI runtime."""
from .boundary import GuestBoundary, make_policy, validate_guest_call
from .witness import make_statement, verify_statement, sign_witness, verify_witness
from .independent import verify_export_structure
