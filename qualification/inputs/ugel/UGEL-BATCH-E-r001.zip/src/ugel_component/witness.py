"""Optional receipt witness with precise local-time and trust limitations."""
import hashlib,time
from .boundary import canon,root,demand,sha,CEILING

def make_statement(subject_root,policy_root,*,witness_id,clock=None,regime_root=None):
    demand(sha(subject_root) and sha(policy_root),'WITNESS_SUBJECT_PIN')
    demand(type(witness_id) is str and 0<len(witness_id)<=128,'WITNESS_ID')
    demand(regime_root is None or sha(regime_root),'REGIME_ROOT')
    now=int((clock or time.time)());demand(now>=0,'HOST_CLOCK')
    body={'schema':'mosaic.ugel.batch-e.witness-statement.v1','subject_root':subject_root,'policy_root':policy_root,
          'regime_root':regime_root,'witness_id':witness_id,'claimed_unix_seconds':now,
          'time_source':'LOCAL_HOST_CLOCK_UNTRUSTED','witness_claim':'LOCAL_OBSERVATION_NOT_INDEPENDENT_TIMESTAMP',**CEILING}
    return {**body,'root':root(body)}

def verify_statement(s):
    demand(type(s) is dict and s.get('schema')=='mosaic.ugel.batch-e.witness-statement.v1','STATEMENT_SCHEMA')
    demand(s.get('time_source')=='LOCAL_HOST_CLOCK_UNTRUSTED','TIME_SCOPE')
    demand(s.get('witness_claim')=='LOCAL_OBSERVATION_NOT_INDEPENDENT_TIMESTAMP','WITNESS_SCOPE')
    demand(all(s.get(k)==v for k,v in CEILING.items()),'STATEMENT_CEILING')
    demand(sha(s.get('subject_root')) and sha(s.get('policy_root')),'STATEMENT_PINS')
    demand(s.get('regime_root') is None or sha(s['regime_root']),'REGIME_FORMAT')
    demand(type(s.get('witness_id')) is str and 0<len(s['witness_id'])<=128,'STATEMENT_ISSUER')
    demand(type(s.get('claimed_unix_seconds')) is int and s['claimed_unix_seconds']>=0,'TIME_FORMAT')
    demand(s.get('root')==root({k:v for k,v in s.items() if k!='root'}),'STATEMENT_ROOT')
    return s

def sign_witness(statement,private_key):
    """Ed25519 signed witness. Host chooses and retains the key; no key generation here."""
    verify_statement(statement)
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives import serialization
    demand(isinstance(private_key,Ed25519PrivateKey),'SIGNER_TYPE')
    pub=private_key.public_key().public_bytes(encoding=serialization.Encoding.Raw,format=serialization.PublicFormat.Raw)
    body={'schema':'mosaic.ugel.batch-e.signed-witness.v1','statement':statement,
          'public_key_sha256':hashlib.sha256(pub).hexdigest(),
          'signature_hex':private_key.sign(canon(statement)).hex(),
          'trust_scope':'LOCAL_KEY_SIGNATURE_NO_INDEPENDENT_TIME_OR_LEGAL_NOTARY',**CEILING}
    return {**body,'root':root(body)}

def verify_witness(signed,public_key_raw,expected_subject_root,expected_public_key_sha256):
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    demand(type(signed) is dict and signed.get('schema')=='mosaic.ugel.batch-e.signed-witness.v1','SIGNED_SCHEMA')
    demand(signed.get('trust_scope')=='LOCAL_KEY_SIGNATURE_NO_INDEPENDENT_TIME_OR_LEGAL_NOTARY','SIGNATURE_SCOPE')
    demand(all(signed.get(k)==v for k,v in CEILING.items()),'SIGNED_CEILING')
    demand(signed.get('root')==root({k:v for k,v in signed.items() if k!='root'}),'SIGNED_ROOT')
    statement=verify_statement(signed['statement']);demand(statement['subject_root']==expected_subject_root,'SUBJECT_PIN')
    demand(type(public_key_raw) is bytes and len(public_key_raw)==32,'PUBLIC_KEY')
    digest=hashlib.sha256(public_key_raw).hexdigest()
    demand(digest==signed['public_key_sha256']==expected_public_key_sha256,'PUBLIC_KEY_PIN')
    sig=bytes.fromhex(signed['signature_hex']);Ed25519PublicKey.from_public_bytes(public_key_raw).verify(sig,canon(statement))
    return {'status':'VALID_LOCAL_SIGNATURE','statement_root':statement['root'],'timestamp_independently_verified':False,
            'issuer_identity_independently_verified':False,'legal_notarization':False}
