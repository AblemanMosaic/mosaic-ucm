"""Language-neutral capability calls mediated into unchanged Batch D commands.
No guest execution happens here. Host grants and session are externally supplied.
"""
import hashlib,json
from dataclasses import dataclass
from typing import Mapping

DOMAIN=b'MOSAIC-UGEL-E1\x00'
EFFECTS={'sim.add','sim.echo','fs.create','fs.read'}
ACTIONS={'PREVIEW','RUN','ADMIT','OBSERVE'}
CEILING={'standing':'INFORMATION_ONLY','authority_effect':'NONE','real_a5':False,'g0':'CLOSED'}

def canon(x):return json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False).encode('ascii')
def root(x):return hashlib.sha256(DOMAIN+canon(x)).hexdigest()
def demand(ok,reason):
    if not ok:raise ValueError(reason)
def sha(s):return isinstance(s,str) and len(s)==64 and all(c in '0123456789abcdef' for c in s)

def validate_policy(p,expected_root):
    demand(type(p) is dict and set(p)=={'schema','component_sha256','contract_root','allowed_effects','allowed_actions','resource_ids','max_text_bytes','root',*CEILING},'POLICY_FIELDS')
    demand(p['schema']=='mosaic.ugel.batch-e.component-policy.v1','POLICY_SCHEMA')
    demand(all(p[k]==v for k,v in CEILING.items()),'POLICY_CEILING')
    demand(sha(p['component_sha256']) and sha(p['contract_root']),'POLICY_IDENTITIES')
    demand(type(p['allowed_effects']) is list and p['allowed_effects']==sorted(set(p['allowed_effects'])) and set(p['allowed_effects'])<=EFFECTS,'POLICY_EFFECTS')
    demand(type(p['allowed_actions']) is list and p['allowed_actions']==sorted(set(p['allowed_actions'])) and set(p['allowed_actions'])<=ACTIONS,'POLICY_ACTIONS')
    demand(type(p['resource_ids']) is list and p['resource_ids']==sorted(set(p['resource_ids'])) and all(type(s) is str and s for s in p['resource_ids']),'POLICY_RESOURCES')
    demand(type(p['max_text_bytes']) is int and 0<=p['max_text_bytes']<=65536,'POLICY_SIZE')
    demand(root({k:v for k,v in p.items() if k!='root'})==p['root']==expected_root,'POLICY_PIN')
    return p

def make_policy(component,contract_root,effects,resources,actions=('PREVIEW','RUN'),max_text_bytes=65536):
    demand(type(component) is bytes,'COMPONENT_BYTES')
    body=dict(schema='mosaic.ugel.batch-e.component-policy.v1',component_sha256=hashlib.sha256(component).hexdigest(),contract_root=contract_root,
              allowed_effects=sorted(set(effects)),allowed_actions=sorted(set(actions)),resource_ids=sorted(set(resources)),max_text_bytes=max_text_bytes,**CEILING)
    p={**body,'root':root(body)}
    return validate_policy(p,p['root'])

def validate_guest_call(call,policy,expected_policy_root):
    validate_policy(policy,expected_policy_root)
    demand(type(call) is dict and set(call)=={'schema','policy_root','action','request'},'CALL_FIELDS')
    demand(call['schema']=='mosaic.ugel.batch-e.guest-call.v1' and call['policy_root']==expected_policy_root,'CALL_POLICY')
    demand(call['action'] in policy['allowed_actions'],'CALL_ACTION')
    q=call['request']
    demand(type(q) is dict and q.get('effect') in policy['allowed_effects'],'CALL_EFFECT')
    demand(q.get('resource_id') in policy['resource_ids'],'CALL_RESOURCE')
    demand(type(q.get('parameters')) is dict,'CALL_PARAMETERS')
    p=q['parameters']
    if 'text' in p:demand(type(p['text']) is str and len(p['text'].encode('utf-8'))<=policy['max_text_bytes'],'CALL_TEXT_LIMIT')
    # D will independently validate all operation, grant, policy, epoch, schema and head fields.
    return q

class GuestBoundary:
    """A bound D EffectSession. Guest supplies requests but never a grant or session.
    Exact signed/unsigned D authority semantics remain those of the host session.
    """
    def __init__(self,session,policy,expected_policy_root):
        self.session=session;self.policy=validate_policy(policy,expected_policy_root)
        demand(self.policy['contract_root']==session.context['contract']['root'],'SESSION_CONTRACT')
    def invoke(self,call,expected_head):
        q=validate_guest_call(call,self.policy,self.policy['root'])
        from ugel_native.protocol import command
        from ugel.contracts import validate
        from ugel.canonical import seal
        # The full request is checked against the fixed session context by D itself.
        qr=validate('request',seal(q))
        cmd=command(self.session.context['root'],expected_head,call['action'],qr)
        response=self.session.handle(cmd)
        return {'schema':'mosaic.ugel.batch-e.mediated-response.v1','policy_root':self.policy['root'],
                'd_response':response,'subject_binding':'UNCHANGED_BATCH_D_EFFECT_SESSION',**CEILING}
