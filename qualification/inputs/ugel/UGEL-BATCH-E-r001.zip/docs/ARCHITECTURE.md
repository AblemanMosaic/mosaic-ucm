# Batch E architecture and assurance contract

The WIT interface and `GuestBoundary` have different roles: WIT documents a future component-host interface, while `GuestBoundary` mediates records submitted by an already trusted host. The latter calls unchanged Batch D, which lowers to Batch A. It does not import UGK authority, issue grants or execute WASI code.

**Source-of-authority rules:** Host supplies the accepted D session, contract and current expected head. The component policy pins a guest binary SHA-256 but has no power to authenticate a runtime binary until a component executor checks that pin. Caller-selected policy cannot mint a grant. Any host omission of capability isolation is `NOT_ESTABLISHED`.

**Independent verification:** `ugel_component.independent` uses its own D-domain hash implementation, exact-root and transcript-chain checks. It intentionally returns `PASS_STRUCTURAL_CUSTODY_ONLY`. Complete D semantic verification still requires D's own `verify_export()` or another independently developed semantic verifier. It imports no candidate modules.

**Witness:** A statement records subject root, policy root, optional regime root, witness ID, and claimed wall-clock second. The issuer can Ed25519 sign its canonical JSON; acceptance checks the externally pinned public key and subject. Host time remains untrusted. Clock disputes, cross-service time consistency, independent witnessing, ZKP and notarization are not provided.

**Continuity:** No D effect retries on transport uncertainty. New C/Rust/WASI activity cannot enlarge signed C or unsigned A authority. Receipt historical correspondence and real UGK integration remain unbound.
