from __future__ import annotations
import argparse, hashlib, json, tempfile, zipfile
from pathlib import Path, PurePosixPath

def sha_file(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

def canon(v): return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode('utf-8')

def safe_extract(archive,dst):
    seen=set()
    with zipfile.ZipFile(archive,'r') as z:
        for info in z.infolist():
            name=info.filename.replace('\\','/')
            p=PurePosixPath(name)
            if not name or name.startswith('/') or '..' in p.parts or p.is_absolute() or name in seen:
                raise SystemExit('REFUSED_UNSAFE_ARCHIVE:'+name)
            seen.add(name)
            if info.is_dir(): continue
            target=dst.joinpath(*p.parts); target.parent.mkdir(parents=True,exist_ok=True)
            with z.open(info) as src, target.open('wb') as out: out.write(src.read())

def verify(root):
    manifest=json.loads((root/'PACKAGE-MANIFEST.json').read_text(encoding='utf-8'))
    body=dict(manifest); claimed=body.pop('manifest_root')
    actual=hashlib.sha256(canon(body)).hexdigest()
    if actual!=claimed: raise SystemExit('REFUSED_MANIFEST_ROOT')
    expected={row['path']:row for row in manifest['members']}
    actual_paths=sorted(p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.name!='PACKAGE-MANIFEST.json')
    if sorted(expected)!=actual_paths: raise SystemExit('REFUSED_MEMBER_SET')
    for rel,row in expected.items():
        p=root.joinpath(*PurePosixPath(rel).parts)
        if p.stat().st_size!=row['length'] or sha_file(p)!=row['sha256']:
            raise SystemExit('REFUSED_MEMBER_IDENTITY:'+rel)
    receipt=json.loads((root/'M0-RECEIPT.json').read_text(encoding='utf-8'))
    if receipt['standing']!='INFORMATION_ONLY' or receipt['authority_effect']!='NONE' or receipt['real_a5'] is not False or receipt['g0']!='CLOSED':
        raise SystemExit('REFUSED_AUTHORITY_POSTURE')
    if any(row['status']!='UNBOUND' for row in receipt['role_bindings']):
        raise SystemExit('REFUSED_BOUND_ROLE')
    print(json.dumps({'status':'PASS','manifest_root':claimed,'members':len(expected),'standing':'INFORMATION_ONLY','authority_effect':'NONE','real_a5':False,'g0':'CLOSED'},sort_keys=True))

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--root'); ap.add_argument('--archive'); ap.add_argument('--sha256')
    a=ap.parse_args()
    if bool(a.root)==bool(a.archive): raise SystemExit('choose exactly one of --root or --archive')
    if a.root: verify(Path(a.root).resolve()); return
    archive=Path(a.archive).resolve()
    if not a.sha256 or sha_file(archive)!=a.sha256.lower(): raise SystemExit('REFUSED_ARCHIVE_IDENTITY')
    with tempfile.TemporaryDirectory(prefix='m0-verify-') as td:
        root=Path(td); safe_extract(archive,root); verify(root)
if __name__=='__main__': main()
