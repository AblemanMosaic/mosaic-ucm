# Recommended M1 plan

1. Decide the Foundation binding shape: either accept the ordered five-layer lineage or build and independently review a consolidated current Foundation archive.
2. Prove the selected Foundation-to-Genesis correspondence; do not bind the older Reference Genesis package by filename alone.
3. Select one exact target profile. Prefer the Raspberry Pi 4 Model B 2GB only if the Governor intends the already-prepared serial-first physical court.
4. Keep UCM AGENTIC_ENVIRONMENT on the host side. Define a rooted correspondence adapter to native MosaiCOS requests, receipts, custody, and rollback without Python entering the trusted guest path.
5. For Ethernet, first close the typed isolated RX-provider gap in a no-external-network court, or define a separate Pi provider after serial identity calibration. Do not treat the existing TX/ABI/court set as an adapter.
6. Produce a new M1 packet with all four role identities still proposal-only until independent review and explicit Governor binding.

M1 must not infer real target selection, network authority, standing, A5, or G0 opening from this M0 packet.
